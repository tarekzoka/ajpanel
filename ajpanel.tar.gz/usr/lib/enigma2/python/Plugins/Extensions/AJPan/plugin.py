import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, split as iSplit
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from re       import IGNORECASE
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime, timedelta
from collections    import Counter as iCounter
from base64      import b64encode, b64decode
from sys      import version_info as pyVersion
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS, SCOPE_FONTS
from Tools.Directories   import SCOPE_CURRENT_SKIN
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction as BF
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.NimManager  import nimmanager
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, addFont, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigSelectionNumber
from Components.config   import ConfigSubList, ConfigInteger
try:  import tarfile as iTar
except: iTar = None
try:  import zipfile as iZip
except: iZip = None
try: from xml.etree import ElementTree as iElem
except: iElem = None
try: from shutil import move as iMove, copyfile as iCopyfile, copymode as iCopymode
except: iMove = iCopyfile = iCopymode = None
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVAnTo   = "v8.8.7"
VVx5h4    = "17-07-2023"
EASY_MODE    = 0
VVKhlF   = 0
VVuRvO   = 0
VVFTYs  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVbd2l  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VV17ob   = "AJPan"
VVAHuZ  = "AUTO FIND"
VVcyVF  = "Custom"
VVYfYu    = "/media/usb/"
VVcNJx    = "/usr/share/enigma2/picon/"
VVTAUs   = "/etc/enigma2/"
VVrs06   = VVTAUs + "settings"
VVz9hY = VVTAUs + "blacklist"
VVvj6M  = None
VVEith    = ""
VVSkqN = "Regular"
VVF3qC = "Fixed"
VV4sBs  = "AJP_Main"
VV7l55 = "AJP_Terminal"
VVOg8O = "AJP_System"
VVXtOH  = VVSkqN
VVBcOf    = ""
VVWwsK   = " && echo 'Successful' || echo 'Failed!'"
VV7GSC  = "Cannot continue (No Enough Memory) !"
VVoWXg  = ["#119f1313","#11005500","#11a08000","#1118188b"]
VVjUqm    = ["KeyMap_RC", "KeyMap_KeyBoard"]
VVImSj  = "utf8"
VVpTvr    = ("-" * 100, )
SEP      = "-" * 80
VVPdMM  = False
VVncAm  = False
VVL1I3     = 0
VV8Fcs    = 1
VV2ZP4    = 2
VVnHWM   = 3
VVzzat    = 4
VV8Fi7    = 5
VVjziV = 6
VVBwm7 = 7
VVECGg  = 8
VVPpdF   = 9
VVAIje  = 10
VVikgj  = 11
VV2FRr = 12
VV1MVU = 13
VV6hMT = 14
VVkay5  = 15
VVolcU    = 16
VVh24A   = 17
VVdDCi   = 18
VV5gWf    = 19
VVQdy0    = 20
VVMPlG  = 21
VV1bnu    = 22
VVdcIX   = 0
VVnCos   = 1
VVkqNa   = 2
def FFZgh7():
 lst = []
 try:
  from enigma import getFontFaces
  lst = sorted(set(getFontFaces()))
 except:
  try:
   from skin import getFontFaces
   lst = sorted(set(getFontFaces()))
  except:
   pass
 if lst:
  global VVXtOH
  if VV4sBs in lst and CFG.fontPathMain.getValue(): VVXtOH = VV4sBs
  else               : VVXtOH = VVSkqN
  return lst
 else:
  return [VVSkqN]
def FF51vv(path, alias, scale=100, isRepl=0):
 try:
  addFont(path, alias, scale, isRepl)
  return True
 except:
  try:
   addFont(path, alias, scale, isRepl, 0)
   return True
  except:
   pass
 return False
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices=[("v", "Virtual Keyboard"),("s", "System Default")])
CFG.FileManagerExit    = ConfigSelection(default="d", choices=[("d", "Directory Up"),("e", "Exit")])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices=[("off", "Disable"),("lok", "Long-OK"),("lesc", "Long-Exit"),("lred", "Long-Red")])
CFG.subtDefaultEnc    = ConfigDirectory(default=VVImSj)
CFG.screenshotFType    = ConfigSelection(default="jpg", choices=[("off", "Disable"),("jpg", "JPG"),("png", "PNG"),("bmp", "BMP")])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices=[("1", "1 (DVB Stream)"),("4097", "4097 (servicemp3)"),("5001", "5001 (GST Player)"),("5002", "5002 (Ext-3 EPlayer)"),("8192", "8192 (HDMI input)"),("8193", "8193 (eServiceUri)")])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=True)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsMode    = ConfigDirectory(default=VVAHuZ, visible_width=45)
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=45)
CFG.portalConnTimeout   = ConfigSelectionNumber(default=2, stepwidth=1, min=1, max=5, wraparound=False)
CFG.PIconsPath     = ConfigDirectory(default=VVcNJx, visible_width=45)
CFG.backupPath     = ConfigDirectory(default=VVYfYu, visible_width=45)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.iptvHostsDirs    = ConfigText(default="")
CFG.favServerPlaylist   = ConfigText(default="")
CFG.favServerPortal    = ConfigText(default="")
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.browserSortMode    = ConfigInteger(default=0, limits=(0, 5))
CFG.browserSortMix    = ConfigYesNo(default=False)
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
CFG.downloadMonitor    = ConfigYesNo(default=False)
CFG.lastTerminalCustCmdLineNum = ConfigInteger(default=0)
CFG.lastSharePickerDvbRow  = ConfigInteger(default=0)
CFG.lastSharePickerIptvRow  = ConfigInteger(default=0)
CFG.lastFileManFindPatt   = ConfigText(default="")
CFG.lastFileManFindSrt   = ConfigText(default="/media/")
CFG.lastPkgProjDir    = ConfigText(default="/media/")
CFG.lastFindTerminal   = ConfigText(default="")
CFG.lastFindServers    = ConfigText(default="")
CFG.lastFindIptv    = ConfigText(default="")
CFG.lastFindMovie    = ConfigText(default="")
CFG.lastFindSubtitle   = ConfigText(default="")
CFG.lastFindPackages   = ConfigText(default="")
CFG.lastFindServices   = ConfigText(default="")
CFG.lastFindSatName    = ConfigText(default="")
CFG.lastFindContextFind   = ConfigText(default="")
CFG.lastFindEditor    = ConfigText(default="")
CFG.lastFindGeneral    = ConfigText(default="")
CFG.lastFindRepl_fnd   = ConfigText(default="")
CFG.lastFindRepl_rpl   = ConfigText(default="")
CFG.fontPathMain    = ConfigText(default="")
CFG.fontPathTerm    = ConfigText(default="")
CFG.fontPathSys     = ConfigText(default="")
CFG.transpColorPicons   = ConfigText(default="#11404040")
CFG.transpColorPosters   = ConfigText(default="#11404040")
CFG.transpColorMovies   = ConfigText(default="#11404040")
CFG.transpColorChannels   = ConfigText(default="#88004040")
CFG.epgLangTitle    = ConfigText(default="")
CFG.epgLangDescr    = ConfigText(default="")
CFG.lastFtpLocalPath   = ConfigText(default="")
CFG.lastNetworkDevice   = ConfigInteger(default=0)
CFG.terminalCmdFile    = ConfigText(default="LinuxCommands.lst")
tmp = [("srt","FROM SRT FILE"),("#00FFFF","Aqua"),("#000000","Black"),("#0000FF","Blue"),("#FF00FF","Fuchsia"),("#808080","Gray"),("#008000","Green"),("#00FF00","Lime"),("#800000","Maroon"),("#000080","Navy"),("#808000","Olive"),("#800080","Purple"),("#FF0000","Red"),("#C0C0C0","Silver"),("#008080","Teal"),("#FFFFFF","White"),("#FFFF00","Yellow")]
CFG.subtDelaySec    = ConfigSelectionNumber(default=0, stepwidth=1, min=-600, max=600, wraparound=False)
CFG.subtBGTransp    = ConfigSelectionNumber(default=100, stepwidth=10, min=0, max=100, wraparound=False)
CFG.subtTextFg     = ConfigSelection(default="#FFFFFF", choices=tmp)
CFG.subtTextFont    = ConfigSelection(default=VVXtOH, choices=[(x,  x) for x in FFZgh7()])
CFG.subtTextSize    = ConfigSelectionNumber(default=50, stepwidth=5, min=30, max=100, wraparound=False)
CFG.subtTextAlign    = ConfigSelection(default="1", choices=[("0", "Left"),("1", "Center"),("2", "Right")])
CFG.subtShadowColor    = ConfigSelection(default="#000080", choices=tmp[1:])
CFG.subtShadowSize    = ConfigSelectionNumber(default=5, stepwidth=1, min=0, max=10, wraparound=False)
CFG.subtVerticalPos    = ConfigSelectionNumber(default=90, stepwidth=1, min=0, max=100, wraparound=False)
del tmp
def FFaj2m():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVj6k2  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VVbUQu = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVj6k2  : return 0
  elif VVbUQu : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVICwr = FFaj2m()
VVHQpO = VVzv5p = VVfMEC = VVszO3 = VVtz60 = VVTKrH = VVCBLl = VVKcVb = VVXF4f = VVJS3b = VVRJhR = VV61JF = VVAaU5 = VVYqlh = VVMVIx = VViypC = ""
def FFFKFb()  : FFCmp6(FFqqQD())
def FFM7rz()  : FFCmp6(FFkEVe())
def FFiNYm(tDict): FFCmp6(iDumps(tDict, indent=4, sort_keys=True))
def FFVNDY(*args): FFOBB3(True, True, *args)
def FFCmp6(*args) : FFOBB3(True , False , *args)
def FFm3Q6(*args): FFOBB3(False, False, *args)
def FFOBB3(addSep=True, isArray=True, *args):
 if VVKhlF:
  sep = (">>>> %s\n" % ("#" * 80)) if addSep else ""
  txt = sep
  if isArray:
   for item in args:
    if isinstance(item, list) or isinstance(item, tuple):
     txt += ">>>> LIST START <--\n"
     for itm in item: txt += ".... %s\n" % str(itm)
     txt += ">>>> LIST END <--\n"
    elif isinstance(item, dict):
     txt += ">>>> LIST START <--\n"
     Len = 0
     for key, val in item.items(): Len = max(Len, len(str(key)))
     for key, val in item.items(): txt += ".... %s: %s\n" % (str(str(key).ljust(Len)), str(val))
     txt += ">>>> LIST END <--\n"
    else:
     txt += "---> %s\n" % str(item)
  else:
   cr = "\n" if addSep else ""
   txt += ">>>> %s%s" % (" , ".join(list(map(str, args))), cr)
  txt += sep.replace("#", "-")
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FFwknU(fnc):
 def VV2Oix(*args, **kwargs):
  t1 = iTime()
  fnc(*args, **kwargs)
  FFCmp6(">>>>>> Elapsed : %s sec\nargs = %s\nkwargs = %s" % (("%.6f" % (iTime() - t1)).rstrip("0"), args, kwargs))
 return VV2Oix
def FFJC0M(*args):
 if VVKhlF:
  path = "/tmp/ajp_log.txt"
  with open(path, "a") as f:
   f.write(">>>> %s\n" % (" , ".join(list(map(str, args)))))
  FFm3Q6("Added to : %s" % path)
def FFMvL6(txt, isAppend=True, ignoreErr=False):
 if VVKhlF:
  tm = FFI6AP()
  err = ""
  if not ignoreErr:
   err = FFkEVe()
  fileName = "/tmp/ajp_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFCmp6(err)
  FFCmp6("Output Log File : %s" % fileName)
def FFkEVe():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FFI6AP()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except:
  return "Cannot Trace !"
def FFqqQD():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VVn36h = 0
def FFKWqk():
 global VVn36h
 VVn36h = iTime()
def FFNXOK(txt=""):
 FFCmp6(">>>>>> Elapsed : %s sec\t%s" % (("%.6f" % (iTime() - VVn36h)).rstrip("0"), txt))
VVOmRd = []
def FFudBR(win):
 global VVOmRd
 if not win in VVOmRd:
  VVOmRd.append(win)
def FFsago(*args):
 global VVOmRd
 for win in VVOmRd:
  try:
   win.close()
  except:
   pass
 VVOmRd = []
def FFzMsA(vTxt):
 if vTxt in globals(): del globals()[vTxt]
def FFTzJT():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VV8rbD = FFTzJT()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FFP44B()    : return PluginDescriptor(fnc=FFPnua, where=[PluginDescriptor.WHERE_SESSIONSTART], needsRestart=True   , description="AJPanel Startup")
def FFYrpC()      : return getDescriptor(FFLq1o  , [ PluginDescriptor.WHERE_MENU   ] , PLUGIN_NAME     , descr="Main Menu")
def FF5Doq()     : return getDescriptor(FFSnvL   , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FFbYFF()  : return getDescriptor(FFAJp6 , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FF0pzC() : return getDescriptor(FFHSYE  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV Menu"   , descr="IPTV Menu")
def FF9qnr()  : return getDescriptor(FFkoEQ  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Player Bar"   , descr="Player Bar")
def FFjJb7(): return getDescriptor(FFuEO9, [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Plugin Browser"  , descr="Plugin Browser")
def FFfQkX()  : return getDescriptor(FFqgrK   , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal Monitor"  , descr="Signal Monitor")
def FFOdEo() : return getDescriptor(FFbdCL  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Terminal"    , descr="Terminal")
def FFWxuC()      : return getDescriptor(FFlX4B , [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Service Information" , descr="Service Info")
def Plugins(**kwargs):
 result = [ FF5Doq() , FFYrpC() , FFP44B() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFbYFF())
  result.append(FF0pzC())
  result.append(FF9qnr())
  result.append(FFjJb7())
  result.append(FFfQkX())
  result.append(FFOdEo())
 if CFG.EventsInfoMenu.getValue():
  result.append(FFWxuC())
 return result
def FFPnua(reason, **kwargs):
 if reason == 0:
  CCOtMo.VVK326()
  if "session" in kwargs:
   session = kwargs["session"]
   FFPk30(session)
   CCtMfQ(session)
def FFLq1o(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFSnvL, PLUGIN_NAME, 45)]
 else:
  return []
def FFSnvL(session, **kwargs):
 session.open(Main_Menu)
def FFAJp6(session, **kwargs) : session.open(CCUGPF)
def FFHSYE(session, **kwargs)  : session.open(CCfw0y)
def FFkoEQ(session, **kwargs)  : CCA3uT.VV1gQV(session)
def FFuEO9(session, **kwargs): CCG5tV.VVsjBg(session)
def FFqgrK(session, **kwargs)   : FFGuKK(session, reopen=True)
def FFbdCL(session, **kwargs)  : session.open(CC6CsJ)
def FFlX4B(session, **kwargs):
 session.open(CCoD37, fncMode=CCoD37.VVp0RA)
def FFxKxA():
 FFNUha(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [FFbYFF(), FF0pzC(), FF9qnr(), FFjJb7(), FFfQkX(), FFOdEo()])
 FFNUha(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FFWxuC() ])
def FFNUha(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
def FFPk30(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions["longOK"] = BF(FFnXZa, session, "lok")
 hk.actions["longCancel"]= BF(FFnXZa, session, "lesc")
 hk.actions["longRed"] = BF(FFnXZa, session, "lred")
 for k in (CCz5Bp.VVgKik, CCz5Bp.VVrFLy, CCz5Bp.VV5Fdw):
  hk.actions[k] = BF(CCz5Bp.VVcXnO, session, k)
def FFnXZa(session, key):
 if CFG.hotkey_signal.getValue() == key:
  try:
   if CCHHqE.VVy2vU:
    CCHHqE.VVy2vU.close()
   if not CCA3uT.VVGbd7:
    CCA3uT.VV1gQV(session)
  except:
   pass
def FF2tHk(confItem, val):
 confItem.setValue(val)
 confItem.save()
 configfile.save()
def FF32Yx(SELF, title="", addLabel=False, addScrollLabel=False, VVMVqr=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFcYIL()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF.VVcytU = eTimer()
 try: SELF.VVlick = SELF.VVcytU.timeout.connect(BF(FF7vgR, SELF))
 except: SELF.VVcytU.callback.append(BF(FF7vgR, SELF))
 SELF.onClose.append(SELF.VVcytU.stop)
 FF7vgR(SELF)
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCLLRm(SELF)
 if VVMVqr:
  SELF["myMenu"] = MenuList(VVMVqr)
  SELF["myActionMap"] = ActionMap(VVjUqm,
  {
   "ok" : SELF.VVthYm ,
   "cancel": SELF.close ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(VVjUqm,
  {
   "ok" : SELF.close,
   "cancel": SELF.close,
   "red" : SELF.close
  }, -1)
def FFwY39(SELF, tableObj, colNum=0, isMenu=False):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0" : BF(FFvTQK, SELF, "0"),
  "1" : BF(FFvTQK, SELF, "1"),
  "2" : BF(FFvTQK, SELF, "2"),
  "3" : BF(FFvTQK, SELF, "3"),
  "4" : BF(FFvTQK, SELF, "4"),
  "5" : BF(FFvTQK, SELF, "5"),
  "6" : BF(FFvTQK, SELF, "6"),
  "7" : BF(FFvTQK, SELF, "7"),
  "8" : BF(FFvTQK, SELF, "8"),
  "9" : BF(FFvTQK, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=BF(FFajQz, SELF, tableObj, colNum, isMenu))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFvTQK(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VViypC:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VViypC + SELF.keyPressed + VVzv5p)
    txt = VVzv5p + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFycel(SELF, txt)
def FFajQz(SELF, tableObj, colNum, isMenu):
 FFycel(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    if isMenu: item = tableObj.list[i][colNum].strip()
    else  : item = tableObj.list[i][colNum + 1][7].strip()
    item = FFQdrB(item).encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     if isMenu: SELF.VVT53N(i)
     else  : SELF.VV7qpv(i)
     break
 except:
  pass
def FFcYIL():
 return ("  %s" % VVBcOf)
def FFCDDm(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFQdrB(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFBCuC(color):
 return parseColor(color).argb()
def FFcdG1(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFzBm8(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFJHmx(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFC7pV(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VViypC)
 else:
  return ""
def FFxGY8(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, SEP, word, SEP, VViypC)
 else : return "echo -e '%s\n--- %s\n%s';" % (SEP, word, SEP)
def FFCzRx(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VViypC
def FFQHwo(color):
 if color: return "echo -e '%s' %s;" % (SEP, FFC7pV(SEP, VVRJhR))
 else : return "echo -e '%s';" % SEP
def FFLhxe(title, color):
 title = "%s\n%s\n%s\n" % (SEP, title, SEP)
 return FFCzRx(title, color)
def FFWzaz(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFA3Mq(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFA9HA(fncCB):
 tCons = CCG9Bk()
 tCons.ePopen(":", BF(FFKseN, fncCB))
def FFKseN(fncCB, result, retval):
 fncCB()
def FFzW1w(SELF, fnc, title="Processing ...", clearMsg=True):
 FFycel(SELF, title)
 tCons = CCG9Bk()
 tCons.ePopen(":", BF(FFnUJX, SELF, fnc, clearMsg))
def FFnUJX(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFycel(SELF)
def FFpCvy(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VV7GSC
  else       : return ""
def FFSInC(cmd):
 txt = FFpCvy(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FFwTnb(cmd):
 lines = FFSInC(cmd)
 if lines: return lines[0]
 else : return ""
def FFvJat(SELF, cmd):
 lines = FFSInC(cmd)
 VVpn2v = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVpn2v.append((key, val))
  elif line:
   VVpn2v.append((line, ""))
 if VVpn2v:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFldB6(SELF, None, header=header, VVWsIU=VVpn2v, VVv3Wm=widths, VVHZHw=28)
 else:
  FFH2jW(SELF, cmd)
def FFgSm7(cmd):
 return os.system(FFgeXp(cmd)) == 0
def FFErQ2(cmd):
 return os.system(FFdlNi(cmd)) == 0
def FFgeXp(cmd)  : return cmd.rstrip("\t; ") + " > /dev/null 2>&1;"
def FFdlNi(cmd) : return cmd.rstrip("\t; ") + " 2> /dev/null;"
def FFH2jW(    SELF, cmd, **kwargs): SELF.session.open(CCL7mk, VVEkBF=cmd, VVb2Gk=True, VVr0Wh=VVnCos, **kwargs)
def FFLde9(  SELF, cmd, **kwargs): SELF.session.open(CCL7mk, VVEkBF=cmd, **kwargs)
def FFK0Ik(   SELF, cmd, **kwargs): SELF.session.open(CCL7mk, VVEkBF=cmd, VVQYkQ=True, VV0NOL=True, VVr0Wh=VVnCos, **kwargs)
def FFr7wJ(  SELF, cmd, **kwargs): SELF.session.open(CCL7mk, VVEkBF=cmd, VVQYkQ=True, VV0NOL=True, VVr0Wh=VVkqNa, **kwargs)
def FFHguD(  SELF, cmd, **kwargs): SELF.session.open(CCL7mk, VVEkBF=cmd, VVlN16=True , **kwargs)
def FFeQKD(  session, cmd, **kwargs):      session.open(CCL7mk, VVEkBF=cmd, VVlN16=True , **kwargs)
def FFt7Dx( SELF, cmd, **kwargs): SELF.session.open(CCL7mk, VVEkBF=cmd, VViiZ9=True   , **kwargs)
def FFVT5b( SELF, cmd, **kwargs): SELF.session.open(CCL7mk, VVEkBF=cmd, VVJ04z=True  , **kwargs)
def FFlgKV(cmd):
 return FFgSm7("which %s" % cmd)
def FFNJvd():
 cmd = "if [ -f /etc/apt/apt.conf ]; then echo dpkg; else if [ -f /etc/opkg/opkg.conf ]; then echo opkg; else if which dpkg; then echo dpkg; else if which opkg; then echo opkg; else if which ipkg; then echo ipkg; else echo ''; fi; fi; fi; fi; fi"
 return FFwTnb(cmd)
def FFWdDQ(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
VV4pgO     = 0
VVjhlW      = 1
VVoElo   = 2
VVh9AH   = 3
VV3ArY      = 4
VVpVRu      = 5
VVFfRF     = 6
VVK0bx     = 7
VVLFdd     = 8
VV8F5p = 9
VVYC8S = 10
VVLn3s = 11
VVIAJ8  = 12
VVS3eG     = 13
VVzVlq  = 14
VVWN0E  = 15
def FF1dKx(parmNum, grepTxt):
 if   parmNum == VV4pgO  : param = ["update"   , "dpkg update"    ]
 elif parmNum == VVjhlW   : param = ["list"   , "apt list"    ]
 elif parmNum == VVoElo: param = ["list-installed" , "dpkg -l"     ]
 elif parmNum == VVh9AH: param = ["list-upgradable", "apt list --upgradable"]
 else         : param = []
 if param:
  pkg = FFNJvd()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FF4ZaS(parmNum, package):
 if   parmNum == VV3ArY      : param = ["info"      , "apt show"         ]
 elif parmNum == VVpVRu      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVFfRF     : param = ["search"      , "dpkg -S"          ]
 elif parmNum == VVK0bx     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VVLFdd     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VV8F5p : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VVYC8S : param = ["install --force-overwrite" , "dpkg -i --force-all"       ]
 elif parmNum == VVLn3s : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVIAJ8  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VVS3eG     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VVzVlq  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VVWN0E  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFNJvd()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFQ4w6():
 result = FFwTnb("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e 'GNU \"ar\" command not found!';"
  installCmd = FF4ZaS(VVLFdd, "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFgeXp("%s enigma2-plugin-extensions-opkg-tools" % installCmd)
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFgeXp("%s binutils" % installCmd)
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFC7pV(failed1, VVRJhR))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFC7pV(failed2, VVRJhR))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFC7pV(failed3, VVfMEC))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFkbwj(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FF4ZaS(VVLFdd , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFgeXp("%s %s" % (installCmd, toolPkgName))
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFC7pV(failed1, VVRJhR))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFC7pV(failed2, VVfMEC))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFpCvR(path, maxSize=-1, encLst=None):
 if   encLst is None    : encLst = CCscRA.VVZguv()
 elif isinstance(encLst, str) : encLst = [encLst]
 txt = ""
 for enc in encLst:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 if txt.startswith(chr(239) + chr(187) + chr(191)):
  txt = txt[3:]
 return txt
def FF2WPS(path, keepends=False, maxSize=-1, encLst=None):
 txt = FFpCvR(path, maxSize, encLst=encLst)
 return txt.splitlines(keepends)
def FFdD2h(SELF, path, encLst=None):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FFPLWs(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFpCvR(path, maxSize=maxSize, encLst=encLst)
  if lines: FFtybv(SELF, lines, title=title, VVr0Wh=VVnCos, width=1600, height=1000, titleFontSize=30)
  else : FFYO45(SELF, path, title=title)
 else:
  FFZ5Ys(SELF, path, title)
def FFGkYk(SELF, fName, title):
 path = VVLS8v + fName
 if fileExists(path):
  txt = FFpCvR(path)
  txt = txt.replace("#W#", VViypC)
  txt = txt.replace("#Y#", VV61JF)
  txt = txt.replace("#G#", VVzv5p)
  txt = txt.replace("#C#", VVAaU5)
  txt = txt.replace("#P#", VVtz60)
  FFtybv(SELF, txt, title=title)
 else:
  FFZ5Ys(SELF, path, title)
def FFDdst(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFIRGA(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FF5DjF(parent)
 else    : return FFZuCm(parent)
def FFZ5fy(path):
 return os.path.basename(os.path.normpath(path))
def FFRUn5(path):
 try:
  os.mkdir(path)
  return "" if pathExists(path) else "Cannot create dir !"
 except Exception as e:
  return str(e)
def FFPLWs(path):
 try:
  if os.path.islink(path)  : return os.lstat(path).st_size
  elif os.path.isfile(path): return os.path.getsize(path)
 except:
  pass
 return -1
def FF5Js2(path):
 path = FFZuCm(path)
 if   os.path.islink(path) : return "SymLink"
 elif os.path.ismount(path) : return "Mount"
 elif os.path.isfile(path) : return "File"
 elif os.path.isdir(path) : return "Directory"
 else      : return ""
def FFM9Wx(path):
 size = 0
 for Dir, dirs, files in os.walk(path):
  files = os.listdir(Dir)
  for f in files:
   fp = os.path.join(Dir, f)
   try:
    if os.path.islink(fp) : size += os.lstat(fp).st_size
    elif os.path.isfile(fp) : size += os.path.getsize(fp)
   except:
    pass
 return size
def FFTsWT(path):
 totDir = totFile = totLink = 0
 for Dir, dirs, files in os.walk(path):
  files = os.listdir(Dir)
  for f in files:
   fp = os.path.join(Dir, f)
   if os.path.islink(fp) : totLink += 1
   elif os.path.isfile(fp) : totFile += 1
   else     : totDir += 1
 return totDir, totFile, totLink
def FFnPMX(path):
 try: os.remove(path)
 except: pass
def FFElys(path):
 with open(path, "rb+") as f:
  try:
   f.seek(-1, 2)
   if ord(f.read(1)) not in (10, 13):
    f.write(b"\n")
  except:
   pass
def FFBjqc(path):
 return FFgSm7("chattr -AacDdijsStu '%s'; rm -fr '%s'" % (path, path))
def FFkECb(path):
 return FFgSm7("cp -f '%s' '%s.bak'" % (path, path))
def FF5DjF(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFZuCm(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFHqmS():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVFTYs)
 paths.append(VVFTYs.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFDdst(ba)
 for p in list:
  p = ba + p + VVFTYs
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VV17ob, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVFTYs, VV17ob , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VV0gUf, VVLS8v = FFHqmS()
def FFW4ra():
 def VVg0qg(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 oldMovieDownloadPath = ""
 if not pathExists(CFG.MovieDownloadPath.getValue()):
  for p in ("/media/hdd/movie/", "/media/usb/movie/", t, "/"):
   if pathExists(p):
    CFG.MovieDownloadPath.setValue(p)
    CFG.MovieDownloadPath.save()
    oldMovieDownloadPath = p
    break
 VVPW1s   = VVg0qg(CFG.backupPath, CCjmed.VVtwV0())
 VVbFLY   = VVg0qg(CFG.downloadedPackagesPath, t)
 VVq4Ff  = VVg0qg(CFG.exportedTablesPath, t)
 VVl562  = VVg0qg(CFG.exportedPIconsPath, t)
 VVt5gt   = VVg0qg(CFG.packageOutputPath, t)
 global VVYfYu
 VVYfYu = FF5DjF(CFG.backupPath.getValue())
 if VVPW1s or VVt5gt or VVbFLY or VVq4Ff or VVl562 or oldMovieDownloadPath:
  configfile.save()
 return VVPW1s, VVt5gt, VVbFLY, VVq4Ff, VVl562, oldMovieDownloadPath
def FF964d(path):
 path = FFZuCm(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFguuW(SELF, pathList, tarFileName, addTimeStamp=True):
 VVWsIU = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVWsIU.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVWsIU.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVWsIU.append(path)
 if not VVWsIU:
  FFzrXb(SELF, "Files not found!")
 elif not pathExists(VVYfYu):
  FFzrXb(SELF, "Path not found!\n\n%s" % VVYfYu)
 else:
  VVfkpo = FF5DjF(VVYfYu)
  tarFileName = "%s%s" % (VVfkpo, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FF4rM4())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVWsIU:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % SEP
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFC7pV(tarFileName, VVXF4f))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFC7pV(failed, VVXF4f))
  cmd += "fi;"
  cmd +=  sep
  FFLde9(SELF, cmd)
def FFDoNq(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FFUK2c(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FFUK2c(SELF["keyInfo"], "info")
def FFUK2c(barObj, fName):
 path = "%s%s%s" % (VVLS8v, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FFZbc3(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFjpbV(satNum)
  return satName
def FFjpbV(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFKMDj(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFZbc3(val)
  else  : sat = FFjpbV(val)
 return sat
def FFhPna(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFZbc3(num)
 except:
  pass
 return sat
def FFwRWu(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFmvpz(SELF, isFromSession=False, addInfoObj=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if not isFromSession: SELF = SELF.session
 service = SELF.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFw1kT(info, iServiceInformation.sServiceref)
   prov = FFw1kT(info, iServiceInformation.sProvider)
   state = str(FFw1kT(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FF3dcV(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")): refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFAE0u(refCode)
 if addInfoObj: return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info
 else   : return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFw1kT(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFp8oe(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFj4lz(refCode):
 info = FFWeAJ(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFUMuc(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns.upper()
def FF3dWJ(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFWeAJ(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVHa0D = eServiceCenter.getInstance()
  if VVHa0D:
   info = VVHa0D.info(service)
 return info
def FFrvm6(SELF, refCode, VViFts=True, checkParentalControl=False, isFromSession=False, fromPortalReplay=False):
 if "j.php" in refCode and "&end=:" in refCode:
  refCode1, decodedUrl, origUrl, iptvRef = FFAE0u(refCode)
  chName = decodedUrl[decodedUrl.index("&end=:") + 6:]
  pr = CCanC9()
  if pr.VVNFjN(refCode1, chName, decodedUrl, iptvRef):
   if pr.VVIERc(SELF, isFromSession):
    return
   else:
    fromPortalReplay = True
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(str(refCode))
  FFlT79(SELF, serviceRef, checkParentalControl, isFromSession, fromPortalReplay)
  if VViFts:
   FFwQ7y(SELF, isFromSession)
 try:
  VV8OMp = InfoBar.instance
  if VV8OMp:
   VV2NxO = VV8OMp.servicelist
   if VV2NxO:
    servRef = eServiceReference(refCode)
    VV2NxO.saveChannel(servRef)
 except:
  pass
def FFlT79(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPortalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPortalReplay:
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFmvpz(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCanC9()
    if pr.VVNFjN(refCode, chName, decodedUrl, iptvRef):
     pr.VVIERc(SELF, isFromSession)
def FF3dcV(refCode):
 return True if iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE) else False
def FFaD7A(ref):
 return "FROM BOUQUET " in ref.upper()
def FFYKlk(ref):
 if "chcm=" in ref.lower(): return False
 else      : return True if iSearch(r"https?([:]|%3a)\/\/(127.0.0.\d|0.0.0.0|192.168.\d.\d|localhost).+", ref, IGNORECASE) else False
def FFzo2Y(url): return FFkUBK(url) or FFtJft(url)
def FFkUBK(url) : return not "mode=itv" in url and any(x in url for x in ("/movie/", "/vod/", "/video/", ".m3u8", "mode=vod"))
def FFtJft(url): return any(x in url for x in ("/series/", "mode=series"))
def FFAE0u(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith(("%3a", "%3A")):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFKkPs(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFKkPs(url):
 if url and iUnquote : return iUnquote(url)
 else    : return url
def FF6XZy(url):
 if url and iQuote : return iQuote(url)
 else    : return url
def FFxHdY(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFmDiU(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFgeok(txt):
 try:
  return FFxHdY(FFmDiU(txt)) == txt
 except:
  return False
def FFY7QR(path, patt):
 if "[" in path or "]" in path:
  newPath = ""
  for char in path:
   if   char == "[": char = "[[]"
   elif char == "]": char = "[]]"
   newPath += char
 else:
  newPath = path
 return iGlob("%s%s" % (FF5DjF(newPath), patt))
def FFwQ7y(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFmvpz(SELF, isFromSession=isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not FFaD7A(servPath):
   isForPlayer = True
 if iptvRef or isForPlayer: CCA3uT.VV1gQV(session)
 else      : FFGuKK(session, reopen=True)
def FFGuKK(session, reopen=False):
 if reopen:
  try:
   session.openWithCallback(BF(FFGuKK, session), CCHHqE)
  except:
   try:
    FFBAQq(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFEEqJ(refCode):
 tp = CC9Nee()
 if tp.VVnM6L(refCode) : return True
 else        : return False
def FF33MI(refCode, isHide, skipReload=False):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if skipReload:
     return True if ret == 0 else False
    elif ret == 0:
     FFwQUx(True)
     return True
 return False
def FFwQUx(save=False):
 db = eDVBDB.getInstance()
 if db:
  if save:
   db.saveServicelist()
  db.reloadServicelist()
  db.reloadBouquets()
 FFhqUe()
def FFhqUe():
 VV8OMp = InfoBar.instance
 if VV8OMp:
  VV2NxO = VV8OMp.servicelist
  if VV2NxO:
   VV2NxO.setMode()
def FFwksx(root, mode=0):
 lst = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVHa0D = eServiceCenter.getInstance()
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    flags = service.flags
    if mode == 0 and service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    ref, info = service.toString(), VVHa0D.info(service)
    name = info.getName(service)
    if   mode == 0: lst.append((ref, name))
    elif mode == 1: lst.append((ref, name, flags))
 except:
  pass
 return lst
def FFs2e5():
 VVRXrA = {0x01:"TV MPEG-2 SD",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Custom",0x81:"Custom",0x82:"Custom",0x84:"Custom",0x95:"Custom",0x98:"Custom",0x9B:"Custom",0xAB:"Custom",0xB4:"Custom",0xB5:"Custom",0xC6:"Custom",0xFA:"Custom",0xFB:"Custom",0xFC:"Custom"}
 VV9tU5 = list(VVRXrA)
 return VV9tU5, VVRXrA
def FFZvbd():
 try:
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFAj3k(delta=0):
 Time = datetime.now() + timedelta(delta)
 midnight = Time.replace(hour=0, minute=0, second=0, microsecond=0)
 return mktime(midnight.timetuple())
def FFgCM6(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFhvWN():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FF4rM4():
 return FFhvWN().replace(" ", "_").replace("-", "").replace(":", "")
def FFRTnP(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFI6AP():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFOecp(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCfw0y.VVKCk4(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCfw0y.VV02WJ(fName)
     phpFile = tmpDir + fName + ext
     FFgSm7("mv -f '%s' '%s'" % (outFile, phpFile))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFSxn2(numStr):
 return iMatch(r"^([-+]?\d+(\.\d*)?$)", numStr) is not None
def FFoTxy(num):
 return "s" if num > 1 else ""
def FFrrt7(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFpM97(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
def FFCxZi(a, b):
 return (a > b) - (a < b)
def FFEzkZ(a, b):
 def VVfjO4(var):
  return [ (int(c) if c.isdigit() else c) for c in iSplit(r'(\d+)', var) ]
 a = VVfjO4(a)
 b = VVfjO4(b)
 return (a > b) - (a < b)
def FFkmXe(mycmp):
 class CCyILD(object):
  def __init__(self, obj, *args) : self.obj = obj
  def __lt__(self, other): return mycmp(self.obj, other.obj) < 0
  def __gt__(self, other): return mycmp(self.obj, other.obj) > 0
  def __eq__(self, other): return mycmp(self.obj, other.obj) == 0
  def __le__(self, other): return mycmp(self.obj, other.obj) <= 0
  def __ge__(self, other): return mycmp(self.obj, other.obj) >= 0
  def __ne__(self, other): return mycmp(self.obj, other.obj) != 0
 return CCyILD
def FFuXZg(SELF, message, title="", VVEStC=None):
 SELF.session.openWithCallback(VVEStC, CCVjNB, title=title, message=message, VVoDLt=True)
def FFtybv(SELF, message, title="", VVr0Wh=VVnCos, VVEStC=None, **kwargs):
 SELF.session.openWithCallback(VVEStC, CCVjNB, title=title, message=message, VVr0Wh=VVr0Wh, **kwargs)
def FFKRQG(SELF, txt):
 SELF.session.open(CC8r03, txt)
def FFzrXb(SELF, message, title="")  : FFBAQq(SELF.session, message, title)
def FFZ5Ys(SELF, path, title="") : FFBAQq(SELF.session, "File not found !\n\n%s" % path, title)
def FFYO45(SELF, path, title="") : FFBAQq(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFV7xB(SELF, title="")  : FFBAQq(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFBAQq(session, message, title="") : session.open(BF(CC2lJb, title=title, message=message))
def FFBgSg(SELF, VVEStC, title="", defaultText="", message=""):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVEStC, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVEStC, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFzrXb(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFo4dm(SELF, callBack_Yes, VV66pG, callBack_No=None, title="", VVxcAw=False, VVDfmh=True, isFromExternal=False):
 session = SELF if isFromExternal else SELF.session
 return session.openWithCallback(BF(FFYUbP, callBack_Yes, callBack_No)
         , BF(CCTEY0, title=title, VV66pG=VV66pG, VVDfmh=VVDfmh, VVxcAw=VVxcAw))
def FFYUbP(callBack_Yes, callBack_No, FFo4dmed):
 if FFo4dmed : callBack_Yes()
 elif callBack_No: callBack_No()
def FFycel(SELF, txt="", timeout=0, isGrn=False):
 if len(txt) > 0:
  try:
   if isGrn: FFzBm8(SELF["myInfoBody"], "#00004040")
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   SELF["myInfoBody"].setText(str(txt))
   if timeout > 0: SELF.VVcytU.start(timeout, True)
  except: pass
 else: FF7vgR(SELF)
def FFhcEU(*kargs, **kwargs):
 FFA9HA(BF(FFycel, *kargs, **kwargs))
def FF7vgR(SELF):
 try:
  SELF.VVcytU.stop()
  SELF["myInfoFrame"].hide()
  SELF["myInfoBody"].hide()
 except:
  pass
def FFA72r(SELF):
 try: return SELF["myInfoBody"].visible
 except: return False
def FFldB6(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, BF(CCYFn3, **kwargs))
  else   : win = SELF.session.open(BF(CCYFn3, **kwargs))
  FFudBR(win)
  return win
 except:
  return None
def FF7ARM(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, BF(CCYGgB, **kwargs))
 FFudBR(win)
 return win
def FFfdOi(txt):
 return ("--[ %s ]%s" % (txt,  "-" * 100), )
def FFwLFH(txt, ref, cond, color=""):
 return (color + txt, ref) if cond else (txt,)
def FFp5JP(SELF, **kwargs):
 SELF.session.open(CCoD37, **kwargs)
def FFieY3(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   FFAF2D(SELF[name], "#000000", 3)
  except:
   pass
def FFAF2D(label, color, w):
 try:
  inst = label.instance
  inst.setBorderColor(parseColor(color))
  inst.setBorderWidth(w)
 except:
  pass
def FFNoWz(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVXtOH, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FF0pG3(SELF, menuObj=None, minRows=0):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFNoWz(SELF, menuObj)
 winInst  = SELF.instance
 menuInst = menuObj.instance
 maxH = SELF.skinParam["height"]
 winW = winInst.size().width()
 winH = winInst.size().height()
 menuW = menuInst.size().width()
 menuH = menuInst.size().height()
 lineH = menuObj.l.getItemSize().height()
 menuH1 = (max(minRows, len(menuObj.list))) * lineH
 diff = menuH1 - menuH
 winNewH = winH + diff
 btnDiff = diff
 if winNewH > winH:
  if winH + lineH <= maxH:
   btnDiff = lineH
   menuH = menuH + lineH
   menuInst.resize(eSize(*(menuW, menuH)))
   winInst.resize(eSize(*(winW, winH + lineH)))
  else:
   btnDiff = 0
  pos  = menuObj.getPosition()
  part = menuInst.size().height() % lineH
  half = int(part / 2)
  menuInst.resize(eSize(*(menuW, menuH - part)))
  menuInst.move(ePoint(pos[0], pos[1] + half))
 else:
  menuInst.resize(eSize(*(menuW, menuH + diff)))
  winInst.resize(eSize(*(winW, winNewH)))
 winH = winInst.size().height()
 screenSize = getDesktop(0).size()
 winInst.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winH) // 2))
 names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
 for name in names:
  try:
   obj = SELF[name]
   pos = obj.getPosition()
   obj.instance.move(ePoint(pos[0], pos[1] + btnDiff))
  except:
   pass
 winSize = winInst.size()
 FFRlMK(SELF, winSize.width(), winSize.height())
def FFRlMK(SELF, w, h):
 fSize = SELF["myInfoFrame"].instance.size()
 bSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((w - fSize.width()) // 2, (h - fSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((w - bSize.width()) // 2, (h - bSize.height()) // 2))
def FFM4r3():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFsu0Y(VVHZHw):
 screenSize  = FFM4r3()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVHZHw)
 return bodyFontSize
def FFYyT1(VVHZHw, extraSpace):
 font = gFont(VVXtOH, VVHZHw)
 VVjcdW = fontRenderClass.getInstance().getLineHeight(font) or (VVHZHw * 1.25)
 return int(VVjcdW + VVjcdW * extraSpace)
def FF5TEn(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, vSliderW=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1, titleSep=True, menuLabel=0, morePar={}):
 screenSize = FFM4r3()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 extraPar  = None
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 vSliderW  = int(ratioW  * vSliderW)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * 15)
 bodyFontStr  = 'font="%s;%d"' % (VVXtOH, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFYyT1(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 if titleSep:
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0" size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb"  %s />' % (width, titleH, titleColor, VVXtOH, titleFontSize, alignLeftCenter)
 if winType == VV1bnu:
  pass
 elif winType in (VVL1I3, VV8Fcs):
  if winType == VV8Fcs : menuName = "config"
  else      : menuName = "myMenu"
  menuW = bodyW - int(bodyW * menuLabel / 100.0) - marginLeft if menuLabel else bodyW
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, menuW, bodyH, bodyColor, bodyLineH)
  if menuLabel:
   param = 'backgroundColor="%s" foregroundColor="#ffffff" %s' % (bodyColor, bodyFontStr)
   x, w, gap = menuW + marginLeft * 2, bodyW - menuW - marginLeft, int(marginLeft / 2.0)
   tmp += '<widget name="myLabelFrm" position="%d,%d" size="%d,%d" zPosition="3" %s />' % (x - gap, bodyTop, w + gap * 2, bodyH, param)
   tmp += '<widget name="myLabelTit" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (x, bodyTop + 10, w, titleH, alignCenter, param)
   tmp += '<widget name="myLabelTxt" position="%d,%d" size="%d,%d" zPosition="4" noWrap="1" %s %s />' % (x, bodyTop + titleH + gap , w, bodyH - titleH - gap * 2, alignLeftCenter, param)
 elif winType == VVMPlG:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignCenter)
 elif winType == VVQdy0:
  names = ("Red", "Green", "Yellow", "Blue")
  colors = [ "#229f1313", "#22005500", "#22a08000", "#2218188b"]
  totBtns = len(names)
  gap  = 5
  btnW = int(width * 0.09)
  btnH = int(titleH * 0.7)
  left = width - btnW - titleH * 2
  top  = int((titleH - btnH) / 2.0)
  fSize = int(0.45  * titleH)
  for i in range(totBtns-1, -1, -1):
   tmp += '<widget name="key%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" backgroundColor="%s" %s />' % (names[i], left, top, btnW, btnH, VVXtOH, fSize, colors[i], alignCenter)
   left -= (btnW + gap)
  names = ("Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos")
  totBtns = len(names)
  btnW = int((width - gap * (totBtns + 1)) / totBtns)
  btnH = titleH
  left = gap
  param = 'size="%d,%d" zPosition="3" backgroundColor="#33222222" %s %s ' % (btnW, btnH, bodyFontStr, alignCenter)
  for i in range(totBtns):
   tmp += '<widget name="mySubt%s"  position="%d,%d" foregroundColor="#00cccccc" %s />' % (names[i], left, titleH + gap  , param)
   tmp += '<widget name="mySubt%s1" position="%d,%d" foregroundColor="#00ffff88" %s />' % (names[i], left, titleH + btnH + 1, param)
   left += btnW + gap
  tmp += '<widget name="mySubtCursor" position="0,%d" size="%d,%d" zPosition="2" backgroundColor="#00ffff00" />' % (titleH + 1, btnW + gap * 2, btnH * 2 + gap - 1)
  top = titleH + 1 + btnH * 2 + gap
  tmp += '<widget name="mySubtCover" position="0,0" size="%d,%d" zPosition="5" backgroundColor="#ff000000" />' % (width, top - 1)
  tmp += '<widget name="mySubtFr" position="0,%d" size="%d,%d" zPosition="3" backgroundColor="#ff002233" />' % (top, width, height - top)
  for i in range(4):
   tmp += '<widget name="mySubtSep%d" position="1,%d" size="%d,1" zPosition="7" backgroundColor="#00555555" />' % (i, top + 1, width - 2)
   if i < 3:
    tmp += '<widget name="mySubt%d" position="1,%d" size="%d,%d" zPosition="6" noWrap="1" backgroundColor="#00000000" %s %s />' % (i, top + 1, width - 2, titleH - 2, bodyFontStr, alignCenter)
   top += titleH
 elif winType == VVolcU:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  picW = int(bodyW * 0.07)
  barW = bodyW - picW - marginLeft
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(barW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = barW - timeW + marginLeft
  b2Left3 = b2Left4 - marginLeft - timeW
  pLeft = width - picW - marginLeft
  FFuXZgL = b2Left2 + timeW + marginLeft
  FFuXZgW = b2Left3 - marginLeft - FFuXZgL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, barW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06445566" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s' % (bodyColor, bodyFontStr)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" %s />' % (name, b2Left1, b2Top, timeW, barH, param, alignLeftCenter)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" %s />' % (name, b2Left2, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" %s />' % (name, FFuXZgL , b2Top, FFuXZgW , barH, param, alignCenter)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" %s />' % (name, b2Left3, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" %s />' % (name, b2Left4, b2Top, timeW, barH, param, alignRightCenter)
  sepTop = int(b3Top - marginTop / 2.0)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (sepTop, pLeft)
  color = ["#0a004400", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((barW - marginLeft * (Len - 1)) / Len)
  left = marginLeft
  for i in range(9):
   if i in (0, Len-1) : bg = 'foregroundColor="#00FFFFFF" backgroundColor="%s"' % color[i]
   else     : bg = 'foregroundColor="%s"'        % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  pTop = titleH + 6
  pW  = width - pLeft - 8
  pH  = height - pTop - 4
  tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00333333" />' % (pLeft, titleH + 2, height - titleH + 1)
  tmp += '<widget name="myPlayPic" position="%d,%d" size="%d,%d" zPosition="1" alphatest="blend" />' % (pLeft + 4, pTop, pW, pH)
  tmp += '<widget name="myPlayTyp" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#1100202a" %s %s />' % (pLeft + 4, pTop, pW, pH, alignCenter, bodyFontStr)
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  tmp += '<widget name="myPlayRpt" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  params = 'zPosition="10" backgroundColor="#11444411"'
  tmp += '<eLabel %s position="0,0"  size="%d,1" />' % (params, width)
  tmp += '<eLabel %s position="0,%d" size="%d,1" />' % (params, height - 1, width)
  tmp += '<eLabel %s position="0,0"  size="1,%d" />' % (params, height)
  tmp += '<eLabel %s position="%d,0" size="1,%d" />' % (params, width - 1, height -1)
 elif winType == VVh24A:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVzzat:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VV2ZP4:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVnHWM:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  tmp += '<widget name="curTime" position="0,%d" size="%d,%d" zPosition="2" foregroundColor="white" transparent="1" %s %s />' % (titleH + 1, width, titleTop - titleH - 2, bodyFontStr, alignCenter)
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVXtOH, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVXtOH, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVAIje:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVXtOH, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVdDCi:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVXtOH, fontH, alignCenter)
 elif winType in (VVikgj, VV2FRr, VV1MVU, VV6hMT, VVkay5):
  if   winType == VVikgj  : totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.75, 0.25, int(width * 0.45), int(width * 0.55), CFG.transpColorPicons.getValue()
  elif winType == VV2FRr : totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorPosters.getValue()
  elif winType == VV1MVU : totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorMovies.getValue()
  elif winType == VV6hMT : totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.80, 0.20, int(width * 0.80), int(width * 0.20), CFG.transpColorChannels.getValue()
  else          : totRows, totCols, picR, lblR, w1, w2, transpBG = 4, 5, 0.65, 0.35, int(width * 0.85), int(width * 0.15), ""
  infT = titleH + 2
  infH = int(titleH * 1.8)
  boxT = infT + infH + marginTop + 2
  boxW = int((width - vSliderW - marginLeft * 2)  / totCols)
  boxH = int((height - barHeight - boxT - marginTop * 2) / totRows)
  extraPar = marginLeft, boxT, boxW, boxH
  s = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" foregroundColor="%s" noWrap="1" backgroundColor="%s" font="%s;%d" %s />'
  h = int(infH * 0.3333)
  y = infT + 1
  fg= "#00ffffff"
  if winType == VVikgj:
   fntSz, bg = int(h * 0.7), ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
   for i in range(3):
    tmp += s % (i  , 0   , y, w1, h, fg, bg[i]  , VVXtOH, fntSz, alignLeftCenter)
    tmp += s % (i+3, w1+1, y, w2, h, fg, bg[i+3], VVXtOH, fntSz, alignLeftCenter)
    y += h
  else:
   h1, h2 = int(infH * 0.60), int(infH * 0.40)
   tmp += s % (0, 0, y  , w1, h1 , "#0088ff88", "#00333333", VVXtOH, int(h1 * 0.7), alignLeftCenter)
   tmp += s % (1, 0, y + h1, w1, h2 , "#00aaaaaa", "#002a2a2a", VVXtOH, int(h2 * 0.7), alignLeftCenter)
   h, fntSz, bg = int(infH * 0.50), int(bodyFontSize * 0.52), "#33001111"
   tmp += s % (2, w1+1, y   , w2, h, fg, bg, VVXtOH, fntSz, alignCenter)
   tmp += s % (3, w1+1, y + h, w2, h, fg, bg, VVXtOH, fntSz, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a555500" />' % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  if morePar.get("grid", 0):
   y = boxT + boxH
   for i in range(totRows - 1):
    tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
    y += boxH
   x = boxW
   h = height - barHeight - boxT
   for i in range(totCols - 1):
    tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
    x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s"/>' % (marginLeft, boxT + marginTop, boxW, boxH, morePar.get("cursC", "#00ffff00"))
  picBgTr = 'transparent="1"' if morePar.get("picBgTr", 0) else ""
  lblTr = 'transparent="1"' if morePar.get("lblTr", 0) else ""
  lblC = morePar.get("lblC", "#00003333")
  gapX = morePar.get("gapX", 3)
  gapY = morePar.get("gapY", 3)
  midGap = morePar.get("mGap", 0)
  areaW = boxW - gapX * 2
  areaH = boxH - gapY * 2 - midGap
  picT = boxT + gapY
  picH = int(areaH * picR)
  lblH = int(areaH * lblR)
  lblT = boxT + gapY + picH + midGap
  lblFont = int(lblH * 0.65)
  transpBG = 'backgroundColor="%s"'% transpBG if transpBG else ""
  for row in range(totRows):
   left = marginLeft + gapX
   for col in range(totCols):
    tmp += '<widget name="myPosterRep%d%d" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (row, col, left, picT, areaW, picH, transpBG, picBgTr)
    tmp += '<widget name="myPosterPic%d%d" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (row, col, left, picT, areaW, picH)
    tmp += '<widget name="myPosterLbl%d%d" position="%d,%d" size="%d,%d" zPosition="6" backgroundColor="%s" noWrap="1" %s font="%s;%d" %s />' % (row, col, left, lblT, areaW, lblH, lblC, lblTr, VVXtOH, lblFont, alignCenter)
    left += boxW
   picT += boxH
   lblT += boxH
 elif winType == VV5gWf:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 elif winType == VV8Fi7:
  tmp += '<widget name="myPic" position="0,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (bodyTop, bodyW+3, bodyH+3)
 else:
  if   winType == VVBwm7 : align = alignLeftCenter
  elif winType == VVjziV : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVPpdF:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  fontName = VVXtOH
  if usefixedFont and winType == VVjziV:
   fLst = FFZgh7()
   if   VV7l55 in fLst and CFG.fontPathTerm.getValue(): fontName = VV7l55
   elif VVF3qC in fLst         : fontName = VVF3qC
  moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" font="%s;%d" %s ' % (bodyColor, fontName, bodyFontSize, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVHZHw = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVXtOH, VVHZHw, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVXtOH, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" noWrap="1" %s />' % (name[i], left, btnTop, btnW, btnH, VVoWXg[i], VVXtOH, barFont, alignCenter)
   left += btnW + gap
 if vSliderW:
  par = 'position="0,0" size="20,20"'
  tmp += '<widget name="mySbFrm" zPosition="13" %s />' % par
  tmp += '<widget name="mySbBak" zPosition="14" %s />' % par
  tmp += '<widget name="mySbSld" zPosition="15" %s />' % par
 if winType == VVjziV:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVoWXg[i], VVXtOH, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPicB" position="%d,%d" size="%d,%d" zPosition="13" backgroundColor="%s" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2, bodyColor)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="14" alphatest="blend" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap, "extraPar":extraPar}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF5TEn(VVL1I3, 800, 1000, 40, 50, 30, "#1a002244", "#10002233", 33, barHeight=40, topRightBtns=2)
  self.session  = session
  self.VV9nvX = ""
  self.themsList  = []
  self.Title   = "%s - %s" % (PLUGIN_NAME, VVAnTo)
  VVMVqr = []
  if VVuRvO:
   VVMVqr.append(("-- MY TEST --", "myTest" ))
  VVMVqr.append(("File Manager"  , "fMan" ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("IPTV"    , "iptv" ))
  VVMVqr.append(("Movies Browser" , "movie" ))
  VVMVqr.append(("Services/Channels", "chan" ))
  VVMVqr.append(("Bouquet Editor" , "bouq" ))
  VVMVqr.append(("PIcons"   , "picon" ))
  VVMVqr.append(("EPG"    , "epg"  ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Terminal"   , "term" ))
  VVMVqr.append(("SoftCam"   , "soft" ))
  VVMVqr.append(("Plugins"   , "plug" ))
  VVMVqr.append(("Backup & Restore" , "bakup" ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Date/Time"  , "date" ))
  VVMVqr.append(("Network"   , "net"  ))
  for ndx, item in enumerate(VVMVqr):
   item = list(item)
   item[0] = "  %s" % item[0]
   VVMVqr[ndx] = tuple(item)
  FF32Yx(self, title=self.Title, VVMVqr=VVMVqr)
  FFCDDm(self["keyRed"] , "Exit")
  FFCDDm(self["keyGreen"] , "Settings")
  FFCDDm(self["keyYellow"], "Dev. Info.")
  FFCDDm(self["keyBlue"] , "Color/Font")
  self["myActionMap"].actions.update({
   "red" : self.close       ,
   "green" : self.VVIy5J      ,
   "yellow": self.VVoUKX      ,
   "blue" : self.VVEi54     ,
   "info" : BF(FFzW1w, self, self.VVMone) ,
   "text" : self.VV7Im4      ,
   "menu" : self.VVStre    ,
   "0"  : BF(self.VVebYL, 0)   ,
   "1"  : BF(self.VVmouG, "fMan")   ,
   "2"  : BF(self.VVmouG, "iptv")   ,
   "3"  : BF(self.VVmouG, "movie")   ,
   "4"  : BF(self.VVmouG, "chan")   ,
   "5"  : BF(self.VVmouG, "bouq")   ,
   "6"  : BF(self.VVmouG, "picon")   ,
   "7"  : BF(self.VVmouG, "epg")   ,
   "8"  : BF(self.VVmouG, "term")   ,
   "9"  : BF(self.VVmouG, "soft")   ,
   "last" : BF(self.VVmouG, "plug")   ,
   "next" : BF(self.VVmouG, "bakup")
  })
  self.onShown.append(self.VVSDD3)
  self.onClose.append(self.onExit)
  global VVPdMM, VVncAm, VVwi7L
  VVPdMM = VVncAm = False
  VVwi7L = True
 def VVthYm(self):
  self.VVmouG(self["myMenu"].l.getCurrentSelection()[1])
 def VVmouG(self, item):
  if item is not None:
   for ndx, param in enumerate(self["myMenu"].list):
    if len(param) > 1 and param[1] == item:
     self["myMenu"].moveToIndex(ndx)
     break
   global VVBcOf
   VVBcOf = self["myMenu"].l.getCurrentSelection()[0].strip()
   if   item == "myTest" : self.VVi3ug()
   elif item == "fMan"  : self.session.open(CCUGPF)
   elif item == "iptv"  : self.session.open(CCfw0y)
   elif item == "movie" : FFzW1w(self, BF(CCEldE.VV4Pej, self))
   elif item == "chan"  : self.session.open(CCh3Pq)
   elif item == "bouq"  : self.session.open(CCPClU)
   elif item == "picon" : self.VVkMMJ()
   elif item == "epg"  : self.session.open(CCL7is)
   elif item == "term"  : self.session.open(CC6CsJ)
   elif item == "soft"  : self.session.open(CCk55e)
   elif item == "plug"  : self.session.open(CCvztK)
   elif item == "bakup" : self.session.open(CCASgz)
   elif item == "date"  : self.session.open(CCI94U)
   elif item == "net"  : self.session.open(CCNV6g)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  FFWzaz(self["myMenu"])
  FF0pG3(self)
  FFieY3(self)
  FFDoNq(self)
  VVPW1s, VVt5gt, VVbFLY, VVq4Ff, VVl562, oldMovieDownloadPath = FFW4ra()
  if VVPW1s or VVt5gt or VVbFLY or VVq4Ff or VVl562 or oldMovieDownloadPath:
   VVchnh = lambda path, subj: "%s:\n%s\n\n" % (subj, FFCzRx(path, VVszO3)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVchnh(VVPW1s   , "Backup/Restore Path"    )
   txt += VVchnh(VVt5gt  , "Created Package Files (IPK/DEB)" )
   txt += VVchnh(VVbFLY  , "Download Packages (from feeds)" )
   txt += VVchnh(VVq4Ff , "Exported Tables"     )
   txt += VVchnh(VVl562 , "Exported PIcons"     )
   txt += VVchnh(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FFtybv(self, txt, title="Settings Paths")
  self.VVVNyu()
  if (EASY_MODE or VVKhlF or VVuRvO):
   FFzBm8(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFycel(self, "Welcome", 300)
  FFA9HA(self.VVULdq)
 def VVULdq(self):
  if CFG.checkForUpdateAtStartup.getValue():
   curVer, webVer, url, isHigher, err = CCjmed.VVxRAl()
   if webVer and isHigher:
    self["myTitle"].setText("  %s (v%s available)" % (self.Title, webVer))
 def onExit(self):
  FFgSm7("rm -f /tmp/ajp_*")
  global VVPdMM, VVncAm
  VVPdMM = VVncAm = False
  FFzMsA("VVwi7L")
 def VVebYL(self, digit):
  self.VV9nvX += str(digit)
  ln = len(self.VV9nvX)
  global VVPdMM
  if ln == 4:
   if self.VV9nvX == "0" * ln:
    VVPdMM = True
    FFzBm8(self["myTitle"], "#11805040")
   else:
    self.VV9nvX = "x"
 def VV7Im4(self):
  self.VV9nvX += "t"
  if self.VV9nvX == "0" * 4 + "t" * 2:
   global VVncAm
   VVncAm = True
   FFzBm8(self["myTitle"], "#dd5588")
 def VVkMMJ(self):
  found = False
  pPath = CCxrlm.VVjBFN()
  if pathExists(pPath):
   for fName, fType in CCxrlm.VVVwfb(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCxrlm)
  else:
   VVMVqr = []
   VVMVqr.append(("PIcons Tools" , "CCxrlm" ))
   VVMVqr.append(VVpTvr)
   VVMVqr.append(CCxrlm.VV6haG())
   VVMVqr.append(VVpTvr)
   VVMVqr += CCxrlm.VVvOz2()
   FF7ARM(self, self.VVxiiK, VVMVqr=VVMVqr)
 def VVxiiK(self, item=None):
  if item:
   if   item == "CCxrlm"   : self.session.open(CCxrlm)
   elif item == "VV4loV"  : CCxrlm.VV4loV(self)
   elif item == "VVHmS7"  : CCxrlm.VVHmS7(self)
   elif item == "findPiconBrokenSymLinks" : CCxrlm.VVzMRY(self, True)
   elif item == "FindAllBrokenSymLinks" : CCxrlm.VVzMRY(self, False)
 def VVMone(self):
  changeLogFile = VVLS8v + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   lines  = FF2WPS(changeLogFile)
   for line in lines:
    line = line.strip()
    if line and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFCzRx("\n%s\n%s\n%s" % (SEP, line, SEP), VVRJhR, VViypC)
     elif line.strip().startswith("-"): line = "\n" + line
     elif line.strip().startswith(".."): line = FFCzRx(line, VVzv5p, VViypC)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFtybv(self, txt.strip(), title="%s %s  -  %s  - By AMAJamry" % (PLUGIN_NAME, VVAnTo, PLUGIN_DESCRIPTION), VVHZHw=28, width=1600, height=1000, VVLuY4="#11000011")
 def VVStre(self):
  VVMVqr = []
  VVMVqr.append(("%s Requirements" % PLUGIN_NAME, "libr"))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Keys Help"     , "hlp" ))
  FF7ARM(self, self.VVFLi0, VVMVqr=VVMVqr, width=650, title="Options")
 def VVFLi0(self, item=None):
  if item:
   if   item == "libr" : FFzW1w(self, BF(self.VVucvj))
   elif item == "hlp" : FFGkYk(self, "_help_main", "Main Page (Keys Help)")
 def VVIy5J(self) : self.session.open(CCjmed)
 def VVoUKX(self) : self.session.open(CCIdnp)
 def VVEi54(self):
  title = "Colors and Fonts"
  c1, c2, c3, c4 = VVJS3b, VVszO3, VV61JF, VVTKrH
  VVMVqr = []
  VVMVqr.append((c1 + "Change Title Colors"   , "title"  ))
  VVMVqr.append((c1 + "Change Menu Area Colors"  , "body"  ))
  VVMVqr.append((c1 + "Change Menu Pointer Colors" , "cursor"  ))
  VVMVqr.append((c1 + "Change Bottom Bar Colors" , "bar"   ))
  VVMVqr.append((c2 + "Reset Colors"    , "resetColor" ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append((c3 + "Change %s Font" % PLUGIN_NAME, "mainFont" ))
  VVMVqr.append((c3 + "Change Termianl Font"   , "termFont" ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append((c4 + "Change System Font"    , "sysFont"  ))
  FF7ARM(self, BF(self.VV1JNi, title), VVMVqr=VVMVqr, width=600, title=title)
 def VV1JNi(self, title, item=None):
  if item:
   if item in ("title", "body", "cursor", "bar"):
    tDict = self.VVvKsa()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(BF(self.VVY8Ky, tDict, item), CCFKE9, defFG=fg, defBG=bg)
   elif item == "resetColor" : FFo4dm(self, self.VVsVAN, "Reset to default colors ?", title=title)
   elif item == "mainFont"  : self.VV9wiM(VV4sBs  )
   elif item == "termFont"  : self.VV9wiM(VV7l55)
   elif item == "sysFont"  : self.VV9wiM(VVOg8O  )
 def VVucvj(self):
  title = "%s requirements (for some features)" % PLUGIN_NAME
  VVpn2v = self.VV2NV1()
  VVEXwE = ("Install", BF(self.VVsYuj, title)    , [])
  VVJvWF  = ("Update Sys. Packages", self.VVZCUj , [])
  header  = ("Library", "State", "Usage" )
  widths  = (20   , 25  , 55  )
  VViqYN = (LEFT  , CENTER , LEFT  )
  VVoLtS = FFldB6(self, None, title=title, header=header, VVWsIU=VVpn2v, VViqYN=VViqYN, VVv3Wm=widths, VVHZHw=28, width=1350, VVEXwE=VVEXwE, VVJvWF=VVJvWF, VVVU1s="#00ffffaa", VVcK1v=1)
 def VVsYuj(self, Title, VVoLtS, title, txt, colList):
  if "Not" in colList[1]:
   cbFnc = BF(self.VV0yzS, VVoLtS)
   pkgDict = self.VVigUs()
   pkg = colList[0]
   if   pkg == "requests" : CCGolS.VV1Ewa(self, cbFnc=cbFnc)
   elif pkg == "Imaging" : CCz5Bp.VVdbmR(self, Title, False, cbFnc=cbFnc)
   elif pkg == "ar"  : FFHguD(self, FFQ4w6(), VVFgpi=cbFnc, title=Title)
   elif pkg in pkgDict  : FFHguD(self, FFkbwj(pkgDict[pkg], pkg, pkg.capitalize()), VVFgpi=cbFnc, title=Title)
  else:
   FFycel(VVoLtS, "Already installed.", 700, isGrn=True)
 def VVZCUj(self, VVoLtS, title, txt, colList):
  CCvztK.VVgseP(self)
 def VV0yzS(self, VVoLtS):
  VVpn2v = self.VV2NV1()
  VVoLtS.VVlhah(VVpn2v[VVoLtS.VVqeSa()])
 def VV2NV1(self):
  tDict = {}
  path = VVLS8v + "_sup_lib"
  if fileExists(path):
   for line in FF2WPS(path):
    lib, eq, txt = line.partition("=")
    tDict[lib] = txt
  def VVchnh(lib, ok):
   txt = tDict.get(lib, "")
   if ok: return (lib, FFCzRx("Installed", VVXF4f), txt)
   else : return (lib, FFCzRx("Not installed", VVfMEC), txt)
  VVpn2v = []
  VVpn2v.append(VVchnh("requests", CCGolS.VV1Ewa(self, install=False)))
  VVpn2v.append(VVchnh("Imaging" , CCz5Bp.VVdbmR(self, "", False, install=False)))
  VVpn2v.append(VVchnh("ar"   , FFgSm7("if [[ \"$(ar -V 2> /dev/null | grep 'GNU ar')\" ]]; then exit 0; else exit 1; fi")))
  for pkg, cmd in self.VVigUs().items(): VVpn2v.append(VVchnh(pkg, FFlgKV(cmd)))
  VVpn2v.sort(key=lambda x: x[0].lower())
  return VVpn2v
 def VVigUs(self):
  d = {}
  for pkg in ("xz", "zip", "p7zip", "unrar", "bzip2", "ffmpeg"):
   d[pkg] = pkg
  d["p7zip"] = "7za"
  return d
 def VVt26C(self):
  return VVYfYu + "ajpanel_colors"
 def VVvKsa(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVt26C()
  if fileExists(p):
   txt = FFpCvR(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVY8Ky(self, tDict, item, fg, bg):
  if fg:
   self.VVBDCB(item, fg)
   self.VVSk4m(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VV5RCf(tDict)
 def VV5RCf(self, tDict):
   p = self.VVt26C()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVBDCB(self, item, fg):
  if   item == "title" : FFcdG1(self["myTitle"], fg)
  elif item == "body"  :
   FFcdG1(self["myMenu"], fg)
   FFcdG1(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   for item in ("myBar", "keyRed", "keyGreen", "keyYellow", "keyBlue"): FFcdG1(self[item], fg)
 def VVSk4m(self, item, bg):
  if   item == "title" : FFzBm8(self["myTitle"], bg)
  elif item == "body"  :
   FFzBm8(self["myMenu"], bg)
   FFzBm8(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFzBm8(self["myBar"], bg)
 def VVsVAN(self):
  FFgSm7("rm '%s'" % self.VVt26C())
  self.close()
 def VVVNyu(self):
  tDict = self.VVvKsa()
  for item in ("title", "body", "cursor", "bar"):
   self.VVnGen(tDict, item)
 def VVnGen(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVBDCB(name, fg)
  if bg: self.VVSk4m(name, bg)
 def VV9wiM(self, which):
  if   which == VV4sBs  : rest, defFnt, title = False, CFG.fontPathMain.getValue(), PLUGIN_NAME
  elif which == VV7l55 : rest, defFnt, title = False, CFG.fontPathTerm.getValue(), "Terminal "
  elif which == VVOg8O  : rest, defFnt, title = True , CFG.fontPathSys.getValue() , "System"
  CC51nM.VV2z8w(self, "Change %s Font" % title, defFnt, rest, BF(self.VV7Bei, which))
 def VV7Bei(self, which, path=None):
  if path:
   path = "" if path == "DEFAULT" else path
   if   which == VV4sBs  : FF2tHk(CFG.fontPathMain, path)
   elif which == VV7l55: FF2tHk(CFG.fontPathTerm, path)
   elif which == VVOg8O  : FF2tHk(CFG.fontPathSys , path)
   err = Main_Menu.VVmNVO(which)
   if err          : FFzrXb(self, err, title=title)
   elif which == VV4sBs   : self.close()
   elif which == VV7l55  : FFycel(self, "Terminal font applied", 1500, isGrn=True)
   elif which == VVOg8O and path: FFycel(self, "System font applied", 1500, isGrn=True)
   elif which == VVOg8O   : FFo4dm(self, BF(Main_Menu.VViiZ9, self), "Font changed (will take effect after GUI Restart).\n\nRestart GUI ?", title="Reset font to default")
 @staticmethod
 def VViiZ9(SELF):
  from Screens.Standby import TryQuitMainloop
  SELF.session.open(TryQuitMainloop, 3)
 @staticmethod
 def VVmNVO(name):
  if   name == VV4sBs : path, repl = CFG.fontPathMain.getValue(), 0
  elif name == VV7l55: path, repl = CFG.fontPathTerm.getValue(), 0
  elif name == VVOg8O : path, repl = CFG.fontPathSys.getValue() , 1
  if not path:
   FFZgh7()
   return ""
  elif not fileExists(path):
   return "Font file not found"
  nameLst = []
  if name == VVOg8O:
   nameLst = []
   for nm in FFZgh7():
    if not nm in (VV4sBs, VV7l55):
     nameLst.append(nm)
  else:
   nameLst = [name]
  totDone = 0
  for fntName in nameLst:
   if FF51vv(path, fntName, isRepl=repl):
    totDone += 1
  if totDone > 0: FFZgh7()
  else    : return "Could not add font"
 def VVi3ug(self):
  CCG5tV.VVsjBg(self.session)
class CCNV6g(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF5TEn(VVL1I3, 800, 950, 40, 50, 30, "#22300030", "#0a202020", 33)
  self.session  = session
  self.netEntryFile = "%s%s" % (VVYfYu, "ajpanel_network")
  c1, c2 = VV61JF, VVJS3b
  VVMVqr = []
  VVMVqr.append((c1 + "Network Devices"     , "dev" ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Network Scanner (ping)"    , "ping"))
  VVMVqr.append(("Port Scanner (scan for famous ports)" , "port"))
  VVMVqr.append(VVpTvr)
  VVMVqr.append((c2 + "Check Internet Connection"  , "intr"))
  FF32Yx(self, title="Network Tools", VVMVqr=VVMVqr)
  FF32Yx(self, VVMVqr=VVMVqr)
  self.onShown.append(self.VVSDD3)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  FFWzaz(self["myMenu"])
  FF0pG3(self)
 def VVthYm(self):
  global VVBcOf
  VVBcOf = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if   item == "dev" : FFzW1w(self, self.VVjy74, title="Reading Devices ...")
  elif item == "ping" : FFzW1w(self, self.VVhnjF, title="Scanning ...")
  elif item == "port" : CCYqD0.VVjZIs(self, self.VV8OLD, title="Select host to scan")
  elif item == "intr" : self.session.open(CCrWAJ)
 def VVjy74(self, canCencel=False):
  title = "Network Devices"
  VVpn2v = self.VV3CJ3()
  if VVpn2v:
   bg = "#0a223333"
   VVpn2v.sort(key=lambda x: x[0].lower())
   VVNYAK = BF(self.VV67LN, canCencel)
   VVd479  = ("Start FTP"   , self.VVG0Uc    , [])
   VV7J8f = ("Entry Options"  , self.VVeSbJ  , [])
   VVJvWF = ("Scan for Devices" , self.VV7WhA , [])
   header  = ("Num" , "IP-Address", "Username", "Password", "Default Path", "Remarks" )
   widths  = (7  , 25   , 19  , 19  , 0.01   , 30  )
   VViqYN = (CENTER , LEFT   , LEFT  , LEFT  , LEFT   , LEFT  )
   VVoLtS = FFldB6(self, None, title=title, header=header, VVWsIU=VVpn2v, VViqYN=VViqYN, width=1500, height=900, VVv3Wm=widths, VVHZHw=28, VVd479=VVd479, VVNYAK=VVNYAK, VV7J8f=VV7J8f, VVJvWF=VVJvWF
       , VVZYdg=bg, VVcwfs=bg, VVLuY4=bg, VVVU1s="#11ffff00", VVG27K="#11220000", VVQ9hc="#00333333", VVGpiI="#11400040")
   ndx = CFG.lastNetworkDevice.getValue()
   if isinstance(ndx, int):
    VVoLtS.VV7qpv(ndx)
  else:
   FFo4dm(self, BF(FFzW1w, self, BF(self.VVGy0t, canCencel=canCencel), title="Scanning ..."), "No devices found !\n\nScan network ?", callBack_No=BF(self.VV67LN, canCencel), title=title)
 def VVeSbJ(self, VVoLtS, title, txt, colList):
  VVMVqr = []
  VVMVqr.append(("Change Username"   , "user"))
  VVMVqr.append(("Change Password"   , "pass"))
  VVMVqr.append(("Change Remarks"   , "rem"))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Remove Selected Server" , "del"))
  FF7ARM(self, BF(self.VVCZVX, VVoLtS), VVMVqr=VVMVqr, title="Entry Options")
 def VVCZVX(self, VVoLtS, item=None):
  if item:
   if   item == "user" : self.VVNXSR("u", VVoLtS)
   elif item == "pass" : self.VVNXSR("p", VVoLtS)
   elif item == "rem" : self.VVNXSR("r", VVoLtS)
   elif item == "del" : FFo4dm(self, BF(FFzW1w, self, BF(self.VVjvH3, VVoLtS), title="Deleting ..."), "Continue ?", title="Delete Entry")
 def VV67LN(self, canCencel, VVoLtS=None):
  if VVoLtS: VVoLtS.cancel()
  if canCencel : self.close()
 def VVG0Uc(self, VVoLtS, title, txt, colList):
  num, ip, u, p, path, rem = colList
  entry = (ip, u, p, path, rem)
  FF2tHk(CFG.lastNetworkDevice, VVoLtS.VVqeSa())
  self.session.openWithCallback(BF(self.VVr5vS, entry, VVoLtS), CClmWE, entry)
 def VVr5vS(self, entry, VVoLtS, newPath=None):
  if newPath:
   ip, u, p, path, rem = entry
   if path != newPath:
    self.VVm7ZW("d", newPath, ip, u, p, path, rem)
    self.VVOy9Q(VVoLtS)
 def VV7WhA(self, VVoLtS, title, txt, colList):
  FFzW1w(VVoLtS, BF(self.VVGy0t, mainTableInst=VVoLtS), title="Scanning Network ...")
 def VVGy0t(self, canCencel=False, mainTableInst=None):
  title = "Network Devices"
  ftpLst, err = CCYqD0.VVAEik(CCYqD0.VVit3G)
  if err:
   FFzrXb(self, err, title=title)
   return
  telLst, err = CCYqD0.VVAEik(CCYqD0.VVMS66)
  if err:
   FFzrXb(self, err, title=title)
   return
  tLst = list(set(ftpLst + telLst))
  lst = []
  for item in tLst:
   typ = []
   if item in ftpLst: typ.append("FTP")
   if item in telLst: typ.append("Telnet")
   lst.append((item[0], item[1], " / ".join(typ)))
  ftpLst = telLst = tLst = None
  if lst:
   def VVxzxq(p1, p2): return FFEzkZ(p1[0], p2[0])
   lst.sort(key=FFkmXe(VVxzxq))
   bg = "#0a202020"
   VVNYAK = BF(self.VV67LN, canCencel)
   VVd479  = ("Add to Devices" , BF(self.VVexSx, mainTableInst, canCencel), [])
   header  = ("IP-Address" , "MAC-Address" , "Open Ports" )
   widths  = (40   , 34   , 26   )
   VViqYN = (LEFT   , CENTER  , CENTER  )
   FFldB6(self, None, title=title, header=header, VVWsIU=lst, VViqYN=VViqYN, VVv3Wm=widths, width=1200, VVHZHw=30, VVd479=VVd479, VVNYAK=VVNYAK, VVcK1v=2
     , VVZYdg=bg, VVcwfs=bg, VVLuY4=bg, VVG27K="#0a225555", VVGpiI="#11403040")
  else:
   FFzrXb(self, "No devices found !", title=title)
 def VVhnjF(self):
  title = 'Hosts that responded to "ping"'
  lst, err = CCYqD0.VVAEik(-1)
  if err:
   FFzrXb(self, err, title=title)
  elif lst:
   def VVxzxq(p1, p2): return FFEzkZ(p1[0], p2[0])
   lst.sort(key=FFkmXe(VVxzxq))
   bg = "#0a202020"
   header  = ("IP-Address" , "MAC-Address" )
   widths  = (50   , 50   )
   VViqYN = (LEFT   , LEFT   )
   FFldB6(self, None, title=title, header=header, VVWsIU=lst, VViqYN=VViqYN, VVv3Wm=widths, width=1000, height=700, VVHZHw=30
     , VVZYdg=bg, VVcwfs=bg, VVLuY4=bg, VVG27K="#0a225555", VVGpiI="#11403040")
  else:
   FFzrXb(self, "Network scanning failed !", title=title)
 def VV8OLD(self, ip=None):
  if ip:
   FFzW1w(self, BF(self.VVIOni, ip), title="Scanning %s" % ip)
 def VVIOni(self, ip):
  dct = {20: "FTP Data Transfer", 21: "FTP Control", 22: "SSH", 23: "Telnet", 25: "SMTP (eMail)", 80: "HTTP", 443: "HTTPS"}
  txt  = "IP:\n   %s\n\n" % ip
  txt += "Ping Result:\n   %s\n\n" % ("OK" if CCYqD0.VVSxWA(ip) else "Failed")
  txt += "Available Ports:\n"
  ports = ""
  for port, subj in dct.items():
   ok = CCYqD0.VVNIbS(ip, port, timeout=0.5)
   if ok:
    ports += "   %d : %s\n" % (port, subj)
  FFtybv(self, txt + (ports or "   None"), title="Scanned ports : %s" % str(list(dct)).strip("[]"))
 def VV3CJ3(self):
  tLst = []
  if fileExists(self.netEntryFile):
   txt = FFpCvR(self.netEntryFile)
   data = iFindall(r"host\s*=(.+),\s*user\s*=(.+),\s*pass\s*=(.*),\s*path\s*=(.*),\s*rem\s*=(.*)", txt, IGNORECASE)
   for ip, u, p, path, rem in data:
    ip, u, p, path, rem = ip.strip(), u.strip(), p.strip(), path.strip() or "/", rem.strip()
    tLst.append((ip, u, p, path, rem))
  def VVxzxq(p1, p2): return FFEzkZ(p1[0], p2[0])
  tLst.sort(key=FFkmXe(VVxzxq))
  lst = []
  for num1, item in enumerate(tLst, start=1):
   ip, u, p, path, rem = item
   lst.append((str(num1), ip, u, p, path, rem))
  return lst
 def VVexSx(self, mainTableInst, canCencel, VVoLtS, title, txt, colList):
  ip, mac, typ = VVoLtS.VVTQjx(VVoLtS.VVqeSa())
  if "Own" in ip:
   FFycel(VVoLtS, "Cannot add your device", 1500)
  else:
   gw = "Gateway"
   if gw in ip : ip, u, p, path, rem = ip.split()[0].strip(), "admin", "123456", "/", gw
   else  : ip, u, p, path, rem = ip, "root", "dreambox", "/", "No-name"
   for entry in self.VV3CJ3():
    num1, ip1, u1, p1, path1, rem1 = entry
    if (ip, u, p, path, rem) == (ip1, u1, p1, path1, rem1):
     break
   else:
    if fileExists(self.netEntryFile):
     FFElys(self.netEntryFile)
    with open(self.netEntryFile, "a") as f:
     f.write(self.VVsMiC(ip, u, p, path, rem))
   if mainTableInst: self.VVOy9Q(mainTableInst, [ip, u, p, path, rem])
   else   : self.VVjy74(canCencel)
   VVoLtS.cancel()
 def VVsMiC(self, ip, u, p, path, rem):
  return "host=%s,user=%s,pass=%s,path=%s,rem=%s\n" % (ip, u, p, path, rem)
 def VVjvH3(self, VVoLtS):
  num, ip, u, p, path, rem = VVoLtS.VVTQjx(VVoLtS.VVqeSa())
  lst = self.VV3CJ3()
  tot = 0
  with open(self.netEntryFile, "w") as f:
   for item in lst:
    num1, ip1, u1, p1, path1, rem1 = item
    if not (ip1, u1, p1, path1, rem1) == (ip, u, p, path, rem):
     f.write(self.VVsMiC(ip1, u1, p1, path1, rem1))
     tot += 1
  if tot:
   self.VVOy9Q(VVoLtS)
  else:
   VVoLtS.cancel()
 def VVNXSR(self, col, VVoLtS):
  num, ip, u, p, path, rem = VVoLtS.VVTQjx(VVoLtS.VVqeSa())
  if   col == "u": orig, subj = u  , "User"
  elif col == "p": orig, subj = p  , "Password"
  elif col == "r": orig, subj = rem, "Remarks"
  FFBgSg(self, BF(self.VVzsqd, col, orig, VVoLtS, num, ip, u, p, path, rem), defaultText=orig, title="Change %s" % subj, message="Enter %s:" % subj)
 def VVzsqd(self, col, orig, VVoLtS, num, ip, u, p, path, rem, newTxt):
  if not newTxt == None:
   newTxt = newTxt.strip()
   if orig == newTxt:
    FFycel(VVoLtS, "No change", 1500)
   elif not newTxt and col == "u":
    FFycel(VVoLtS, "No user !", 2000)
   else:
    self.VVm7ZW(col, newTxt, ip, u, p, path, rem)
    self.VVOy9Q(VVoLtS)
 def VVm7ZW(self, col, newTxt, ip, u, p, path, rem):
  lst = self.VV3CJ3()
  oldItem = (ip, u, p, path, rem)
  with open(self.netEntryFile, "w") as f:
   for item in lst:
    num1, ip1, u1, p1, path1, rem1 = item
    if (ip1, u1, p1, path1, rem1) == oldItem:
     if   col == "u": u1  = newTxt
     elif col == "p": p1  = newTxt
     elif col == "d": path1 = newTxt
     elif col == "r": rem1 = newTxt
    f.write(self.VVsMiC(ip1, u1, p1, path1, rem1))
 def VVOy9Q(self, VVoLtS, newEntry=None):
  VVpn2v = self.VV3CJ3()
  if VVpn2v : VVoLtS.VVkYNn(VVpn2v, tableRefreshCB=BF(self.VV193C, newEntry))
  else  : VVoLtS.cancel()
 def VV193C(self, newEntry, VVoLtS, title, txt, colList):
  if newEntry:
   for ndx, row in enumerate(VVoLtS.VVGkEL()):
    if row[1:] == newEntry:
     VVoLtS.VV7qpv(ndx)
 def VV67LN(self, canCencel, VVoLtS=None):
  if VVoLtS: VVoLtS.cancel()
  if canCencel : self.close()
class CCYqD0():
 VVit3G = 21
 VVMS66 = 23
 def __init__(self):
  self.VV2U3N()
 def VV2U3N(self):
  self.ftp  = None
  self.ftpIp  = ""
  self.ftpUser = ""
  self.ftpPass = ""
  self.ftpSys  = ""
 def VVjMf2(self, ip, User, Pass, timeout=5):
  myIp = CCYqD0.VVXYgI()
  if ip != myIp:
   if CCYqD0.VVNIbS(ip, CCYqD0.VVit3G):
    self.VV2U3N()
    err = ""
    try:
     from ftplib import FTP
     self.ftp  = FTP(ip, user=User, passwd=Pass, timeout=timeout)
     self.ftp.set_pasv(False)
     self.ftpIp  = ip
     self.ftpUser = User
     self.ftpPass = Pass
    except Exception as e:
     err = str(e)
   else:
    err = "Connection timed out !\n\n%s" % ip
  else:
   err = "Cannot FTP to your Device-IP:\n\n%s" % ip
  return err
 def VVBD1k(self):
  try: return self.ftp.sendcmd("SYST")
  except: return ""
 def VVugl3(self):
  try: return self.ftp.sendcmd("NOOP")
  except: return ""
 def VVPdDs(self, timeout=3):
  t1 = iTime()
  while True:
   state = self.VVugl3()
   if not state or state == "200 OK" or iTime() - t1 >= timeout:
    break
 def VV8tbe(self):
  try: return self.ftp.sendcmd("STAT")
  except: return ""
 def VVqtd2(self, Dir, isLong=False):
  files, err = [], ""
  if self.ftp and self.VVOj0I(Dir):
   try:
    if isLong: self.ftp.dir(files.append)
    else  : self.ftp.nlst()
   except Exception as e:
    err = str(e)
  else:
   err = "No FTP Connection !"
  return files, err
 def VVPk41(self):
  try: return self.ftp.pwd()
  except: return ""
 def VVsFmm(self, path):
  try:
   size = self.ftp.sendcmd("SIZE %s" % path)
   return "f"
  except:
   curDir = self.VVPk41()
   if self.VVOj0I(path) : typ = "d"
   else      : typ = "b"
   self.VVOj0I(curDir)
   return typ
 def VVfF8D(self, path):
  try: return self.ftp.size(path)
  except: return -1
 def VVOj0I(self, path):
  try:
   self.ftp.cwd(path)
   return True
  except:
   return False
 def VVt290(self, path):
  try:
   self.ftp.mkd(path)
   return True
  except:
   return False
 def VVVdVN(self, path, flag):
  try:
   if flag == "d" : self.ftp.rmd(path)
   else   : self.ftp.delete(path)
   return True
  except:
   return False
 def VVgLVo(self, fromN, toN):
  try:
   self.ftp.rename(fromN, toN)
   return True
  except:
   return False
 def VVj7u5(self, remFile, locFile="", maxSz=10000000):
  sz = self.VVfF8D(remFile)
  if   sz == -1 : return "", sz, "Cannot read file size."
  elif sz > maxSz : return "", sz, "File too big."
  else   : err= ""
  locFile = locFile or "/tmp/%s" % os.path.basename(remFile)
  try:
   self.ftp.retrbinary("RETR %s" % remFile, open(locFile, "wb").write)
   if fileExists(locFile) : return locFile, sz, ""
   else     : return "", sz, "Download Failed."
  except Exception as e:
   FFnPMX(locFile)
   return "", sz, str(e)
 def VVgcxM(self):
  if self.ftp:
   try: self.ftp.quit()
   except: pass
  self.VV2U3N()
 @staticmethod
 def VVy8w7():
  from uuid import getnode
  return ':'.join(iFindall('..', '%012x' % getnode())).upper()
 @staticmethod
 def VVXYgI():
  from socket import socket, setdefaulttimeout, AF_INET, SOCK_DGRAM
  try:
   setdefaulttimeout(1)
   s = socket(AF_INET, SOCK_DGRAM)
   s.connect(("1.1.1.1", 80))
   ip = s.getsockname()[0]
   s.close()
   return ip
  except:
   return ""
 @staticmethod
 def VVIVbm():
  myIp = CCYqD0.VVXYgI()
  if myIp.count(".") == 3:
   parts = myIp.split('.')
   return ".".join(parts[:3]) + "."
  return ""
 @staticmethod
 def VVouof():
  span = iSearch(r"((?:\d+.){3}\.\d+)", FFwTnb("ip route | grep default"), IGNORECASE)
  return span.group(1) if span else ""
 @staticmethod
 def VVG3Bw(port=-1):
  lst = []
  def VV7VNt(ip):
   if port > -1: ok = CCYqD0.VVNIbS(ip, port)
   else  : ok = CCYqD0.VVSxWA(ip)
   if ok:
    lst.append(ip)
  try:
   baseIp = CCYqD0.VVIVbm()
   thLst  = []
   for num in range(1, 255):
    ip = "%s%d" % (baseIp, num)
    th = iThread(name="ajp_scanIp%d" % num, target=BF(VV7VNt, ip))
    th.start()
    thLst.append(th)
   for th in thLst: th.join()
   return lst, ""
  except Exception as e:
   err = str(e)
   return [], err + '\n\nMax Threads = %d\nCheck your system "Max User Processes" with "ulimit -u"' % len(thLst) if "can't start new thread" in err else ""
 @staticmethod
 def VVAEik(port):
  myIp = CCYqD0.VVXYgI()
  myGw = CCYqD0.VVouof()
  tDict = { myIp: CCYqD0.VVy8w7() }
  devLst, err = CCYqD0.VVG3Bw(port)
  if err:
   return [], err
  else:
   for ip in devLst:
    span = iSearch(r"((?:\d+.){3}\.\d+).+\s+((?:[a-f\d]{2}:){5}[a-f\d]{2})", FFpCvy("arp -n %s" % ip), IGNORECASE)
    if span    : tDict[ip] = span.group(2).upper()
    elif not ip == myIp : tDict[ip] = ""
   lst = []
   for key, val in tDict.items():
    if   key == myIp: txt = " %s Own" % VV61JF
    elif key == myGw: txt = " %s Gateway" % VV61JF
    else   : txt = ""
    lst.append((key + txt, val))
   return lst, ""
 @staticmethod
 def VVSxWA(ip):
  return FFgSm7("ping -W1 -q -c1 %s" % ip)
 @staticmethod
 def VVNIbS(host, port, timeout=1.0):
  from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
  setdefaulttimeout(timeout)
  try:
   socket(AF_INET, SOCK_STREAM).connect((host, port))
   return True
  except:
   return False
 @staticmethod
 def VVv6Xs(ip="1.1.1.1", timeout=1):
  if CCYqD0.VVNIbS(ip, 53, timeout):
   return True
  if CCYqD0.VVSxWA(ip):
   return True
  return FFgSm7("wget -q -T %d -t 1 --spider %s" % (timeout, ip))
 @staticmethod
 def VVjZIs(SELF, okFnc, title):
  baseIp = CCYqD0.VVIVbm()
  lst = []
  for num in range(1, 255):
   item = "%s%d" % (baseIp, num)
   lst.append((item, item))
  FF7ARM(SELF, okFnc, VVMVqr=lst, width=600, title=title, VVZYdg="#222222", VVcwfs="#222222")
class CClmWE(Screen, CCYqD0):
 def __init__(self, session, entry):
  self.skin, self.skinParam = FF5TEn(VVL1I3, 1400, 920, 40, 50, 30, "#11333344", "#08303030", 30, barHeight=40, topRightBtns=2)
  self.session  = session
  self.ftpEntry  = entry
  self.VVHZHw  = self.skinParam["bodyFontSize"]
  self.VVjcdW  = self.skinParam["bodyLineH"]
  self.VVqbE4  = self.skinParam["width"]
  self.curDir   = "/"
  self.list   = []
  self.png_fil  = CC87Iy.VVsdXn("fil")
  self.png_dir  = CC87Iy.VVsdXn("dir")
  self.png_dirup  = CC87Iy.VVsdXn("dirup")
  self.png_slwfil  = CC87Iy.VVsdXn("slwfil")
  self.png_slbfil  = CC87Iy.VVsdXn("slbfil")
  self.png_slwdir  = CC87Iy.VVsdXn("slwdir")
  self.serverOrigData = None
  self.Title   = "FTP (%s)" % entry[0]
  CCYqD0.__init__(self)
  VVMVqr = [("Item-%d" % x,) for x in range(50)]
  FF32Yx(self, title=self.Title, VVMVqr=VVMVqr)
  FFCDDm(self["keyRed"] , "Exit")
  self["myMenu"] = MenuList(VVMVqr, True, eListboxPythonMultiContent)
  self["myMenu"].l.setFont(0, gFont(VVXtOH, self.VVHZHw))
  self["myMenu"].l.setItemHeight(self.VVjcdW)
  self["myActionMap"] = ActionMap(VVjUqm,
  {
   "red" : BF(self.VVmU2O, True) ,
   "ok" : self.VVthYm    ,
   "cancel": self.VVmU2O    ,
   "menu" : self.VVNFsM   ,
   "info" : self.VVJ2Dl  ,
   "pageUp": self.VVN9iM    ,
   "chanUp": self.VVN9iM
  })
  self.onShown.append(self.VVSDD3)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVjCf9)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  FFWzaz(self["myMenu"])
  FF0pG3(self)
  FFieY3(self)
  FFDoNq(self)
  FFzBm8(self["keyBlue"], "#11333333")
  FFzW1w(self, self.VVLOH5, title="Connecting ...")
 def VVLOH5(self):
  ip, u, p, path, rem = self.ftpEntry
  err = self.VVjMf2(ip, u, p)
  if err:
   FFzrXb(self, err, title=self.Title)
   FFCDDm(self["keyBlue"] , "")
   self.close()
  elif self.ftp:
   FFCDDm(self["keyBlue"], self.ftpIp)
   if not self.VVOj0I(path):
    path = "/"
   self.VV9Itn(path)
   self.serverOrigData = (ip, u, p, path, rem)
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  if self.VVugl3():
   self.VVgcxM()
 def VVthYm(self):
  if self.VVTP2z():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    if   flag == "d" or targetState == "d" : self.VV9Itn(os.path.join(self.curDir, name))
    elif flag == "x"      : self.VVN9iM()
    else         : self.VVZ3Pj(os.path.join(self.curDir, name))
 def VVmU2O(self, force=False):
  if force or CFG.FileManagerExit.getValue() == "e": self.close(self.curDir)
  else            : self.VVN9iM()
 def VVTP2z(self):
  if self.VVugl3():
   return True
  else:
   FFzrXb(self, "FTP Server is now diconnected !", title=self.Title)
   return False
 def VVZ3Pj(self, path):
  cat = self.VV402F(path)
  if cat in ("pic"):
   FFzW1w(self, BF(self.VV2Pg8, path))
  elif cat in ("mov", "mus"):
   if CCfw0y.VVP4kA("5002"):
    url = "ftp%%3a//%s%%3a%s@%s%s" % (self.ftpUser, self.ftpPass, self.ftpIp, path)
    rType = "5002"
   else:
    rType = CFG.iptvAddToBouquetRefType.getValue()
    url = "http%%3a//%s/file?file=%s" % (self.ftpIp, path)
   FFzW1w(self, BF(CCUGPF.VV0bc3, self, url, rType=rType), title="Playing Media ...")
 def VV2Pg8(self, path):
  locFile, size, err = self.VVj7u5(path)
  if err: FFzrXb(self, err, title="View Picture File")
  else  : CCwf80.VVR0Px(self, locFile, fakePath="ftp:/%s" % path, cbFnc=BF(FFnPMX))
 def VVjCf9(self):
  sel = self["myMenu"].l.getCurrentSelection()
  if sel: title = "  %s  " % os.path.join(self.curDir, "" if sel[0][0] == CC87Iy.VVtowH else sel[0][0])
  else  : title=  VVfMEC + "  No Files Found !"
  self["myTitle"].setText(title)
 def VVN9iM(self):
  if self.VVTP2z():
   lastPart = FFZ5fy(self.curDir)
   parentDir = os.path.abspath(os.path.join(self.curDir, os.pardir))
   self.VV9Itn(parentDir, lastPart, "d")
 def VV9Itn(self, Dir, moveTo="", moveToType=""):
  FFzW1w(self, BF(self.VVbkeX, Dir, moveTo, moveToType))
 def VVbkeX(self, Dir, moveTo, moveToType):
  files, err = self.VVqtd2(Dir, isLong=True)
  self.curDir = self.VVPk41() or "/"
  self.VVN0MH(files)
  if moveTo:
   for ndx, item in enumerate(self.list):
    name, target, targetState, flag, sortSeq = item[0]
    if moveTo == name:
     if not moveToType or moveToType == flag:
      self["myMenu"].moveToIndex(ndx)
      break
  else:
   self["myMenu"].moveToIndex(0)
 def VVN0MH(self, files):
  self.list = []
  if self.curDir != "/":
   self.list.append(self.VVyVWb(CC87Iy.VVtowH, CC87Iy.VVtowH, "", "", "x"))
  for item in files:
   linkTo = ""
   isDir = isFile = isLink = False
   item = item.strip()
   if   item.startswith("l")     : flag = "l"
   elif item.startswith("d") or "<DIR>" in item: flag = "d"
   else          : flag = "f"
   gaps = 3 if item[:1].isdigit() else 8
   name = item.split(None, gaps)[gaps]
   linkSep = " -> "
   origName = name
   target = targetState = ""
   if linkSep in name:
    flag = "l"
    name, _, target = name.partition(linkSep)
    if not target.startswith("/"):
     target = "/" + target
    targetState = self.VVsFmm(target)
    color = VVfMEC if targetState == "b" else VVXF4f
    origName = name + VVRJhR + linkSep + color + " "+ target
   self.list.append(self.VVyVWb(origName, name, target, targetState, flag))
  self.list.sort(key=lambda x: (x[0][4], x[0][0]))
  self["myMenu"].l.setList(self.list)
 def VVyVWb(self, origName, name, target, targetState, flag):
  if flag == "f":
   png = self.png_fil
   ext = os.path.splitext(name)[1]
   if ext:
    cat = self.VV402F(name)
    if cat: png = LoadPixmap("%s%s.png" % (VVLS8v, cat))
  elif flag == "d": png = self.png_dir
  elif flag == "l":
   if   targetState == "f" : png = self.png_slwfil
   elif targetState == "d" : png = self.png_slwdir
   elif targetState == "b" : png = self.png_slbfil
   else      : png = self.png_slwfil
  elif flag == "x": png = self.png_dirup
  else   : png = self.png_fil
  if   origName == CC87Iy.VVtowH: sortSeq = 0
  elif flag == "d" or targetState == "d"  : sortSeq = 1
  else          : sortSeq = 2
  tableRow = [ (name, target, targetState, flag, sortSeq) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVjcdW + 10, 0, self.VVqbE4, self.VVjcdW, 0, LEFT | RT_VALIGN_CENTER, origName))
  tableRow.append(CCYFn3.VVsoXp(0, 2, self.VVjcdW-4, self.VVjcdW-4, png))
  return tableRow
 def VV402F(self, path):
  ext = os.path.splitext(path)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in CC87Iy.VVbM6s().items():
    if ext in lst:
     return cat
  return ""
 def VVNFsM(self):
  sel = self["myMenu"].l.getCurrentSelection()
  if sel : name, target, targetState, flag, sortSeq = sel[0]
  else : name = target = targetState = flag = ""
  isTop  = name == CC87Iy.VVtowH
  isDir  = flag == "d" or targetState == "d"
  isFile = flag == "f" or targetState == "f"
  def VVx4Jc(titl, ref, chk, color=""):
   if chk: return VVMVqr.append((color + titl, ref))
   else  : return VVMVqr.append((titl, ))
  VVMVqr = []
  VVx4Jc("Properties", "VVJ2Dl", not isTop)
  c = VV61JF
  VVMVqr.append(VVpTvr)
  VVx4Jc("Download Selected File ..."    , "FFOecpFromServer", isFile, c)
  VVx4Jc("Upload a Local File to Remote Server ...", "VVlOES" , True  , c)
  VVMVqr.append(VVpTvr)
  VVx4Jc("Create new directory", "VVHnkF", True)
  VVx4Jc("Rename", "VV4rmG", not isTop)
  VVx4Jc("DELETE", "VV2Vke", not isTop, VVtz60)
  VVMVqr.append(VVpTvr)
  VVx4Jc("FTP Server Information", "VVcRCd", True)
  VVMVqr.append(VVpTvr)
  VVx4Jc("Refresh File List", "refresh", True)
  FF7ARM(self, self.VVeMgH, VVMVqr=VVMVqr, title="Options")
 def VVeMgH(self, item=None):
  if item:
   if   item == "VVJ2Dl"     : self.VVJ2Dl()
   elif item == "FFOecpFromServer"   : self.FFOecpFromServer()
   elif item == "VVlOES"   : self.VVlOES()
   elif item == "VVHnkF"   : self.VVHnkF()
   elif item == "VV4rmG"   : self.VV4rmG()
   elif item == "VV2Vke"   : self.VV2Vke()
   elif item == "VVcRCd"    : self.VVcRCd()
   elif item == "refresh" and self.VVTP2z(): self.VV9Itn(self.curDir)
 def VVJ2Dl(self):
  if self.VVTP2z():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    path = os.path.join(self.curDir, name)
    txt = "%s:\n%s\n\n" % (FFCzRx("Path", VV61JF), path)
    typ = {"d": "Directory", "f": "File", "l": "SymLink", "x": ""}.get(flag, "")
    if typ: txt += "Type\t: %s%s\n" % (typ, " (Broken)" if targetState == "b" else "")
    if target: txt += "Target\t: %s\n" % target
    sz = self.VVfF8D(path)
    if sz > -1: txt += "Size\t: %s" % CCUGPF.VVuy4U(sz)
   else:
    txt = "Nothing selected"
   FFtybv(self, txt, title="Properties")
 def VVcRCd(self):
  if self.VVTP2z():
   Sys  = self.VVBD1k() or " -"
   txt = "%s\n  %s\n\n" % (FFCzRx("System:", VV61JF), Sys[4:] if Sys.startswith("215 ") else Sys)
   Stat = self.VV8tbe() or " -"
   txt += "%s\n" % (FFCzRx("Status:", VV61JF))
   for line in Stat.splitlines():
    txt += "  %s\n" % (line[4:] if line.startswith("211-") or line.startswith("211 ") else line)
   FFtybv(self, txt, title="FTP Server Information")
 def VVHnkF(self, name=""):
  if self.VVTP2z():
   title = "Add New Directory"
   FFBgSg(self, BF(self.VVGtJT, title), defaultText=name, title=title, message="Enter Directory name")
 def VVGtJT(self, title, name):
  if name and name.strip():
   if self.VVt290(name) : self.VV9Itn(self.curDir, name, "d")
   else     : FFzrXb(self, "Failed to create : %s" % name, title)
 def VV4rmG(self):
  if self.VVTP2z():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    title = "Rename"
    name, target, targetState, flag, sortSeq = sel[0]
    FFBgSg(self, BF(self.VVL8Fv, title, name, flag), defaultText=name, title=title, message="Enter new name")
 def VVL8Fv(self, title, name, flag, newName):
  if newName and newName.strip():
   if self.VVgLVo(name, newName.strip()) : self.VV9Itn(self.curDir, newName, flag)
   else          : FFzrXb(self, "Failed to rename to : %s" % newName, title)
 def VV2Vke(self):
  if self.VVTP2z():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    FFo4dm(self, BF(FFzW1w, self, BF(self.VVqmiY, name, flag), title="Deleting ..."), "Delete ?\n\n%s" % name, title="Delete")
 def VVqmiY(self, name, flag):
  if self.VVVdVN(name, flag) : self.VV9Itn(self.curDir)
  else         : FFzrXb(self, "Failed to delete:\n\n%s" % name, "Delete")
 def FFOecpFromServer(self):
  if self.VVTP2z():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    title = "Download File"
    name, target, targetState, flag, sortSeq = sel[0]
    remFile = os.path.join(self.curDir, name)
    size = self.VVfF8D(remFile)
    if size == -1:
     FFzrXb(self, "Cannot get file size for:\n\n%s" % remFile, title=title)
    else:
     Dir = CFG.lastFtpLocalPath.getValue() if pathExists(CFG.lastFtpLocalPath.getValue()) else VVYfYu
     self.session.openWithCallback(BF(self.VVu7rp, title, remFile, name, size), BF(CCUGPF, mode=CCUGPF.VVGIMp, VVSPOW="Download here", VVRawy=Dir, width=1200, height=840, pickTitleBG="#11002222", pickBodyBG="#11003333", cursorBG="#11005566"))
 def VVu7rp(self, title, remFile, name, size, locPath):
  if locPath:
   FF2tHk(CFG.lastFtpLocalPath, locPath)
   locFile = os.path.join(locPath, name)
   self.session.open(CCSCNk, barTheme=CCSCNk.VVSu4G, titleBg="#22220022", bodyBg="#22220022"
       , titlePrefix = "Downloading ..."
       , fncToRun  = BF(self.VVJDeF, remFile, size, locFile)
       , VVEStC = BF(self.VVaSa1, remFile, size, locFile))
 def VVJDeF(self, remFile, size, locFile, VV2ohY):
  VV2ohY.VVHJ4P(size)
  VV2ohY.VVRTV9 = ""
  with open(locFile, "wb") as locFileObj:
   try:
    def VVzMSA(data):
     if not VV2ohY or VV2ohY.isCancelled:
      return
     locFileObj.write(data)
     VV2ohY.VVc1xD(len(data))
    self.ftp.retrbinary("RETR %s" % remFile, VVzMSA)
   except Exception as e:
    VV2ohY.VVRTV9 = str(e)
 def VVaSa1(self, remFile, size, locFile, VVPnF9, VVRTV9, threadCounter, threadTotal, threadErr):
  title = "File Download"
  delF = False
  if VVRTV9:
   FFzrXb(self, "%s\n\nftp:/%s" % (VVRTV9, remFile), title="Download Error")
   delF = True
  elif not VVPnF9:
   FFzrXb(self, "Download cancelled for:\n\nftp:/%s" % remFile, title=title)
   delF = True
  else:
   if size == FFPLWs(locFile):
    txt = "Successfully downloaded to:\n\n%s" % locFile
    FFuXZg(self, txt, title=title)
   else:
    FFzrXb(self, "Incorrect downloaded file size for:\n\nftp:/%s" % remFile, title=title)
    delF = True
  if delF:
   FFnPMX(locFile)
 def VVlOES(self):
  if self.VVTP2z():
   Dir = CFG.lastFtpLocalPath.getValue() if pathExists(CFG.lastFtpLocalPath.getValue()) else VVYfYu
   self.session.openWithCallback(self.VViztt, BF(CCUGPF, VVSPOW="Upload selected file", VVRawy=Dir, patternMode="all", width=1200, height=850, pickTitleBG="#11001122", pickBodyBG="#11330033", cursorBG="#11662200"))
 def VViztt(self, locFile):
  if locFile:
   title = "Upload File to Remote Server"
   FF2tHk(CFG.lastFtpLocalPath, os.path.dirname(locFile))
   size = FFPLWs(locFile)
   if size == -1:
    FFzrXb(self, "Cannot get file size for:\n\n%s" % locFile, title=title)
   else:
    remFile = os.path.join(self.curDir, os.path.basename(locFile))
    self.session.open(CCSCNk, barTheme=CCSCNk.VVSu4G, titleBg="#22220022", bodyBg="#22220022"
        , titlePrefix = "Uploading ..."
        , fncToRun  = BF(self.VVxjkH, locFile, size, remFile)
        , VVEStC = BF(self.VVuUau, locFile, size, remFile))
 def VVxjkH(self, locFile, size, remFile, VV2ohY):
  VV2ohY.VVHJ4P(size)
  VV2ohY.VVRTV9 = ""
  with open(locFile, "rb") as locFileObj:
   try:
    def VVnDnm(data):
     if not VV2ohY or VV2ohY.isCancelled:
      VV2ohY.VVRTV9 = "Upload cancelled"
      locFileObj.close()
      return
     VV2ohY.VVc1xD(len(data))
    self.ftp.storbinary("STOR %s" % remFile, locFileObj, callback=VVnDnm)
   except Exception as e:
    VV2ohY.VVRTV9 = VV2ohY.VVRTV9 or str(e)
 def VVuUau(self, locFile, size, remFile, VVPnF9, VVRTV9, threadCounter, threadTotal, threadErr):
  title = "File Upload"
  err = ""
  if VVPnF9:
   if size == FFPLWs(locFile) : FFuXZg(self, "Successfully uploaded to:\n\n%s" % remFile, title=title)
   else       : err = "Incorrect uploaded file size for:\n\nftp:/%s" % remFile
  elif VVRTV9 : err = "%s\n\n%s" % (VVRTV9, locFile)
  else    : err = "Incomplete file transfer:\n\n%s" % locFile
  if err:
   FFzrXb(self, err, title=title)
   self.VVPdDs()
   self.VVVdVN(remFile, "")
  self.VV9Itn(self.curDir)
class CCz5Bp():
 VVgKik  = "all"
 VVrFLy = "vid"
 VV5Fdw  = "osd"
 @staticmethod
 def VVcXnO(session, k):
  if not CFG.screenshotFType.getValue() == "off":
   title = "%s Screenshot" % PLUGIN_NAME
   if FFlgKV("grab"):
    winShown = session.current_dialog.shown
    if k == CCz5Bp.VVrFLy and winShown: session.current_dialog.hide()
    FFA9HA(BF(CCz5Bp.VVdokI, title, session, k, winShown))
   else:
    FFBAQq(session, "No Grab command !", title=title)
 @staticmethod
 def VVdokI(title, session, k, winShown):
  fTitle = skinName = ""
  x = y = w = h = 0
  if k == CCz5Bp.VV5Fdw:
   if not winShown:
    FFBAQq(session, "No Window to capture !", title=title)
    return
   if not CCz5Bp.VVdbmR(session, title, True):
    return
   valid, origTitle, clnTitle, skinName, x, y, w, h = CCz5Bp.VV1lH4(session)
   fTitle = "%s_(%s)" % (clnTitle, skinName)
   if not valid:
    FFBAQq(session, "Cannot get Window Dimensions !", title=title)
    return
  if not fTitle:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFmvpz(session, isFromSession=True)
   chName = iSub(r"[^A-Za-z0-9]" ,"-" , chName.strip())
   fTitle = chName or refCode.replace(":", "_")
  ext = CFG.screenshotFType.getValue()
  if   ext == "jpg": typ = "-j 100"
  elif ext == "png": typ = "-p"
  else    : typ = ""
  path = "%sscreenshot_%s_%s.%s" % (FF5DjF(CFG.exportedPIconsPath.getValue()), fTitle, FF4rM4(), ext)
  ok = FFErQ2("grab -q -s %s > '%s'" % (typ, path))
  if k == CCz5Bp.VVrFLy and winShown:
   session.current_dialog.show()
  elif k == CCz5Bp.VV5Fdw:
   ok = CCz5Bp.VV32Dv(path, x, y, w, h)
   if not ok:
    FFnPMX(path)
    FFBAQq(session, "Error while cropping image file !", title=title)
    return
  if ok and fileExists(path) : session.open(BF(CCwf80, title=path, VVxlEn=path))
  else      : FFBAQq(session, "Error while capturing screen !", title=title)
 @staticmethod
 def VVdbmR(SELF, title, isFromExternal, install=True, cbFnc=None):
  try:
   from PIL import Image
   return True
  except:
   if install:
    FFo4dm(SELF, BF(CCz5Bp.VVXQS3, SELF, isFromExternal, cbFnc=cbFnc), "Imaging Library is required.\n\nInstall ?", title=title, isFromExternal=isFromExternal)
   return False
 @staticmethod
 def VVXQS3(SELF, isFromExternal, cbFnc=None):
  if pyVersion[0] >= 3: name = "python3-pillow"
  else    : name = "python-imaging"
  if isFromExternal: fnc = BF(FFeQKD, VVFgpi=cbFnc)
  else    : fnc = BF(FFHguD , VVFgpi=cbFnc)
  fnc(SELF, FF4ZaS(VVLFdd, name), checkNetAccess=True, title="Installing Imaging Library")
 @staticmethod
 def VV1lH4(session, repl="-"):
  valid = False
  origTitle = clnTitle = skinName = ""
  x = y = w = h = 0
  obj = session.current_dialog
  if obj:
   inst = obj.instance
   skinName = obj.skinName
   if inst:
    origTitle = inst.getTitle()
    pos, size = inst.position(), inst.size()
    x, y, w, h = pos.x(), pos.y(), size.width(), size.height()
    valid = w != 0 and h !=0
    clnTitle = iSub(r"[^A-Za-z0-9]", repl , origTitle.strip())
  return valid, origTitle, clnTitle, skinName, x, y, w, h
 @staticmethod
 def VV32Dv(path, x, y, w, h, scaleToScreen=True):
  try:
   from PIL import Image
   im = Image.open(path)
   x1 = w + x
   y1 = h + y
   if scaleToScreen:
    scrW, scrH = FFM4r3()
    w, h = im.size
    if w != scrW or h != scrH:
     x  = FFpM97(x , 0, scrW, 0, w)
     y  = FFpM97(y , 0, scrH, 0, h)
     x1 = FFpM97(x1, 0, scrW, 0, w)
     y1 = FFpM97(y1, 0, scrH, 0, h)
   im = im.crop((x, y, x1, y1))
   im.save(path)
   return True
  except:
   return False
 @staticmethod
 def VVdVZw(path):
  size = FFPLWs(path)
  sizeTxt = CCUGPF.VVuy4U(size) if size > -1 else ""
  try:
   from PIL import Image
   im = Image.open(path)
   form = im.format
   mode = im.mode
   resTxt = "%d x %d" % im.size
  except:
   resTxt = form = mode = ""
  return size, sizeTxt, resTxt, form, mode
class CC51nM(Screen):
 def __init__(self, session, title, fontsList, defFnt, withRestart):
  self.skin, self.skinParam = FF5TEn(VVL1I3, 1400, 1000, 40, 40, 30, "#0a001100", "#10110000", 30, barHeight=220)
  self.session  = session
  self.fontsList  = fontsList
  self.defFnt   = defFnt
  txt = FFCzRx(" (Requires GUI Restart)", VVTKrH) if withRestart else ""
  VVMVqr = []
  for path in self.fontsList:
   VVMVqr.append((os.path.splitext(os.path.basename(path))[0], path))
  VVMVqr.sort(key=lambda x: x[0].lower())
  VVMVqr.insert(0, VVpTvr)
  VVMVqr.insert(0, ("Reset to Default%s" % txt, "DEFAULT"))
  curIndex = 0
  if self.defFnt:
   for ndx, item in enumerate(VVMVqr):
    if len(item) == 2 and item[1] == self.defFnt:
     VVMVqr[ndx] = (VVXF4f + item[0], item[1])
     curIndex = ndx
     break
  else:
   VVMVqr[curIndex] = (VVXF4f + VVMVqr[curIndex][0], VVMVqr[curIndex][1])
  FF32Yx(self, VVMVqr=VVMVqr, title=title)
  self["myActionMap"].actions.update({"cancel": self.cancel})
  self.onShown.append(self.VVSDD3)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  FFWzaz(self["myMenu"])
  FF0pG3(self)
  self["myBar"].setText(self.VV8M59())
  self["myBar"].instance.setHAlign(1)
  self["myMenu"].onSelectionChanged.append(self.VVPCdU)
  self.VVPCdU()
 def VVthYm(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VVPCdU(self):
  path = self["myMenu"].l.getCurrentSelection()[1]
  if fileExists(path):
   fnt = "AJP_Sample"
   FF51vv(path, fnt, isRepl=1)
  else:
   fnt = VVSkqN
  self["myMenu"].instance.setFont(gFont(fnt, self.skinParam["bodyFontSize"]))
  self["myMenu"].instance.invalidate()
  self["myBar"].instance.setFont(gFont(fnt, int(self.skinParam["bodyFontSize"] * 1.3)))
  self["myBar"].instance.invalidate()
 def VV8M59(self):
  txt = ""
  for i in range(65, 91): txt += chr(i)
  txt += "\n"
  for i in range(97, 123): txt += chr(i)
  txt += "  "
  for i in range(48, 58): txt += chr(i)
  txt += "\n"
  txt += u"\u0623\u0628\u062c\u062f \u0647\u0648\u0632 \u062d\u0637\u064a \u0643\u0644\u0645\u0646 \u0633\u0639\u0641\u0635 \u0642\u0631\u0634\u062a \u062b\u062e\u0630 \u0636\u0638\u063a  \u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
  return str(txt)
 @staticmethod
 def VV2z8w(SELF, title, defFnt, rest, VVEStC):
  fntPath = resolveFilename(SCOPE_FONTS)
  fontsList = FFY7QR(fntPath, "*.[tToO][tT][fF]")
  if fontsList: SELF.session.openWithCallback(VVEStC, CC51nM, title, fontsList, defFnt, rest)
  else  : FFzrXb(self, "No fonts found in:\n\n%s" % fntPath, title=title)
class CC513c(Screen):
 def __init__(self, session, path, VVMVqr, title):
  self.skin, self.skinParam = FF5TEn(VVL1I3, 1700, 1000, 40, 40, 30, "#11001122", "#11002233", 30, menuLabel=50)
  self.session = session
  self.path  = path
  FF32Yx(self, VVMVqr=VVMVqr, title=title)
  self["myLabelFrm"] = Label()
  self["myLabelTit"] = Label("Result Sample")
  self["myLabelTxt"] = Label()
  self["myActionMap"] = ActionMap(VVjUqm,
  {
   "ok"  : self.VVthYm   ,
   "cancel" : self.cancel   ,
   "pageUp" : self.VVP1r8,
   "chanUp" : self.VVP1r8,
   "pageDown" : self.VV6q16 ,
   "chanDown" : self.VV6q16 ,
  }, -1)
  self.onShown.append(self.VVSDD3)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  FFWzaz(self["myMenu"])
  FF0pG3(self)
  FFzBm8(self["myLabelFrm"], "#11110000")
  FFzBm8(self["myLabelTit"], "#11663322")
  FFzBm8(self["myLabelTxt"], "#11110000")
  self["myMenu"].onSelectionChanged.append(self.VVB23e)
  self.VVB23e()
 def VVB23e(self):
  if fileExists(self.path): txt = FFpCvR(self.path, maxSize=1000, encLst=[self["myMenu"].l.getCurrentSelection()[1]])
  else     : txt = "Review error !"
  self["myLabelTxt"].setText(txt.strip())
 def VVthYm(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VVP1r8(self) : self["myMenu"].moveToIndex(0)
 def VV6q16(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCscRA():
 @staticmethod
 def VVZguv():
  return [None, "utf-8"] + ["iso-8859-%d" % i for i in range(1,17)] + ["windows-125%d" % i for i in range(1,9)]
 @staticmethod
 def VVwMfV(SELF):
  import sys, locale
  lst = []
  c1 = "#f#00ffbbff#"
  c2 = "#f#00ffffaa#"
  lst.append(("Language Code"     , locale.getdefaultlocale()[0]  ))
  lst.append(("Default Locale Encoding"  , locale.getdefaultlocale()[1]  ))
  lst.append((c1 + "Preferred Encoding"  , c1 + locale.getpreferredencoding(False)))
  lst.append((c2 + "System Default Encoding" , c2 + sys.getdefaultencoding()  ))
  lst.append((c2 + "Filesystem Encoding"  , c2 + sys.getfilesystemencoding() ))
  c = "#f#11aaffff#"
  for item in locale.setlocale(locale.LC_ALL).split(";"):
   parts = item.split("=")
   if len(parts) == 2:
    lst.append((c + parts[0], c +
    parts[1]))
  FFldB6(SELF, None, VVWsIU=lst, VVHZHw=30, VVcK1v=1)
 @staticmethod
 def VVf2n6(path, SELF=None):
  for enc in CCscRA.VVZguv():
   try:
    with ioOpen(path, "r", encoding=enc) as f:
     for line in f:
      pass
    return enc
   except:
    pass
  if SELF:
   FFzrXb(SELF, "Cannot detect file encoding for:\n\n%s" % path)
  return -1
 @staticmethod
 def VVnhog(path, enc):
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     pass
   return True
  except:
   return False
 @staticmethod
 def VVf3m2(SELF, path, cbFnc, curEnc=VVImSj, title="Select Encoding"):
  lst = CCscRA.VVEHHn(SELF, path, "")
  if lst:
   SELF.session.openWithCallback(cbFnc, CC513c, path, lst, title)
 @staticmethod
 def VVW4Bp(SELF, cbFnc, curEnc=VVImSj, title="Select Encoding"):
  lst = CCscRA.VVEHHn(SELF, "", "")
  if lst:
   FF7ARM(SELF, cbFnc, title=title, VVMVqr=lst, width=1000, height=1000, VVZYdg="#22220000", VVcwfs="#22220000", VVy9CS=True)
 @staticmethod
 def VVEHHn(SELF, path, curEnc):
  lst = CCscRA.VVFch9(path)
  if lst:
   VVMVqr = []
   for name, enc in lst:
    txt = "%s (%s)" % (name, enc)
    if   enc == curEnc   : c = VVXF4f
    elif enc == VVImSj: c = VVRJhR
    else      : c = ""
    VVMVqr.append((c + txt, enc))
   return VVMVqr
  else:
   FFhcEU(SELF, "No proper encoding", 2000)
 @staticmethod
 def VVFch9(path=""):
  encLst = []
  cPath = VVLS8v + "_sup_codecs"
  if fileExists(cPath):
   lines = FF2WPS(cPath)
   for line in lines:
    parts = line.split("\t")
    if len(parts) == 2:
     encLst.append((parts))
  if not encLst:
   tmp = list(CCscRA.VVZguv())
   tmp.pop(0)
   encLst = [("General", ",".join(tmp))]
  lst = []
  for item in encLst:
   for enc in (item[1].split(",")):
    if path:
     try:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        pass
      lst.append((item[0], enc))
     except:
      pass
    else:
     lst.append((item[0], enc))
  return lst
class CCIdnp(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF5TEn(VVL1I3, 900, 950, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVMVqr = []
  VVMVqr.append(("Settings File"   , "SettingsFile"  ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Box Info"     , "VVoiQ3"   ))
  VVMVqr.append(("Tuners Info"    , "VV9Oh2"  ))
  VVMVqr.append(("Python Version"   , "VVvjAh"  ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Screen Size"    , "ScreenSize"   ))
  VVMVqr.append(("Language/Locale"   , "Locale"    ))
  VVMVqr.append(("Processor"    , "Processor"   ))
  VVMVqr.append(("Operating System"   , "OperatingSystem"  ))
  VVMVqr.append(("Drivers"     , "drivers"    ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("System Users"    , "SystemUsers"   ))
  VVMVqr.append(("Logged-in Users"   , "LoggedInUsers"  ))
  VVMVqr.append(("Uptime"     , "Uptime"    ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Host Name"    , "HostName"   ))
  VVMVqr.append(("MAC Address"    , "MACAddress"   ))
  VVMVqr.append(("Network Configuration" , "NetworkConfiguration"))
  VVMVqr.append(("Network Status"   , "NetworkStatus"  ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Disk Usage"    , "VVKycI"   ))
  VVMVqr.append(("Mount Points"    , "MountPoints"   ))
  VVMVqr.append(("File System Table (FSTAB)", "FileSystemTable"  ))
  VVMVqr.append(("USB Devices"    , "USB_Devices"   ))
  VVMVqr.append(("List Block-Devices"  , "listBlockDevices" ))
  VVMVqr.append(("Directory Size"   , "DirectorySize"  ))
  VVMVqr.append(("Memory"     , "Memory"    ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Loaded Kernel Modules" , "LoadedKernelModules" ))
  VVMVqr.append(("Running Processes"  , "RunningProcesses" ))
  VVMVqr.append(("Processes with open files", "ProcessesOpenFiles" ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"))
  FF32Yx(self, VVMVqr=VVMVqr, title="Device Information")
  self.onShown.append(self.VVSDD3)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  FFWzaz(self["myMenu"])
  FF0pG3(self)
 def VVthYm(self):
  global VVBcOf
  VVBcOf = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"   : self.session.open(CCAxZU)
   elif item == "VVoiQ3"   : self.VVoiQ3()
   elif item == "VV9Oh2"  : self.VV9Oh2()
   elif item == "VVvjAh"  : self.VVvjAh()
   elif item == "ScreenSize"   : FFtybv(self, "Width\t: %s\nHeight\t: %s" % (FFM4r3()[0], FFM4r3()[1]))
   elif item == "Locale"    : CCscRA.VVwMfV(self)
   elif item == "Processor"   : self.VV0IjL()
   elif item == "OperatingSystem"  : FFH2jW(self, "uname -a")
   elif item == "drivers"    : self.VVUsdu()
   elif item == "SystemUsers"   : FFH2jW(self, "id")
   elif item == "LoggedInUsers"  : FFH2jW(self, "who -a", consFont=True)
   elif item == "Uptime"    : FFH2jW(self, "uptime")
   elif item == "HostName"    : FFH2jW(self, "hostname")
   elif item == "MACAddress"   : self.VVUhHO()
   elif item == "NetworkConfiguration" : FFH2jW(self, "ifconfig %s %s" % (FFC7pV("HWaddr", VVMVIx), FFC7pV("addr:", VVRJhR)))
   elif item == "NetworkStatus"  : FFH2jW(self, "netstat -tulpn", VVHZHw=24, consFont=True)
   elif item == "VVKycI"   : self.VVKycI()
   elif item == "MountPoints"   : FFH2jW(self, "mount %s" % (FFC7pV(" on ", VVRJhR)))
   elif item == "FileSystemTable"  : FFH2jW(self, "cat /etc/fstab", VVHZHw=24, consFont=True)
   elif item == "USB_Devices"   : FFH2jW(self, "lsusb")
   elif item == "listBlockDevices"  : FFH2jW(self, "blkid")
   elif item == "DirectorySize"  : FFH2jW(self, "du -shc /* 2>/dev/null | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVnUUN="Reading size ...")
   elif item == "Memory"    : FFH2jW(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules" : self.VVCe1l()
   elif item == "RunningProcesses"  : FFH2jW(self, "ps", consFont=True)
   elif item == "ProcessesOpenFiles" : FFH2jW(self, "lsof", consFont=True)
   elif item == "DreamBoxBootloader"  : self.VVXzbW()
   else        : self.close()
 def VVUhHO(self):
  res = FFpCvy("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFtybv(self, txt)
  else:
   FFH2jW(self, "ip link")
 def VVkqjn(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFSInC(cmd)
  return lines
 def VV9Km1(self, lines, headerRepl, widths, VViqYN):
  VVpn2v = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVpn2v.append(parts)
  if VVpn2v and len(header) == len(widths):
   VVpn2v.sort(key=lambda x: x[0].lower())
   FFldB6(self, None, header=header, VVWsIU=VVpn2v, VViqYN=VViqYN, VVv3Wm=widths, VVHZHw=28, VVcK1v=1)
   return True
  else:
   return False
 def VVKycI(self):
  headerRepl = "Mounted on"
  cmd   = "df -Th"
  txt = FFpCvy(cmd)
  if not "invalid option" in txt:
   lines  = self.VVkqjn(cmd, headerRepl, 6, False)
   widths  = (25 , 12 , 10 , 9  , 10 , 9  , 25 )
   VViqYN = (LEFT , CENTER, CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VV9Km1(lines, headerRepl, widths, VViqYN)
  else:
   cmd = "df -h"
   lines  = self.VVkqjn(cmd, headerRepl, 6, False)
   widths  = (28 , 11 , 11 , 11 , 11 , 28 )
   VViqYN = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VV9Km1(lines, headerRepl, widths, VViqYN)
  if not allOK:
   lines = FFSInC(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFZuCm(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVXF4f:
     note = "\n%s" % FFCzRx("Green = Mounted Partitions", VVXF4f)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVRJhR
     elif line.endswith(mountList) : color = VVXF4f
     else       : color = VVzv5p
     txt += FFCzRx(line, color) + "\n"
    FFtybv(self, txt + note)
   else:
    FFzrXb(self, "Not data from system !")
 def VVCe1l(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVkqjn(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VViqYN = (LEFT , CENTER, LEFT )
  allOK = self.VV9Km1(lines, headerRepl, widths, VViqYN)
  if not allOK:
   FFH2jW(self, cmd)
 def VVUsdu(self):
  cmd = FF1dKx(VVoElo, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFH2jW(self, cmd)
  else : FFV7xB(self)
 def VV0IjL(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFH2jW(self, cmd)
 def VVXzbW(self):
  cmd = FF1dKx(VVjhlW, "| grep secondstage")
  if cmd : FFH2jW(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFV7xB(self)
 def VVoiQ3(self):
  c = VVXF4f
  VVWsIU = []
  VVWsIU.append((FFCzRx("Box Type"  , c), FFCzRx(self.VVmKgG("boxtype").upper(), c)))
  VVWsIU.append((FFCzRx("Board Version", c), FFCzRx(self.VVmKgG("board_revision") , c)))
  VVWsIU.append((FFCzRx("Chipset"  , c), FFCzRx(self.VVmKgG("chipset")  , c)))
  VVWsIU.append((FFCzRx("S/N"   , c), FFCzRx(self.VVmKgG("sn")    , c)))
  VVWsIU.append((FFCzRx("Version"  , c), FFCzRx(self.VVmKgG("version")  , c)))
  VVu0fJ   = []
  VV3n2o = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VV3n2o = SystemInfo[key]
     else:
      VVu0fJ.append((FFCzRx(str(key), VVAaU5), FFCzRx(str(SystemInfo[key]), VVAaU5)))
  except:
   pass
  if VV3n2o:
   VVzmxF = self.VVRyjq(VV3n2o)
   if VVzmxF:
    VVzmxF.sort(key=lambda x: x[0].lower())
    VVWsIU += VVzmxF
  if VVu0fJ:
   VVu0fJ.sort(key=lambda x: x[0].lower())
   VVWsIU += VVu0fJ
  if VVWsIU:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFldB6(self, None, header=header, VVWsIU=VVWsIU, VVv3Wm=widths, VVHZHw=28, VVcK1v=1)
  else:
   FFtybv(self, "Could not read info!")
 def VVmKgG(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FF2WPS(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVRyjq(self, mbDict):
  try:
   mbList = list(mbDict)
   VVWsIU = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVWsIU.append((FFCzRx(subject, VVRJhR), FFCzRx(value, VVRJhR)))
  except:
   pass
  return VVWsIU
 def VV9Oh2(self):
  txt = self.VVf1y2("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVf1y2("/proc/bus/nim_sockets")
  if not txt: txt = self.VV07Ms()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFtybv(self, txt)
 def VV07Ms(self):
  txt = ""
  VVchnh = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVchnh("Slot Name" , slot.getSlotName())
     txt += FFCzRx(slotName, VVRJhR)
     txt += VVchnh("Description"  , slot.getFullDescription())
     txt += VVchnh("Frontend ID"  , slot.frontend_id)
     txt += VVchnh("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVf1y2(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FF2WPS(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFCzRx(line, VVRJhR)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVvjAh(self):
  major   = pyVersion[0]
  minor   = pyVersion[1]
  micro   = pyVersion[2]
  releaselevel = pyVersion[3]
  serial   = pyVersion[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFtybv(self, txt)
 @staticmethod
 def VVLVvZ():
  def VVchnh(v, ndx):
   lst = v.split(";")[ndx].split(",")
   return {lst[i]: lst[i + 1] for i in range(0, len(lst), 2)}
  v = "openbox,OpenBox,openpli,OpenPLI,openvision,OpenVision;areadeltasat,ArEaDeltaSat,cobralibero,Cobralibero,opentr,OpenTR,peter,PeterPan;italysat,ItalySat,oozoon,OoZooN,openatv,openATV,openeight,OpenEight,openmips,OpenMips,opennfr,OpenNFR,openplus,OpenPlus,openspa,OpenSPA,pure2,Pure2,rudream,ruDream,teamblue,teamBlue,titannit,OpenAFF_Titan"
  v = {"/etc/issue": VVchnh(v,0), "/etc/issue.net": VVchnh(v,1), "/etc/image-version": VVchnh(v,2)}
  for p1, d in v.items():
   img = CCIdnp.VVZHFn(p1, d)
   if img: return img
  v = "Blackhole,Blackhole,DE,Dream-Elite,EGAMI,Egami,LT,LT,MediaSat,MediaSat,OPENDROID,OpenDroid,Bp/geminimain,GP3;Domica,Domica,SatLodge,Satlodge,Satdreamgr,SatdreamGr,TSimage,OpenTS_Ts,newnigma2,newnigma2;DemonisatManager,DDD-Demoni,VTIPanel,VTI,ViX,OpenVIX;AddOnManager,Merlin3,DreamOSatcamManager,DreamOSat CamManager,ExtraAddonss,OpenESI,HDF-Toolbox,OpenHDF,HDMUCenter,HDMU,LDteam,OpenLD,NssPanel,NonSoloSat,PKT,PKT,PowerboardCenter,PBNigma-VX,TDW,TDW"
  p = "/usr/lib/enigma2/python/"
  v = {p: VVchnh(v,0), p + "Plugins/": VVchnh(v,1), VVbd2l: VVchnh(v,2), VVFTYs: VVchnh(v,3)}
  for p1, d in v.items():
   img = CCIdnp.VVJpXP(p1, d)
   if img: return img
  return "OpenBlackhole" if iGlob("%sScreens/BpBlue.p*" % p) else ""
 @staticmethod
 def VVZHFn(path, d):
  if fileExists(path):
   txt = FFpCvR(path).lower()
   for key, val in d.items():
    if key in txt: return val
  return ""
 @staticmethod
 def VVJpXP(path, d):
  for key, val in d.items():
   if pathExists(path + key): return val
  return ""
class CCAxZU(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF5TEn(VVL1I3, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVMVqr = []
  VVMVqr.append(("Settings (All)"   , "Settings_All"   ))
  VVMVqr.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  VVMVqr.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVMVqr.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVMVqr.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVMVqr.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVMVqr.append(("Settings (Skin)"   , "Settings_Skin"   ))
  if VVncAm:
   VVMVqr.append(VVpTvr)
   VVMVqr.append(("Settings (%s)" % PLUGIN_NAME , "Settings_ajp" ))
   VVMVqr.append(("Settings (FHDG-17)"   , "Settings_FHDG_17"))
  FF32Yx(self, VVMVqr=VVMVqr)
  self.onShown.append(self.VVSDD3)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  FFWzaz(self["myMenu"])
  FF0pG3(self)
 def VVthYm(self):
  global VVBcOf
  VVBcOf = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat %s" % VVrs06
   grep = " | grep "
   if   item == "Settings_All"   : FFH2jW(self, cmd)
   elif item == "Settings_HotKeys"  : FFH2jW(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'")
   elif item == "Settings_ajp"   : FFH2jW(self, cmd + grep + "'config.plugins.%s.'" % PLUGIN_NAME)
   elif item == "Settings_FHDG_17"  : FFH2jW(self, cmd + grep + "'config.plugins.setupGlass17.'")
   elif item == "Settings_Tuner_DiSEqC": FFH2jW(self, cmd + grep + "'config.Nims.'")
   elif item == "Settings_Plugins"  : FFH2jW(self, cmd + grep + "'.plugins.\|config.TS'")
   elif item == "Settings_Usage"  : FFH2jW(self, cmd + grep + "'.usage.'")
   elif item == "Settings_TimeZone" : FFH2jW(self, cmd + grep + "'.timezone.'")
   elif item == "Settings_Skin"  : FFH2jW(self, cmd + grep + "'.skin.'")
   else        : self.close()
class CCk55e(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF5TEn(VVL1I3, 950, 800, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VV93cD, VVUJZY, VVcZxg, camCommand = CCk55e.VVHyaf()
  self.VVUJZY = VVUJZY
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  camName = "SoftCam"
  nC = oC = c = ""
  if VVUJZY:
   c = VVJS3b if VVcZxg else VVYqlh
   if   "oscam" in VVUJZY : camName, oC = "OSCam", c
   elif "ncam"  in VVUJZY : camName, nC = "NCam" , c
  VVMVqr = []
  VVMVqr.append(("OSCam Files" , "OSCamFiles" ))
  VVMVqr.append(("NCam Files" , "NCamFiles" ))
  VVMVqr.append(("CCcam Files" , "CCcamFiles" ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append((VV61JF + 'Convert "/etc/CCcam.cfg" to OSCam/NCam Readers', "VV0Azz" ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append((oC + "OSCam Readers Table (oscam.server)" , "OSCamReaders" ))
  VVMVqr.append((nC + "NCam Readers Table (ncam.server)" , "NSCamReaders" ))
  VVMVqr.append(VVpTvr)
  camCmd = os.path.basename(camCommand)
  txt = "%s Settings%s" % (camName, "" if camCmd in ("oscam", "ncam") else " ( %s )" % camCmd)
  VVMVqr.append(FFwLFH(txt, "camInfo", VVUJZY, c))
  VVMVqr.append(VVpTvr)
  camLst = ((c + camName + " Live Status" , "camLiveStatus" )
    , (c + camName + " Live Readers", "camLiveReaders" )
    , (c + camName + " Live Log" , "camLiveLog"  ))
  if VVUJZY:
   for item in camLst: VVMVqr.append(item)
  else:
   for item in camLst: VVMVqr.append((item[0], ))
  FF32Yx(self, VVMVqr=VVMVqr)
  self.onShown.append(self.VVSDD3)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  FFWzaz(self["myMenu"])
  FF0pG3(self)
 def VVthYm(self):
  global VVBcOf
  VVBcOf = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(BF(CCXr9E, "oscam"))
   elif item == "NCamFiles"  : self.session.open(BF(CCXr9E, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(BF(CCXr9E, "cccam"))
   elif item == "VV0Azz" : self.VV0Azz()
   elif item == "OSCamReaders"  : self.VVcJw4("os")
   elif item == "NSCamReaders"  : self.VVcJw4("n")
   elif item == "camInfo"   : FFvJat(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : CCk55e.VVcuZG(self.session, CCqz8v.VV5gOq)
   elif item == "camLiveReaders" : CCk55e.VVcuZG(self.session, CCqz8v.VV5BOP)
   elif item == "camLiveLog"  : CCk55e.VVcuZG(self.session, CCqz8v.VVGkHi)
   else       : self.close()
 def VV0Azz(self):
  path = "/etc/CCcam.cfg"
  outFile = "%scccam_to_reader_%s.txt" % (VVYfYu, FF4rM4())
  if fileExists(path):
   lines = FF2WPS("/etc/CCcam.cfg")
   lst = []
   for line in lines:
    line = line.strip()
    if line.startswith("C:"):
     while "  " in line: line = line.replace("  ", " ")
     parts = line.split(" ")
     if len(parts) == 5:
      CTxt, host, port, User, Pass = parts
      lst.append((host, port, User, Pass))
   newLine = []
   if lst:
    VVchnh = lambda txt, val: "%s= %s\n" % (txt.ljust(30), str(val))
    with open(outFile, "w") as f:
     for ndx, item in enumerate(lst, start=1):
      host, port, User, Pass = item
      f.write("[reader]\n")
      f.write(VVchnh("label"    , "CCcam-Line-%d" % ndx))
      f.write(VVchnh("description"  , "CCcam-Line-%d" % ndx))
      f.write(VVchnh("protocol"   , "cccam"))
      f.write(VVchnh("device"    , "%s,%s" % (host, port)))
      f.write(VVchnh("user"    , User))
      f.write(VVchnh("password"   , Pass))
      f.write(VVchnh("fallback"   , "1"))
      f.write(VVchnh("group"    , "64"))
      f.write(VVchnh("cccversion"   , "2.3.2"))
      f.write(VVchnh("audisabled"   , "1"))
      f.write("\n")
    tot = len(lst)
    FFuXZg(self, "Output = %d Reader%s in:\n\n%s" % (tot, FFoTxy(tot), outFile))
   else:
    FFycel(self, "No valid CCcam lines", 1500)
  else:
   FFycel(self, "%s not found" % path, 1500)
 def VVcJw4(self, camPrefix):
  VVpn2v = self.VVi3uR(camPrefix)
  if VVpn2v:
   VVpn2v.sort(key=lambda x: int(x[0]))
   if self.VVUJZY and self.VVUJZY.startswith(camPrefix):
    VVEXwE = ("Toggle State", self.VVsNpw, [camPrefix], "Changing State ...")
   else:
    VVEXwE = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VViqYN  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFldB6(self, None, header=header, VVWsIU=VVpn2v, VViqYN=VViqYN, VVv3Wm=widths, VVHZHw=26, VVEXwE=VVEXwE, VV65AN=True)
 def VVi3uR(self, camPrefix):
  readersFile = self.VV93cD + camPrefix + "cam.server"
  VVpn2v = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FF2WPS(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVpn2v.append((str(len(VVpn2v) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVpn2v:
    FFzrXb(self, "No readers found !")
  else:
   FFZ5Ys(self, readersFile)
  return VVpn2v
 def VVsNpw(self, VVoLtS, camPrefix):
  confFile  = "%s%scam.conf" % (self.VV93cD, camPrefix)
  readerState  = VVoLtS.VVh7wm(1)
  readerLabel  = VVoLtS.VVh7wm(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCk55e.VVpitz(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVoLtS.VV6eCK()
    FFzrXb(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVpn2v = self.VVi3uR(camPrefix)
   if VVpn2v:
    VVoLtS.VVkYNn(VVpn2v)
  else:
   VVoLtS.VV6eCK()
 @staticmethod
 def VVpitz(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FF2WPS(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFzrXb(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFzrXb(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFZ5Ys(SELF, confFile)
   return None
  if not iRequest:
   FFzrXb(SELF, "Module not found\n\nurllib/urllib2")
   return None
  if not CCk55e.VVccK9(SELF):
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), iElem
  except Exception as e:
   FFzrXb(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
 @staticmethod
 def VVccK9(SELF):
  if iElem:
   return True
  else:
   FFzrXb(SELF, "Module not found:\n\nxml.etree")
   return False
 @staticmethod
 def VVcuZG(session, VVVOLh):
  VV93cD, VVUJZY, VVcZxg, camCommand = CCk55e.VVHyaf()
  if VVUJZY:
   runLog = False
   if   VVVOLh == CCqz8v.VV5gOq : runLog = True
   elif VVVOLh == CCqz8v.VV5BOP : runLog = True
   elif not VVcZxg          : FFBAQq(session, message="SoftCam not started yet!")
   elif fileExists(VVcZxg)        : runLog = True
   else             : FFBAQq(session, message="File not found !\n\n%s" % VVcZxg)
   if runLog:
    session.open(BF(CCqz8v, VV93cD=VV93cD, VVUJZY=VVUJZY, VVcZxg=VVcZxg, VVVOLh=VVVOLh))
  else:
   FFBAQq(session, message="No active OSCam/NCam found !", title="Live Log")
 @staticmethod
 def VVHyaf():
  VV93cD = "/etc/tuxbox/config/"
  VVUJZY = None
  VVcZxg  = None
  camCommand = FFwTnb("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
  if camCommand:
   camCmd = os.path.basename(camCommand).lower()
   if   camCmd.startswith("oscam") : VVUJZY = "oscam"
   elif camCmd.startswith("ncam") : VVUJZY = "ncam"
  if VVUJZY:
   tStr = os.path.basename(camCommand).lower()
   for path in iGlob("/etc/init.d/softcam.*"):
    _, _, camName = os.path.basename(path).lower().partition(".")
    if camName == tStr:
     span = iSearch(r"-config-dir\s(\/etc\/tuxbox.*?)\s", FFpCvR(path), IGNORECASE)
     if span:
      VV93cD = FF5DjF(span.group(1))
      break
   else:
    path = FFwTnb(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
    path = FF5DjF(path)
    if pathExists(path):
     VV93cD = path
   tFile = FF5DjF(VV93cD) + VVUJZY + ".conf"
   tFile = FFwTnb("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
   if fileExists(tFile):
    VVcZxg = tFile
  return VV93cD, VVUJZY, VVcZxg, camCommand
class CCXr9E(Screen):
 def __init__(self, VVF723, session, args=0):
  self.skin, self.skinParam = FF5TEn(VVL1I3, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VV93cD, VVUJZY, VVcZxg, camCommand = CCk55e.VVHyaf()
  if   VVF723 == "ncam" : self.prefix = "n"
  elif VVF723 == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVMVqr = []
  if self.prefix == "":
   VVMVqr.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVMVqr.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVMVqr.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVMVqr.append(("constant.cw"         , "x_constant_cw" ))
   VVMVqr.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVMVqr.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVMVqr.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVMVqr.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVMVqr.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVMVqr.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVMVqr.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVMVqr.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVMVqr.append(VVpTvr)
   VVMVqr.append(("SoftCam.Key / SoftCam.key"     , "x_SoftCam_Key" ))
   VVMVqr.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVMVqr.append(VVpTvr)
   VVMVqr.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVMVqr.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVMVqr.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FF32Yx(self, VVMVqr=VVMVqr)
  self.onShown.append(self.VVSDD3)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  FFWzaz(self["myMenu"])
  FF0pG3(self)
 def VVthYm(self):
  global VVBcOf
  VVBcOf = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFdD2h(self, "/var/etc/CCcam.cfg")
   elif item == "c_ecm_info"  : FFdD2h(self, "/tmp/ecm.info")
   elif item == "x_AutoRoll_Key" : FFdD2h(self, self.VV93cD + "AutoRoll.Key")
   elif item == "x_constant_cw" : FFdD2h(self, self.VV93cD + "constant.cw")
   elif item == "x_cam_ccache"  : self.VVwr15("cam.ccache")
   elif item == "x_cam_conf"  : self.VVwr15("cam.conf")
   elif item == "x_cam_dvbapi"  : self.VVwr15("cam.dvbapi")
   elif item == "x_cam_provid"  : self.VVwr15("cam.provid")
   elif item == "x_cam_server"  : self.VVwr15("cam.server")
   elif item == "x_cam_services" : self.VVwr15("cam.services")
   elif item == "x_cam_srvid2"  : self.VVwr15("cam.srvid2")
   elif item == "x_cam_user"  : self.VVwr15("cam.user")
   elif item == "x_SEP"   : pass
   elif item == "x_SoftCam_Key" : self.VV37Og()
   elif item == "x_CCcam_cfg"  : FFdD2h(self, self.VV93cD + "CCcam.cfg")
   elif item == "x_SEP"   : pass
   elif item == "x_cam_log"  : FFdD2h(self, pathTmp + self.prefix + "cam.log")
   elif item == "x_cam_log_prev" : FFdD2h(self, pathTmp + self.prefix + "cam.log-prev")
   elif item == "x_cam_pid"  : FFdD2h(self, pathTmp + self.prefix + "cam.pid")
   else       : self.close()
 def VVwr15(self, fileName):
  FFdD2h(self, self.VV93cD + self.prefix + fileName)
 def VV37Og(self):
  path = self.VV93cD + "SoftCam.Key"
  if fileExists(path) : FFdD2h(self, path)
  else    : FFdD2h(self, path.replace(".Key", ".key"))
class CCqz8v(Screen):
 VV5gOq  = 0
 VV5BOP = 1
 VVGkHi = 2
 def __init__(self, session, VV93cD="", VVUJZY="", VVcZxg="", VVVOLh=VV5gOq):
  self.skin, self.skinParam = FF5TEn(VVjziV, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVcZxg   = VVcZxg
  self.VVVOLh  = VVVOLh
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VV93cD + VVUJZY + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVUJZY : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VV93cD, self.camPrefix)
  if self.VVVOLh == self.VV5gOq:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVVOLh == self.VV5BOP:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FF32Yx(self, self.Title, addScrollLabel=True)
  FFCDDm(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVEWRA
  self.onShown.append(self.VVSDD3)
  self.onClose.append(self.onExit)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  self["myLabel"].VVqlfR(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFieY3(self)
  self.VVEWRA()
 def onExit(self):
  self.timer.stop()
 def VVOLDM(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVYasA)
  except:
   self.timer.callback.append(self.VVYasA)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFycel(self, "Started", 1000)
 def VV4aTq(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVYasA)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFycel(self, "Stopped", 1000)
 def VVEWRA(self):
  if self.timerRunning:
   self.VV4aTq()
  else:
   self.VVOLDM()
   if self.VVVOLh == self.VV5gOq or self.VVVOLh == self.VV5BOP:
    if self.VVVOLh == self.VV5gOq : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCk55e.VVpitz(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFA9HA(self.VVOaQQ)
    else:
     self.close()
   else:
    self.VVB1he()
 def VVYasA(self):
  if self.timerRunning:
   if   self.VVVOLh == self.VV5gOq : self.VVbHzq()
   elif self.VVVOLh == self.VV5BOP : self.VVbHzq()
   else            : self.VVB1he()
 def VVB1he(self):
  if fileExists(self.VVcZxg):
   fTime = FFgCM6(os.path.getmtime(self.VVcZxg))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVZZcv(), VVr0Wh=VVkqNa)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVcZxg)
 def VVOaQQ(self):
  self.VVbHzq()
 def VVbHzq(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFCzRx("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVtz60))
   self.camWebIfErrorFound = True
   self.VV4aTq()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVVOLh == self.VV5gOq : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFCzRx("Error while parsing data elements !\n\nError = %s" % str(e), VVfMEC)
   self.camWebIfErrorFound = True
   self.VV4aTq()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVGy19(root)
  self["myLabel"].setText(txt, VVr0Wh=VVkqNa)
  self["myBar"].setText("Last Update : %s" % FFhvWN())
 def VVGy19(self, rootElement):
  def VVchnh(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVVOLh == self.VV5gOq:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFCzRx(status, VVXF4f)
    else          : status = FFCzRx(status, VVfMEC)
    txt += SEP + "\n"
    txt += VVchnh("Name"  , name)
    txt += VVchnh("Description" , desc)
    txt += VVchnh("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVchnh("Protocol" , protocol)
    txt += VVchnh("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFCzRx("Yes", VVXF4f)
    else    : enabTxt = FFCzRx("No", VVfMEC)
    txt += SEP + "\n"
    txt += VVchnh("Label"  , label)
    txt += VVchnh("Protocol" , protocol)
    txt += VVchnh("Enabled" , enabTxt)
  return txt
 def VVZZcv(self):
  lines = FFSInC("tail -n %d %s" % (100, self.VVcZxg))
  txt   = ""
  for line in lines:
   line = line.strip()
   span = iSearch(r"^[0-9]{4}[-\/][0-9]{2}[-\/][0-9]{2}\s+", line, IGNORECASE)
   if span:
    line = "\n" + VVTKrH + line[:19] + VVzv5p + line[19:]
    for preTxt in (" connecting to ", " from server ", " by ", "reader ", "server ", "(reader) "):
     if preTxt in line:
      if preTxt == " by " and " by WebIf" in line:
       line = line.replace("WebIf", VVCBLl + "WebIf" + VVzv5p)
      else:
       t1, t2, t3 = line.partition(preTxt)
       if t2:
        h1, h2, h3 = t3.partition(" ")
        line = t1 + t2 + VVAaU5 + h1 + h2 + VVzv5p + h3
    span = iSearch(r"(.+:\s*)(found\s*)(\(\d+\s*ms\))(.+)", line, IGNORECASE)
    if span:
     line = "\n" + span.group(1) + VVXF4f + span.group(2) + VV61JF + span.group(3) + VVzv5p + span.group(4)
    line = self.VVMQid(line, VV61JF, ("(webif)", ))
    line = self.VVMQid(line, VV61JF, ("(anticasc)", "(anticasc)", "(cache)", "(cccam)", "(chk)", "(client)", "(config)", "(dvbapi)", "(ecm)", "(emm)", "(emmcache)", "(emu)", "(main)", "(net)", "(newcamd)", "(reader)", "(stat)"))
    line = self.VVMQid(line, VVXF4f, ("OSCam", "NCam", "log switched"))
    line = self.VVMQid(line, VVszO3, (": not found", "failed", "rejected group", "usr/pwd invalid", "timeout", "no matching reader", "disconnected"))
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVRJhR + line[ndx + 3:] + VVzv5p
   elif line.startswith("----") or ">>" in line:
    line = FFCzRx(line, VViypC)
   txt += line + "\n"
  return txt
 def VVMQid(self, line, color, lst):
  for txt in lst:
   if txt in line:
    t1, t2, t3 = line.partition(txt)
    if t2:
     return t1 + color + t2 + VVzv5p + t3
  return line
class CCASgz(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF5TEn(VVL1I3, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVMVqr = []
  VVMVqr.append(("Backup Channels"    , "VVh8YJ"   ))
  VVMVqr.append(("Restore Channels"    , "Restore_Channels"  ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Backup SoftCAM Files"   , "VVTYJC" ))
  VVMVqr.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VVMVqr.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VVMVqr.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Backup Network Settings"  , "VVSDQ0"   ))
  VVMVqr.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VVncAm:
   VVMVqr.append(VVpTvr)
   VVMVqr.append((VVtz60 + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME    , "VVHEZq"   ))
   VVMVqr.append((VVXF4f + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VVx5h4), "createMyIpk"   ))
   VVMVqr.append((VVXF4f + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VVx5h4), "createMyDeb"   ))
   VVMVqr.append((VVAaU5 + "Create %s TAR (Absolute Path)" % PLUGIN_NAME    , "createMyTar"   ))
   VVMVqr.append((VVAaU5 + "Decode %s Crash Report"   % PLUGIN_NAME    , "VVSChR" ))
   VVMVqr.append((VVAaU5 + "Show Windows Stats"           , "VVlw56" ))
  FF32Yx(self, VVMVqr=VVMVqr)
  self.onShown.append(self.VVSDD3)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  FFWzaz(self["myMenu"])
  FF0pG3(self)
 def VVthYm(self):
  global VVBcOf
  VVBcOf = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVh8YJ"    : self.VVh8YJ()
   elif item == "Restore_Channels"    : self.VVwQkL("channels_backup*.tar.gz", self.VVbpPA, isChan=True)
   elif item == "VVTYJC"   : self.VVTYJC()
   elif item == "Restore_SoftCAM_Files"  : self.VVwQkL("softcam_backup*.tar.gz", self.VVEo8U)
   elif item == "Backup_TunerDiSEqC"   : self.VVRW6B("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVwQkL("tuner_backup*.backup", BF(self.VVTxhP, "tuner"), isTuner=True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVRW6B("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVwQkL("hotkey_*backup*.backup", BF(self.VVTxhP, "misc"))
   elif item == "VVSDQ0"    : self.VVSDQ0()
   elif item == "Restore_Network"    : self.VVwQkL("network_backup*.tar.gz", self.VVGsHy)
   elif item == "VVHEZq"     : FFo4dm(self, BF(FFzW1w, self, BF(CCASgz.VVHEZq, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVReoG(False)
   elif item == "createMyDeb"     : self.VVReoG(True)
   elif item == "createMyTar"     : self.VVOZYV()
   elif item == "VVSChR"   : self.VVSChR()
   elif item == "VVlw56"    : CCASgz.VVlw56(self)
 @staticmethod
 def VVqAjj(SELF):
  OBF_Path = VV0gUf + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try: from .OBF import obf
   except: import obf
   reload(obf)
   return obf
  else:
   FFZ5Ys(SELF, OBF_Path)
   return None
 @staticmethod
 def VVlw56(SELF):
  obf = CCASgz.VVqAjj(SELF)
  if obf:
   txt, title = obf.windowsStats()
   FFtybv(SELF, txt, title=title, outputFileToSave="WinStat")
 @staticmethod
 def VVHEZq(SELF):
  obf = CCASgz.VVqAjj(SELF)
  if obf:
   txt, err = obf.fixCode(VV0gUf, VVAnTo, VVx5h4)
   if err : FFzrXb(SELF, err)
   else : FFtybv(SELF, txt)
 def VVReoG(self, VV6sgm):
  OBF_Path = VV0gUf + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFzrXb(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  FFgSm7("rm -f %s__pycache__/" % VV0gUf)
  FFgSm7("mv -f '%smain.py' '%s'" % (VV0gUf, OBF_Path))
  FFgSm7("mv -f '%splugin.py' '%s'" % (VV0gUf, OBF_Path))
  FFgSm7("cp -f %s*main_final.py %splugin.py" % (OBF_Path, VV0gUf))
  self.session.openWithCallback(self.VVNvJG, BF(CCfeee, path=VV0gUf, VV6sgm=VV6sgm))
 def VVNvJG(self):
  FFgSm7("mv -f %s %s" % (VV0gUf + "OBF/main.py" , VV0gUf))
  FFgSm7("mv -f %s %s" % (VV0gUf + "OBF/plugin.py", VV0gUf))
 def VVSChR(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFzrXb(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFzrXb(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVcyFG("%s*.list" % path)
  if err:
   FFZ5Ys(self, path + "*.list")
   return
  srcF, err = self.VVcyFG("%s*main_final.py" % path)
  if err:
   FFZ5Ys(self, path + "*.final.py")
   return
  VVWsIU = []
  for f in files:
   f = os.path.basename(f)
   VVWsIU.append((f, f))
  FF7ARM(self, BF(self.VV8SLn, path, codF, srcF), VVMVqr=VVWsIU)
 def VV8SLn(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFZ5Ys(self, logF)
   else     : FFzW1w(self, BF(self.VVtnOu, logF, codF, srcF))
 def VVtnOu(self, logF, codF, srcF):
  lst  = []
  lines = FF2WPS(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FFzrXb(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVrgt8(lst, logF, newLogF)
  totSrc  = self.VVrgt8(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFtybv(self, txt)
 def VVcyFG(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVrgt8(self, lst, f1, f2):
  txt = FFpCvR(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVOZYV(self):
  VVWsIU = []
  VVWsIU.append("%s%s" % (VV0gUf, "*.py"))
  VVWsIU.append("%s%s" % (VV0gUf, "*.png"))
  VVWsIU.append("%s%s" % (VV0gUf, "*.xml"))
  VVWsIU.append("%s"  % (VVLS8v))
  FFguuW(self, VVWsIU, "%s_%s" % (PLUGIN_NAME, VVAnTo), addTimeStamp=False)
 def VVh8YJ(self):
  path1 = VVTAUs
  path2 = "/etc/tuxbox/"
  VVWsIU = []
  VVWsIU.append("%s%s" % (path1, "*.tv"))
  VVWsIU.append("%s%s" % (path1, "*.radio"))
  VVWsIU.append("%s%s" % (path1, "*list"))
  VVWsIU.append("%s%s" % (path1, "lamedb*"))
  VVWsIU.append("%s%s" % (path2, "*.xml"))
  FFguuW(self, VVWsIU, self.VV1JOw("channels_backup"), addTimeStamp=True)
 def VVTYJC(self):
  VVWsIU = []
  VVWsIU.append("/etc/tuxbox/config/")
  VVWsIU.append("/usr/keys/")
  VVWsIU.append("/usr/scam/")
  VVWsIU.append("/etc/CCcam.cfg")
  FFguuW(self, VVWsIU, self.VV1JOw("softcam_backup"), addTimeStamp=True)
 def VVSDQ0(self):
  VVWsIU = []
  VVWsIU.append("/etc/hostname")
  VVWsIU.append("/etc/default_gw")
  VVWsIU.append("/etc/resolv.conf")
  VVWsIU.append("/etc/wpa_supplicant*.conf")
  VVWsIU.append("/etc/network/interfaces")
  VVWsIU.append("%snameserversdns.conf" % VVTAUs)
  FFguuW(self, VVWsIU, self.VV1JOw("network_backup"), addTimeStamp=True)
 def VV1JOw(self, fName):
  img = CCIdnp.VVLVvZ()
  if img: fName = "%s_%s" % (fName, img)
  return fName
 def VVbpPA(self, fileName=None):
  if fileName:
   FFo4dm(self, BF(FFzW1w, self, BF(self.VVbRxt, fileName), title="Restoring ..."), "Overwrite current channels ?")
 def VVbRxt(self, fileName):
  path = "%s%s" % (VVYfYu, fileName)
  if fileExists(path):
   if CCUGPF.VV594T(path):
    VVxkAm , VVLjas = CCh3Pq.VVqy0g()
    VVLX4p, VVFNX5 = CCh3Pq.VVIHcs()
    cmd  = FFgeXp("cd %s" % VVTAUs)
    cmd += FFgeXp("rm -f *.tv *.radio *.del lamedb* whitelist blacklist satellites.xml %s %s" % (VVLjas, VVFNX5))
    cmd += "tar -xzf '%s' -C /" % path
    ok = FFgSm7(cmd)
    FFwQUx()
    if ok: FFuXZg(self, "Channels Restored.")
    else : FFzrXb(self, "Error while restoring:\n\n%s" % fileName)
   else:
    FFzrXb(self, "Invalid tar file:\n\n%s" % path)
  else:
   FFZ5Ys(self, path)
 def VVEo8U(self, fileName=None):
  if fileName:
   FFo4dm(self, BF(self.VV81tp, fileName), "Overwrite SoftCAM files ?")
 def VV81tp(self, fileName):
  fileName = "%s%s" % (VVYfYu, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % SEP
   note = "You may need to restart your SoftCAM."
   FFr7wJ(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFC7pV(note, VVRJhR), sep))
  else:
   FFZ5Ys(self, fileName)
 def VVGsHy(self, fileName=None):
  if fileName:
   FFo4dm(self, BF(self.VVUm1d, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVUm1d(self, fileName):
  fileName = "%s%s" % (VVYfYu, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFHguD(self,  cmd)
  else:
   FFZ5Ys(self, fileName)
 def VVwQkL(self, pattern, callBackFunction, isTuner=False, isChan=False):
  title = FFcYIL()
  if pathExists(VVYfYu):
   myFiles = FFY7QR(VVYfYu, pattern)
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVWsIU = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVWsIU.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if   isTuner  : VVYJ07 = ("Sat. List", self.VVppYd)
    elif isChan and iTar: VVYJ07 = ("Bouquets Importer", CCxlZC.VVd4AI)
    else    : VVYJ07 = None
    FF7ARM(self, callBackFunction, title=title, width=1200, VVMVqr=VVWsIU, VVYJ07=VVYJ07, VVYpxU=VVYfYu)
   else:
    FFzrXb(self, "No files found in:\n\n%s" % VVYfYu, title)
  else:
   FFzrXb(self, "Path not found:\n\n%s" % VVYfYu, title)
 def VVRW6B(self, filePrefix, wordsFilter):
  title = FFcYIL()
  if fileExists(VVrs06):
   tCons = CCG9Bk()
   tCons.ePopen("cat %s | grep '%s'" % (VVrs06, wordsFilter), BF(self.VVpGxb, title, filePrefix))
  else:
   FFzrXb(self, "Cannot read settings file", title)
 def VVpGxb(self, title, filePrefix, result, retval):
  if pathExists(VVYfYu):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFzrXb(self, "No settings found to backup !", title)
   else:
    fName = "%s%s%s_%s.backup" % (VVYfYu, filePrefix, self.VV1JOw(""), FF4rM4())
    try:
     VVWsIU = str(result.strip()).split()
     if VVWsIU:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVWsIU:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (SEP, FFCzRx(fName, VVRJhR), SEP)
       FFtybv(self, txt, title=title, VVr0Wh=VVkqNa)
      else:
       FFzrXb(self, "File creation failed!", title)
     else:
      FFzrXb(self, "Parameters not found in settings file.", title)
    except IOError as e:
     FFgSm7("rm %s" % fName)
     FFzrXb(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     FFgSm7("rm %s" % fName)
     FFzrXb(self, "Error while writing file.")
  else:
   FFzrXb(self, "Path not found:\n\n%s" % VVYfYu, title)
 def VVTxhP(self, mode, path=None):
  if path:
   path = "%s%s" % (VVYfYu, path)
   if fileExists(path):
    lines = FF2WPS(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FFo4dm(self, BF(self.VVDWG2, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FFYO45(self, path, title=FFcYIL())
   else:
    FFZ5Ys(self, path)
 def VVDWG2(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  finalList = []
  for line in newList:
   if line.strip() and not line in finalList:
    finalList.append(line)
  VVEkBF = []
  tFile = "/tmp/ajp_tmp"
  VVEkBF.append("echo -e 'Reading current settings ...'")
  VVEkBF.append("cat %s | grep -v '%s' > %s" % (VVrs06, grepFilter, tFile))
  settingsLines = "echo -e '"
  for line in finalList:
   settingsLines += line
  settingsLines = settingsLines.strip()
  settingsLines += "' >> %s" % tFile
  VVEkBF.append("echo -e 'Preparing new settings ...'")
  VVEkBF.append(settingsLines)
  VVEkBF.append("echo -e 'Applying new settings ...'")
  VVEkBF.append("mv -f %s %s" % (tFile, VVrs06))
  FFVT5b(self, VVEkBF)
 def VVppYd(self, selectionObj, path):
  if not path:
   return
  path = VVYfYu + path
  if not fileExists(path):
   FFZ5Ys(self, path)
   return
  txt = FFpCvR(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   txt = ""
   for item in satList:
    txt += "%s\t%s\n" % (item[0], FFZbc3(item[1]))
   FFtybv(self, txt, title="Satellites List")
  else:
   FFzrXb(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCxlZC():
 def __init__(self, SELF):
  self.SELF   = SELF
  self.Title   = "Bouquets Importer"
  self.fileName  = ""
  self.filePath  = ""
  self.instance  = None
  self.isZip   = False
 @staticmethod
 def VVd4AI(SELF, fName):
  bi = CCxlZC(SELF)
  bi.instance = bi
  bi.VVE2vo(SELF, fName)
 @staticmethod
 def VVckjm(SELF):
  bi = CCxlZC(SELF)
  bi.instance = bi
  bi.VVrbXq()
 def VVE2vo(self, waitObg, fName):
  self.fileName = fName
  self.filePath = VVYfYu + fName
  self.isZip   = fName.endswith(".zip")
  if fileExists(self.filePath): FFzW1w(waitObg, self.VVrj4D, title="Reading bouquets ...")
  else      : self.VViXrF(self.filePath)
 def VVvL0a(self, txt) : FFzrXb(self.SELF, txt, title=self.Title)
 def VVx3z3(self, txt)  : FFycel(self, txt, 1500)
 def VViXrF(self, path) : FFZ5Ys(self.SELF, path, title=self.Title)
 def VVrbXq(self):
  if pathExists(VVYfYu):
   lst = FFY7QR(VVYfYu, "channels_backup*.tar.gz")
   if iZip: lst.extend(self.VVRVlU())
   if len(lst) > 0:
    VVMVqr = []
    for item in lst:
     item = os.path.basename(item)
     txt = FFCzRx(item, VV61JF) if item.endswith(".zip") else item
     VVMVqr.append((txt, item))
    VVMVqr.sort(key=lambda x: x[1].lower())
    VVmKhE = self.VVPwc0
    FF7ARM(self.SELF, self.VVpWDx, minRows=3, title=self.Title, width=1200, VVMVqr=VVMVqr, VVmKhE=VVmKhE, VVYpxU=VVYfYu, VVZYdg="#22111111", VVcwfs="#22111111")
   else:
    self.VVvL0a("No valid backup files found in:\n\n%s" % VVYfYu)
  else:
   self.VVvL0a("Backup Directory not found:\n\n%s" % VVYfYu)
 def VVPwc0(self, item=None):
  if item:
   VVdtUh, txt, fName, ndx = item
   self.VVE2vo(VVdtUh, fName)
 def VVpWDx(self, item=None):
  if not item and self.instance:
   del self.instance
 def VVRVlU(self):
  files = FFY7QR(VVYfYu, "*.zip")
  lst = []
  for path in files:
   bakFile = os.path.basename(path)
   with iZip.ZipFile(path) as zipF:
    dbFound = bFound = False
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     if fName == "lamedb" : dbFound = True
     if fName.endswith(".tv"): bFound = True
     if dbFound and bFound:
      lst.append(bakFile)
      break
  return lst
 def VVrj4D(self):
  lines, err = CCxlZC.VV0PJG(self.filePath, "bouquets.tv")
  if err:
   self.VVvL0a(err)
   return
  bTvSortLst  = self.VVvY8W(lines)
  lines, err = CCxlZC.VV0PJG(self.filePath, "bouquets.radio")
  if err:
   self.VVvL0a(err)
   return
  bRadSortLst = self.VVvY8W(lines)
  VVpn2v = []
  subBouquets = {}
  if self.filePath.endswith(".zip"):
   with iZip.ZipFile(self.filePath) as zipF:
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      with zipF.open(zipInfo.filename) as f:
       row, bnbLst, err = self.VVMf5P(f, mode, len(VVpn2v), zipInfo.filename, False)
       if err:
        return
       tName = os.path.basename(row[9])
       if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
       elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
       VVpn2v.append(row)
       parent = zipInfo.filename
       lst = []
       for fPath in bnbLst:
        for zipInfo in zipF.infolist():
         fName = os.path.basename(zipInfo.filename)
         if fName == fPath:
          with zipF.open(zipInfo.filename) as f:
           row, bnbLst, err = self.VVMf5P(f, mode, len(VVpn2v), zipInfo.filename, True)
           if err:
            return
           lst.append(row)
       if lst:
        subBouquets[tName] = lst
  else:
   with iTar.open(self.filePath) as tar:
    for mem in tar.getmembers():
     fName = os.path.basename(mem.name)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      f = tar.extractfile(mem)
      row, bnbLst, err = self.VVMf5P(f, mode, len(VVpn2v), mem.name, False)
      if err:
       return
      tName = os.path.basename(row[9])
      if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
      elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
      VVpn2v.append(row)
      parent = mem.name
      lst = []
      for fPath in bnbLst:
       for mem in tar.getmembers():
        fName = os.path.basename(mem.name)
        if fName == fPath:
         f = tar.extractfile(mem.name)
         row, bnbLst, err = self.VVMf5P(f, mode, len(VVpn2v), mem.name, True)
         if err:
          return
         lst.append(row)
      if lst:
       subBouquets[tName] = lst
  if VVpn2v:
   VVpn2v.sort(key=lambda x: int(x[0]))
   for ndx, item in enumerate(VVpn2v): VVpn2v[ndx][0] = str(ndx + 1)
   for key, lst in subBouquets.items():
    for ndx, row in enumerate(VVpn2v):
     if key == os.path.basename(row[9]):
      VVpn2v = VVpn2v[:ndx+1] + lst + VVpn2v[ndx+1:]
      break
   for ndx, item in enumerate(VVpn2v): VVpn2v[ndx][0] = str(ndx + 1)
   VVLuY4 = "#11000600"
   VVd479  = ("Show Services" , self.VV8mtF  , [], "Reading ..." )
   VV1Jd7 = (""    , self.VVTsu2, [])
   VV7J8f = ("Options"  , self.VVE7Uw, []    )
   header   = ("Num" , "Bouquet Name", "Mode", "Items" , "DVB" , "IPTV", "S.Relay" , "Local" , "Marker" , "Bouquet" , "File")
   widths   = (7  , 36   , 7  , 7   , 7  , 7  , 7   , 7   , 7   , 8   ,  0.01 )
   VViqYN  = (CENTER , LEFT   , CENTER, CENTER , CENTER, CENTER, CENTER , CENTER , CENTER , CENTER ,  LEFT )
   FFldB6(self.SELF, None, title=self.Title, header=header, VVWsIU=VVpn2v, VViqYN=VViqYN, VVv3Wm=widths, VVHZHw=24, VVd479=VVd479, VV1Jd7=VV1Jd7, VV7J8f=VV7J8f, searchCol=1, lastFindConfigObj=CFG.lastFindServers
     , VVZYdg=VVLuY4, VVcwfs=VVLuY4, VVLuY4=VVLuY4, VVG27K="#00004455", VVQ9hc="#0a282828")
  else:
   self.VVvL0a("No valid bouquets in:\n\n%s" % self.filePath)
 def VVvY8W(self, lines):
  lst = []
  for line in lines:
   span = iSearch(r".+(userbouquet\..+\.(tv|radio))", line, IGNORECASE)
   if span:
    lst.append(span.group(1))
  return lst
 def VVTsu2(self, VVoLtS, title, txt, colList):
  FFtybv(self.SELF, FFQdrB(txt), title=title)
 def VVE7Uw(self, VVoLtS, title, txt, colList):
  mSel = CC74Cn(self.SELF, VVoLtS)
  if VVoLtS.VVzBSi:
   totSel = VVoLtS.VVv3mu()
   if totSel: VVMVqr = [("Import %s Bouquet%s" % (FFCzRx(str(totSel), VVXF4f), FFoTxy(totSel)), "imp")]
   else  : VVMVqr = [("Import Bouquet (nothing selected)", )]
  else:
   bName = colList[1]
   if len(bName) > 40: bName = bName[:40] + " .."
   bName = FFCzRx(bName, VVXF4f)
   VVMVqr = [("Import Selected Bouquet : %s" % bName, "imp")]
  cbFncDict = {"imp": BF(FFzW1w, VVoLtS, BF(CCxlZC.VVBMuE, self.SELF, VVoLtS, self.filePath))}
  mSel.VVKonP(VVMVqr, cbFncDict)
 def VV8mtF(self, VVoLtS, title, txt, colList):
  err = ""
  if fileExists(self.filePath):
   lines, err = CCxlZC.VV0PJG(self.filePath, "lamedb")
   if err:
    self.VVvL0a(err)
    return
   dbServLst = CCh3Pq.VVM6w4(lines, mode=10)
   num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName = VVoLtS.VVkHbA()
   lines, err = CCxlZC.VV0PJG(self.filePath, os.path.basename(fName))
   if err:
    self.VVvL0a(err)
    return
   VVpn2v = []
   bnbFound = False
   for line in lines:
    if line.startswith("#SERVICE "):
     span = iSearch(r"1:64:(?:[A-Fa-f0-9]+:){8}:(.+)", line, IGNORECASE)
     if span:
      VVpn2v.append((span.group(1).strip(), "Marker"))
     else:
      span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
      if span:
       VVpn2v.append((span.group(1) or "-", "Sub-Bouquet"))
       bnbFound = True
      else:
       span = iSearch(r"(?:[A-Fa-f0-9]+:){10}http.+:(.+)", line)
       if span:
        VVpn2v.append((span.group(1).strip() or "-", "Stream Relay" if FFYKlk(line) else "IPTV"))
       else:
        span = iSearch(r"(?:[A-Fa-f0-9]+:){10}(\/.+)", line)
        if span:
         VVpn2v.append((os.path.basename(span.group(1).strip() or "-"), "Local Media"))
        else:
         span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
         if span:
          VVpn2v.append((span.group(1) or "-", "Sub-Bouquet"))
          bnbFound = True
         else:
          span = iSearch(r"((?:[A-Fa-f0-9]+:){10})(?:$|:.+)", line)
          if span:
           dbCode = CCh3Pq.VV3ySm(span.group(1))
           for dbCode1, name, prov in dbServLst:
            if dbCode1.upper() in dbCode:
             VVpn2v.append((name.strip() or "-", FFKMDj(span.group(1), False)))
             break
   if bnbFound:
    for ndx, item in enumerate(VVpn2v):
     name, descr = item
     if iMatch(r".+\..+\.tv", name, IGNORECASE):
      lines, err = CCxlZC.VV0PJG(self.filePath, os.path.basename(name))
      if lines and not err:
       span = iSearch(r"#NAME\s+(.+)", lines[0], IGNORECASE)
       if span:
        bName = span.group(1).strip()
        if bName:
         VVpn2v[ndx] = (bName, descr)
   if VVpn2v:
    VVLuY4 = "#11001122"
    bName = iSub(r"\s{4,}" ," .. " , bName)
    header  = ("Service", "Type")
    widths  = (80  , 20 )
    VViqYN = (LEFT  , CENTER)
    FFldB6(self.SELF, None, title="Services in : %s" % bName, header=header, VVWsIU=VVpn2v, VViqYN=VViqYN, VVv3Wm=widths, VVHZHw=28, VVZYdg=VVLuY4, VVcwfs=VVLuY4, VVLuY4=VVLuY4, lastFindConfigObj=CFG.lastFindServers)
   else:
    err = "No valid services !"
  else:
   err = "Cannot open file !"
  if err : FFycel(VVoLtS, err, 1500)
  else : VVoLtS.VV6eCK()
 def VVMf5P(self, f, mode, sequence, fPath, isSubB):
  bName = ""
  totItem = totDVB = totMrk = totBnb = totIptv = totSRelay = totLoc = 0
  bnbLst = []
  for line in f:
   try:
    line = str(line.decode()).strip()
   except:
    self.VVvL0a("Encoding Error in the archived file:\n\n%s" % fPath)
    return [], [], "File Encoding Error"
   if line.startswith("#SERVICE "):
    totItem +=1
    if   iMatch(r".+1:64:(?:[A-Fa-f0-9]+:){8}:.+", line)      : totMrk += 1
    elif iMatch(r".+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET.+", line, IGNORECASE) :
     totBnb += 1
     span = iSearch(r'.+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET\s+"(.+)".+', line)
     if span:
      bnbLst.append(span.group(1))
    elif FFYKlk(line)             : totSRelay += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}http.+:.+", line, IGNORECASE)   : totIptv += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}\/.+", line)       : totLoc += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}(?:$|:.+)", line)      : totDVB += 1
   elif line.startswith("#NAME "):
    bName = line[6:]
  def VVulVX(var):
   return str(var) if var else VVHQpO + str(var)
  totItem = VVRJhR + str(totItem)
  bMode = "TV" if mode == "tv" else "Radio"
  if   totBnb : bColor, totBnb  = VVtz60   , str(totBnb)
  elif isSubB : bColor, totBnb  = VV61JF, "Sub-B."
  else  : bColor, totBnb = ""      , VVulVX(totBnb)
  row = [str(2000001 + sequence), bColor + bName, bMode, totItem, VVulVX(totDVB), VVulVX(totIptv), VVulVX(totSRelay), VVulVX(totLoc), VVulVX(totMrk), totBnb, fPath]
  return row, bnbLst, ""
 @staticmethod
 def VVBMuE(SELF, VVoLtS, archPath):
  title = "Import Bouquets"
  tvBouquetFile = VVTAUs + "bouquets.tv"
  radBouquetFile = VVTAUs + "bouquets.radio"
  if not fileExists(tvBouquetFile):
   FFZ5Ys(SELF, tvBouquetFile, title=title)
   return
  elif not fileExists(radBouquetFile):
   FFZ5Ys(SELF, radBouquetFile, title=title)
   return
  isMulti = VVoLtS.VVzBSi
  if isMulti : rows = VVoLtS.VV3z03()
  else  : rows = [VVoLtS.VVkHbA()]
  for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
   if totBnb.isdigit():
    FFzrXb(SELF, "Cannot import Sub-Bouquets from:\n\n%s" % FFQdrB(bName), title=title)
    return
  bList = []
  totAllServ = 0
  if fileExists(archPath):
   for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
    totAllServ += int(FFQdrB(totItem))
    newFile = os.path.basename(fName)
    span = iSearch(r".+\.(.+)\.(tv|radio)", newFile, IGNORECASE)
    if span : fNamePart, fNameExt = span.group(1), span.group(2)
    else : fNamePart, fNameExt = "bouquet", "tv"
    newFile = "userbouquet.%s.%s" % (fNamePart, fNameExt)
    bPath = VVTAUs + newFile
    num  = 0
    while fileExists(bPath):
     num += 1
     newFile = "userbouquet.%s_%d.%s" % (fNamePart, num, fNameExt)
     bPath = VVTAUs + newFile
    CCxlZC.VVhIRK(archPath, fName, VVTAUs, newFile)
    if fileExists(bPath):
     bList.append(newFile)
  totTP = totServ = totTv = totRad = totMissTP = totMissServ = 0
  if bList:
   FFElys(tvBouquetFile)
   FFElys(radBouquetFile)
   for bFile in bList:
    if bFile.endswith("tv") : mainBFile, totTv = tvBouquetFile , totTv  + 1
    else     : mainBFile, totRad = radBouquetFile, totRad + 1
    with open(mainBFile, "a") as f:
     f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
   totTP, totServ, totMissTP, totMissServ = CCxlZC.VVRstM(SELF, archPath, bList)
   FFwQUx()
  txt  = FFCzRx("Added:\n", VV61JF)
  txt += "Bouquets\t: %d     (%d TV , %d Radio)\n" % (len(bList), totTv, totRad)
  txt += "Services\t: %d\n" % totAllServ
  if totTP or totServ:
   txt += "\n"
   txt += FFCzRx("Imported to lamedab:\n", VV61JF)
   if totTP : txt += "Transponders\t: %d\n" % totTP
   if totServ : txt += "Services\t: %d\n"  % totServ
  if totMissTP or totMissServ:
   txt += "\n"
   txt += FFCzRx("Missing from archived lamedb:\n", VVtz60)
   if totMissTP : txt += "Transponders\t: %d\n" % totMissTP
   if totMissServ : txt += "Services\t: %d"  % totMissServ
  FFtybv(SELF, txt, title=title, width=1000)
 @staticmethod
 def VVRstM(SELF, archPath, bList):
  VVxkAm, err = CCh3Pq.VV7Ps5(SELF, VVLya0=False)
  if err:
   return 0, 0, 0, 0
  dbServIDs = CCh3Pq.VVYr4K(VVxkAm, mode=11)
  if not dbServIDs:
   return 0, 0, 0, 0
  newDbTpIDs  = []
  newDbServIDs = []
  for bFile in bList:
   lines = FF2WPS(VVTAUs + bFile)
   for line in lines:
    span = iSearch(r"((?:[A-Fa-f0-9]+:){10}$)", line, IGNORECASE)
    if span:
     refCode = span.group(1)
     dbCode = CCh3Pq.VV3ySm(refCode)
     if not dbCode in dbServIDs:
      newDbServIDs.append(dbCode)
      tpID = CCh3Pq.VVzp7h(refCode)
      if not tpID in newDbTpIDs:
       newDbTpIDs.append(tpID)
  dbServIDs = None
  tFile = ""
  if newDbServIDs and fileExists(archPath):
   dbName = "lamedb"
   tFile = "/tmp/%s.tmp" % dbName
   fName = CCxlZC.VVAOGf(archPath, dbName)
   CCxlZC.VVhIRK(archPath, fName, "/tmp/", dbName + ".tmp")
  newTPLines = []
  if newDbTpIDs:
   for item in CCh3Pq.VVYr4K(tFile, mode=0):
    if item[0].upper() in newDbTpIDs:
     newTPLines.append(item)
  newServLines = []
  for item in CCh3Pq.VVYr4K(tFile, mode=10):
   if item[0].upper() in newDbServIDs:
    newServLines.append(item)
  dbCodeLst = CCh3Pq.VVYr4K(tFile, mode=1)
  totMissTP = 0
  for dbCode in newDbTpIDs:
   if not dbCode in dbCodeLst:
    totMissTP += 1
  dbCodeLst = CCh3Pq.VVYr4K(tFile, mode=11)
  totMissServ = 0
  for dbCode in newDbServIDs:
   if not dbCode in dbCodeLst:
    totMissServ += 1
  FFnPMX(tFile)
  totServ = totTP = 0
  if newDbTpIDs or newServLines:
   isServ = isTP = False
   tmpDbFile = VVxkAm + ".tmp"
   lines   = FF2WPS(VVxkAm)
   with open(tmpDbFile, "w") as f:
    for line in lines:
     sLine = line.strip()
     if   sLine == "transponders": isTP, isServ = True, False
     elif sLine == "services" : isTP, isServ = False, True
     elif sLine == "end":
      if isTP:
       for item in (newTPLines):
        totTP += 1
        for L in item:
         f.write(L + "\n")
      elif isServ:
       for item in (newServLines):
        totServ += 1
        for L in item:
         f.write(L + "\n")
     f.write(line + "\n")
   FFgSm7("mv -f '%s' '%s'" % (tmpDbFile, VVxkAm))
  return totTP, totServ, totMissTP, totMissServ
 @staticmethod
 def VV3gsl(path):
  lst = []
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     lst.append(os.path.basename(zipInfo.filename), zipInfo.filename)
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     lst.append(os.path.basename(mem.name), mem.name)
  return lst
 @staticmethod
 def VVAOGf(path, baseName):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     if os.path.basename(zipInfo.filename) == baseName:
      return zipInfo.filename
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     if os.path.basename(mem.name) == baseName:
      return mem.name
  return ""
 @staticmethod
 def VVhIRK(path, fName, newPath, newFile):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    zipInfo = zipF.getinfo(fName)
    zipInfo.filename = newFile
    zipF.extract(zipInfo, newPath)
  else:
   with iTar.open(path) as tar:
    mem = tar.getmember(fName)
    mem.name = newFile
    tar.extract(mem, path=newPath)
 @staticmethod
 def VV0PJG(path, subFile):
  lines = []
  try:
   if path.endswith(".zip"):
    with iZip.ZipFile(path) as zipF:
     for zipInfo in zipF.infolist():
      fName = os.path.basename(zipInfo.filename)
      if fName == subFile:
       with zipF.open(zipInfo.filename) as f:
        lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   else:
    with iTar.open(path) as tar:
     for mem in tar.getmembers():
      fName = os.path.basename(mem.name)
      if fName == subFile:
       f = tar.extractfile(mem)
       lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   return [str(x.strip()) for x in lines], ""
  except:
   return [], "Error while reading the archived file:\n\n%s" % subFile
class CCOkaf():
 def __init__(self):
  self.projTitle   = "Package Creator"
  self.projPrefix   = "ajpanel_package_"
  self.projMainPath  = CFG.packageOutputPath.getValue()
  self.projName   = ""
  self.projPath   = ""
  self.projFile   = ""
  self.projMenu   = None
  self.projTable   = None
  self.projFile_control = ""
  self.projFile_preRm  = ""
  self.projFile_postRm = ""
  self.projFile_preInst = ""
  self.projFile_postInst = ""
  self.projLastDepends = ""
  self.VVcinJ()
 def VVcinJ(self):
  self.projPkg   = ""
  self.projVer   = ""
  self.projArch   = ""
  self.projFilesSize  = 0
  self.projTotalDirs  = 0
  self.projTotalFiles  = 0
  self.projAct_postInst = 0
  self.projAct_postRm  = 0
 def VVfAbk(self):
  FFzW1w(self, self.VVv0We)
 def VVv0We(self):
  if pathExists(self.projMainPath):
   lst = FFDdst(self.projMainPath)
   VVMVqr = []
   if lst:
    for path in lst:
     if path.startswith(self.projPrefix):
      prName = os.path.basename(path)
      VVMVqr.append((prName, prName))
   if VVMVqr:
    VVMVqr.sort(key=lambda x: x[1].lower())
    VVmKhE = self.VVbpxM
    VVYJ07 = ("Add new project", self.VVHty2)
    VV0afn= ("Delete Project" , self.VVosNL)
    self.projMenu = FF7ARM(self, None, VVMVqr=VVMVqr, width=1100, VVmKhE=VVmKhE, VVYJ07=VVYJ07, VV0afn=VV0afn, minRows=5, VVZYdg="#22111133", VVcwfs="#22111133")
   else:
    FFo4dm(self, self.VV1yBZ, "No projects found !\n\n Create new project ?", title=self.projTitle)
  else:
   self.VVTWYk("Main Packages Directory not found:\n\n%s" % self.projMainPath)
 def VV1yBZ(self)    : FFzW1w(self, BF(self.VVk8ep))
 def VVHty2(self, VVdtUh, item) : FFzW1w(self.projMenu, BF(self.VVk8ep))
 def VVk8ep(self):
  c = 0
  while True:
   c += 1
   name = "project_%d" % (c)
   if not pathExists("%s%s%s" % (self.projMainPath, self.projPrefix, name)):
    break
  self.VVQDuk(name)
 def VVQDuk(self, name, cbFnc=None):
  FFBgSg(self, cbFnc or self.VV3owj, defaultText=name, title="New Project Name", message="Enter project name")
 def VV3owj(self, name):
  if name and name.strip():
   path = "%s%s%s" % (self.projMainPath, self.projPrefix, name)
   if pathExists(path):
    FFo4dm(self, BF(self.VVQDuk, name), "Project directory already exists !\n\n Change name ?", title=self.projTitle)
   else:
    err = FFRUn5(path)
    if err:
     self.VVTWYk("Cannot create project directory !\n\n %s" % err)
    else:
     item = os.path.basename(path)
     if self.projMenu: self.projMenu.VVe40s((item, item), isSort=True)
     else   : self.VVfAbk()
 def VVosNL(self, VVdtUh, path):
  if path:
   path = self.projMainPath + path
   if pathExists(path):
    totDir, totFile, totLink = FFTsWT(path)
    FFo4dm(self, BF(self.VV3PBR, path), "Project directory contains %d items.\n\n%s\n\nDelete ?" %(totDir + totFile + totLink, path), title=self.projTitle)
 def VV3PBR(self, path):
  if FFgSm7("rm -rf '%s'" % path):
   self.projMenu.VVsFUY()
 def VVbpxM(self, item=None):
  if item:
   VVdtUh, txt, Dir, ndx = item
   self.VVcinJ()
   self.projName = os.path.basename(Dir)[len(self.projPrefix):]
   self.projPath = "%s%s/" % (self.projMainPath, Dir)
   self.projFile = "%s%s.cfg"  % (self.projPath, self.projName)
   self.projFile_control = self.projPath + "control"
   self.projFile_preRm  = self.projPath + "prerm"
   self.projFile_postRm = self.projPath + "postrm"
   self.projFile_preInst = self.projPath + "preinst"
   self.projFile_postInst = self.projPath + "postinst"
   tmplF = "%sajpanel_pkg" % VVLS8v
   if not fileExists(self.projFile_control) and fileExists(tmplF):
    pkg = iSub(r"([^\x00-\x7F]+)", r"_", self.projName, flags=IGNORECASE).lower()
    with open(self.projFile_control, "w") as f:
     for line in FF2WPS(tmplF, keepends=True):
      f.write(line.replace("xx1", pkg).replace("xx2", self.projName))
   if not fileExists(self.projFile):
    with open(self.projFile, "w") as f:
     sep = "#" * 80
     f.write("%s\n" % sep)
     f.write("%s Project\t: %s\n" % ("#", self.projName))
     f.write("%s Started\t: %s\n" % ("#", FFhvWN()))
     f.write("%s\n" % sep)
   if fileExists(self.projFile): self.VVjg5a()
   else      : self.VVTWYk("Cannot create project file:\n\n%s" % self.projFile)
 def VVjg5a(self, VVdtUh=None, jmpDict=None):
  FFzW1w(VVdtUh or self.projTable or self, BF(self.VVAzXZ, jmpDict))
 def VVAzXZ(self, jmpDict):
  self.VVcinJ()
  pkgRows, ctrlRows, actnRows, fileRows, unknRows = [], [], [], [], []
  if fileExists(self.projFile_control):
   for lineNdx, line in enumerate(FF2WPS(self.projFile_control)):
    line = line.strip()
    if ":" in line:
     subj, val, rem = self.VVLuSp(line)
     pkgRows.append((str(lineNdx), "Control", subj, val, "", rem, ""))
  if not pkgRows:
   self.VVTWYk('Invalid "control" file:\n\n%s' % self.projFile_control)
   return
  for path in (self.projFile_preInst, self.projFile_postInst, self.projFile_preRm, self.projFile_postRm):
   size = val = ""
   if fileExists(path):
    val = path
    sz = FFPLWs(path)
    if sz > -1: size = CCUGPF.VVuy4U(sz, mode=4)
    else   : size = FFCzRx("Size error", VVtz60)
   ctrlRows.append(("", "Script", os.path.basename(path), val, size, "", ""))
  for lineNdx, line in enumerate(FF2WPS(self.projFile)):
   lineNdx = str(lineNdx)
   line = line.strip()
   if line and not line.startswith("#"):
    validF = size = rem = ""
    if line.startswith("/"):
     path, fName, typ, size, rem, validF = self.VVEKwU(line, fileRows)
     fileRows.append((lineNdx, "Resource", typ or "Unknown", path, size, rem, validF))
    else:
     Title, val = self.VVIUhj(line)
     if Title: actnRows.append((lineNdx, "Action", Title, val, size, rem, validF))
     else : unknRows.append((lineNdx, "?", "-", line, size, FFCzRx("Unknown value", VVtz60), validF))
  for ndx, row in enumerate(actnRows):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   rem = ""
   if   fileExists(self.projFile_postInst) and Title == "postinst" : rem = "Ignored (if custom postinst)"
   elif fileExists(self.projFile_postRm  ) and Title == "postrm" : rem = "Ignored (if custom postrm)"
   if rem:
    actnRows[ndx] = (lineNdx, Section, Title, Value, Size, FFCzRx(rem, VVtz60), ValidF)
  actnRows.sort(key=lambda x: x[2].lower())
  fileRows.sort(key=lambda x: (x[2].lower(), x[3].lower()))
  unknRows.sort(key=lambda x: x[3].lower())
  VVpn2v = pkgRows
  VVpn2v.extend(actnRows)
  VVpn2v.extend(ctrlRows)
  VVpn2v.extend(fileRows)
  VVpn2v.extend(unknRows)
  cDict = {"Control":"", "Action":"0c302636", "Script":"0a28281a", "Resource":"1100385a", "?":"11550000"}
  for ndx, row in enumerate(VVpn2v):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   color = cDict.get(Section, "")
   if color:
    if ValidF: Remarks = "%s%s" % (FFCzRx("Valid", VVXF4f), " ... " + Remarks if Remarks else "")
    VVpn2v[ndx] = (lineNdx, "#b#%s#" % color + Section, Title, Value, Size, "#b#0a0b0b1b#" + Remarks, ValidF)
  if self.projTable:
   self.projTable.VVkYNn(VVpn2v, tableRefreshCB=BF(self.VVKlMv, jmpDict) if jmpDict else None, isSort=False)
  else:
   bg = "#15000000"
   title = "%s : %s" % (self.projTitle, self.projName)
   VV1Jd7 = (""     , self.VV65mq   , [])
   menuButtonFnc = (""     , self.VVtBYH   , [])
   VVKDDh = ("Create Package"  , self.VVL6Wj , [])
   VV7J8f = ("Post Install Action", self.VV2hSC, [])
   VVJvWF = ("Edit File"   , self.VVcZIA  , [])
   header  = ("lineNdx", "Section" , "Title" , "Value / Path", "Size", "Remarks" , "ValidF")
   widths  = (0  , 9   , 11  , 48   , 10 , 22  , 0   )
   VViqYN = (CENTER , CENTER , LEFT  , LEFT   , CENTER, LEFT  , CENTER )
   self.projTable = FFldB6(self, None, title=title, header=header, VVWsIU=VVpn2v, VViqYN=VViqYN, VVv3Wm=widths, width=1850, height=1040, VVHZHw=26, VV1Jd7=VV1Jd7, menuButtonFnc=menuButtonFnc, VVKDDh=VVKDDh, VV7J8f=VV7J8f, VVJvWF=VVJvWF, searchCol=2
         , VVZYdg=bg, VVcwfs=bg, VVLuY4=bg, VVG27K="#00664411", VVQ9hc="#00444444", VVGpiI="#08442211")
   self.projTable.VVKoPU(self.VVS5ON, True)
 def VVKlMv(self, jmpDict, VVoLtS, title, txt, colList):
  self.projTable.VVQ2Hx(jmpDict)
 def VVS5ON(self):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = self.projTable.VVkHbA()
  if Section == "Control":
   txt = '"control" File'
  elif Section == "Script" :
   txt = "Script File"
   if Value.startswith("/") and fileExists(Value):
    txt = "Script File"
   else:
    self.projTable["keyBlue"].hide()
    return
  else:
   txt = "Project File"
  self.projTable["keyBlue"].show()
  self.projTable["keyBlue"].setText("Edit %s" % txt)
 def VVLuSp(self, line):
  def VV7VNt(patt, val, Len):
   if len(val) < Len   : return FFCzRx("Length error" , VVtz60)
   elif not iMatch(patt, val) : return FFCzRx("Invalid format" , VVtz60)
   else      : return ""
  subj, _, val = line.partition(":")
  val, rem = val.strip(), ""
  if   not self.projPkg  and subj == "Package"  : self.projPkg, rem = val, VV7VNt(r"^[a-z]+[a-z0-9+-_.]+$", val, 2)
  elif not self.projVer  and subj == "Version"  : self.projVer, rem = val, VV7VNt(r"^[a-zA-Z0-9_+-.~]*$" , val, 1)
  elif not self.projArch and subj == "Architecture": self.projArch = val
  return subj, val, rem
 def VVEKwU(self, path, fileRows):
  rem = note = validF = targetType = ""
  size = "-"
  isCtrl = False
  fName = os.path.basename(path)
  typ = FF5Js2(path)
  path = FFZuCm(path)
  c = VVtz60
  if   typ == "Mount" : rem = FFCzRx("Not allowed", c)
  elif not typ  : rem = FFCzRx("Not found", c)
  else:
   for item in fileRows:
    if item[3].strip() == path:
     rem = FFCzRx("Duplicate", c)
     break
   else:
    sz = -1
    skipSz = False
    if typ == "Directory":
     sz = FFM9Wx(path)
    elif typ == "SymLink":
     targetPath = os.path.realpath(path)
     targetType = FF5Js2(targetPath)
     if  targetType == "Mount"  : skipSz, rem = True, FFCzRx("Not allowed", c)
     elif targetType == "Directory" : sz = FFM9Wx(targetPath)
     elif targetType == "File"  : sz = FFPLWs(targetPath)
     else       : sz, rem = FFPLWs(path), FFCzRx("Invalid", c)
     note = "%s%s%s" % (note, " ... " if note else "", "Linked to : %s" % targetPath)
    elif typ == "File":
     sz = FFPLWs(path)
    if not skipSz:
     if sz > -1:
      validF = "" if rem else "1"
      if validF:
       if "Directory" in (typ, targetType) : self.projTotalDirs  += 1
       if "File" in (typ, targetType)  : self.projTotalFiles += 1
       self.projFilesSize += sz
      size = CCUGPF.VVuy4U(sz, mode=4)
     else:
      size = FFCzRx("Size error", c)
    rem = "%s%s%s" % (rem, " ... " if rem else "", note)
  return path, fName, typ, size, rem, validF
 def VVIUhj(self, line):
  Title = val = ""
  actDict = {"restart":1, "reboot":2 }
  span = iSearch(r"postinst\s*=\s*(.+)", line, IGNORECASE)
  if span:
   act = span.group(1).lower()
   self.projAct_postInst = actDict.get(act, 0)
   Title, val = "postinst", "%s after the package is installed" % act.capitalize()
  else:
   span = iSearch(r"postrm\s*=\s*(.+)", line, IGNORECASE)
   if span:
    act = span.group(1).lower()
    self.projAct_postRm = actDict.get(act, 0)
    Title, val = "postrm", "%s after the package is removed" % act.capitalize()
  return Title, val
 def VVcZIA(self, VVoLtS, title, txt, colList):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = colList
  if   Section == "Control": path, lineNdx = self.projFile_control, int(lineNdx)
  elif Section == "Script" : path, lineNdx = Value, 0
  else      : path, lineNdx = self.projFile, int(lineNdx)
  if fileExists(path) : CCH94c(self, path, VVEStC=self.VV5kYY, curRowNum=lineNdx)
  else    : FFZ5Ys(self, path)
 def VV5kYY(self, fileChanged):
  if fileChanged:
   self.VVjg5a()
 def VVTWYk(self, txt):
  FFzrXb(self, txt, title=self.projTitle)
 def VV65mq(self, VVoLtS, title, txt, colList):
  tab = lambda x, y: "%s\t: %s\n" % (x, y)
  c = VV61JF
  s  = FFLhxe("Current Row", c)
  s += title + "\n"
  s += txt + "\n"
  s += FFLhxe("Project", c)
  s += tab("File Name", self.projFile)
  s += tab("Valid Dirs", self.projTotalDirs)
  s += tab("Valid Files", self.projTotalFiles)
  s += tab("Total Size", CCUGPF.VVuy4U(self.projFilesSize))
  FFtybv(self, s, title="Project Info", width=1600)
 def VVtBYH(self, VVoLtS, title, txt, colList):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = colList
  c1, c2, c3 = VVJS3b, VVYqlh, VV61JF
  VVMVqr = []
  VVMVqr.append((c1 + "Add Resource File"  , "addFile" ))
  VVMVqr.append((c1 + "Add Resource Directory" , "addDir" ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Change Package Name"   , "pkgNam" ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append((c2 + "Add Dependency"   , "addDep" ))
  VVMVqr.append((c2 + "Remove Dependency"  , "delDep" ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Import Control File (control/preinst/prerm/postinst/postrm)", "ctrlFMan"))
  VVMVqr.append(VVpTvr)
  VVMVqr.append((c3 + 'Import Control Data from an Installed Package' , "ctrlImprt" ))
  VVMVqr.append(FFwLFH('Undo Last "control" File Changes'   , "ctrlUndo" , fileExists(self.projFile_control + ".bak"), c3))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(FFwLFH("Delete Current Row (from Project File)" , "delRow"  , Section not in ("Control", "Script")   , VVtz60))
  FF7ARM(self, self.VVVbrG, VVMVqr=VVMVqr, width=1050, title="Options", VVZYdg="#11001122", VVcwfs="#11001122")
 def VVVbrG(self, item=None):
  if item:
   if   item == "addFile" : self.VVY3P8(False)
   elif item == "addDir" : self.VVY3P8(True)
   elif item == "pkgNam" : self.VVACyK()
   elif item == "addDep" : FFzW1w(self.projTable, self.VVhiMQ)
   elif item == "delDep" : self.VVmzg5()
   elif item == "ctrlFMan" : self.VVHHSk()
   elif item == "ctrlImprt": FFzW1w(self.projTable, self.VVSehI)
   elif item == "ctrlUndo" : self.VV2yc8()
   elif item == "delRow" : self.VVPPcK()
 def VVY3P8(self, isDir):
  Dir = FFIRGA(CFG.lastPkgProjDir.getValue(), False)
  if isDir: self.session.openWithCallback(self.VVpMaR, BF(CCUGPF, mode=CCUGPF.VVGIMp, VVRawy=Dir))
  else : self.session.openWithCallback(self.VVpMaR, BF(CCUGPF, patternMode="all", VVRawy=Dir))
 def VVpMaR(self, path):
  if path:
   FF2tHk(CFG.lastPkgProjDir, path)
   self.VVcO27(path, 2)
 def VVHHSk(self):
  Dir = FFIRGA(CFG.lastPkgProjDir.getValue(), False)
  self.session.openWithCallback(self.VV7ERq, BF(CCUGPF, patternMode="pkgCtrl", VVRawy=Dir))
 def VV7ERq(self, path):
  if path:
   FF2tHk(CFG.lastPkgProjDir, path)
   fName = os.path.basename(path)
   if FFgSm7("cp -f '%s' '%s'" % (path, self.projPath + fName)):
    self.VVjg5a()
    self.projTable.VVQ2Hx({1:"Script", 2:fName})
 def VVSehI(self):
  cmd = FF1dKx(VVoElo, "")
  if not cmd:
   FFV7xB(self)
   return
  lst = FFSInC(cmd)
  if lst:
   err = CCUGPF.VVnFIi(lst, fromFind=False)
   if err:
    self.VVTWYk(err)
    return
   lst.sort()
   VVpn2v = []
   for item in lst:
    span = iSearch(r"(.+) - (.+)", item)
    if span:
     VVpn2v.append(("", span.group(1), span.group(2)))
   if VVpn2v:
    VVEXwE = ("Import 'control' data", self.VVb2a2, [])
    VV7J8f = ("Package Info.", self.VV4uc5     , [])
    header = ("dum", "Package" , "Version" )
    widths = (0 , 70  , 30  )
    FFldB6(self, None, header=header, VVWsIU=VVpn2v, VVv3Wm=widths, VVHZHw=30, VVEXwE=VVEXwE, VV7J8f=VV7J8f, VVMYDy=self.lastSelectedRow, lastFindConfigObj=CFG.lastFindPackages
      , VVZYdg="#22110011", VVcwfs="#22191111", VVLuY4="#22191111", VVG27K="#00003030", VVQ9hc="#00333333")
   else:
    self.VVTWYk("Cannot process installed packages !")
  else:
   self.VVTWYk("Cannot read installed packages !")
 def VV2yc8(self):
  if FFgSm7("mv -f '%s' '%s'" % (self.projFile_control + ".bak", self.projFile_control)):
   self.VVjg5a(jmpDict={1:"Control", 2:"Package"})
  else:
   self.VVTWYk("Process Failed !")
 def VVb2a2(self, VVoLtS, title, txt, colList):
  FFzW1w(VVoLtS, BF(self.VVaVMt, VVoLtS, colList[1]))
 def VVaVMt(self, VVoLtS, pkg):
  lines = []
  for line in FFSInC(FF4ZaS(VV3ArY, pkg)):
   span = iSearch(r"^([A-Z].+):\s*.+", line)
   if span and span.group(1) in ("Package", "Version", "Depends", "Section", "Architecture", "Maintainer", "Source", "Description"):
    lines.append(line)
  if lines: FFo4dm(self, BF(self.VVOEfB, VVoLtS, lines), "Replace current fields ?", title="Import Control Fields")
  else : self.VVTWYk("Cannot import from this package:\n\n%s" % pkg)
 def VVOEfB(self, VVoLtS, lines):
  VVoLtS.cancel()
  FFkECb(self.projFile_control)
  with open(self.projFile_control, "w") as f:
   for line in lines:
    f.write(line.strip()+ "\n")
  self.VVjg5a(jmpDict={1:"Control", 2:"Package"})
 def VVPPcK(self):
  lineNum = int(self.projTable.VVkHbA()[0]) + 1
  FFgSm7("sed -i.bak -e '%dd' '%s'" % (lineNum, self.projFile))
  self.VVjg5a()
 def VVcO27(self, line, jmp):
  if fileExists(self.projFile):
   FFkECb(self.projFile)
   FFElys(self.projFile)
   with open(self.projFile, "a") as f:
    f.write("%s\n" % line)
   if   jmp == 1: jmpDict = {1:"Action" , 2:line.split("=")[0]}
   elif jmp == 2: jmpDict = {1:"Resource" , 3:line.strip().rstrip("/")}
   else   : jmpDict = None
   self.VVjg5a(jmpDict=jmpDict)
  else:
   FFZ5Ys(self, self.projFile, title=self.projTitle)
 def VV2hSC(self, VVoLtS, title, txt, colList):
  VVMVqr = []
  VVMVqr.append(FFwLFH("No-Action after installation" , "instNon", self.projAct_postInst != 0))
  VVMVqr.append(FFwLFH("Restart after installation" , "instRes", self.projAct_postInst != 1))
  VVMVqr.append(FFwLFH("Reboot after installation"  , "instReb", self.projAct_postInst != 2))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(FFwLFH("No-Action after removal" , "rmNon", self.projAct_postRm != 0))
  VVMVqr.append(FFwLFH("Restart after removal" , "rmRes", self.projAct_postRm != 1))
  VVMVqr.append(FFwLFH("Reboot after removal"  , "rmReb", self.projAct_postRm != 2))
  FF7ARM(self, self.VVhvN6, VVMVqr=VVMVqr, title="Action (after the package is installed/removed)")
 def VVhvN6(self, item=None):
  if item:
   if   item == "instNon" : self.VV8lsb("postinst", 0)
   elif item == "instRes" : self.VV8lsb("postinst", 1)
   elif item == "instReb" : self.VV8lsb("postinst", 2)
   elif item == "rmNon" : self.VV8lsb("postrm", 0)
   elif item == "rmRes" : self.VV8lsb("postrm", 1)
   elif item == "rmReb" : self.VV8lsb("postrm", 2)
 def VV8lsb(self, subj, val):
  if fileExists(self.projFile):
   lines = FF2WPS(self.projFile)
   FFkECb(self.projFile)
  else:
   lines = []
  inFile = False
  with open(self.projFile, "w") as f:
   for ndx, line in enumerate(lines):
    line = line.strip()
    if not iMatch(r"%s\s*=.+" % subj, line, IGNORECASE) : f.write(line + "\n")
    else            : inFile = True
  if val > 0: self.VVcO27("%s=%s" % (subj, {1:"restart", 2:"reboot"}.get(val, "")), 1)
  elif inFile: self.VVjg5a()
 def VVACyK(self):
  pkg = iSub(r"([^\x00-\x7F]+)", r"_", self.projName, flags=IGNORECASE).lower()
  VVMVqr = []
  VVMVqr.append((pkg, pkg))
  VVMVqr.append(VVpTvr)
  for s in ("extensions", "systemplugins", "", "skins", "picons", "softcams", "", "drivers", "security", "settings"):
   if s:
    name = "enigma2-plugin-%s-%s" % (s, pkg)
    c = VV61JF if name == self.projPkg else ""
    VVMVqr.append((c + name, name))
   else:
    VVMVqr.append(VVpTvr)
  FF7ARM(self, self.VVKZkx, VVMVqr=VVMVqr, title="Package Name")
 def VVKZkx(self, item=None):
  if item:
   self.VVTeu1("Package", item)
 def VVhiMQ(self):
  lst = set()
  for s in ("d", "o", "i"):
   path = "/var/lib/%spkg/status" % s
   if fileExists(path):
    with open(path, "r") as f:
     for line in f:
      if line.startswith(("Package:", "Depends:", "Recommends:", "Suggests:", "Conflicts:", "Replaces:", "Breaks:", "Provides:")):
       line = line.split(":", 1)[1]
       for dep in line.split(","):
        lst.add(dep.strip())
  if lst:
   VVMVqr = []
   for item in lst: VVMVqr.append((item, item))
   VVMVqr.sort(key=lambda x: x[0].lower())
   VVdtUh = FF7ARM(self, self.VVTxsg, VVMVqr=VVMVqr, width=1100, title="Add Dependency")
   if self.projLastDepends:
    VVdtUh.VVzELa(self.projLastDepends)
  else:
   self.VVTWYk("Cannot read dependencies list !")
 def VVTxsg(self, item=None):
  if item:
   lst = []
   self.projLastDepends = item
   if fileExists(self.projFile_control):
    for line in FF2WPS(self.projFile_control):
     if line.startswith("Depends:"):
      lst = list(map(str.strip, line[8:].split(",")))
      break
   if not item in lst:
    lst.append(item)
    self.VVTeu1("Depends", ", ".join(lst))
   else:
    FFycel(self.projTable, "Already added", 1500)
    self.projTable.VVQ2Hx({1:"Control", 2:"Depends"})
 def VVmzg5(self):
  lst = []
  for row in self.projTable.VVGkEL():
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   if Title == "Depends":
    lst = list(map(str.strip, Value.split(",")))
    break
  if lst:
   VVMVqr = []
   for item in lst: VVMVqr.append((item, item))
   FF7ARM(self, BF(self.VVhqQ1, lst), VVMVqr=VVMVqr, title="Remove Dependency")
  else:
   self.VVTWYk("No dependencies to remove !")
 def VVhqQ1(self, lst, item=None):
  if item:
   for ndx, dep in enumerate(lst):
    if dep == item:
     del lst[ndx]
     break
   if lst:
    self.VVTeu1("Depends", ", ".join(lst))
   else:
    FFgSm7("sed -i '/Depends:*/d' '%s'" % self.projFile_control)
    self.VVjg5a()
 def VVTeu1(self, subj, val):
  lines = FF2WPS(self.projFile_control) if fileExists(self.projFile_control) else []
  inFile = False
  with open(self.projFile_control, "w") as f:
   for ndx, line in enumerate(lines):
    line = line.strip()
    if iMatch(r"%s\s*:\s*.+" % subj, line):
     line = "%s: %s" % (subj, val)
     inFile = True
    f.write(line + "\n")
   if not inFile:
    f.write("%s: %s\n" % (subj, val))
  self.VVjg5a(jmpDict={1:"Control", 2:subj})
 def VVL6Wj(self, VVoLtS, title, txt, colList):
  VVMVqr = []
  VVMVqr.append(("Create .ipk"  , "ipk"))
  VVMVqr.append(("Create .deb"  , "deb"))
  VVMVqr.append(("Create .tar.gz" , "tar"))
  FF7ARM(self, self.VVx9VU, VVMVqr=VVMVqr, width=500, title=self.projTitle)
 def VVx9VU(self, item=None):
  if item:
   FFzW1w(self.projTable, BF(self.VVf7xd, item))
 def VVf7xd(self, item):
  if self.projTotalDirs + self.projTotalFiles == 0:
   self.VVTWYk("No Dirs/Files found !\n\nYou need to add at least 1 directory or 1 file to the project !")
   return
  if   item in ("ipk", "tar") : VV6sgm, tarParam, tarExt = False, "-czhf", ".tar.gz"
  elif item == "deb"   : VV6sgm, tarParam, tarExt = True , "-cJhf", ".tar.xz"
  if   not self.projPkg : err = "Package"
  elif not self.projVer : err = "Version"
  elif not self.projArch : err = "Architecture"
  else     : err = ""
  if err:
   VVTWYk(self, 'Parameter "%s" not found !' % err)
   return
  if item == "tar": pName, arch, ext = self.projName, "", "tar.gz"
  else   : pName, arch, ext = self.projPkg , self.projArch, item
  pkgFile = "%s%s_%s_%s.%s" % (CFG.packageOutputPath.getValue(), pName, self.projVer, arch, ext)
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  dataTmpPath  = projDir + "DATA/"
  dataFile  = projDir + "data" + tarExt
  removePorjDir = FFgeXp("rm -rf '%s'" % projDir)
  ctrlDir   = "%sCONTROL" % projDir
  controlTarF  = projDir + "control" + tarExt
  controlFile  = "%s/control" % ctrlDir
  debianFile  = projDir + "debian-binary"
  result = "Package:"
  failed= "Process Failed."
  resCmd  = " if [ -f '%s' ]; then "  % pkgFile
  resCmd += "  echo -e '\n%s\n%s' %s;" % (result, pkgFile, FFC7pV(result  , VVXF4f))
  resCmd += " else"
  resCmd += "  echo -e '\n%s' %s;"  % (failed, FFC7pV(failed, VVfMEC))
  resCmd += " fi;"
  cmd  = ""
  cmd += FFgeXp("rm -f '%s'" % pkgFile)
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % dataTmpPath
  linkLst = []
  ctrlLst = []
  for ndx, row in enumerate(self.projTable.VVGkEL()):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   if Section == "Control":
    ctrlLst.append("%s: %s" % (Title, Value))
   elif ValidF:
    Dir = os.path.dirname(Value)
    cmd += "mkdir -p '%s%s';"  % (dataTmpPath, Dir)
    cmd += "ln -sf '%s' '%s%s';" % (Value, dataTmpPath, Value)
  if item == "tar":
   cmd += "echo 'Processing Data Files ...';"
   cmd += "tar -C '%s' %s '%s' ./;" % (dataTmpPath, tarParam, pkgFile)
   cmd += resCmd
   cmd += removePorjDir
   FFHguD(self, cmd)
   return
  cmd += "mkdir -p '%s';"  % ctrlDir
  cmd += " echo '2.0' > %s;" % debianFile
  if not FFgSm7(cmd) or not pathExists(ctrlDir):
   VVTWYk(self, "Preparation Failed")
   return
  else:
   with open(controlFile, "w") as f:
    for item in ctrlLst:
     f.write("%s\n" % item)
  fName = ("prerm"     ,"preinst"      ,"postrm"     , "postinst"     )
  srcF  = (self.projFile_preRm  , self.projFile_preInst   , self.projFile_postRm  , self.projFile_postInst  )
  line  = ("Removing package : xx ...", "Installing Package : xx ..." , "Package removed (xx)." , "Installation completed (xx)" )
  act   = (0       , 0        , self.projAct_postRm  , self.projAct_postInst   )
  def VV7VNt(act):
   if   act == 1: return "echo 'RESTARTING GUI ...'\nif which systemctl; then sleep 2; systemctl restart enigma2; elif [ -r '/usr/lib/enigma2/python/EGAMI' ]; then sleep 2; killall -9 enigma2; else init 4; sleep 4; init 3; fi\n"
   elif act == 2: return "echo 'REBOOTING DEVICE ...'\nsleep 3; reboot\n"
   else   : return "echo 'echo 'You may need to Restart GUI.'\n"
  for fName, srcF, line, act in zip(fName, srcF, line, act):
   dstF = os.path.join(ctrlDir, fName)
   if fileExists(srcF):
    FFgSm7("cp -f '%s' '%s'" % (srcF, dstF))
   else:
    with open(dstF, "w") as f:
     f.write("#!/bin/bash\n")
     f.write("echo '%s'\n" % line.replace("xx", self.projPkg))
     f.write(VV7VNt(act) if srcF in (self.projFile_postInst, self.projFile_postRm) else "")
     f.write("exit 0\n")
   FFElys(dstF)
   FFgSm7("chmod 755 '%s'" % dstF)
  cmd  = ""
  cmd += FFQ4w6()
  if VV6sgm:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFkbwj("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  cmd += "cd '%s';" % dataTmpPath
  cmd += " echo 'Processing Control Files ...';"
  cmd += " cd '%s';"   % ctrlDir
  cmd += " tar %s '%s' ./*;" % (tarParam, controlTarF)
  cmd += " echo 'Processing Data Files ...';"
  cmd += " tar -C '%s' %s '%s' ./;" % (dataTmpPath, tarParam, dataFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Cannot create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlTarF, "control.tar")
  cmd += checkCmd % (dataFile   , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (pkgFile, debianFile, controlTarF, dataFile)
  cmd += " fi;"
  cmd +=  resCmd
  cmd += "fi;"
  cmd += removePorjDir
  FFHguD(self, cmd)
class CCvztK(Screen, CCOkaf):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF5TEn(VVL1I3, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  CCOkaf.__init__(self)
  c1, c2, c3, c4 = VVJS3b, VVYqlh, VVTKrH, VV61JF
  VVMVqr = []
  VVMVqr.append((c1 + "Plugins Browser"        , "pluginsBrowser"   ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append((c2 + "Download/Install Packages (from image feeds)", "downloadInstallPackages" ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append((c3 + "Remove Packages (show all)"     , "VVuH24sAll"  ))
  VVMVqr.append((c3 + "Remove Packages (Plugins/SoftCams/Skins)" , "removePluginSkinSoftCAM" ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append((c2 + "Update Packages List from Feed"    , "VVgseP"  ))
  VVMVqr.append((c2 + "Upgradable Packages"       , "VVxgsp" ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append((c4 + "Package Creator (ipk/deb/tar.gz)"   , "packageCreator"   ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Packaging Tool"         , "VVSit8"   ))
  VVMVqr.append(("Active Feeds"          , "VVSIU2"   ))
  FF32Yx(self, VVMVqr=VVMVqr)
  self.onShown.append(self.VVSDD3)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  FFWzaz(self["myMenu"])
  FF0pG3(self)
 def VVthYm(self):
  global VVBcOf
  VVBcOf = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "pluginsBrowser"    : CCG5tV.VVsjBg(self.session)
   elif item == "downloadInstallPackages"  : FFzW1w(self, BF(self.VValDu, 0, ""))
   elif item == "VVuH24sAll"   : FFzW1w(self, BF(self.VValDu, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFzW1w(self, BF(self.VValDu, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVgseP"   : CCvztK.VVgseP(self)
   elif item == "VVxgsp"  : FFzW1w(self, self.VVxgsp)
   elif item == "packageCreator"    : self.VVfAbk()
   elif item == "VVSit8"    : self.VVSit8()
   elif item == "VVSIU2"    : FFzW1w(self, self.VVSIU2)
   else          : self.close()
 def VVSIU2(self):
  files = []
  for s in ("d", "o", "i"):
   files.extend(iGlob("/var/lib/%spkg/lists/*" % s))
  VVpn2v = []
  if files:
   for path in files:
    tot = 0
    with open(path, "r") as f:
     for line in f:
      if line.startswith("Package:"): tot += 1
    VVpn2v.append((os.path.basename(path), str(tot)))
  if VVpn2v:
   VVpn2v.sort(key=lambda x: x[0].lower())
   header  = ("Feed","Packages")
   widths  = (82  , 18  )
   VViqYN = (LEFT  , CENTER )
   FFldB6(self, None, header=header, VVWsIU=VVpn2v, VViqYN=VViqYN, VVv3Wm=widths, width=1000, VVHZHw=26, VVcK1v=2)
  else:
   self.VVTWYk("Cannot read packages list !")
 def VVxgsp(self, VVoLtS=None):
  lst = FFSInC(FF1dKx(VVh9AH, ""))
  VVpn2v = []
  if lst:
   lst.sort(key=lambda x: x.lower())
   for line in lst:
    pkg = curV = newVer = ""
    span = iSearch(r"(.+) - (.+) - (.+)", line)
    if span:
     pkg, curV, newVer = span.group(1), span.group(2), span.group(3)
    else:
     span = iSearch(r"(.+) (.+) (.+) \[upgradable from: (.+)\]", line)
     if span:
      pkg, newVer, arch, curV = span.group(1), span.group(2), span.group(3), span.group(4)
    if all((pkg, curV, newVer)):
     VVpn2v.append((str(len(VVpn2v) + 1), pkg, curV, newVer))
   if VVpn2v:
    if VVoLtS:
     VVoLtS.VVkYNn(VVpn2v, VVz586Msg=True)
    else:
     bg = "#00221111"
     VVEXwE = ("Upgrade", self.VVY34P   , [])
     VV7J8f = ("Package Info.", self.VV4uc5 , [])
     header  = ("Num" ,"Package" ,"Version" , "New Version" )
     widths  = (6  , 42  , 26  , 26   )
     VViqYN = (CENTER , LEFT  , LEFT  , LEFT   )
     FFldB6(self, None, header=header, VVWsIU=VVpn2v, VViqYN=VViqYN, VVv3Wm=widths, width=1700, VVHZHw=26, VVEXwE=VVEXwE, VV7J8f=VV7J8f, VV65AN=True, VVklCm=0, searchCol=1, lastFindConfigObj=CFG.lastFindPackages, VVZYdg=bg, VVcwfs=bg, VVLuY4=bg, VVVU1s="#00ffff55", VVG27K="#00003040")
  if not VVpn2v:
   FFhcEU(self, "Nothing to upgrade", 1500)
   if VVoLtS: VVoLtS.cancel()
 def VVY34P(self, VVoLtS, title, txt, colList):
  pkg = colList[1]
  cmd = FF4ZaS(VVLFdd, pkg)
  if cmd : FFHguD(self, cmd, title="Installing : %s" % pkg, VVFgpi=BF(self.VVxgsp, VVoLtS))
  else : FFV7xB(SELF)
 def VVSit8(self):
  pkg = FFNJvd()
  aptT = "apt - Advanced Package Tool" if FFlgKV("apt") else ""
  txt = {"ipkg": "Itsy", "opkg": "Open", "dpkg": "Debian"}.get(pkg, "")
  txt = "%s - %s Package Management System" % (pkg, txt) if txt else ""
  txt += "%s%s" % ("\n\nand\n\n" if txt and aptT else "", aptT)
  FFuXZg(self, txt or "No packaging tools found!")
 def VValDu(self, mode, grep, VVoLtS=None, title=""):
  if   mode == 0: cmd = FF1dKx(VVjhlW    , grep)
  elif mode == 1: cmd = FF1dKx(VVoElo , grep)
  elif mode == 2: cmd = FF1dKx(VVoElo , grep)
  if not cmd:
   FFV7xB(self)
   return
  VVpn2v = FFSInC(cmd)
  if VVpn2v:
   err = CCUGPF.VVnFIi(VVpn2v, fromFind=False)
   if err:
    FFzrXb(self, err)
    return
  else:
   if VVoLtS: VVoLtS.VV6eCK()
   FFzrXb(self, "No packages found!")
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVWsIU  = []
  for item in VVpn2v:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVWsIU.append((name, package, version))
  if mode > 0:
   extensions = FFSInC("ls %s -l | grep '^d' | awk '{print $9}'" % VVFTYs)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVWsIU:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == VV17ob: name += "el"
      VVWsIU.append((name, VVFTYs + item, "-"))
   systemPlugins = FFSInC("ls %s -l | grep '^d' | awk '{print $9}'" % VVbd2l)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVWsIU:
      if item.lower() == row[0].lower():
       break
     else:
      VVWsIU.append((item, VVbd2l + item, "-"))
  if not VVWsIU:
   FFzrXb(self, "No packages found!")
   return
  if VVoLtS:
   VVWsIU.sort(key=lambda x: x[0].lower())
   VVoLtS.VVkYNn(VVWsIU, title)
  else:
   widths = (20, 50, 30)
   VVEXwE = None
   VVJvWF = None
   if mode == 0:
    VVKDDh = ("Install" , self.VVOZFj   , [])
    VVEXwE = ("Download" , self.VV3PvK   , [])
    VVJvWF = ("Filter"  , self.VVCIzu , [])
   elif mode == 1:
    VVKDDh = ("Uninstall", self.VVuH24, [])
   elif mode == 2:
    VVKDDh = ("Uninstall", self.VVuH24, [])
    widths= (18, 57, 25)
   VVWsIU.sort(key=lambda x: x[0].lower())
   VV7J8f = ("Package Info.", self.VV4uc5, [])
   header   = ("Name" ,"Package" , "Version" )
   FFldB6(self, None, header=header, VVWsIU=VVWsIU, VVv3Wm=widths, VVHZHw=28, VVKDDh=VVKDDh, VVEXwE=VVEXwE, VV7J8f=VV7J8f, VVJvWF=VVJvWF, VVMYDy=self.lastSelectedRow, lastFindConfigObj=CFG.lastFindPackages
     , VVZYdg="#22110011", VVcwfs="#22191111", VVLuY4="#22191111", VVG27K="#00003030", VVQ9hc="#00333333")
 def VV4uc5(self, VVoLtS, title, txt, colList):
  FFzW1w(VVoLtS, BF(self.VVCMVg, VVoLtS, colList[1]))
 def VVCMVg(self, VVoLtS, pkg):
  if pathExists(pkg):
   pkg, err = CCvztK.VVf3Qd(pkg)
   if err:
    FFhcEU(VVoLtS, err, 1000)
    return
  CCvztK.VVo7RC(self, pkg)
 def VVCIzu(self, VVoLtS, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVMVqr = []
  VVMVqr.append(("All Packages", "all"))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVMVqr.append(VVpTvr)
  for word in words:
   VVMVqr.append((word, word))
  FF7ARM(self, BF(self.VVyRtj, VVoLtS), VVMVqr=VVMVqr, title="Select Filter")
 def VVyRtj(self, VVoLtS, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFzW1w(VVoLtS, BF(self.VValDu, 0, grep, VVoLtS, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVuH24(self, VVoLtS, title, txt, colList):
  FFzW1w(VVoLtS, BF(self.VVq6gf, VVoLtS, colList[1]))
 def VVq6gf(self, VVoLtS, package):
  if pathExists(package):
   pkg, err = CCvztK.VVf3Qd(package)
   if pkg:
    package = pkg
  if package.startswith((VVFTYs, VVbd2l)):
   FFo4dm(self, BF(self.VVefou, VVoLtS, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVMVqr = []
   VVMVqr.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVMVqr.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVMVqr.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FF7ARM(self, BF(self.VVAh9a, VVoLtS, package), VVMVqr=VVMVqr)
 def VVefou(self, VVoLtS, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -rf '%s' &>/dev/null %s" % (package, VVWwsK)
  FFHguD(self, cmd, VVFgpi=BF(self.VVMpgv, VVoLtS))
 def VVAh9a(self, VVoLtS, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVS3eG
   elif item == "remove_ForceRemove"  : cmdOpt = VVzVlq
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVWN0E
   FFo4dm(self, BF(self.VVFui7, VVoLtS, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVFui7(self, VVoLtS, package, cmdOpt):
  self.lastSelectedRow = VVoLtS.VVqeSa()
  cmd = FF4ZaS(cmdOpt, package)
  if cmd : FFHguD(self, cmd, VVFgpi=BF(self.VVMpgv, VVoLtS))
  else : FFV7xB(self)
 def VVMpgv(self, VVoLtS):
  VVoLtS.cancel()
  FFZvbd()
 def VVOZFj(self, VVoLtS, title, txt, colList):
  package  = colList[1]
  VVMVqr = []
  VVMVqr.append(("Install Package"        , "install_CheckVersion" ))
  VVMVqr.append(("Install Package (force reinstall)"   , "install_ForceReinstall" ))
  VVMVqr.append(("Install Package (force overwrite)"   , "install_ForceOverwrite" ))
  VVMVqr.append(("Install Package (force downgrade)"   , "install_ForceDowngrade" ))
  VVMVqr.append(("Install Package (ignore failed dependencies)" , "install_IgnoreDepends" ))
  FF7ARM(self, BF(self.VVWI9O, package), VVMVqr=VVMVqr)
 def VVWI9O(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVLFdd
   elif item == "install_ForceReinstall" : cmdOpt = VV8F5p
   elif item == "install_ForceOverwrite" : cmdOpt = VVYC8S
   elif item == "install_ForceDowngrade" : cmdOpt = VVLn3s
   elif item == "install_IgnoreDepends" : cmdOpt = VVIAJ8
   FFo4dm(self, BF(self.VVcyt8, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVcyt8(self, package, cmdOpt):
  cmd = FF4ZaS(cmdOpt, package)
  if cmd : FFHguD(self, cmd, VVFgpi=FFZvbd, checkNetAccess=True)
  else : FFV7xB(self)
 def VV3PvK(self, VVoLtS, title, txt, colList):
  package  = colList[1]
  FFo4dm(self, BF(self.VVmPvu, package), "Download Package ?\n\n%s" % package)
 def VVmPvu(self, package):
  if CCYqD0.VVv6Xs():
   cmd = FF4ZaS(VVK0bx, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFC7pV(success, VVXF4f))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFC7pV(fail, VVfMEC))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFHguD(self, cmd, VVq3Yu=[VVfMEC, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFV7xB(self)
  else:
   FFzrXb(self, "No internet connection !")
 @staticmethod
 def VVgseP(SELF):
  cmd = FF1dKx(VV4pgO, "")
  if cmd : FFHguD(SELF, cmd, checkNetAccess=True, title="Available Packages List Upadate")
  else : FFV7xB(SELF)
 @staticmethod
 def VVf3Qd(path):
  pkg = err = ""
  if pathExists(path):
   for line in FFSInC(FF4ZaS(VVFfRF, "*%s*" % path)):
    span = iSearch(r"(.+) - .+", line)
    if span:
     pkg = span.group(1)
     break
    else:
     span = iSearch(r"(.+):+", line)
     if span:
      pkg = span.group(1)
      break
   if not pkg:
    err = "No package info !"
  else:
   err = "Path not found !"
  return pkg, err
 @staticmethod
 def VVo7RC(SELF, package, title=""):
  title = title or package
  infoCmd  = FF4ZaS(VV3ArY, package)
  filesCmd = FF4ZaS(VVpVRu, package)
  listInstCmd = FF1dKx(VVoElo, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFQHwo(VVRJhR)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFC7pV(notInst, VVtz60))
   cmd += "else "
   cmd +=   FFxGY8("System Info", VVRJhR)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFxGY8("Related Files", VVRJhR)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFK0Ik(SELF, cmd, title=title)
  else:
   FFV7xB(SELF, title=title)
class CCbA6i():
 def VVh0LG(self, isRef, onlyEpg=False):
  self.shareIsRef   = isRef
  self.onlyEpg   = onlyEpg
  self.shareFilePrefix = "ajpanel_share_%s_" % ("ref" if self.shareIsRef else "data")
  self.shareFilePath  = ""
  self.shareData   = []
  self.VV3Id2()
 def VV3Id2(self):
  files = FFY7QR(VVYfYu, self.shareFilePrefix + "*.xml")
  if files:
   files.sort()
   VVMVqr = []
   for fil in files:
    VVMVqr.append((os.path.basename(fil), fil))
   if self.shareIsRef : VVZYdg, VVcwfs = "#22221133", "#22221133"
   else    : VVZYdg, VVcwfs = "#22003344", "#22002233"
   VVYJ07  = ("Add new File", self.VVIlvt)
   FF7ARM(self, self.VVmp3Z, VVMVqr=VVMVqr, width=1100, VVYJ07=VVYJ07, VVYpxU="", minRows=4, VVZYdg=VVZYdg, VVcwfs=VVcwfs)
  else:
   FFo4dm(self, self.VVAxYi, "No files found.\n\nCreate a new file ?")
 def VVAxYi(self):
  path = self.VVJjn7()
  if fileExists(path) : self.VV3Id2()
  else    : FFycel(self, "Cannot create file", 1500)
 def VVIlvt(self, VVdtUh, path):
  path = self.VVJjn7()
  VVdtUh.VVe40s((os.path.basename(path), path), isSort=True)
 def VVJjn7(self):
  path = "%s%s%s.xml" % (VVYfYu, self.shareFilePrefix, FF4rM4())
  with open(path, "w") as f:
   f.write('<?xml version="1.0" encoding="utf-8"?>\n<share>\n\n\t<ch>\n\t\t<name1>Channel-1</name1>  <ref1>5001:0:1:22:22:22:22:0:0:0</ref1>\n\t\t<name2>Channel-2</name2>  <ref2>4097:0:1:22:22:22:22:0:0:0</ref2>\n\t</ch>\n\n</share>')
  return path
 def VVmp3Z(self, path=None):
  if path:
   FFzW1w(self, BF(self.VVuQg2, path))
 def VVuQg2(self, path):
  if not fileExists(path):
   FFZ5Ys(self, path)
   return
  elif not CCUGPF.VV1eSU(self, path, FFcYIL()):
   return
  else:
   self.shareFilePath = path
  if not CCk55e.VVccK9(self):
   return
  tree = CCh3Pq.VVFz4s(self, self.shareFilePath)
  if not tree:
   return
  refLst = CCrfsB.VVeBU6()
  def VVchnh(refCode):
   if   FFEEqJ(refCode): return FFCzRx("DVB", VVJS3b)
   elif refCode in refLst     : return FFCzRx("IPTV", VVJS3b)
   else         : return ""
  VVpn2v= []
  errColor= "#f#00ffaa55#"
  num  = 1
  dupl = 0
  for ch in tree.getroot():
   ok, srcName, srcRef, dstName, dstRef = self.VVFALS(ch)
   if ok:
    srcTxt = VVchnh(srcRef)
    dstTxt = VVchnh(dstRef)
    srcName, dstName = srcName.strip(), dstName.strip()
    skip = False
    for num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 in VVpn2v:
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      dupl += 1
      break
    else:
     if  srcRef == dstRef : remark, c1, c2 = "4", errColor, errColor
     elif srcTxt and dstTxt : remark, c1, c2 = "0", ""  , ""
     elif dstTxt    : remark, c1, c2 = "1", errColor, ""
     elif srcTxt    : remark, c1, c2 = "2", ""  , errColor
     else     : remark, c1, c2 = "3", errColor, errColor
     c3 = "#f#0000ff00#" if remark == "0" else errColor
     VVpn2v.append((c3 + str(num), c1 + srcName, c1 + srcRef, c1 + srcTxt, c2 + dstName, c2 + dstRef, c2 + dstTxt, remark))
     num += 1
  refLst = None
  if VVpn2v:
   if self.shareIsRef : VVZYdg, VVcwfs, optTxt = "#1a221133", "#1a221133", "Share Reference"
   else    : VVZYdg, VVcwfs, optTxt = "#1a003344", "#1a002233", "Copy EPG" if self.onlyEpg else "Copy EPG/PIcons"
   VV4ePT = (""    , BF(self.VVXhDW, dupl), [])
   VV1Jd7 = (""    , self.VVs6yV    , [])
   VVKDDh = ("Delete Entry" , self.VVYcG7   , [])
   VVEXwE = ("Add Entry"  , self.VVdjyf   , [])
   VV7J8f = (optTxt   , self.VV643M  , [])
   header  = ("Num" , "Source" , "Source Ref." ,"Type" , "Destination" , "Dest. Ref." , "Type", "Remark" )
   widths  = (8  , 25  , 15   , 6  , 25   , 15   , 6  , 0   )
   VViqYN = (CENTER , LEFT  , LEFT   ,CENTER , LEFT   , LEFT   , CENTER, CENTER )
   VVoLtS = FFldB6(self, None, header=header, VVWsIU=VVpn2v, VViqYN=VViqYN, VVv3Wm=widths, VVHZHw=24, VV4ePT=VV4ePT, VV1Jd7=VV1Jd7, VVKDDh=VVKDDh, VVEXwE=VVEXwE, VV7J8f=VV7J8f, VV65AN=True, searchCol=1, lastFindConfigObj=CFG.lastFindServices
         , VVZYdg=VVZYdg, VVcwfs=VVcwfs, VVLuY4=VVcwfs, VVG27K="#0a000000")
  else:
   FFzrXb(self, "No valid sharing data found in:\n\n%s" % self.shareFilePath)
 def VVXhDW(self, dupl, VVoLtS, title, txt, colList):
  if dupl:
   VVoLtS.VVOPq5("Skipped %d duplicate%s" % (dupl, FFoTxy(dupl)), 2000)
 def VVs6yV(self, VVoLtS, title, txt, colList):
  def VVchnh(key, val): return "%s\t: %s\n" % (key, val or FFCzRx("?", VVszO3))
  Keys = VVoLtS.VVPdoF()
  Vals = VVoLtS.VVkHbA()
  txt = ""
  for i in range(len(Keys) - 1):
   txt += VVchnh(Keys[i], Vals[i])
   if i in (0, 3, 6):
    txt += "\n"
  remark = colList[7]
  txt1 = "Remarks\t: "
  c1, c2 = VVXF4f, VVszO3
  if   remark == "0": txt1 += c1 + "Valid"
  elif remark == "1": txt1 += c2 + "Source channel is not in system"
  elif remark == "2": txt1 += c2 + "Destination channel is not in system"
  elif remark == "3": txt1 += c2 + "Both channels are not in system"
  elif remark == "4": txt1 += c2 + "Both channels have same Reference"
  FFtybv(self, txt + txt1, title=title)
 def VVFALS(self, chElem):
  srcName = chElem.find("name1")
  srcRef  = chElem.find("ref1")
  dstName = chElem.find("name2")
  dstRef  = chElem.find("ref2")
  patt = r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))"
  if srcName is not None and srcRef is not None and dstName is not None and dstRef is not None:
   lst = [srcName.text or "", srcRef.text or "", dstName.text or "", dstRef.text or ""]
   for i, text in enumerate(lst):
    lst[i] = str(text.encode("UTF-8").decode())
   srcName, srcRef, dstName, dstRef = lst
   span = iSearch(patt, srcRef)
   if span:
    srcRef = span.group(1).upper()
    span = iSearch(patt, dstRef)
    if span:
     dstRef = span.group(1).upper()
     return True, srcName.strip(), srcRef.strip(":"), dstName.strip(), dstRef.strip(":")
  return False, "", "", "", ""
 def VVYcG7(self, VVoLtS, title, txt, colList):
  if VVoLtS.VVqeSa() == 0 and VVoLtS.VVgRm7() == 1:
   isLast, ques = True, "This is the last entry.\n\nDelete File ?"
  else:
   isLast, ques = False, "Delete current row ?"
  FFo4dm(self, BF(self.VV6Juw, isLast, VVoLtS), ques)
 def VV6Juw(self, isLast, VVoLtS):
  if isLast:
   FFnPMX(self.shareFilePath)
   VVoLtS.cancel()
  else:
   num, srcName, srcRef, srcType, dstName, dstRef, dstType, remark = VVoLtS.VVkHbA()
   if self.VV7BJo(srcName, srcRef, dstName, dstRef):
    VVoLtS.VVftBC()
    VVoLtS.VVnSKz()
    FFycel(VVoLtS, "Deleted", 500, isGrn=True)
   else:
    FFycel(VVoLtS, "Cannot delete from file", 2000)
 def VVdjyf(self, VVoLtS, title, txt, colList):
  self.shareData = []
  if self.shareIsRef : self.VVqH8p(VVoLtS, isDvb=True)
  else    : self.VV4CJ1(VVoLtS, "Source Channel", "#22003344", "#22002233")
 def VV4CJ1(self, mainTableInst, title, VVZYdg, VVcwfs):
  FF7ARM(self, BF(self.VVS16q, mainTableInst, title), VVMVqr=[("DVB", "DVB"), ("IPTV / Stream Relay", "IPTV")], title=title + " Type", width=800, VVZYdg=VVZYdg, VVcwfs=VVcwfs)
 def VVS16q(self, mainTableInst, title, item=None):
  if item:
   FFzW1w(mainTableInst, BF(self.VVBatx, mainTableInst, title, item), clearMsg=False)
 def VVBatx(self, mainTableInst, title, item):
  FFycel(mainTableInst)
  if item == "DVB": self.VVqH8p(mainTableInst, isDvb=True)
  else   : self.VVqH8p(mainTableInst, isDvb=False)
 def VVnLbn(self, mainTableInst, chType, VVoLtS, title, txt, colList):
  self.shareData.append((colList[0], colList[3], chType))
  curRowNdx = VVoLtS.VVqeSa()
  if   chType == "DVB" : FF2tHk(CFG.lastSharePickerDvbRow , curRowNdx)
  elif chType == "IPTV": FF2tHk(CFG.lastSharePickerIptvRow, curRowNdx)
  if len(self.shareData) == 2:
   srcName, srcRef, srcTxt = self.shareData[0]
   dstName, dstRef, dstTxt = self.shareData[1]
   srcName, dstName = srcName.strip(), dstName.strip()
   if not srcRef == dstRef:
    for ndx, row in enumerate(mainTableInst.VVGkEL()):
     num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 = row
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      FFzrXb(self, "Already added in row Num-%d" % (ndx + 1))
      break
    else:
     if self.VV5VHO(srcName, srcRef, dstName, dstRef):
      mainTableInst.VVY957((str(mainTableInst.VVgRm7() + 1), srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, "0"))
      FFycel(mainTableInst, "Added", 500, isGrn=True)
     else:
      FFycel(mainTableInst, "Cannot edit XML File", 2000)
   else:
    FFycel(mainTableInst, "Cannot use same Reference", 2000)
  else:
   if self.shareIsRef : self.VVqH8p(mainTableInst, isDvb=False)
   else    : FFA9HA(BF(self.VV4CJ1, mainTableInst, "Select Destination", "#11661122", "#11661122"))
  VVoLtS.cancel()
 def VVjwPo(self, item, VVoLtS, title, txt, colList):
  if   item == "DVB" : ndx = CFG.lastSharePickerDvbRow.getValue()
  elif item == "IPTV": ndx = CFG.lastSharePickerIptvRow.getValue()
  VVoLtS.VV7qpv(ndx)
 def VVqH8p(self, VVoLtS, isDvb):
  typ  = "DVB" if isDvb else "IPTV"
  txt  = "Soruce" if len(self.shareData) == 0 else "Destination"
  okFnc = BF(self.VVnLbn, VVoLtS, typ)
  doneFnc = BF(self.VVjwPo, typ)
  if isDvb: CCbA6i.VVEh2f(VVoLtS , "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
  else : CCbA6i.VVOBwu(VVoLtS, "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
 @staticmethod
 def VVEh2f(SELF, title, okFnc, doneFnc=None):
  FFzW1w(SELF, BF(CCbA6i.VVx6kb, SELF, title, okFnc, doneFnc), title="Loading DVB Services ...")
 @staticmethod
 def VVx6kb(SELF, title, okFnc, doneFnc=None):
  VVpn2v, err = CCh3Pq.VVM6i7(SELF, CCh3Pq.VVsscu)
  if VVpn2v:
   color = "#0a000022"
   VVpn2v.sort(key=lambda x: x[0].lower())
   VVd479 = ("Select" , okFnc, [])
   VV4ePT= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Provider", "Sat.", "Reference" )
   widths  = (29  , 27  , 9  , 35   )
   VViqYN = (LEFT  , LEFT  , CENTER, LEFT    )
   FFldB6(SELF, None, title=title, header=header, VVWsIU=VVpn2v, VViqYN=VViqYN, VVv3Wm=widths, VVHZHw=26, VVZYdg=color, VVcwfs=color, VVLuY4=color, VVd479=VVd479, VV4ePT=VV4ePT, lastFindConfigObj=CFG.lastFindServices)
  else:
   FFzrXb(SELF, "No DVB Services !")
 @staticmethod
 def VVOBwu(SELF, title, okFnc, doneFnc=None):
  FFzW1w(SELF, BF(CCbA6i.VVDXMf, SELF, title, okFnc, doneFnc), title="Loading IPTV Services ...")
 @staticmethod
 def VVDXMf(SELF, title, okFnc, doneFnc=None):
  VVpn2v = CCbA6i.VVvQW6()
  if VVpn2v:
   color = "#0a112211"
   VVpn2v.sort(key=lambda x: x[0].lower())
   VVd479 = ("Select" , okFnc, [])
   VV4ePT= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Bouquet" , "URL" , "Reference" )
   widths  = (35  , 35  , 15 , 15   )
   FFldB6(SELF, None, title=title, header=header, VVWsIU=VVpn2v, VVv3Wm=widths, VVHZHw=26, VVZYdg=color, VVcwfs=color, VVLuY4=color, VVd479=VVd479, VV4ePT=VV4ePT, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFzrXb(SELF, "No IPTV Services !")
 @staticmethod
 def VVvQW6():
  VVpn2v = []
  files  = CCfw0y.VVvkN7()
  patt  = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+(.+)"
  if files:
   for path in files:
    txt = FFpCvR(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVxZ1m = span.group(1)
    else : VVxZ1m = ""
    VVxZ1m_lCase = VVxZ1m.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper().strip(":")
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     VVpn2v.append((chName, VVxZ1m, url, refCode))
  return VVpn2v
 def VV5VHO(self, srcName, srcRef, dstName, dstRef):
  tree = CCh3Pq.VVFz4s(self, self.shareFilePath)
  if not tree:
   return False
  root = tree.getroot()
  ch = iElem.Element("ch")
  root.append(ch)
  name  = iElem.SubElement(ch, "name1")
  ref   = iElem.SubElement(ch, "ref1")
  name.text = srcName
  ref.text = srcRef
  name  = iElem.SubElement(ch, "name2")
  ref   = iElem.SubElement(ch, "ref2")
  name.text = dstName
  ref.text = dstRef
  self.VVFguz(tree, root)
  return True
 def VV7BJo(self, srcName1, srcRef1, dstName1, dstRef1):
  tree = CCh3Pq.VVFz4s(self, self.shareFilePath)
  if not tree:
   return False
  tableLst = [srcName1, srcRef1, dstName1, dstRef1]
  found = False
  root = tree.getroot()
  for ch in root:
   ok, srcName, srcRef, dstName, dstRef = self.VVFALS(ch)
   if ok and [srcName, srcRef, dstName, dstRef] == tableLst:
    root.remove(ch)
    found = True
  if found:
   self.VVFguz(tree, root)
  return found
 def VVFguz(self, tree, root, withComments=True):
  xmlTxt = iElem.tostring(root)
  txt  = CCh3Pq.VV4T5m(xmlTxt)
  parser = CCh3Pq.CCp3at()
  if withComments : parser = iElem.XMLParser(target=parser)
  else   : parser = None
  root = iElem.fromstring(txt, parser=parser)
  tree._setroot(root)
  tree.write(self.shareFilePath, encoding="UTF-8")
 def VV643M(self, VVoLtS, title, txt, colList):
  if self.onlyEpg:
   self.VVzKHt(VVoLtS, "epg")
  else:
   if self.shareIsRef:
    FFo4dm(self, BF(FFzW1w, VVoLtS, BF(self.VV8IWI, VVoLtS)), "Copy all References from Source to Destination ?")
   else:
    VVMVqr = []
    VVMVqr.append(("Copy EPG\t (All List)" , "epg"  ))
    VVMVqr.append(("Copy Picons\t (All List)" , "picon" ))
    FF7ARM(self, BF(self.VVzKHt, VVoLtS), VVMVqr=VVMVqr, width=1000)
 def VVzKHt(self, VVoLtS, item=None):
  if item:
   if   item == "epg" : fnc, txt = self.VV0Mzc  , "EPG"
   elif item == "picon": fnc, txt = self.VV69QI , "PIcons"
   title = "Copy %s" % txt
   tot   = VVoLtS.VVgRm7()
   FFo4dm(self, BF(FFzW1w, VVoLtS, BF(fnc, VVoLtS, title)), "Overwrite %s for %d Service%s ?" % (FFCzRx(txt, VVRJhR), tot, FFoTxy(tot)), title=title)
 def VV8IWI(self, VVoLtS):
  files = CCfw0y.VVvkN7()
  totChange = 0
  if files:
   for path in files:
    txt = FFpCvR(path)
    toSave = False
    for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVoLtS.VVGkEL():
     if remark == "0":
      srcPart = ":".join(srcRef.split(":")[1:]) + ":"
      dstPart = ":".join(dstRef.split(":")[1:]) + ":"
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]))%s(.+\/\/.+)" % dstPart, r"\g<1>%s\2" % srcPart, txt, IGNORECASE)
      if tot:
       toSave = True
       totChange += tot
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
  if totChange > 0:
   FFwQUx()
  tot = VVoLtS.VVgRm7()
  txt  = "Services\t: %d\n" % tot
  txt += "Changed\t: %d\n"  % totChange
  txt += "Skipped\t: %d\n"  % (tot- totChange)
  FFtybv(self, txt)
 def VV69QI(self, VVoLtS, title):
  if not iCopyfile:
   FFzrXb(self, "Module not found:\n\nshutil", title=title)
   return
  pPath = CCxrlm.VVjBFN()
  totFound = totDone = totSame = totErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVoLtS.VVGkEL():
   srcPng = pPath + srcRef.replace(":", "_") + ".png"
   dstPng = pPath + dstRef.replace(":", "_") + ".png"
   if fileExists(srcPng):
    totFound += 1
    if srcPng == dstPng:
     totSame += 1
    else:
     try:
      iCopyfile(srcPng, dstPng)
      totDone += 1
     except:
      totErr += 1
  txt  = "Services\t: %d\n" % VVoLtS.VVgRm7()
  txt += "Found\t: %d\n" % totFound
  txt += "Copied\t: %d"  % totDone
  if totSame: txt += "\nSame Ref.\t: %d" % totSame
  if totErr : txt += "\nErrors\t: %d"  % totErr
  FFtybv(self, txt, title=title)
 def VV0Mzc(self, VVoLtS, title):
  txt, err = CCL7is.VVlbN8(VVoLtS, title)
  if err : FFzrXb(self, err, title=title)
  else : FFtybv(self, txt, title=title)
 class CCp3at(iElem.TreeBuilder):
  def comment(self, data):
   self.start(iElem.Comment, {})
   self.data(data)
   self.end(iElem.Comment)
 @staticmethod
 def VVFz4s(SELF, path, withComments=True, title=""):
  try:
   if withComments:
    try:
     return iElem.parse(path, parser=iElem.XMLParser(target=CCh3Pq.CCp3at()))
    except:
     return iElem.parse(path)
  except Exception as e:
   txt  = "%s\n%s\n\n" % (FFCzRx("XML Parse Error in:", VVszO3), path)
   txt += "%s\n%s\n\n" % (FFCzRx("Error:", VVszO3), str(e))
   FFtybv(SELF, txt, VVLuY4="#11220000", title=title)
   return None
 @staticmethod
 def VV4T5m(xmlTxt):
  txt = iSub(r">[\n\s]*", ">" , xmlTxt.decode("UTF-8"))
  txt = iSub(r"([^12])>\s*<" , r"\1>\n<", txt)
  txt = iSub(r"ref1>\s*<name2", r"ref1>\n<name2", txt)
  txt = iSub(r"</ref2></ch>" , r"</ref2>\n</ch>\n", txt)
  txt = iSub(r"<ch>"   , r"\t<ch>", txt)
  txt = iSub(r"</ch>"   , r"\t</ch>", txt)
  txt = iSub(r"<name1>"  , r"\t\t<name1>", txt)
  txt = iSub(r"<name2>"  , r"\t\t<name2>", txt)
  txt = iSub(r"(<!-- .+ -->)" , r"\t\1\n", txt)
  txt = iSub(r"<share>"  , r"<share>\n", txt)
  return txt
class CCL7is(Screen, CCbA6i):
 VVBBj8  = "BDTSE"
 VV1yeZ   = "save"
 VVRrvL   = "load"
 VVbi83  = "flushEPG"
 def __init__(self, session):
  self.skin, self.skinParam = FF5TEn(VVL1I3, 950, 800, 50, 40, 30, "#22110011", "#22110022", 30)
  self.session  = session
  valid, path, sz, szTxt = CCL7is.VVz8nD()
  qUrl, decodedUrl, iptvRef = CCfw0y.VVdDss(self)
  VVMVqr = []
  VVMVqr.append((VVJS3b + "Cache File Info." , "inf"))
  VVMVqr.append(VVpTvr)
  fTxt = " (%s)" % os.path.basename(path) if valid else ""
  VVMVqr.append(FFwLFH("Save EPG to File%s" % fTxt , self.VV1yeZ, valid))
  VVMVqr.append(FFwLFH("Load EPG from File%s" % fTxt , self.VVRrvL, valid))
  VVMVqr.append(VVpTvr)
  VVMVqr.append((VVtz60 + "Delete EPG (from RAM only)", self.VVbi83))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(FFwLFH("Update Current Bouquet EPG (from IPTV Server)", "refreshIptvEPG", qUrl or "chCode" in iptvRef))
  VVMVqr.append(("Copy EPG between Channels (from xml file)", "copyEpg" ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Translate Current Channel EPG %s(Experimental)" % VVtz60, "VVbXOC"))
  FF32Yx(self, VVMVqr=VVMVqr)
  self.onShown.append(self.VVSDD3)
 def VVthYm(self):
  global VVBcOf
  VVBcOf = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "inf"    : self.VV6ThW()
   elif item in (self.VV1yeZ, self.VVRrvL, self.VVbi83):
    reset = item == self.VVRrvL
    FFo4dm(self, BF(FFzW1w, self, BF(self.VVepzh, item, reset)), VV66pG="Continue ?")
   elif item == "refreshIptvEPG"  : CCfw0y.VVNX8T(self)
   elif item == "VVbXOC" : self.VVbXOC()
   elif item == "copyEpg"    : self.VVh0LG(False, onlyEpg=True)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  FFWzaz(self["myMenu"])
  FF0pG3(self)
 def VVepzh(self, act, reset=False):
  ok = CCL7is.VVeSto(act)
  if ok:
   if reset:
    CCL7is.VVDHYQ(self)
   FFuXZg(self, "Done")
  else:
   FFuXZg(self, "Failed!")
 def VV6ThW(self):
  title = "EPG Cache File"
  valid, path, sz, szTxt = CCL7is.VVz8nD()
  if path:
   if valid: txt = "File Path\t: %s\n\nFile Size\t: %s\n" % (path, szTxt or "?")
   else : txt = "System Settings: %s\n\n%s" % (path, FFCzRx("File not found (check System EPG settings).", VVtz60))
   FFtybv(self, txt, title=title)
  else:
   FFzrXb(self, "Cannot read Path Settings !", title=title)
 @staticmethod
 def VVfc7d():
  return [("", "Disable"),("af","Afrikaans"),("sq","Albanian"),("am","Amharic"),("ar","Arabic"),("hy","Armenian"),("as","Assamese"),("ay","Aymara"),("az","Azerbaijani"),("bm","Bambara"),("eu","Basque"),("be","Belarusian"),("bn","Bengali"),("bho","Bhojpuri"),("bs","Bosnian"),("bg","Bulgarian"),("ca","Catalan"),("ceb","Cebuano"),("ny","Chichewa"),("zh-CN","Chinese (Simplified)"),("zh-TW","Chinese (Traditional)"),("co","Corsican"),("hr","Croatian"),("cs","Czech"),("da","Danish"),("dv","Dhivehi"),("doi","Dogri"),("nl","Dutch"),("en","English"),("eo","Esperanto"),("et","Estonian"),("ee","Ewe"),("tl","Filipino"),("fi","Finnish"),("fr","French"),("fy","Frisian"),("gl","Galician"),("ka","Georgian"),("de","German"),("el","Greek"),("gn","Guarani"),("gu","Gujarati"),("ht","Haitian Creole"),("ha","Hausa"),("haw","Hawaiian"),("iw","Hebrew"),("hi","Hindi"),("hmn","Hmong"),("hu","Hungarian"),("is","Icelandic"),("ig","Igbo"),("ilo","Ilocano"),("id","Indonesian"),("ga","Irish"),("it","Italian"),("ja","Japanese"),("jw","Javanese"),("kn","Kannada"),("kk","Kazakh"),("km","Khmer"),("rw","Kinyarwanda"),("gom","Konkani"),("ko","Korean"),("kri","Krio"),("ku","Kurdish (Kurmanji)"),("ckb","Kurdish (Sorani)"),("ky","Kyrgyz"),("lo","Lao"),("la","Latin"),("lv","Latvian"),("ln","Lingala"),("lt","Lithuanian"),("lg","Luganda"),("lb","Luxembourgish"),("mk","Macedonian"),("mai","Maithili"),("mg","Malagasy"),("ms","Malay"),("ml","Malayalam"),("mt","Maltese"),("mi","Maori"),("mr","Marathi"),("mni-Mtei","Meiteilon (Manipuri)"),("lus","Mizo"),("mn","Mongolian"),("my","Myanmar (Burmese)"),("ne","Nepali"),("no","Norwegian"),("or","Odia (Oriya)"),("om","Oromo"),("ps","Pashto"),("fa","Persian"),("pl","Polish"),("pt","Portuguese"),("pa","Punjabi"),("qu","Quechua"),("ro","Romanian"),("ru","Russian"),("sm","Samoan"),("sa","Sanskrit"),("gd","Scots Gaelic"),("nso","Sepedi"),("sr","Serbian"),("st","Sesotho"),("sn","Shona"),("sd","Sindhi"),("si","Sinhala"),("sk","Slovak"),("sl","Slovenian"),("so","Somali"),("es","Spanish"),("su","Sundanese"),("sw","Swahili"),("sv","Swedish"),("tg","Tajik"),("ta","Tamil"),("tt","Tatar"),("te","Telugu"),("th","Thai"),("ti","Tigrinya"),("ts","Tsonga"),("tr","Turkish"),("tk","Turkmen"),("ak","Twi"),("uk","Ukrainian"),("ur","Urdu"),("ug","Uyghur"),("uz","Uzbek"),("vi","Vietnamese"),("cy","Welsh"),("xh","Xhosa"),("yi","Yiddish"),("yo","Yoruba"),("zu","Zulu")]
 def VVbXOC(self):
  title = "Translate Current Channel EPG"
  bg = "#11101010"
  VVd479  = (""  , BF(self.VVozJy, title, True) , [])
  VVEXwE = ("Start" , BF(self.VVozJy, title, False), [])
  VVJvWF = ("Change Language", self.VVxcv4      , [])
  widths  = (70 , 30)
  VViqYN = (LEFT , CENTER)
  FFldB6(self, None, title=title, VVWsIU=self.VVhe69(), VViqYN=VViqYN, VVv3Wm=widths, width=1200, vMargin=20, VVHZHw=30, VVd479=VVd479, VVEXwE=VVEXwE, VVJvWF=VVJvWF, VVcK1v=2
    , VVZYdg="#11201010", VVcwfs=bg, VVLuY4=bg, VVG27K="#00004455", VVQ9hc=bg)
 def VVhe69(self):
  Def, ch = "DISABLED", dict(CCL7is.VVfc7d())
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  VVWsIU = [("Event Name Language", ch.get(tVal, Def)), ("Description Language", ch.get(dVal, Def))]
  return VVWsIU
 def VVxcv4(self, VVoLtS, title, txt, colList):
  ndx = VVoLtS.VVqeSa()
  title = colList[0]
  confItem = CFG.epgLangTitle if ndx == 0 else CFG.epgLangDescr
  CCjmed.VVLGnu(self, confItem, title, lst=CCL7is.VVfc7d(), cbFnc=BF(self.VVeYhO, VVoLtS), isSave=True)
 def VVeYhO(self, VVoLtS):
  for ndx, row in enumerate(self.VVhe69()):
   VVoLtS.VVzJT7(ndx, row)
 def VVozJy(self, Title, isAsk, VVoLtS, title, txt, colList):
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  if not (tVal or dVal):
   FFycel(VVoLtS, "Change Language", 700)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFmvpz(self)
   refCode, evList, err = CCL7is.VVQJl6(refCode)
   fnc = BF(self.VVPEgH, Title, refCode, evList, VVoLtS)
   if   err : FFzrXb(self, err, title=Title)
   elif isAsk : FFo4dm(self, fnc, "Start ?", title=Title)
   else  : fnc()
 def VVPEgH(self, title, refCode, evList, VVoLtS):
  self.session.open(CCSCNk, barTheme=CCSCNk.VVSu4G, titleBg="#22003344", bodyBg="#22001122"
      , titlePrefix = title
      , fncToRun  = BF(self.VVNf2F, evList)
      , VVEStC = BF(self.VVvgoA, title, refCode))
  VVoLtS.cancel()
 def VVNf2F(self, evList, VV2ohY):
  totEv = len(evList)
  newLst = []
  totErrName = totErrShort = totErrLong = totSkip = 0
  VV2ohY.VVHJ4P(totEv)
  VV2ohY.VVRTV9 = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
  lang = CFG.epgLangDescr.getValue()
  for ev in evList:
   trName, trShort, trLong, errName, errShort, errLong = CCL7is.VV98Lo(*ev[2:5])
   totErrName  += errName
   totErrShort += errShort
   totErrLong  += errLong
   if not VV2ohY or VV2ohY.isCancelled:
    return
   VV2ohY.VVc1xD(1)
   VV2ohY.VV0VIG(len(newLst), ev[2] if len(ev[2]) < 22 else ev[2][:22] + " ...")
   name1, short1, long1 = ev[2:5]
   if (name1, short1, long1) != (trName, trShort, trLong):
    item = list(ev)
    item[2], item[3], item[4] = trName, trShort, trLong
    item.append(1)
    newLst.append(tuple(item))
   else:
    totSkip += 1
   VV2ohY.VVRTV9 = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
 def VVvgoA(self, title, refCode, VVPnF9, VVRTV9, threadCounter, threadTotal, threadErr):
  newLst, totEv, totErrName, totErrShort, totErrLong, totSkip = VVRTV9
  if newLst: totEv, totOK = CCL7is.VVNpl5(refCode, newLst)
  else  : totOK = 0
  if totOK:
   CCL7is.VV2crm()
   CCL7is.VVDHYQ(self)
  txt  = "Events\t: %d\n"  % totEv
  txt += "Processed\t: %d\n" % len(newLst)
  txt += "Changed\t: %d\n" % totOK
  if totSkip : txt += "Skipped\t: %d \t... Same language\n" % totSkip
  if any((totErrName, totErrShort, totErrLong)):
   txt += "\nErrors:\n"
   if totErrName : txt += "  Event Name\t: %d\n" % totErrName
   if totErrShort: txt += "  Description\t: %d\n" % totErrShort
   if totErrLong : txt += "  Description\t: %d\n" % totErrLong
  FFtybv(self, txt, title=title)
 @staticmethod
 def VV98Lo(eName, eShort, eLong):
  eName, eShort, eLong = eName.strip(), eShort.strip(), eLong.strip()
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  lang, lst, resLst, errLst = (tVal, dVal, dVal), (eName, eShort, eLong), ["", "", ""], [0, 0, 0]
  def VVchnh(ndx):
   if lst[ndx] and lang[ndx]:
    txt, err = CCL7is.VVBsQn(lst[ndx], lang[ndx])
    resLst[ndx], errLst[ndx] = txt, 1 if err else 0
  thLst = []
  for ndx in range(3):
   th = iThread(name="ajp_%d" % ndx, target=BF(VVchnh, ndx))
   th.start()
   thLst.append(th)
  for th in thLst: th.join()
  trName, trShort, trLong = resLst[0] or eName, resLst[1] or eShort, resLst[2] or eLong
  errName, errShort, errLong = errLst
  return trName, trShort, trLong, errName, errShort, errLong
 @staticmethod
 def VVBsQn(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "%s%s&q=%s" % ("=lt&otua=ls&?m/moc.elgoog.etalsnart//:sptth"[::-1], toLang, FF6XZy(txt))
   txt, err = CCfw0y.VVtidF(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFKkPs(txt)
    ndx  = txt.find('<div class="result-container">')
    if ndx > -1:
     txt = txt[ndx + 30:]
     ndx  = txt.find("</div>")
     if ndx > -1:
      return str(CCL7is.VVCemW(txt[:ndx])).strip(), ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVz8nD():
  path = szTxt = ""
  valid = sz = 0
  try: path = config.misc.epgcache_filename.getValue()
  except: pass
  if fileExists(path):
   valid = 1
   sz = FFPLWs(path)
   szTxt = CCUGPF.VVuy4U(sz) if sz > -1 else ""
  return valid, path, sz, szTxt
 @staticmethod
 def VVDjvm():
  try:
   from enigma import eEPGCache
   return eEPGCache, eEPGCache.getInstance()
  except:
   return None, None
 @staticmethod
 def VV2crm(): CCL7is.VVeSto(CCL7is.VV1yeZ)
 @staticmethod
 def VVeSto(act):
  ec, inst = CCL7is.VVDjvm()
  if inst and hasattr(ec, act):
   try:
    exec("inst.%s()" % act)
    return True
   except:
    pass
  return False
 @staticmethod
 def VVDHYQ(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   SELF.session.nav.stopService()
   SELF.session.nav.playService(serv)
 @staticmethod
 def VVQJl6(refCode):
  ec, inst = CCL7is.VVDjvm()
  if inst:
   try:
    evList = inst.lookupEvent([CCL7is.VVBBj8, (refCode, 0, -1, 20160)])
    if evList: return refCode, evList, ""
    else  : return refCode, [], "System returned empty EPG list"
   except:
    return refCode, [], "EPG Read-Error !"
  else:
   return refCode, [], "Cannot read EPG Cache !"
 @staticmethod
 def VVNpl5(refCode, events, longDescDays=0):
  ec, inst = CCL7is.VVDjvm()
  totEv, totOK, fnc = 0, 0, None
  if inst:
   if   hasattr(ec, "importEvents"): fnc = inst.importEvents
   elif hasattr(ec, "importEvent") : fnc = inst.importEvent
  if fnc:
   for data in events:
    totEv += 1
    try:
     if longDescDays and data[0] > iTime() + 86400 * longDescDays:
      data = data[:4] + ("",) + data[5:]
     fnc(refCode, (data,))
     totOK += 1
    except:
     pass
  return totEv, totOK
 @staticmethod
 def VV5fo0(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   ec, inst = CCL7is.VVDjvm()
   if ec:
    event = inst.lookupEventTime(serv, -1, 0)
    if event:
     return CCL7is.VVtFVK(event)
   try:
    info = serv and eServiceCenter.getInstance().info(serv)
    event = info and info.getEvent(serv)
    if event:
     return CCoD37.CCL7is(event)
   except:
    pass
  return [""] * 7
 @staticmethod
 def VVtFVK(event):
  evName = event.getEventName().strip()    or ""
  evTime = event.getBeginTime()      or ""
  evDur = event.getDuration()      or ""
  evShort = event.getShortDescription().strip()  or ""
  evDesc = event.getExtendedDescription().strip() or ""
  genre, PR = CCL7is.VVCHHV(event)
  return evName, evTime, evDur, evShort, evDesc, genre, PR
 @staticmethod
 def VVAjJu(refCode):
  service = eServiceReference(refCode)
  evLst = []
  if service:
   ec, inst = CCL7is.VVDjvm()
   try:
    if inst:
     for evNum in range(2):
      event = inst.lookupEventTime(service, -1, evNum)
      evName, evTime, evDur, evShort, evDesc, genre, PR = CCL7is.VVtFVK(event)
      evEnd = evPos = evRem = evCom = 0
      evTimeTxt = evPosTxt = evDurTxt = evEndTxt = evRemTxt = evComTxt = ""
      if evTime and evDur:
       evEnd = evTime + evDur
       evTimeTxt = FFgCM6(evTime)
       evEndTxt  = FFgCM6(evEnd)
       evDurTxt  = FFRTnP(evDur)
       now = int(iTime())
       if now > evTime and now < evEnd:
        evPos = now - evTime
        evPosTxt = FFRTnP(evPos)
        evRem = evEnd - now
        evRemTxt = FFRTnP(evRem)
       elif now < evTime:
        evCom = evTime - now
        evComTxt = FFRTnP(evCom)
      evLst.append((evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt))
   except:
    pass
  return evLst
 @staticmethod
 def VVCHHV(event):
  genre = PR = ""
  try:
   genre  = CCL7is.VVdF29(event.getGenreData().getLevel1(), event.getGenreData().getLevel2())
   age = event.getParentalData().getRating()
   PR  = CCL7is.VVWc0V(age)
  except:
   pass
  return genre, PR
 @staticmethod
 def VVWc0V(age):
  if   age == 0 : return "Undefinded (all ages)"
  elif age > 15 : return "Rated by broadcaster (%d)" % age
  else   : return "Minimum Age = %d years" % (age + 3)
 @staticmethod
 def VVdF29(L1, L2):
  if   L1 <= 0  : return "Undefined Content"
  elif L1 >= 15  : return "User Defined Genre"
  elif L1 > 12  : return "Unlisted Genre"
  else:
   MG, SG = CCL7is.VVEr5D()
   if MG and SG:
    key = "%d,%d" % (L1, L2)
    if key in SG   : return SG[key].title()
    elif L1 - 1 < len(MG) : return MG[L1 - 1] .title()
    else     : return "Unknown Genre"
   else:
    return ""
 @staticmethod
 def VVEr5D():
  path = VVLS8v + "_sup_genre"
  MG = SG = ""
  if fileExists(path):
   MG = iFindall(r"\d,0;(\w+\s?\w+)", FFpCvR(path), IGNORECASE)
   SG = iFindall(r"(\d+,\d+);(.+)", FFpCvR(path), IGNORECASE)
   if SG: SG = dict(SG)
  return MG, SG
 @staticmethod
 def VVlbN8(VVoLtS, title):
  ec, inst = CCL7is.VVDjvm()
  if not inst:
   return "", "Cannot access EPG Cache !"
  totFound = totEvents = totSuccess = totInvalid = totEvErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVoLtS.VVGkEL():
   if remark == "0":
    try:
     evList = inst.lookupEvent([CCL7is.VVBBj8, (srcRef, 0, -1, 20160)])
    except:
     totEvErr += 1
     evList = []
    if evList:
     totFound += 1
     lst = []
     for item in evList:
      lst.append((item[0], item[1], item[2], item[3], item[4], 1))
     totEv, totOK = CCL7is.VVNpl5(dstRef, lst)
     totEvents += totEv
     totSuccess += totOK
   else:
    totInvalid += 1
  if totSuccess > 0:
   CCL7is.VV2crm()
  txt  = "Services\t: %d\n"  % VVoLtS.VVgRm7()
  txt += "Invalid Ref.\t: %s\n" % totInvalid
  txt += "With Events\t: %d\n\n" % totFound
  txt += "Found Events\t: %d\n" % totEvents
  txt += "Copied Events\t: %d\n" % totSuccess
  if totEvErr:
   txt += "EPG Errors\t: %d" % totEvErr
  return txt, ""
 @staticmethod
 def VVc5HW(info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += CCL7is.VVWYBC(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += CCL7is.VVWYBC(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += CCL7is.VVWYBC(event, 0)
     except:
      pass
  return epg
 @staticmethod
 def VVWYBC(event, evNum):
  txt = ""
  if event:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCL7is.VVtFVK(event)
   if any([evName, evShort, evDesc, evTime, evDur]):
    trName, trShort, trLong, errName, errShort, errLong = CCL7is.VV98Lo(evName, evShort, evDesc)
    evShort, evDesc = trShort, trLong
    evNameTransl = trName if evName and trName and evName != trName else ""
    if evName          : txt += "Name\t: %s\n"   % FFCzRx(evName, VV61JF)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (CFG.epgLangDescr.getValue().upper(), FFCzRx(evNameTransl, VV61JF))
    if evTime           : txt += "Start Time\t: %s\n" % FFgCM6(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFgCM6(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFRTnP(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFRTnP(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFRTnP(evTime - now)
    if genre          : txt += "Genre\t: %s\n"  % genre
    if PR           : txt += "PC Rating\t: %s\n" % PR
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FFCzRx(evShort, VVYqlh)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFCzRx(evDesc , VVYqlh)
    if txt:
     txt = FFCzRx("\n%s\n%s Event:\n%s\n" % (SEP, ("Current", "Next")[evNum], SEP), VV61JF) + txt
  return txt
 @staticmethod
 def VVCemW(txt):
  try:
   from HTMLParser import HTMLParser
   return HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
class CCh3Pq(Screen, CCbA6i):
 VVIfVL  = 0
 VV2etj = 1
 VVNd7R  = 2
 VViwtE  = 3
 VVI8wC = 4
 VVPia1 = 5
 VVQqvd = 6
 VVsscu   = 7
 def __init__(self, session):
  self.skin, self.skinParam = FF5TEn(VVL1I3, 1000, 1040, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VVagcj = None
  self.lastfilterUsed  = None
  self.servFilterInFilter = False
  VVMVqr = self.VVU5Om()
  FF32Yx(self, VVMVqr=VVMVqr, title="Services/Channels")
  self.onShown.append(self.VVSDD3)
 def VVSDD3(self):
  self["myMenu"].setList(self.VVU5Om())
  FFWzaz(self["myMenu"])
  FF0pG3(self)
 def VVU5Om(self):
  VVMVqr = []
  c = VVJS3b
  VVMVqr.append((c + "Open Player Bar"         , "openPlayer"       ))
  VVMVqr.append((c + "Open Signal Monitor"        , "openSignal"       ))
  VVMVqr.append((c + "Current Service Information"      , "currentServiceInfo"     ))
  VVMVqr.append(VVpTvr)
  c = VV61JF
  VVMVqr.append((c + "Services (Change Parental-Control & Hidden)"  , "lameDB_allChannels_with_refCode"  ))
  VVMVqr.append((c + "Services (Transponders)"       , "lameDB_allChannels_with_tranaponder" ))
  VVMVqr.append((VVszO3 + "More tables ..."     , "VVJMWs"    ))
  c = VVYqlh
  VVMVqr.append(VVpTvr)
  txt = "Import Bouquets from Backup Files"
  if iTar : VVMVqr.append((c + txt          , "VVckjm"  ))
  else : VVMVqr.append((txt           ,          ))
  VVMVqr.append((c + 'Export Services to "channels.xml"'    , "VVu2i9"      ))
  VVMVqr.append((c + "Copy EPG/PIcons between Channels (from xml file)" , "copyEpgPicons"      ))
  c = VVTKrH
  VVMVqr.append(VVpTvr)
  VVMVqr.append((c + "Satellites Services Cleaner"      , "SatellitesCleaner"     ))
  VVMVqr.append((c + "Invalid Services Cleaner"       , "VVdksD"    ))
  c = VVTKrH
  VVMVqr.append(VVpTvr)
  VVMVqr.append((c + "Delete Channels with no names"     , "VVSeHK"    ))
  VVMVqr.append((c + "Delete Empty Bouquets"       , "VVR75P"     ))
  VVMVqr.append(VVpTvr)
  VVxkAm, VVLjas = CCh3Pq.VVqy0g()
  if fileExists(VVxkAm):
   enab = fileExists(VVLjas)
   if enab: VVMVqr.append(("Enable Hidden Services List"    , "enableHiddenChannels"    ))
   else   : VVMVqr.append(("Disable Hidden Services List"   , "disableHiddenChannels"    ))
  VVMVqr.append(("Reset Parental Control Settings"      , "VVFhQc"    ))
  VVMVqr.append(("Reload Channels and Bouquets"       , "VV326Q"      ))
  return VVMVqr
 def VVthYm(self):
  global VVBcOf
  VVBcOf = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "openPlayer"       : CCA3uT.VV1gQV(self.session)
   elif item == "openSignal"       : FFGuKK(self.session, reopen=True)
   elif item == "currentServiceInfo"     : FFp5JP(self, fncMode=CCoD37.VVp0RA)
   elif item == "lameDB_allChannels_with_refCode"  : FFzW1w(self, self.VVfiGq)
   elif item == "lameDB_allChannels_with_tranaponder" : FFzW1w(self, self.VVsGTm)
   elif item == "VVJMWs"     : self.VVJMWs()
   elif item == "VVckjm"  : CCxlZC.VVckjm(self)
   elif item == "VVu2i9"      : self.VVu2i9()
   elif item == "copyEpgPicons"      : self.VVh0LG(False)
   elif item == "SatellitesCleaner"     : FFzW1w(self, self.FFzW1w_SatellitesCleaner)
   elif item == "VVdksD"    : FFzW1w(self, BF(self.VVdksD))
   elif item == "VVSeHK"    : FFzW1w(self, self.VVSeHK)
   elif item == "VVR75P"     : self.VVR75P(self)
   elif item == "enableHiddenChannels"     : self.VVVbW5(True)
   elif item == "disableHiddenChannels"    : self.VVVbW5(False)
   elif item == "VVFhQc"    : FFo4dm(self, self.VVFhQc, "Reset and Restart ?")
   elif item == "VV326Q"      : FFzW1w(self, BF(CCh3Pq.VV326Q, self))
 def VVJMWs(self):
  VVMVqr = []
  VVMVqr.append(("Services (IDs)"       , "lameDB_allChannels_with_details" ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Services (Parental-Control List)"   , "parentalControlChannels"   ))
  VVMVqr.append(("Services (Hidden List)"     , "showHiddenChannels"    ))
  VVMVqr.append(("Services with PIcons for the System"  , "VVettd"    ))
  VVMVqr.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"  ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Transponders (Statistics)"    , "TranspondersStats"    ))
  VVMVqr.append(("Satellites.xml (Statistics)"    , "SatellitesXmlStats"    ))
  FF7ARM(self, self.VV65hk, VVMVqr=VVMVqr, title="Service Information", VVy9CS=True)
 def VV65hk(self, item):
  if item:
   title, ref, ndx = item
   if   ref == "lameDB_allChannels_with_details" : FFzW1w(self, BF(self.VVTMn3, title))
   elif ref == "parentalControlChannels"   : FFzW1w(self, BF(self.VVWkXP, title))
   elif ref == "showHiddenChannels"    : FFzW1w(self, BF(self.VVXjeO, title))
   elif ref == "VVettd"    : FFzW1w(self, BF(self.VVVQla, title))
   elif ref == "servicesWithMissingPIcons"   : FFzW1w(self, BF(self.VVJaVq, title))
   elif ref == "TranspondersStats"     : FFzW1w(self, BF(self.VV0Xr1, title))
   elif ref == "SatellitesXmlStats"    : FFzW1w(self, BF(self.VVtAWO, title))
 def VVu2i9(self):
  VVMVqr = []
  VVMVqr.append(("All DVB-S/C/T Services", "all"))
  VVMVqr.extend(CCrfsB.VVcVdn())
  FF7ARM(self, self.VVEcq6, VVMVqr=VVMVqr, title="", VVy9CS=True)
 def VVEcq6(self, item=None):
  if item:
   txt, ref, ndx = item
   if ref == "all" : lst = CCh3Pq.VVrNhE("1:7:")
   else   : lst = FFwksx(eServiceReference(ref))
   if lst:
    tot = len(lst)
    if tot > 0:
     rows = []
     for r, n in lst:
      sat = "?"
      serv = eServiceReference(r)
      if serv:
       chPath = serv.getPath()
       if not chPath    : sat = FFKMDj(r, False)
       elif chPath.startswith("/") : sat = "Local"
       elif FFYKlk(r)  : sat = "Stream Relay"
       elif FF3dcV(r)    : sat = "IPTV"
       rows.append('<!-- %s --><channel id="%s">%s</channel><!-- %s -->\n' % (sat, n, r, n))
     if rows:
      rows.sort()
      fPath = "%schannels_%s.xml" % (FF5DjF(CFG.exportedTablesPath.getValue()), FF4rM4())
      with open(fPath, "w") as f:
       f.write('<?xml version="1.0" encoding="utf-8"?>\n')
       f.write('<channels>\n\n')
       for row in rows: f.write(row)
       f.write('\n</channels>\n')
      FFuXZg(self, "Saved %d services to:\n\n%s" % (tot, fPath))
      return
   FFycel(self, "No Services found !", 1500)
 @staticmethod
 def VV326Q(SELF):
  FFwQUx()
  FFuXZg(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVfiGq(self):
  self.VVagcj = None
  self.lastfilterUsed  = None
  self.filterObj   = CCOe8b(self)
  VVpn2v, err = CCh3Pq.VVM6i7(self, self.VVIfVL)
  if VVpn2v:
   VVpn2v.sort(key=lambda x: x[0].lower())
   VVd479  = ("Zap"   , self.VVMur1     , [])
   VV1Jd7 = (""    , self.VVRyKf   , [])
   VV7J8f = ("Options"  , self.VVK3Oj , [])
   VVEXwE = ("Current Service", self.VV4DDl , [])
   VVJvWF = ("Filter"   , self.VViruN  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VViqYN  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFldB6(self, None, header=header, VVWsIU=VVpn2v, VViqYN=VViqYN, VVv3Wm=widths, VVHZHw=26, VVd479=VVd479, VV1Jd7=VV1Jd7, VVEXwE=VVEXwE, VV7J8f=VV7J8f, VVJvWF=VVJvWF, lastFindConfigObj=CFG.lastFindServices)
 def VVsGTm(self):
  self.VVagcj = None
  self.lastfilterUsed  = None
  self.filterObj   = CCOe8b(self)
  VVpn2v, err = CCh3Pq.VVM6i7(self, self.VV2etj)
  if VVpn2v:
   VVpn2v.sort(key=lambda x: x[0].lower())
   VVd479  = ("Zap"   , self.VVMur1      , [])
   VV1Jd7 = (""    , self.VVRyKf    , [])
   VVEXwE = ("Current Service", self.VV4DDl  , [])
   VV7J8f = ("Options"  , self.VVm2kQ , [])
   VVJvWF = ("Filter"   , self.VVpRc7  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VViqYN  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFldB6(self, None, header=header, VVWsIU=VVpn2v, VViqYN=VViqYN, VVv3Wm=widths, VVHZHw=26, VVd479=VVd479, VV1Jd7=VV1Jd7, VVEXwE=VVEXwE, VV7J8f=VV7J8f, VVJvWF=VVJvWF, lastFindConfigObj=CFG.lastFindServices)
 def VVK3Oj(self, VVoLtS, title, txt, colList):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  pcState  = colList[4].strip()
  hidState = colList[5].strip()
  mSel = CC74Cn(self, VVoLtS)
  VVMVqr = []
  isMulti = VVoLtS.VVzBSi
  if isMulti:
   refCodeList = VVoLtS.VVCtEG(3)
   if refCodeList:
    VVMVqr.append(("Add Selection to Parental Control"  , "parentalControl_sel_add"  ))
    VVMVqr.append(("Remove Selection from Parental Control" , "parentalControl_sel_remove" ))
    VVMVqr.append(VVpTvr)
    VVMVqr.append(("Add Selection to Hidden Services"   , "hiddenServices_sel_add"  ))
    VVMVqr.append(("Remove Selection from Hidden Services" , "hiddenServices_sel_remove" ))
    VVMVqr.append(VVpTvr)
  else:
   txt1 = "Add to Parental Control"
   txt2 = "Remove from Parental Control"
   if pcState == "No":
    VVMVqr.append((txt1, "parentalControl_add" ))
    VVMVqr.append((txt2,        ))
   else:
    VVMVqr.append((txt1,       ))
    VVMVqr.append((txt2, "parentalControl_remove" ))
   VVMVqr.append(VVpTvr)
   txt1 = "Add to Hidden Services"
   txt2 = "Remove from Hidden Services"
   if hidState == "No":
    VVMVqr.append((txt1, "hiddenServices_add"  ))
    VVMVqr.append((txt2,       ))
   else:
    VVMVqr.append((txt1,        ))
    VVMVqr.append((txt2, "hiddenServices_remove" ))
   VVMVqr.append(VVpTvr)
  cbFncDict = { "parentalControl_add"   : BF(self.VVM44d, VVoLtS, refCode, True)
     , "parentalControl_remove"  : BF(self.VVM44d, VVoLtS, refCode, False)
     , "hiddenServices_add"   : BF(self.VVFDtp, VVoLtS, refCode, True)
     , "hiddenServices_remove"  : BF(self.VVFDtp, VVoLtS, refCode, False)
     , "parentalControl_sel_add"  : BF(self.VVDu9p, VVoLtS, True)
     , "parentalControl_sel_remove" : BF(self.VVDu9p, VVoLtS, False)
     , "hiddenServices_sel_add"  : BF(self.VVRkVt, VVoLtS, True)
     , "hiddenServices_sel_remove" : BF(self.VVRkVt, VVoLtS, False)
     }
  VVMVqr1, cbFncDict1 = CCh3Pq.VVxSFC(self, VVoLtS, servName, 3)
  VVMVqr.extend(VVMVqr1)
  for key, val in cbFncDict1.items(): cbFncDict[key] = val
  mSel.VVKonP(VVMVqr, cbFncDict)
 def VVm2kQ(self, VVoLtS, title, txt, colList):
  servName = colList[0]
  mSel = CC74Cn(self, VVoLtS)
  VVMVqr, cbFncDict = CCh3Pq.VVxSFC(self, VVoLtS, servName, 3)
  mSel.VVKonP(VVMVqr, cbFncDict)
 @staticmethod
 def VVxSFC(SELF, VVoLtS, servName, refCodeCol):
  tot = VVoLtS.VVv3mu()
  if tot > 0:
   sTxt = FFCzRx("%d Service%s" % (tot, FFoTxy(tot)), VV61JF)
   VVMVqr = [("Add %s to Bouquet ..." % sTxt   , "addToBouquet_multi" )]
  else:
   servName = FFQdrB(servName)
   if len(servName) > 20: servName = servName[:20] + ".."
   servName = FFCzRx(servName, VV61JF)
   VVMVqr = [('Add "%s" to Bouquet ...' % servName , "addToBouquet_one" )]
  cbFncDict = { "addToBouquet_multi" : BF(CCh3Pq.VVaNZj, SELF, VVoLtS, refCodeCol, True)
     , "addToBouquet_one" : BF(CCh3Pq.VVaNZj, SELF, VVoLtS, refCodeCol, False)
     }
  return VVMVqr, cbFncDict
 @staticmethod
 def VVaNZj(SELF, VVoLtS, refCodeCol, isMulti):
  picker = CCrfsB(SELF, VVoLtS, "Add to Bouquet", BF(CCh3Pq.VVVkGN, VVoLtS, refCodeCol, isMulti))
 @staticmethod
 def VVVkGN(VVoLtS, refCodeCol, isMulti):
  if isMulti : refCodeList = VVoLtS.VVCtEG(refCodeCol)
  else  : refCodeList = [VVoLtS.VVkHbA()[refCodeCol]]
  chUrlLst = []
  for ref in refCodeList:
   chUrlLst.append(ref)
  return chUrlLst
 def VVM44d(self, VVoLtS, refCode, isAddToBlackList):
  VVoLtS.VVwNb0("Processing ...")
  FFA9HA(BF(self.VV7mnt, VVoLtS, [refCode], isAddToBlackList))
 def VVDu9p(self, VVoLtS, isAddToBlackList):
  refCodeList = VVoLtS.VVCtEG(3)
  if not refCodeList:
   FFzrXb(self, "Nothing selected", title="Change Parental-Control State")
   return
  VVoLtS.VVwNb0("Processing ...")
  FFA9HA(BF(self.VV7mnt, VVoLtS, refCodeList, isAddToBlackList))
 def VV7mnt(self, VVoLtS, refCodeList, isAddToBlackList):
  for ndx, refCode in enumerate(refCodeList):
   refCode = refCode.strip()
   if not refCode.endswith(":"):
    refCode += ":"
    refCodeList[ndx] = refCode
  changed = False
  if isAddToBlackList:
   if isAddToBlackList:
    with open(VVz9hY, "a") as f:
     for refCode in refCodeList:
      f.write(refCode + "\n")
      changed = True
  elif fileExists(VVz9hY):
   lines = FF2WPS(VVz9hY)
   if lines:
    for refCode in refCodeList:
     while refCode in lines:
      ndx = lines.index(refCode)
      lines[ndx] = ""
      changed = True
    if changed:
     with open(VVz9hY, "w") as f:
      for line in lines:
       if line:
        f.write(line + "\n")
  if changed:
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   isMulti = VVoLtS.VVzBSi
   if isMulti:
    self.VVAYmh(VVoLtS, len(refCodeList))
   else:
    if refCode.endswith(":"):
     refCode = refCode[:-1]
    self.VVdgLO(VVoLtS, refCode)
    VVoLtS.VV6eCK()
  else:
   VVoLtS.VVOPq5("No changes")
 def VVFDtp(self, VVoLtS, refCode, isHide):
  title = "Change Hidden State"
  if FFEEqJ(refCode):
   VVoLtS.VVwNb0("Processing ...")
   ret = FF33MI(refCode, isHide)
   if ret : FFzW1w(self, BF(self.VVdgLO, VVoLtS, refCode))
   else : FFzrXb(self, "Cannot Hide/Unhide this channel.", title=title)
  else:
   FFzrXb(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)", title=title)
 def VVdgLO(self, VVoLtS, refCode):
  VVpn2v, err = CCh3Pq.VVM6i7(self, self.VVIfVL, VVpr3b=[3, [refCode], False])
  done = False
  if VVpn2v:
   data = VVpn2v[0]
   if data[3] == refCode:
    done = VVoLtS.VVlhah(data)
  if not done:
   self.VVhvau(VVoLtS, VVoLtS.VVqJjk(), self.VVIfVL)
  VVoLtS.VV6eCK()
 def VVAYmh(self, VVoLtS, totRefCodes):
  VVpn2v, err = CCh3Pq.VVM6i7(self, self.VVIfVL, VVpr3b=self.VVagcj)
  VVoLtS.VVkYNn(VVpn2v)
  VVoLtS.VV14UF(False)
  VVoLtS.VVOPq5("%d Processed" % totRefCodes)
 def VVRkVt(self, VVoLtS, isHide):
  refCodeList = VVoLtS.VVCtEG(3)
  if not refCodeList:
   FFzrXb(self, "Nothing selected", title="Change Hidden State")
   return
  VVoLtS.VVwNb0("Processing ...")
  FFA9HA(BF(self.VVyvzi, VVoLtS, refCodeList, isHide))
 def VVyvzi(self, VVoLtS, refCodeList, isHide):
  totChanges = 0
  for refCode in refCodeList:
   ret = FF33MI(refCode, isHide, skipReload=True)
   if ret:
    totChanges += 1
  if totChanges > 0:
   FFwQUx(True)
   self.VVAYmh(VVoLtS, len(refCodeList))
  else:
   VVoLtS.VVOPq5("No changes")
 def VViruN(self, VVoLtS, title, txt, colList):
  inFilterFnc = BF(self.VV7owZ, VVoLtS) if self.VVagcj else None
  self.filterObj.VVcL71(1, VVoLtS, 2, BF(self.VVIzZb, VVoLtS), inFilterFnc=inFilterFnc)
 def VVIzZb(self, VVoLtS, item):
  self.VVLlb5(VVoLtS, False, item, 2, self.VVIfVL)
 def VV7owZ(self, VVoLtS, VVdtUh, item):
  self.VVLlb5(VVoLtS, True, item, 2, self.VVIfVL)
 def VVpRc7(self, VVoLtS, title, txt, colList):
  inFilterFnc = BF(self.VVJw5X, VVoLtS) if self.VVagcj else None
  self.filterObj.VVcL71(2, VVoLtS, 4, BF(self.VVSdHz, VVoLtS), inFilterFnc=inFilterFnc)
 def VVSdHz(self, VVoLtS, item):
  self.VVLlb5(VVoLtS, False, item, 4, self.VV2etj)
 def VVJw5X(self, VVoLtS, VVdtUh, item):
  self.VVLlb5(VVoLtS, True, item, 4, self.VV2etj)
 def VVvSrR(self, VVoLtS, title, txt, colList):
  inFilterFnc = BF(self.VVrZrA, VVoLtS) if self.VVagcj else None
  self.filterObj.VVcL71(0, VVoLtS, 4, BF(self.VV1qPN, VVoLtS), inFilterFnc=inFilterFnc)
 def VV1qPN(self, VVoLtS, item):
  self.VVLlb5(VVoLtS, False, item, 4, self.VVNd7R)
 def VVrZrA(self, VVoLtS, VVdtUh, item):
  self.VVLlb5(VVoLtS, True, item, 4, self.VVNd7R)
 def VVLlb5(self, VVoLtS, isInFilter, item, satCol, mode):
  self.servFilterInFilter = isInFilter
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVoLtS.VVh7wm(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VVagcj = None
  else:
   words, asPrefix = CCOe8b.VVjxXj(words)
   self.VVagcj = [col, words, asPrefix]
  if words: FFzW1w(VVoLtS, BF(self.VVhvau, VVoLtS, title, mode), clearMsg=False)
  else : FFycel(VVoLtS, "Incorrect filter", 2000)
 def VVhvau(self, VVoLtS, title, mode):
  VVpn2v, err = CCh3Pq.VVM6i7(self, mode, VVpr3b=self.VVagcj, VVkOYc=False)
  if self.servFilterInFilter:
   lst = []
   for row in VVoLtS.VVGkEL():
    try:
     ndx = VVpn2v.index(tuple(list(map(str.strip, row))))
     lst.append(VVpn2v[ndx])
    except:
     pass
   VVpn2v = lst
  if VVpn2v:
   VVpn2v.sort(key=lambda x: x[0].lower())
   VVoLtS.VVkYNn(VVpn2v, title, VVz586Msg=True)
  else:
   FFycel(VVoLtS, "Not found!", 1500)
 def VV28ta(self, title, VVWsIU, VVd479=None, VV1Jd7=None, VVKDDh=None, VVEXwE=None, VV7J8f=None, VVJvWF=None):
  VVEXwE = ("Current Service", self.VV4DDl, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VViqYN = (LEFT  , LEFT  , CENTER, LEFT    )
  FFldB6(self, None, title=title, header=header, VVWsIU=VVWsIU, VViqYN=VViqYN, VVv3Wm=widths, VVHZHw=26, VVd479=VVd479, VV1Jd7=VV1Jd7, VVKDDh=VVKDDh, VVEXwE=VVEXwE, VV7J8f=VV7J8f, VVJvWF=VVJvWF, lastFindConfigObj=CFG.lastFindServices)
 def VV4DDl(self, VVoLtS, title, txt, colList):
  self.VVaUk8(VVoLtS)
 def VVG4E7(self, VVoLtS, title, txt, colList):
  self.VVaUk8(VVoLtS, True)
 def VVaUk8(self, VVoLtS, isFromDetails=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFmvpz(self)
  if refCode:
   if isFromDetails:
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVoLtS.VVQ2Hx(colDict, VVx3z3=True)
   else:
    VVoLtS.VVVRgf(3, refCode, True)
   return
  FFzrXb(self, "Cannot read current Reference Code !")
 def VVTMn3(self, title):
  self.VVagcj = None
  self.lastfilterUsed  = None
  self.filterObj   = CCOe8b(self)
  VVpn2v, err = CCh3Pq.VVM6i7(self, self.VVNd7R)
  if VVpn2v:
   VVpn2v.sort(key=lambda x: x[0].lower())
   VV1Jd7 = (""    , self.VVdzfS , []      )
   VVEXwE = ("Current Service", self.VVG4E7  , []      )
   VVJvWF = ("Filter"   , self.VVvSrR   , [], "Loading Filters ..." )
   VVd479  = ("Zap"   , self.VVE8V9      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VViqYN  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFldB6(self, None, title=title, header=header, VVWsIU=VVpn2v, VViqYN=VViqYN, VVv3Wm=widths, VVHZHw=26, VVd479=VVd479, VV1Jd7=VV1Jd7, VVEXwE=VVEXwE, VVJvWF=VVJvWF, lastFindConfigObj=CFG.lastFindServices)
 def VVdzfS(self, VVoLtS, title, txt, colList):
  refCode  = self.VVm2B3(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFp5JP(self, fncMode=CCoD37.VVPeb2, refCode=refCode, chName=chName, text=txt)
 def VVE8V9(self, VVoLtS, title, txt, colList):
  refCode = self.VVm2B3(colList)
  FFrvm6(self, refCode)
 def VVMur1(self, VVoLtS, title, txt, colList):
  FFrvm6(self, colList[3])
 def VVm2B3(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVYr4K(VVxkAm, mode=0):
  lines = FF2WPS(VVxkAm, encLst=["UTF-8"])
  return CCh3Pq.VVM6w4(lines, mode)
 @staticmethod
 def VVM6w4(lines, mode):
  lst = []
  header = "transponders" if mode < 10 else "services"
  if header in lines:
   lines = lines[lines.index(header) + 1:]
   if "end" in lines:
    lines = lines[:lines.index("end")]
    if len(lines) % 3 == 0:
     for i in range(0, len(lines), 3):
      if   mode in (0, 10): lst.append((lines[i], lines[i + 1], lines[i + 2]))
      elif mode in (1, 11): lst.append(lines[i].upper())
      elif mode in (2, 12): lst.append(lines[i + 1])
      elif mode in (3, 13): lst.append(lines[i + 2])
  return lst
 @staticmethod
 def VVM6i7(SELF, mode, VVpr3b=None, VVkOYc=True, VVLya0=True):
  VVxkAm, err = CCh3Pq.VV7Ps5(SELF, VVLya0)
  if err:
   return None, err
  asPrefix = False
  if VVpr3b:
   filterCol = VVpr3b[0]
   filterWords = VVpr3b[1]
   asPrefix = VVpr3b[2]
   filterWords = list(filterWords)
   for ndx, item in enumerate(filterWords):
    filterWords[ndx] = item.strip().lower()
  else:
   filterWords = None
  if mode == CCh3Pq.VVIfVL:
   blackList = None
   if fileExists(VVz9hY):
    blackList = FF2WPS(VVz9hY)
    if blackList:
     blackList = set(blackList)
  elif mode == CCh3Pq.VV2etj:
   tp = CC9Nee()
  VV9tU5, VVRXrA = FFs2e5()
  if mode in (CCh3Pq.VVPia1, CCh3Pq.VVQqvd):
   VVpn2v = {}
  else:
   VVpn2v = []
  tagFound = False
  with ioOpen(VVxkAm, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end":
      break
     lines.append(line)
     if len(lines) >= 3:
      chCode = lines[0].upper()
      chName = lines[1]
      chProv = lines[2]
      if chCode.count(":") > 4 and not "," in chCode:
       parts = chCode.split(":")
       SID   = parts[0]
       NameSpace = parts[1]
       TSID  = parts[2]
       ONID  = parts[3]
       STYPE  = parts[4]
      else:
       SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
      chProvOrig = chProv
      if ","  in chProv : chProv = chProv.split(",")[0].strip()
      if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
      if len(chName) == 0 : chName = "-"
      if len(chProv) == 0 : chProv = "-"
      s = NameSpace.zfill(8)[:4]
      val = int(s, 16)
      sat = FFjpbV(val)
      try:
       sTypeInt = int(STYPE)
       servTypeHex = (hex(sTypeInt))[2:].upper()
      except:
       sTypeInt = 0
       servTypeHex = "0"
      if mode == CCh3Pq.VVNd7R:
       if sTypeInt in VV9tU5:
        STYPE = VVRXrA[sTypeInt]
       tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
       if filterWords:
        tmp = tRow[filterCol].lower()
        if asPrefix:
         if any(tmp.startswith(x) for x in filterWords) : VVpn2v.append(tRow)
        elif any(x in tmp for x in filterWords)    : VVpn2v.append(tRow)
       else:
        VVpn2v.append(tRow)
      else:
       refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
       refCode = refCode.replace("::", ":0:")
       if mode == CCh3Pq.VVsscu:
        VVpn2v.append((chName, chProv, sat, refCode))
       elif mode == CCh3Pq.VVPia1:
        VVpn2v[refCode.replace(":", "_")] = (chName, sat, 1)
       elif mode == CCh3Pq.VVQqvd:
        VVpn2v[chName] = refCode
       elif mode == CCh3Pq.VVIfVL:
        if blackList and refCode + ":" in blackList : isBlackList = "Yes"
        else          : isBlackList = "No"
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
        else          : hidStr =  "No"
        tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVpn2v.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVpn2v.append(tRow)
        else:
         VVpn2v.append(tRow)
       elif mode == CCh3Pq.VV2etj:
        if sTypeInt in VV9tU5:
         STYPE = VVRXrA[sTypeInt]
        freq, pol, fec, sr, syst = tp.VVsUQe(refCode)
        if not "-S" in syst:
         sat = syst
        if freq == "-" : tpStr = "-"
        else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
        tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVpn2v.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVpn2v.append(tRow)
        else:
         VVpn2v.append(tRow)
       elif mode == CCh3Pq.VViwtE:
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2:
         VVpn2v.append((chName, chProv, sat, refCode))
       elif mode == CCh3Pq.VVI8wC:
        VVpn2v.append((chName, chProv, sat, refCode))
      lines = []
    elif line == "services":
     tagFound = True
  if not VVpn2v and VVkOYc:
   FFzrXb(SELF, "No services found!")
  return VVpn2v, ""
 def VVWkXP(self, title):
  if fileExists(VVz9hY):
   lines = FF2WPS(VVz9hY)
   if lines:
    newRows = []
    VVpn2v, err = CCh3Pq.VVM6i7(self, self.VVI8wC)
    if VVpn2v:
     lines = set(lines)
     for item in VVpn2v:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVpn2v = newRows
      VVpn2v.sort(key=lambda x: x[0].lower())
      VV1Jd7 = ("", self.VVRyKf, [])
      VVd479 = ("Zap", self.VVMur1, [])
      self.VV28ta(title, VVpn2v, VVd479=VVd479, VV1Jd7=VV1Jd7)
     else:
      FFtybv(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVpn2v)))
   else:
    FFuXZg(self, "No active Parental Control services.", FFcYIL())
  else:
   FFZ5Ys(self, VVz9hY)
 def VVXjeO(self, title):
  VVpn2v, err = CCh3Pq.VVM6i7(self, self.VViwtE)
  if VVpn2v:
   VVpn2v.sort(key=lambda x: x[0].lower())
   VV1Jd7 = ("" , self.VVRyKf, [])
   VVd479  = ("Zap", self.VVMur1, [])
   self.VV28ta(title, VVpn2v, VVd479=VVd479, VV1Jd7=VV1Jd7)
  elif err:
   pass
  else:
   FFuXZg(self, "No hidden services.", FFcYIL())
 def VVdksD(self):
  title = "Services unused in Tuner Configuration"
  VVxkAm, err = CCh3Pq.VV7Ps5(self, title=title)
  if err:
   return
  nsLst = set()
  usedSats = CCh3Pq.VVtJEv()
  for tuner in usedSats:
   for item in tuner[1]:
    ns = self.VVDJX8(str(item[0]))
    nsLst.add(ns)
  sysLst = CCh3Pq.VVrNhE("1:7:")
  tpLst  = CCh3Pq.VVYr4K(VVxkAm, mode=1)
  VVpn2v = []
  for refCode, chName in sysLst:
   servID = CCh3Pq.VV3ySm(refCode)
   tpID = CCh3Pq.VVzp7h(refCode)
   refNs = refCode.split(":")[6].zfill(8)[:4]
   if not tpID in tpLst or not refNs in nsLst:
    VVpn2v.append((chName, FFKMDj(refCode, False), refCode, servID))
  if VVpn2v:
   VVpn2v.sort(key=lambda x: x[0].lower())
   VV7J8f = ("Options"   , BF(self.VVi490, title), [])
   header   = ("Name" , "Media" , "Reference" , '"lamedb" Code' )
   widths   = (55  , 10  , 0    , 35    )
   VViqYN  = (LEFT  , CENTER , LEFT   , CENTER   )
   FFldB6(self, None, title=title, header=header, VVWsIU=VVpn2v, VViqYN=VViqYN, VVv3Wm=widths, VVHZHw=26, VV7J8f=VV7J8f, VVZYdg="#0a001122", VVcwfs="#0a001122", VVLuY4="#0a001122", VVG27K="#00004455", VVQ9hc="#0a333333", VVGpiI="#11331100", lastFindConfigObj=CFG.lastFindServices)
  else:
   FFuXZg(self, "No invalid service found !", title=title)
 def VVi490(self, Title, VVoLtS, title, txt, colList):
  mSel = CC74Cn(self, VVoLtS)
  isMulti = VVoLtS.VVzBSi
  if isMulti : txt = "Remove %s Services" % FFCzRx(str(VVoLtS.VVv3mu()), VVszO3)
  else  : txt = "Remove : %s" % FFCzRx(VVoLtS.VVkHbA()[0], VVszO3)
  VVMVqr = [(txt, "del")]
  cbFncDict = {"del": BF(FFzW1w, VVoLtS, BF(self.VVLZJC, VVoLtS, Title))}
  mSel.VVKonP(VVMVqr, cbFncDict)
 def VVLZJC(self, VVoLtS, title):
  VVxkAm, err = CCh3Pq.VV7Ps5(self, title=title)
  if err:
   return
  isMulti = VVoLtS.VVzBSi
  skipLst = []
  if isMulti : skipLst = VVoLtS.VVCtEG(3)
  else  : skipLst = [VVoLtS.VVkHbA()[3]]
  tpLst = CCh3Pq.VVYr4K(VVxkAm, mode=0)
  servLst = CCh3Pq.VVYr4K(VVxkAm, mode=10)
  tmpDbFile = VVxkAm + ".tmp"
  lines   = FF2WPS(VVxkAm)
  skip = False
  with open(tmpDbFile, "w") as f:
   for line in lines:
    tLine = line.strip()
    if tLine == "services":
     skip = True
     f.write(line + "\n")
     for item in servLst:
      if not item[0].upper() in skipLst:
       for L in item:
        f.write(L + "\n")
    elif skip and tLine == "end":
     skip = False
    if not skip:
     f.write(line + "\n")
  FFgSm7("mv -f '%s' '%s'" % (tmpDbFile, VVxkAm))
  VVpn2v = []
  for row in VVoLtS.VVGkEL():
   if not row[3] in skipLst:
    VVpn2v.append(row)
  FFwQUx()
  FFtybv(self, "Removed Services : %d" % len(skipLst), title="Remove Services")
  if VVpn2v:
   VVoLtS.VVkYNn(VVpn2v, title)
   VVoLtS.VV14UF(False)
  else:
   VVoLtS.cancel()
 def VV0Xr1(self, title):
  VVxkAm, err = CCh3Pq.VV7Ps5(self)
  if err:
   return
  totT, totC, totA, totS, totS2, satList = self.VVUPNW(VVxkAm)
  txt = FFCzRx("Total Transponders:\n\n", VVAaU5)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFCzRx("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVAaU5)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat.sort(key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFwRWu(item), satList.count(item))
  FFtybv(self, txt, title)
 def VVUPNW(self, VVxkAm):
  totT = totC = totA = totS = totS2 = 0
  satList = []
  tagFound = False
  with ioOpen(VVxkAm, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end"    : break
     elif line.startswith("t")  : totT += 1
     elif line.startswith("c")  : totC += 1
     elif line.startswith("a")  : totA += 1
     elif line.startswith("s"):
      c = line.count(":")
      if   c > 9: totS2 += 1
      elif c > 5: totS  += 1
      if c > 5:
       satList.append(line.split(":")[4])
    elif line == "transponders":
     tagFound = True
  return totT, totC, totA, totS, totS2, satList
 def VVtAWO(self, title):
  path = "/etc/tuxbox/satellites.xml"
  if not fileExists(path):
   FFZ5Ys(self, path, title=title)
   return
  elif not CCUGPF.VV1eSU(self, path, title):
   return
  if not CCk55e.VVccK9(self):
   return
  tree = CCh3Pq.VVFz4s(self, path, title=title)
  if not tree:
   return
  VVpn2v = []
  root  = tree.getroot()
  totTpColor = "#f#00FFFF55#"
  for sat in root.findall("sat"):
   name = str(sat.get("name", "").encode("UTF-8").decode())
   pos  = sat.get("position", "")
   totTp = len(sat)
   hor = ver = cirL = cirR = unk = 0
   dvbS = dvbS2 = dvbUnk = 0
   for tp in sat.findall("transponder"):
    pol = tp.get("polarization")
    if   pol == "0" : hor += 1
    elif pol == "1" : ver += 1
    elif pol == "2" : cirL += 1
    elif pol == "3" : cirR += 1
    Sys = tp.get("system")
    if   Sys == "0" : dvbS += 1
    elif Sys == "1" : dvbS2 += 1
   try:
    posNum = int(pos)
    if posNum == 1801:
     posCalc = "180.1E"
    else:
     if posNum < 0:
      posNum += 3600
     posCalc = FFjpbV(posNum)
   except:
    posCalc = "?"
    pos  = "-9999"
   if " " in name : posXml, name = name.split(" ", 1)
   else   : posXml = posCalc
   bg = "" if posCalc.endswith("W") else "#b#00003333#"
   VVpn2v.append((bg + name, pos, posXml, posCalc, totTpColor + str(totTp), str(hor), str(ver), str(cirL), str(cirR), str(dvbS), str(dvbS2)))
  if VVpn2v:
   VVpn2v.sort(key=lambda x: int(x[1]))
   VVEXwE = ("Current Satellite", BF(self.VVirLm, 3), [])
   header   = ("Satellite" , "Pos #" , "xml Pos" , "Position", "TP" , "Hor" , "Ver" , "Circ-L" , "Circ-R" , "DVB-S" , "DVB-S2" )
   widths   = (36    , 8   , 0   , 10  , 6  , 5  , 5  , 7   , 7   , 8   , 8   )
   VViqYN  = (LEFT   , CENTER , CENTER , CENTER , CENTER, CENTER, CENTER, CENTER , CENTER , CENTER , CENTER )
   FFldB6(self, None, title=title, header=header, VVWsIU=VVpn2v, VViqYN=VViqYN, VVv3Wm=widths, VVHZHw=25, VVklCm=1, VVEXwE=VVEXwE, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FFzrXb(self, "No data found !", title=title)
 def VVirLm(self, satCol, VVoLtS, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFmvpz(self)
  sat = FFKMDj(refCode, False)
  for ndx, row in enumerate(VVoLtS.VVGkEL()):
   if sat == row[satCol].strip():
    VVoLtS.VV7qpv(ndx)
    break
  else:
   FFycel(VVoLtS, "No listed !", 1500)
 def FFzW1w_SatellitesCleaner(self):
  satLst = nimmanager.getSatList()
  if not satLst:
   FFzrXb(self, "No Satellites found !")
   return
  usedSats = CCh3Pq.VVtJEv()
  VVpn2v = []
  for sat in satLst:
   tunerLst = []
   for tuner, sats in usedSats:
    if sat in sats:
     tunerLst.append(tuner)
   tunerLst.sort()
   tuners = " , ".join(tunerLst) if tunerLst else ""
   posVal = sat[0]
   if posVal > 1800: posTxt = str(posVal - 3600)
   else   : posTxt = str(posVal)
   VVpn2v.append((sat[1], posTxt, FFjpbV(sat[0]), tuners, str(posVal)))
  if VVpn2v:
   VVLuY4 = "#11222222"
   VVpn2v.sort(key=lambda x: int(x[1]))
   VVEXwE = ("Current Satellite" , BF(self.VVirLm, 2) , [])
   VV7J8f = ("Options"   , self.VVlEDa  , [])
   header   = ("Satellite" , "Pos #" , "Position", "Tuners" , "posVal" )
   widths   = ( 50    , 10  , 10  , 30  , 0   )
   VViqYN  = ( LEFT  , CENTER , CENTER , CENTER , CENTER )
   FFldB6(self, None, header=header, VVWsIU=VVpn2v, VViqYN=VViqYN, VVv3Wm=widths, VVHZHw=28, VVEXwE=VVEXwE, VV7J8f=VV7J8f, VVZYdg=VVLuY4, VVcwfs=VVLuY4, VVLuY4=VVLuY4, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FFzrXb(self, "No data found !")
 def VVlEDa(self, VVoLtS, title, txt, colList):
  mSel = CC74Cn(self, VVoLtS)
  isMulti = VVoLtS.VVzBSi
  if isMulti : txt = "Remove ALL Services on %s Satellites" % FFCzRx(str(VVoLtS.VVv3mu()), VVszO3)
  else  : txt = "Remove ALL Services on : %s" % FFCzRx(VVoLtS.VVkHbA()[0], VVszO3)
  VVMVqr = []
  VVMVqr.append((txt, "deleteSat"))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Delete Empty Bouquets", "VVR75P"))
  cbFncDict = { "deleteSat"   : BF(FFzW1w, VVoLtS, BF(self.VVpoLp, VVoLtS))
     , "VVR75P" : BF(self.VVR75P, VVoLtS)
     }
  mSel.VVKonP(VVMVqr, cbFncDict)
 def VVpoLp(self, VVoLtS):
  posLst = []
  isMulti = VVoLtS.VVzBSi
  posLst = []
  if isMulti : posLst = VVoLtS.VVCtEG(4)
  else  : posLst = [VVoLtS.VVkHbA()[4]]
  nsLst = []
  for pos in posLst:
   nsLst.append(self.VVDJX8(pos))
  db = eDVBDB.getInstance()
  if db:
   for pos in posLst:
    db.removeServices(-1, -1, -1, int(pos))
  totCh, totBoq = self.VVpRHo(nsLst)
  FFwQUx(True)
  FFtybv(self, "Deleted Satellites:\n%d\n\nDeleted Services:\n%d\n\nCleaned Bouquets:\n%d" % (len(posLst), totCh, totBoq), title="Delete Satellites")
 def VVR75P(self, winObj):
  title = "Delete Empty Bouquets"
  FFo4dm(self, BF(FFzW1w, winObj, BF(self.VVNknf, title)), "Delete bouquets with no services ?", title=title)
 def VVNknf(self, title):
  bList = CCrfsB.VVXSkm()
  bNames = []
  if bList:
   fList = []
   for bName, bRef in bList:
    bFile = CCrfsB.VVGT0Q(bRef)
    bPath = VVTAUs + bFile
    FFnPMX(bPath)
    bNames.append(bName)
    fList.append(bFile)
   if fList:
    for fil in ("bouquets.tv", "bouquets.radio"):
     path = VVTAUs + fil
     if fileExists(path):
      lines = FF2WPS(path)
      newLines = []
      for line in lines:
       for bFile in fList:
        if bFile in line:
         break
       else:
        newLines.append(line)
      if newLines:
       with open(path, "w") as f:
        f.write("\n".join(newLines) + "\n")
   FFwQUx(True)
  if bNames: txt = "%s\n\n%s" % (FFCzRx("Deleted Bouquets:", VV61JF), "\n".join(bNames))
  else  : txt = "No empty bouquets."
  FFtybv(self, txt, title=title)
 def VVDJX8(self, pos):
  pos = int(pos.strip())
  if pos < 0:
   pos += 3600
  return ("%04x" % pos).upper()
 def VVpRHo(self, nsLst):
  totCh = totBoq = 0
  files = iGlob("%suserbouquet.*.tv" % VVTAUs)
  for srcF in files:
   if fileExists(srcF):
    lines = FF2WPS(srcF)
    newLines = []
    found = False
    for line in lines:
     span = iSearch(r"#SERVICE\s+((?:[A-Za-z0-9]+:){10})$", line, IGNORECASE)
     if span:
      ns = FFUMuc(span.group(1))
      if ns in nsLst:
       found = True
       totCh += 1
       continue
     newLines.append(line)
    if found and newLines:
     totBoq += 1
     with open(srcF, "w") as f:
      f.write("\n".join(newLines) + "\n")
  return totCh, totBoq
 def VVVQla(self, title)   : self.VVettd(title, True)
 def VVJaVq(self, title) : self.VVettd(title, False)
 def VVettd(self, title, isWithPIcons):
  piconsPath = CCxrlm.VVjBFN()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCxrlm.VVVwfb(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVpn2v, err = CCh3Pq.VVM6i7(self, self.VVI8wC)
    if VVpn2v:
     channels = []
     for (chName, chProv, sat, refCode) in VVpn2v:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FF3dWJ(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVpn2v)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVchnh(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVchnh("PIcons Path"  , piconsPath)
     txt += VVchnh("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVchnh("Total services" , totalServices)
     txt += VVchnh("With PIcons"  , totalWithPIcons)
     txt += VVchnh("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFtybv(self, txt)
     else:
      VV1Jd7     = (""      , self.VVRyKf , [])
      if isWithPIcons : VVJvWF = ("Export Current PIcon", self.VV1sf0  , [])
      else   : VVJvWF = None
      VV7J8f     = ("Statistics", FFtybv, [txt])
      VVd479      = ("Zap", self.VVMur1, [])
      channels.sort(key=lambda x: x[0].lower())
      self.VV28ta(title, channels, VVd479=VVd479, VV1Jd7=VV1Jd7, VV7J8f=VV7J8f, VVJvWF=VVJvWF)
   else:
    FFzrXb(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFzrXb(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVRyKf(self, VVoLtS, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFp5JP(self, fncMode=CCoD37.VVPeb2, refCode=refCode, chName=chName, text=txt)
 def VV1sf0(self, VVoLtS, title, txt, colList):
  png, path = CCxrlm.VV9eBq(colList[3], colList[0])
  if path:
   CCxrlm.VVKLHi(self, png, path)
 @staticmethod
 def VVqy0g():
  VVxkAm  = "%slamedb" % VVTAUs
  VVLjas = "%slamedb.disabled" % VVTAUs
  return VVxkAm, VVLjas
 @staticmethod
 def VVIHcs():
  VVLX4p  = "%slamedb5" % VVTAUs
  VVFNX5 = "%slamedb5.disabled" % VVTAUs
  return VVLX4p, VVFNX5
 def VVVbW5(self, isEnable):
  VVxkAm, VVLjas = CCh3Pq.VVqy0g()
  if isEnable and not fileExists(VVLjas):
   FFuXZg(self, "Aready enabled.")
  elif not isEnable and not fileExists(VVxkAm):
   FFzrXb(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFo4dm(self, BF(self.VVkFNh, isEnable), "%s Hidden Channels ?" % word)
 def VVkFNh(self, isEnable):
  VVxkAm , VVLjas = CCh3Pq.VVqy0g()
  VVLX4p, VVFNX5 = CCh3Pq.VVIHcs()
  cmd = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVLjas, VVLjas, VVxkAm)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVFNX5, VVFNX5, VVLX4p)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp -f '%s' '%s'; fi;"   % (VVxkAm  , VVxkAm , VVLjas)
   cmd += "if [ -f '%s' ]; then cp -f '%s' '%s'; fi;"   % (VVLX4p , VVLX4p, VVFNX5)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVLjas, VVxkAm )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVFNX5, VVLX4p)
  ok = FFgSm7(cmd)
  FFwQUx()
  if ok: FFuXZg(self, "Hidden List %s" % word)
  else : FFzrXb(self, "Error while restoring:\n\n%s" % fileName)
 def VVFhQc(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat %s | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;" % VVrs06
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt %s" % VVrs06
  FFVT5b(self, cmd)
 def VVSeHK(self):
  VVxkAm, err = CCh3Pq.VV7Ps5(self)
  if err:
   return
  tmpFile = "/tmp/ajp_lamedb"
  FFnPMX(tmpFile)
  totChan = totRemoved = 0
  lines = FF2WPS(VVxkAm, keepends=True)
  with open(tmpFile, "w") as f:
   servFound = False
   servLines = []
   for line in lines:
    if servFound:
     if line.strip() == "end":
      f.write(line)
      break
     else:
      servLines.append(line)
      if len(servLines) == 3:
       if len(servLines[1].strip()) > 0:
        totChan += 1
        f.write(servLines[0])
        f.write(servLines[1])
        f.write(servLines[2])
       else:
        totRemoved += 1
       servLines = []
    else:
     f.write(line)
     if line.strip() == "services":
      servFound = True
  if totRemoved:
   FFo4dm(self, BF(FFzW1w, self, BF(self.VVKg7v, tmpFile, VVxkAm, totRemoved, totChan))
      , "Delete %d servce%s (out of %d service%s) ?" % (totRemoved, FFoTxy(totRemoved), totChan, FFoTxy(totChan))
      , callBack_No=BF(self.VVzb6J, tmpFile))
  else:
   FFtybv(self, "Total Channels\t: %d\nWith no names\t: %d" % (totChan, totRemoved))
 def VVKg7v(self, tmpFile, VVxkAm, totRemoved, totChan):
  FFgSm7("mv -f '%s' '%s'" % (tmpFile, VVxkAm))
  FFwQUx()
  FFtybv(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
 def VVzb6J(self, tmpFile):
  FFnPMX(tmpFile)
 @staticmethod
 def VV7Ps5(SELF, VVLya0=True, title=""):
  VVxkAm, VVLjas = CCh3Pq.VVqy0g()
  if   not fileExists(VVxkAm)       : err = "File not found !\n\n%s" % VVxkAm
  elif not CCUGPF.VV1eSU(SELF, VVxkAm) : err = "'lamedb' file is not in 'UTF-8' Encoding !"
  else             : err = ""
  if err and VVLya0:
   FFzrXb(SELF, err, title=title)
  return VVxkAm, err
 @staticmethod
 def VVzp7h(refCode):
  _, flg, _, _, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([ns.zfill(8), tsid.zfill(4), nid.zfill(4)])).upper()
  else   : return ""
 @staticmethod
 def VV3ySm(refCode):
  _, flg, st, sid, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([sid.zfill(4), ns.zfill(8), tsid.zfill(4), nid.zfill(4), str(int(st, 16)), "0", "0"])).upper()
  else   : return ""
 @staticmethod
 def VVrNhE(servTypes):
  VVHa0D  = eServiceCenter.getInstance()
  VVTNLv   = '%s ORDER BY name' % servTypes
  VV3F3L   = eServiceReference(VVTNLv)
  VVQ6d6 = VVHa0D.list(VV3F3L)
  if VVQ6d6: return VVQ6d6.getContent("CN", False)
  else     : return []
 @staticmethod
 def VVtJEv():
  slotSats = []
  for slot in nimmanager.nim_slots:
   if slot.frontend_id is not None:
    lst = nimmanager.getSatListForNim(slot.frontend_id)
    if lst:
     slotSats.append((slot.getSlotName(), lst))
  return slotSats
class CCoD37(Screen):
 VVp0RA  = 0
 VVCzW3   = 1
 VVSl6s   = 2
 VVPeb2    = 3
 VVUQoW    = 4
 VVWlCC   = 5
 VVdXsX   = 6
 VVPXCI    = 7
 VVENG6   = 8
 VVwflt   = 9
 VVMXbL   = 10
 VVYfui   = 11
 EPG_MODE_BOUQUET_EDITOR   = 12
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FF5TEn(VVjziV, 1400, 1000, 50, 30, 10, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVp0RA)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.portalEpgUrl = kwargs.get("portalEpgUrl", "")
  self.piconShown  = False
  self.Sep   = FFCzRx("%s\n", VVHQpO) % SEP
  self.picViewer  = None
  FF32Yx(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VVuWli })
  self["myPicF"] = Label()
  self["myPicB"] = Label()
  self["myPic"] = Pixmap()
  self["myPicF"].hide()
  self["myPicB"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVSDD3)
  self.onClose.append(self.onExit)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  self["myLabel"].VVqlfR(outputFileToSave="chann_info")
  if   self.fncMode == self.VVp0RA : fnc = self.VVf93y
  elif self.fncMode == self.VVCzW3  : fnc = self.VVf93y
  elif self.fncMode == self.VVSl6s  : fnc = self.VVf93y
  elif self.fncMode == self.VVPeb2  : fnc = self.VVl1k3
  elif self.fncMode == self.VVUQoW  : fnc = self.VVU8YX
  elif self.fncMode == self.VVWlCC  : fnc = self.VV3Myi
  elif self.fncMode == self.VVdXsX  : fnc = self.VVwnLb
  elif self.fncMode == self.VVPXCI  : fnc = self.VVWYfS
  elif self.fncMode == self.VVENG6  : fnc = self.VVVFAM
  elif self.fncMode == self.VVwflt : fnc = self.VV3MMy
  elif self.fncMode == self.VVMXbL  : fnc = self.VVcEZs
  elif self.fncMode == self.VVYfui : fnc = self.VVv5nw
  elif self.fncMode == self.EPG_MODE_BOUQUET_EDITOR : fnc = self.VV1s8I
  self["myLabel"].setText("\n   Reading Info ...")
  self["myLabel"].VVteSG()
  FFA9HA(fnc)
 def onExit(self):
  if self.picViewer:
   self.picViewer.VVeafN()
 def VVA8jw(self, err):
  self["myLabel"].setText(err)
  FFzBm8(self["myTitle"], "#22200000")
  FFzBm8(self["myBody"], "#22200000")
  self["myLabel"].VVCZfE("#22200000")
  self["myLabel"].VVteSG()
 def VVf93y(self):
  try:
   dum = self.session
  except:
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFmvpz(self)
  self.refCode = refCode
  self.VViLNt(chName)
 def VVl1k3(self):
  self.VViLNt(self.chName)
 def VVU8YX(self):
  self.VViLNt(self.chName)
 def VV3Myi(self):
  self.VViLNt(self.chName)
 def VVwnLb(self):
  self.VViLNt("Picon Info")
 def VVWYfS(self):
  self.VViLNt(self.chName)
 def VVVFAM(self):
  self.VViLNt(self.chName)
 def VV3MMy(self):
  self.VViLNt(self.chName)
 def VVcEZs(self):
  if self.chCm.startswith("Zz1") : self.chUrl = FFmDiU(self.chCm[3:])
  else       : self.chUrl = self.refCode + self.callingSELF.VVngdY(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VViLNt(self.chName)
 def VVv5nw(self):
  self.VViLNt(self.chName)
 def VV1s8I(self):
  self.VVNX0N(self.picPath)
  self.VV4pd0()
 def VViLNt(self, title):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFmvpz(self, addInfoObj=True)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVXxzJ(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.portalEpgUrl or self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    self.text = self.text.rstrip() + "\n\nURL:\n%s\n" % FFCzRx(self.VVhdCq(tUrl), VVzv5p)
  if not self.epg:
   epg = CCL7is.VVc5HW(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VVNX0N(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CCxrlm.VV9eBq(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VVNX0N(path)
  self.VVcwtO()
  self.VVU4bX(decodedUrl)
  self.VV4pd0()
 def VV4pd0(self):
  self["myLabel"].setText(self.text or "   No active service", VVr0Wh=VVnCos)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVteSG(minHeight=minH)
 def VVU4bX(self, decodedUrl):
  url = max([self.refCode, self.chUrl, self.iptvRef, self.portalEpgUrl], key=len)
  if not FF3dcV(url):
   return
  url = url.replace("%3a", ":").replace("%3A", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVzRtg(FFKkPs(url))
  if not epg:
   if self.portalEpgUrl: epg, err = CCEgQt.VV101m(self.portalEpgUrl, refCode=self.refCode)
   else    : epg, err = CCEgQt.VV101m(decodedUrl, refCode=self.refCode)
  if epg:
   self.text += "\n" + FFLhxe("EPG:", VV61JF) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVcwtO()
 def VVcwtO(self):
  if not self.piconShown and self.picUrl:
   path, err = FFOecp(self.picUrl, "ajp_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VVNX0N(path)
    if self.piconShown and self.refCode:
     self.VVTMrw(path, self.refCode)
 def VVTMrw(self, path, refCode):
  if path and fileExists(path) and FFlgKV("ffmpeg"):
   pPath = CCxrlm.VVjBFN()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = CCoD37.VVBGeg(path)
    cmd += FFgeXp("mv -f '%s' '%s%s'" % (path, pPath, picon))
    FFgSm7(cmd)
 def VVNX0N(self, path):
  if path and fileExists(path):
   err, w, h = self.VVyNbl(path)
   if not err:
    if h > w:
     self.VVcvdi(self["myPicF"], w, h, True)
     self.VVcvdi(self["myPicB"], w, h, False)
     self.VVcvdi(self["myPic"] , w, h, False)
   self.picViewer = CCty9w.VVu2OK(self["myPic"], path)
   if self.picViewer:
    self["myPicF"].show()
    self["myPicB"].show()
    self["myPic"].show()
    return True
  return False
 def VVcvdi(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVyNbl(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFwTnb(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVXxzJ(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FFCzRx(chName, VV61JF)
  txt += self.VVchnh(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFCzRx(state, VVtz60)
   txt += "State\t: %s\n" % state
  w = FFw1kT(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFw1kT(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VV7ouL(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVchnh(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVchnh(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVchnh(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VV0wPz()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VVp1gw()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = CCoD37.VV0pTW(self)
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FFCzRx("Stream-Relay" if FFYKlk(decodedUrl) else "IPTV", VVAaU5)
   txt += self.VVyqel(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Reference\t: %s\n" % ":".join(refCode.split(":")[:10])
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VVc61J(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CC9Nee()
    tpTxt, namespace = tp.VVBCQT(refCode)
    if tpTxt:
     txt += FFCzRx("Tuner:\n", VV61JF)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFCzRx("Codes:\n", VV61JF)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVchnh(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVchnh(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVchnh(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVchnh(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVchnh(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVchnh(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVchnh(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVchnh(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVchnh(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VV7ouL(info):
  if info:
   aspect = FFw1kT(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVchnh(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFw1kT(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVwwxg(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVwwxg(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VV0wPz(self):
  try:
   return self.session.nav.getCurrentService().audioTracks().getNumberOfTracks() or 0
  except:
   return -1
 def VVp1gw(self):
  try:
   return len(InfoBar.instance.getCurrentServiceSubtitle().getSubtitleList())
  except:
   return -1
 def VVc61J(self, refCode, iptvRef, chName):
  refCode = FFp8oe(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFpCvR(VVTAUs + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFpCvR(VVTAUs + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList.extend(list)
  VVWsIU = []
  tmpRefCode = FFKkPs(refCode)
  for item in fList:
   path = VVTAUs + item
   if fileExists(path):
    txt = FFpCvR(path)
    if tmpRefCode in FFKkPs(txt):
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVWsIU.append((bName, os.path.basename(path)))
  txt = self.Sep
  if VVWsIU:
   if len(VVWsIU) == 1:
    txt += "%s\t: %s%s\n" % (FFCzRx("Bouquet", VV61JF), VVWsIU[0][0], " (%s)" % VVWsIU[0][1] if VVPdMM else "")
   else:
    txt += FFCzRx("Bouquets:\n", VV61JF)
    for ndx, item in enumerate(VVWsIU):
     txt += "%d- %s%s\n" % (ndx + 1, item[0].strip(), " (%s)" % item[1] if VVPdMM else "")
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVyqel(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFAE0u(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCEgQt()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVfC9q(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FFCzRx("URL:", VVAaU5) + "\n%s\n" % self.VVhdCq(decodedUrl)
  else:
   txt = "\n"
   txt += FFCzRx("Reference:", VVAaU5) + "\n%s\n" % refCode
  return txt
 def VVhdCq(self, url):
  if not FFYKlk(url):
   span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
   if span:
    url = span.group(1)
   if not VVncAm:
    url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return FFKkPs(url)
 def VVzRtg(self, decodedUrl):
  if not CCYqD0.VVv6Xs():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCfw0y.VVKCk4(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCfw0y.VVtidF(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVbsmG(tDict)
   elif uType == "movie" : epg, picUrl = CCoD37.VVAIrc(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVbsmG(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCfw0y.VVEl8A(item, "title"    , is_base64=True )
     lang    = CCfw0y.VVEl8A(item, "lang"         ).upper()
     description   = CCfw0y.VVEl8A(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CCfw0y.VVEl8A(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CCfw0y.VVEl8A(item, "start_timestamp"      )
     stop_timestamp  = CCfw0y.VVEl8A(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCfw0y.VVEl8A(item, "stop_timestamp"       )
     now_playing   = CCfw0y.VVEl8A(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VViypC, ""
      else     : color, txt = VVtz60 , "    (CURRENT EVENT)"
      epg += FFCzRx("_" * 32 + "\n", VVHQpO)
      epg += FFCzRx("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FFCzRx(description, VVzv5p)
      else   : epg += "Description\t: - \n"
      evNum += 1
      try:
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       totEv, totOK = CCL7is.VVNpl5(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)], longDescDays=7)
      except:
       pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 @staticmethod
 def VVAIrc(tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCfw0y.VVEl8A(item, "movie_image" )
    genre  = CCfw0y.VVEl8A(item, "genre"   ) or "-"
    plot  = CCfw0y.VVEl8A(item, "plot"   ) or "-"
    country  = CCfw0y.VVEl8A(item, "country"  ) or "-"
    actors  = CCfw0y.VVEl8A(item, "actors"   ) or "-"
    cast  = CCfw0y.VVEl8A(item, "cast"   ) or "-"
    rating  = CCfw0y.VVEl8A(item, "rating"   ) or "-"
    director = CCfw0y.VVEl8A(item, "director"  ) or "-"
    releasedate = CCfw0y.VVEl8A(item, "releasedate" ) or "-"
    duration = CCfw0y.VVEl8A(item, "duration"  ) or "-"
    try:
     lang = CCfw0y.VVEl8A(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Country\t: %s\n"  % country
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FFCzRx(cast if cast != "-" else actors, VVzv5p)
    epg += "Plot:\n%s"    % FFCzRx(plot, VVzv5p)
   except:
    pass
  return epg, movie_image
 def VVuWli(self):
  if VVncAm:
   def VVchnh(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFmvpz(self)
   n = ("refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VVchnh(n[i], v[i])
   if "chCode" in iptvRef:
    p = CCEgQt()
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVfC9q(decodedUrl)
    n = ("valid", "ph1" , "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , ph1 , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VVchnh(n[i], v[i])
   path = "/tmp/ajp_channel_details"
   with open(path, "a") as f:
    f.write("%s\n%s\n" % (SEP, txt))
   FFycel(self, "Saved to : %s" % path, 1000)
 @staticmethod
 def VV7N1e(SELF):
  if not CCGolS.VV1Ewa(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFmvpz(SELF)
  err = url =  fSize = resumable = ""
  if FFzo2Y(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CCEgQt.VV08j2(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CCEgQt.VVIOWr(), timeout=4, stream=True, verify=False)
    if not resp.ok:
     FFzrXb(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CCUGPF.VVuy4U(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FFCzRx(" (M3U/M3U8 File)", VVzv5p)
    else:
     fSize = "No info. from server. Try again later."
    resumable = "Yes" if CCXFYJ.VVvLFg(resp) else "No"
   except requests.Timeout as e: err = "Connection Timeout"
   except      : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VVulVX(subj, val):
   return "%s\n%s\n\n" % (FFCzRx("%s:" % subj, VV61JF), val)
  title = "File Size"
  txt  = VVulVX(title , fSize or "?")
  txt += VVulVX("Name" , chName)
  txt += VVulVX("URL" , url)
  if resumable: txt += VVulVX("Supports Download-Resume", resumable)
  if err  : txt += FFCzRx("Error:\n", VVtz60) + err
  FFtybv(SELF, txt, title=title)
 @staticmethod
 def VV0pTW(SELF):
  fPath, fDir, fName = CCUGPF.VVKW1S(SELF)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 @staticmethod
 def VVBGeg(path):
  return FFgeXp("ffmpeg -y -i '%s' -vf scale=-1:132 '%s'" % (path, path))
 @staticmethod
 def VVMUmM(refCode):
  span = iSearch(r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))", refCode.rstrip(":"))
  if span:
   pPath = CCxrlm.VVjBFN() + span.group(1).strip(":").replace(":", "_").upper() + ".png"
   return pPath
  return ""
 @staticmethod
 def VV5V8k(serv):
  isLocal = isIptv = isFtp = isDvb = isDvbS = isDvbC = isDvbT = False
  typeTxt = chPath = ""
  if serv:
   refCode = serv.toString() or ""
   chPath = serv.getPath() or ""
   if "file?file" in refCode or ":ftp%3a//" in refCode:
    isFtp = True
    typeTxt = "FTP"
   elif FF3dcV(refCode):
    isIptv = True
    typeTxt = "IPTV"
   elif chPath.startswith("/"):
    isLocal = True
    typeTxt = "Local Media"
   elif not chPath:
    isDvb = True
    ns = FFUMuc(refCode)
    if   ns.startswith("EEEE") : isDvbT, typeTxt = True, "DVB-T"
    elif ns.startswith("FFFF") : isDvbC, typeTxt = True, "DVB-C"
    else      : isDvbS, typeTxt = True, "DVB-S"
  return isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath
class CCEgQt():
 def __init__(self):
  self.VVoT9V()
  self.VVzCbv    = ""
  self.VVv7iM   = "#f#11ffffaa#User"
  self.VV4VS1   = "#f#11aaffff#Server"
 def VVoT9V(self):
  self.VVrHOQ   = ""
  self.VVEHz9    = ""
  self.VVT3Jh   = ""
  self.VVJ23Q = ""
  self.VVHUA4  = ""
  self.VVhNXl = 0
 def VVb3Ec(self, url, mac, ph1="", VVx3z3=True):
  self.VVoT9V()
  self.VVzCbv = {"s": "/server/load.php", "p": "/portal.php", "q": "/portal1.php"}.get(ph1, "")
  host = self.VVMvcH(url)
  if not host:
   if VVx3z3:
    self.VVvL0a("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVuu5Q(mac)
  if not host:
   if VVx3z3:
    self.VVvL0a("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVrHOQ = host
  self.VVEHz9  = mac
  return True
 def VV5k7U(self):
  return {"/server/load.php":"s", "/portal.php":"p", "/portal1.php":"q"}.get(self.VVzCbv, "")
 def VVMvcH(self, url):
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  span = iSearch(r"(.+)(\/playlist.+mac)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url
 def VVuu5Q(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VV3XZy(self):
  res, err = self.VVHuq9(self.VVxjcq())
  if "404" in err or res and res.status_code == 200 and not res.text.strip():
   if self.VVrHOQ.endswith("/c"):
    self.VVrHOQ = self.VVrHOQ[:-2]
    res, err = self.VVHuq9(self.VVxjcq())
   elif self.VVrHOQ.endswith("/stalker_portal"):
    self.VVrHOQ = self.VVrHOQ[:-15]
    res, err = self.VVHuq9(self.VVxjcq())
   else:
    self.VVrHOQ += "/c"
    res, err = self.VVHuq9(self.VVxjcq())
  token = rand = ""
  if not err:
   try:
    tDict = jLoads(res.text)         #
    token = CCfw0y.VVEl8A(tDict["js"], "token")
    rand  = CCfw0y.VVEl8A(tDict["js"], "random")
   except:
    pass
  return token.strip(), rand.strip(), err
 def VVIZ9u(self, VVx3z3=True):
  if not self.VVzCbv:
   self.VVWnaS()
  err = blkMsg = FFuXZgTxt = ""
  try:
   token, rand, err = self.VV3XZy()
   if token:
    self.VVT3Jh = token
    self.VVJ23Q = rand
    if rand:
     self.VVhNXl = 2
    prof, retTxt = self.VVzHNk(True)
    if prof:
     self.VVHUA4 = retTxt
     if any(x in retTxt for x in ("device_id mismatch", "old firmware")):
      self.VVhNXl = 3
      prof, retTxt = self.VVzHNk(False)
      if retTxt:
       self.VVHUA4 = retTxt
    return token, prof, ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if blkMsg or FFuXZgTxt:
   tErr += "\n"
   if blkMsg: tErr += "\n%s" % blkMsg
   if FFuXZgTxt: tErr += "\n%s" % FFuXZgTxt
  if VVx3z3:
   self.VVvL0a(tErr)
  return "", "", tErr
 def VVWnaS(self):
  try:
   import requests
   url = self.VVEB3G()
   jsFile = "xpcom.common.js"
   res = requests.get("%s/stalker_portal/c/%s" % (url, jsFile), headers=CCEgQt.VVIOWr(), stream=True, timeout=2)
   if not res.ok or not "javascript" in res.headers.get("content-type"):
    res = requests.get("%s/c/%s" % (url, jsFile), headers=CCEgQt.VVIOWr(), stream=True, timeout=2)
   if res.ok and "javascript" in res.headers.get("content-type"):
    patt = ""
    for line in res.iter_lines():
     if line:
      line = str(line.decode('utf-8'))
      span = iSearch(r"\s*var\s+pattern\s*=\s*\/(.+)\/\s*;", line, IGNORECASE)
      if span:
       patt = span.group(1)
      span = iSearch(r".+ajax_loader.+'(\/.+\.php)'", line, IGNORECASE)
      if span:
       if "portal_path" in line:
        if patt.endswith("*\/(.)*") : url += "/c"
        else      : url += "/stalker_portal"
       self.VVrHOQ = url
       self.VVzCbv = span.group(1)
       return
  except:
   pass
  self.VVzCbv = "/server/load.php"
 def VVEB3G(self):
  url = self.VVrHOQ.rstrip("/")
  if url.endswith("/c")    : url = url[:-2]
  if url.endswith("/stalker_portal") : url = url[:-15]
  if url.endswith("/c")    : url = url[:-2]
  return url
 def VVpMtS(self, url, isJsFile=False):
  import requests
  jsFile = "xpcom.common.js" if isJsFile else "version.js"
  res, err = self.VVHuq9("%s/stalker_portal/c/%s" % (url, jsFile))
  if not res or not "javascript" in res.headers.get("content-type"):
   res, err = self.VVHuq9("%s/c/%s" % (url, jsFile))
  if res and "javascript" in res.headers.get("content-type"):
   if isJsFile:
    return str(res.content), ""
   else:
    span = iSearch(r"var\s+ver\s*=\s*'(.+)'", res.text, IGNORECASE)
    if span:
     return span.group(1), ""
  return "", err
 def VVzHNk(self, capMac):
  res, err = self.VVHuq9(self.VVHiiN(capMac))
  if not err:
   try:
    tDict = jLoads(res.text)
    word = "m" + "sg"
    blkMsg = CCfw0y.VVEl8A(tDict["js"], "block_%s" % word)
    FFuXZgTxt = CCfw0y.VVEl8A(tDict["js"], word)
    return tDict, FFuXZgTxt.strip() or blkMsg.strip()
   except:
    pass
  return "", ""
 def VVHiiN(self, capMac):
  param = ""
  if self.VVHUA4 or self.VVJ23Q:
   param = self.getMoreAuth_params(self.getMoreAuth_IDs(self.VVEHz9.upper() if capMac else self.VVEHz9.lower(), self.VVJ23Q))
  return self.VVYp7W() + "type=stb&action=get_profile" + param
 exec(FFmDiU("ZGVmIGdldE1vcmVBdXRoX3BhcmFtcyhzZWxmLCBJZCk6DQogcGFyYW0gPSAiJmF1dGhfc2Vjb25kX3N0ZXA9MSZod192ZXJzaW9uPTIuMTctSUItMDAmaHdfdmVyc2lvbl8yPTYyJnNuPSVzJmRldmljZV9pZD0lcyZkZXZpY2VfaWQyPSVzJnNpZ25hdHVyZT0lcyIgJSAoSWRbMF0sIElkWzFdLCBJZFsxXSwgSWRbMl0pDQogcmV0dXJuIHBhcmFtICsgJyZ2ZXI9UGxheWVyIEVuZ2luZSB2ZXJzaW9uOiAweDU4YyZtZXRyaWNzPXsibWFjIjoiJXMiLCJzbiI6IiVzIiwidHlwZSI6IlNUQiIsIm1vZGVsIjoiTUFHMjUwIiwicmFuZG9tIjoiJXMifScgJSAoSWRbM10sIElkWzBdLCBJZFs0XSkNCmRlZiBnZXRNb3JlQXV0aF9JRHMoc2VsZiwgbSwgcik6DQogaW1wb3J0IGhhc2hsaWINCiBtYWNVdGY4ID0gbS5lbmNvZGUoJ3V0Zi04JykNCiBzID0gaGFzaGxpYi5tZDUobWFjVXRmOCkuaGV4ZGlnZXN0KCkudXBwZXIoKVs6MTNdDQogcmV0dXJuIHMsIGhhc2hsaWIuc2hhMjU2KG1hY1V0ZjgpLmhleGRpZ2VzdCgpLnVwcGVyKCksIGhhc2hsaWIuc2hhMjU2KChzICsgbSkuZW5jb2RlKCd1dGYtOCcpKS5oZXhkaWdlc3QoKS51cHBlcigpLCBtLCBy"))
 def VV5YZa(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVmqsQ()
  if len(rows) < 10:
   rows = self.VVKWNh()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVrHOQ ))
   rows.append(("MAC (from URL)" , self.VVEHz9 ))
   rows.append(("Token"   , self.VVT3Jh ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.VVv7iM  , "MAC" , self.VVEHz9 ))
   rows.append(("2", self.VV4VS1, "Host" , self.VVrHOQ ))
   rows.append(("2", self.VV4VS1, "Token" , self.VVT3Jh ))
   rows.sort(key=lambda x: (x[0], x[2]))
   return rows, 4
 def VV5OAb(self, isPhp=True, VVx3z3=False):
  token, profile, tErr = self.VVIZ9u(VVx3z3)
  if not token:
   return "", "", "", "", tErr
  m3u_Url = host = user1 = pass1 = err=  ""
  url = self.VVLg2Y()
  res, err = self.VVHuq9(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCfw0y.VVEl8A(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FF6XZy(span.group(2))
     pass1 = FF6XZy(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, host, user1, pass1, err
 def VVmqsQ(self):
  m3u_Url, host, user1, pass1, err = self.VV5OAb()
  rows = []
  if m3u_Url:
   res, err = self.VVHuq9(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FFgCM6(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.VVv7iM, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FFgCM6(int(val))
      else      : val = str(val)
      rows.append(("2", self.VV4VS1, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VVKWNh(self):
  token, profile, tErr = self.VVIZ9u()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFgeok(val): val = FFmDiU(val.decode("UTF-8"))
     else     : val = self.VVEHz9
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FFgCM6(int(parts[1]))
      if parts[2] : ends = FFgCM6(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FFgCM6(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVngdY(self, mode, chCm, epNum, epId):
  token, profile, tErr = self.VVIZ9u(VVx3z3=False)
  if not token:
   return ""
  crLinkUrl = self.VVnOjB(mode, chCm, epNum, epId)
  res, err = self.VVHuq9(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCfw0y.VVEl8A(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  chUrl = chUrl.replace("auto ", "")
  return chUrl
 def VVYp7W(self):
  return self.VVrHOQ + self.VVzCbv + "?"
 def VVxjcq(self):
  return self.VVYp7W() + "type=stb&action=handshake&token=&mac=%s" % self.VVEHz9
 def VVmQlk(self, mode):
  url = self.VVYp7W() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VV4S3a(self, catID):
  return self.VVYp7W() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VV300Y(self, mode, catID, page):
  url = self.VVYp7W() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "itv": url += "genre=%s" % catID
  else   : url += "category=%s&force_ch_link_check=" % catID
  return url
 def VVyDe7(self, mode, searchName, catId, page):
  catId = ("&category=%s" % catId) if catId else ""
  return self.VVYp7W() + "type=%s&action=get_ordered_list&search=%s&%s&p=%d" % (mode, searchName, catId, page)
 def VVGRyQ(self, stID):
  return self.VVYp7W() + "type=itv&action=get_short_epg&ch_id=%s" % stID
 def VVnOjB(self, mode, chCm, serCode, serId):
  url = self.VVYp7W() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=0&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VVLg2Y(self):
  return self.VVYp7W() + "type=itv&action=create_link"
 def VViO0E(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VV1K8x(catID, stID, chNum)
  query = self.VVzzi8(mode, self.VV5k7U(), FFxHdY(host), FFxHdY(mac), serCode, serId, chCm, catID, stID)
  if chCm.endswith(".m3u8") : chUrl = "%s?%s" % (chCm, query)
  else      : chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VVzzi8(self, mode, ph1, host, mac, serCode, serId, chCm, catID, stID):
  query = "mode=%s&ph1=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&cId=%s&sId=%s&chCm=%s&end=" % (mode, ph1, host, mac, serCode, serId, catID, stID, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVfC9q(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  ph1  = tDict.get("ph1" , [""])[0].strip()
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  catID = tDict.get("cId" , [""])[0].strip()
  stID = tDict.get("sId" , [""])[0].strip()
  query = self.VVzzi8(mode, ph1, host, mac, epNum, epId, FF6XZy(chCm), catID, stID)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFmDiU(host)
  mac   = FFmDiU(mac)
  valid = False
  if self.VVMvcH(playHost) and self.VVMvcH(host) and self.VVMvcH(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query
 def VVHuq9(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CCEgQt.VVIOWr()
   if self.VVT3Jh:
    headers["Authorization"] = "Bearer %s" % self.VVT3Jh
   if useCookies : cookies = {"mac": self.VVEHz9, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=CFG.portalConnTimeout.getValue(), cookies=cookies)
   if res.ok:
    return res, ""
   else:
    if res.status_code == 407: reason = "Proxy Authentication Required"
    else      : reason = "Unknown"
    err = "Err-%d : %s" % (res.status_code, res.reason or reason)
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VVAAns(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CCEgQt.VVIOWr(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VVIOWr():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 def VVvL0a(self, err, title="Portal Browser"):
  FFzrXb(self, str(err), title=title)
 def VVAzis(self, mode):
  if   mode in ("itv"  , CCfw0y.VV1LVs , CCfw0y.VVZsQj)  : return "Live"
  elif mode in ("vod"  , CCfw0y.VVgfJL , CCfw0y.VVJwAe)  : return "VOD"
  elif mode in ("series" , CCfw0y.VVFsH1 , CCfw0y.VV4xmt) : return "Series"
  else                          : return "IPTV"
 def VVJNVW(self, mode, searchName):
  return 'Find in %s : %s' % (self.VVAzis(mode), FFCzRx(searchName, VVzv5p))
 def VV5jeg(self, catchup=False):
  VVMVqr = []
  VVMVqr.append(("Live"    , "live"  ))
  VVMVqr.append(("VOD"    , "vod"   ))
  VVMVqr.append(("Series"   , "series"  ))
  if catchup:
   VVMVqr.append(VVpTvr)
   VVMVqr.append(("Catch-up TV" , "catchup"  ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Account Info." , "accountInfo" ))
  return VVMVqr
 @staticmethod
 def VVCt6q(decodedUrl):
  m3u_Url = host = user1 = pass1 = streamId = ""
  p = CCEgQt()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVfC9q(decodedUrl)
  if valid:
   ok = p.VVb3Ec(host, mac, ph1, VVx3z3=False)
   if ok:
    m3u_Url, host1, user1, pass1, err = p.VV5OAb(isPhp=False, VVx3z3=False)
    streamId = CCEgQt.VVE3my(decodedUrl)
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query, m3u_Url, host1, user1, pass1, streamId, err
 @staticmethod
 def VVE3my(decodedUrl):
  p = CCEgQt()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVfC9q(decodedUrl)
  if valid and chCm:
   if   mode == "itv"  : patt = r'.+ch\/(\d+)_'
   elif mode == "vod"  : patt = r'stream_id":"*(\d+)'
   elif mode == "series": patt = r'series_id":"*(\d+)'
   span = iSearch(patt, FFmDiU(chCm), IGNORECASE)
   if span:
    return span.group(1)
  return ""
 @staticmethod
 def VV08j2(decodedUrl):
  p = CCEgQt()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVfC9q(decodedUrl)
  if valid:
   if CCEgQt.VVwJzB(chCm):
    return FFKkPs(chCm)
   else:
    ok = p.VVb3Ec(host, mac, ph1, VVx3z3=False)
    if ok:
     try:
      chUrl = p.VVngdY(mode, chCm, epNum, epId)
      return FFKkPs(chUrl)
     except:
      pass
  return ""
 @staticmethod
 def VVwJzB(chCm):
  return chCm.startswith("http") and not "//localhost/" in chCm
 @staticmethod
 def VV101m(decodedUrl, retLst=False, refCode=""):
  epg = err = ""
  if "mode=itv" in decodedUrl:
   p = CCEgQt()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVfC9q(decodedUrl)
   if valid:
    if not stID:
     stID = CCEgQt.VVE3my(decodedUrl)
    if stID:
     if p.VVb3Ec(host, mac, ph1, VVx3z3=False):
      token, profile, tErr = p.VVIZ9u(VVx3z3=False)
      if token:
       res, err = p.VVHuq9(p.VVGRyQ(stID))
       if res:
        epg, err = CCEgQt.VVuUHw(res.text, retLst)
        if not retLst and epg and refCode:
         pList, err = CCEgQt.VVuUHw(res.text, retLst=True)
         if pList:
          totEv, totOK = CCL7is.VVNpl5(refCode, pList)
  return epg, err
 @staticmethod
 def VVuUHw(txt, retLst=False):
  epg, lst = "", []
  try:
   tDict = jLoads(txt)
   evNum = 1
   for item in tDict["js"]:
    actor    = CCfw0y.VVEl8A(item, "actor"       )
    category   = CCfw0y.VVEl8A(item, "category"      )
    descr    = CCfw0y.VVEl8A(item, "descr"   , is_base64=True).replace("\n", " .. ")
    director   = CCfw0y.VVEl8A(item, "director"      )
    name    = CCfw0y.VVEl8A(item, "name"   , is_base64=True)
    start_timestamp  = CCfw0y.VVEl8A(item, "start_timestamp", isDate=True )
    start_timestamp_unix= CCfw0y.VVEl8A(item, "start_timestamp"    )
    stop_timestamp  = CCfw0y.VVEl8A(item, "stop_timestamp" , isDate=True )
    stop_timestamp_unix = CCfw0y.VVEl8A(item, "stop_timestamp"     )
    if retLst:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ""
       lst.append((start, dur, name, shortDesc, descr, 1))
     except:
      pass
    else:
     skip, curEv = False, ""
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
      if float(start_timestamp_unix) < iTime() and float(stop_timestamp_unix) > iTime():
       curEv = FFCzRx("    (CURRENT EVENT)", VVJS3b)
     except:
      pass
     if not skip:
      epg += FFCzRx("_" * 32 + "\n", VVHQpO)
      epg += "Event\t: %d%s\n" % (evNum, curEv)
      epg += "Title\t: %s\n"  % FFCzRx(name, VV61JF)
      epg += "Start\t: %s\n"  % start_timestamp
      epg += "End\t: %s\n"  % stop_timestamp
      epg += "Description:\n%s\n" % FFCzRx(descr , VVzv5p) if descr else "Description\t: - \n"
      epg += "Genre:\n%s\n"  % FFCzRx(category, VVzv5p) if category else ""
      epg += "Actors:\n%s\n"  % FFCzRx(actor , VVzv5p) if actor else ""
      epg += "Director:\n%s\n" % FFCzRx(director, VVzv5p) if director else ""
      evNum += 1
  except:
   return "", "Cannot parse received data !"
  if retLst: return lst, ""
  else  : return epg, ""
class CCanC9(CCEgQt):
 def __init__(self):
  CCEgQt.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVNFjN(self, refCode, chName, decodedUrl, iptvRef):
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = self.VVfC9q(decodedUrl)
  if valid:
   if self.VVb3Ec(host, mac, ph1, VVx3z3=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVIERc(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  try:
   if self.chCm.startswith("Zz1"):
    self.chCm = FFmDiU(self.chCm[3:])
   else:
    chUrl = self.VVngdY(self.mode, self.chCm, self.epNum, self.epId)
  except:
   return False
  isDirect = False
  if CCEgQt.VVwJzB(self.chCm):
   chUrl = FFKkPs(self.chCm)
   chUrl = FF6XZy(self.chCm)
   chUrl = chUrl.replace("%253a", "%3a")
   if not "?" in chUrl:
    chUrl += "?"
  elif " " in self.chCm or " " in chUrl:
   if " " in chUrl:
    chUrl = chUrl.split(" ")[1]
   if not "?" in chUrl:
    chUrl += "?"
  if not chUrl.startswith("http"):
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = chUrl.strip()
  chUrl = self.refCode + chUrl + ":" + self.chName
  newIptvRef = self.VV3RH8(chUrl)
  bPath = CCrfsB.VVMKYk()
  if newIptvRef:
   if passedSELF:
    FFrvm6(passedSELF, newIptvRef, VViFts=False, fromPortalReplay=True, isFromSession=isFromSession)
   else:
    FFrvm6(self, newIptvRef, VViFts=False, fromPortalReplay=True)
   if self.iptvRef and newIptvRef and bPath:
    serv = eServiceReference(newIptvRef)
    newCode = serv and serv.toString()
    if newCode:
     self.VVLxqJ(self.iptvRef, newCode, bPath)
   return True
  else:
   return False
 def VV3RH8(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/", "lid=")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VVLxqJ(self, oldCode, newCode, bPath):
  patt = r"((?:[A-Fa-f0-9]+[:]){10}).+(mode=.+)chCm="
  span = iSearch(patt, newCode, IGNORECASE)
  if span:
   newRef, newPar = span.group(1).upper(), span.group(2)
   params = ("ph1", "cId", "sId")
   for par in params:
    newPar = iSub(r"&%s=.*?&" % par, "&", newPar)
   lines = FF2WPS(bPath)
   for ndx, line in enumerate(lines):
    span = iSearch(patt, line, IGNORECASE)
    if span:
     fileRef, filePar = span.group(1).upper(), span.group(2)
     if newRef == fileRef:
      for par in params:
       filePar = iSub(r"&%s=.*?&" % par, "&", filePar)
      if newPar == filePar:
       lines[ndx] = "#SERVICE %s" % newCode
       with open(bPath, "w") as f: f.write("\n".join(lines) + "\n")
       FFwQUx()
class CCtMfQ(CCanC9):
 def __init__(self, passedSession):
  CCanC9.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.startTime  = iTime()
  self.timer1   = eTimer()
  self.timer2   = eTimer()
  self.dnldWin  = None
  self.isFromEOF  = False
  Main_Menu.VVmNVO(VV4sBs  )
  Main_Menu.VVmNVO(VV7l55)
  Main_Menu.VVmNVO(VVOg8O  )
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVsouB, iPlayableService.evEOF: self.VVorta, iPlayableService.evEnd: self.VVvSuG})
  except:
   pass
  try:
   self.timer_conn = self.timer2.timeout.connect(self.VVKpl5)
  except:
   self.timer2.callback.append(self.VVKpl5)
  self.timer2.start(3000, False)
  self.VVKpl5()
 def VVKpl5(self):
  if not CFG.downloadMonitor.getValue():
   self.VVrWfj()
   return
  lst = CCXFYJ.VVi8FB()
  avPerc = []
  txt = ""
  if lst:
   for path, totSz, logF in lst:
    if totSz:
     totSz = int(totSz) if totSz.isdigit() else 0
     curSz = 0
     sz = FFPLWs(path)
     if sz > -1:
      curSz = sz
     if totSz:
      perc = (float(curSz) / float(totSz) * 100.0)
      avPerc.append(perc)
    elif logF:
     perc = CCXFYJ.VVKhSs(logF)
     if perc > -1:
      avPerc.append(perc)
   if lst:
    txt = "Files=%d" % len(lst)
    if avPerc:
     perc = sum(avPerc) / len(avPerc)
     if perc: txt += "   %.2f %%" % perc
  if txt:
   if not self.dnldWin : self.dnldWin = CCt8ct.VVoIE1(self.passedSession, txt, 30)
   else    : CCt8ct.VV0lyM(self.dnldWin, txt)
  elif self.dnldWin:
   self.VVrWfj()
 def VVrWfj(self):
  if self.dnldWin:
   self.passedSession.deleteDialog(self.dnldWin)
   self.dnldWin = None
 def VVsouB(self):
  self.startTime = iTime()
 def VVorta(self):
  global VVf6vh
  VVf6vh = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.startTime) > 5:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFmvpz(self.passedSession, isFromSession=True)
    if iptvRef and not "file?file" in iptvRef and not ":ftp%3a//" in iptvRef and not FFzo2Y(decodedUrl):
     self.isFromEOF = True
     CCt8ct(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
     self.startTime = iTime()
 def VVvSuG(self):
  self.startTime = iTime()
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VVEJ1A)
  except:
   self.timer1.callback.append(self.VVEJ1A)
  self.timer1.start(100, True)
 def VVEJ1A(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFmvpz(self.passedSession, isFromSession=True)
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if self.isFromEOF or not ref == self.lastRef:
     valid = self.VVNFjN(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if self.isFromEOF or not CCA3uT.VVGbd7:
       self.isFromEOF = False
       self.VVIERc(self.passedSession, isFromSession=True)
       InfoBar.instance.hide()
class CCaV2Y():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
  self.nameTagPatt = iCompile( r"\s*^[A-Za-z]{2,3}\d*\s*[|:-]+\s*(.+)"
          r"|^(?!\[)*\s*[\[(|:][ A-Za-z0-9\/\-._:|\]\[]+[\])|:](.+)"
          r"|^[A-Za-z]{,3}[^\x00-\x7F]{,3}\ (.+)")
  self.prefixRemoveList = self.VVFg0G(self.removeTag, "ajpanel_iptv_prefix", False, ())
  self.adultWords = self.VVFg0G(self.hideAdult, "ajpanel_iptv_blacklist", True, ("adult","aduld","sex","porn","xxx","xxi","erotic","x-rated","xrated","skin flick","dirty movie","dirty film","blue movie","blue film","18+","+18","r18 movie","r18 film","r-18 movie","r-18 film","r-17 movie","r-17 film"))
 def VVFg0G(self, cond, fName, isLower, tSet):
  tSet = set(tSet)
  if cond:
   for path in (VVLS8v, VVYfYu):
    path += fName
    if fileExists(path):
     for line in FF2WPS(path):
      line = line.strip()
      if len(line) >= 3:
       tSet.add(line.lower() if isLower else line)
  return tuple(sorted(tSet, key=lambda x: x.lower()))
 def VVba4j(self, name,  censored=""):
  if self.hideAdult and (censored == "1" or any(x in name.lower() for x in self.adultWords)):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CCfw0y.VVV5BR(name):
   return CCfw0y.VV5Gqm(name)
  return self.VVZo4L(name)
 def VVZo4L(self, name):
  newName = ""
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    tName = span.group(1) or span.group(2) or span.group(3)
    if not tName.startswith(("HD", "[HD]", "SD", "[SD]")):
     newName = tName
   for t in self.prefixRemoveList:
    if name.startswith(t):
     newName = name[len(t):]
     break
  return newName.strip() or name
 def VV5ZIs(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  name = self.VVZo4L(name)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VV3PAZ(self, name):
  if self.hideAdult:
   tName = name.lower()
   if any(x in tName for x in self.adultWords):
    return ""
  return name.strip()
 def VVlVjJ(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVFpjk(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCGolS(CCEgQt):
 def __init__(self):
  self.curPortalCatId = ""
  CCEgQt.__init__(self)
 def VVM1kc(self):
  if CCGolS.VV1Ewa(self):
   FFzW1w(self, BF(self.VVHYUH, 2), title="Searching ...")
 def VVmEzC(self, winSession, url, mac):
  self.curUrl = url
  if CCGolS.VV1Ewa(self):
   if self.VVb3Ec(url, mac):
    FFzW1w(winSession, self.VVJ0jg, title="Checking Server ...")
   else:
    FFzrXb(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVDjl3(self, item=None):
  if item:
   VVdtUh, txt, path, ndx = item
   enc = CCscRA.VVf2n6(path, self)
   if enc == -1:
    return
   self.session.open(CCSCNk, barTheme=CCSCNk.VV7KPr
       , titlePrefix = "Processing file lines"
       , fncToRun  = BF(self.VVpb1w, path, enc)
       , VVEStC = BF(self.VVPJ6N, VVdtUh, path))
 def VVpb1w(self, path, enc, VV2ohY):
  urlMacPatt  = r"(.*)(https?:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(https?:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  VV2ohY.VVHJ4P(totLines)
  VV2ohY.VVRTV9 = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not VV2ohY or VV2ohY.isCancelled:
     return
    VV2ohY.VVc1xD(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip().strip('"') or "-"
     url  = span.group(2).strip().split(" ")[0].split("\t")[0].strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip().strip(';"') or "-"
     host = self.VVMvcH(url).strip('"')
     mac  = self.VVuu5Q(mac)
     if host and mac and VV2ohY:
      VV2ohY.VVRTV9.append((str(c), str(lineNum), subj, host, mac, info))
     url = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip().strip('"') or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip().strip(';"') or "-"
      host = self.VVMvcH(url).strip('"')
      mac  = self.VVuu5Q(mac)
      if host and mac and not mac.startswith("AC") and VV2ohY:
       VV2ohY.VVRTV9.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VVPJ6N(self, VVdtUh, path, VVPnF9, VVRTV9, threadCounter, threadTotal, threadErr):
  title = "Portals File : %s" % os.path.basename(path)
  if VVRTV9:
   VVKDDh  = ("Home Menu"  , FFsago            , [])
   VV7J8f = ("Edit File"  , BF(self.VVmtLW, path)       , [])
   VVEXwE = ("M3U Options" , self.VV8q00         , [])
   VVJvWF = ("Check & Filter" , BF(self.VVFEFq, VVdtUh, path), [])
   VVd479  = ("Select"   , self.VVavQT      , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VViqYN  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVoLtS = FFldB6(self, None, title=title, header=header, VVWsIU=VVRTV9, VViqYN=VViqYN, VVv3Wm=widths, VVHZHw=26, VVd479=VVd479, VVKDDh=VVKDDh, VVEXwE=VVEXwE, VV7J8f=VV7J8f, VVJvWF=VVJvWF, VVZYdg="#0a001122", VVcwfs="#0a001122", VVLuY4="#0a001122", VVG27K="#00004455", VVQ9hc="#0a333333", VVGpiI="#11331100", VV65AN=True, searchCol=3, lastFindConfigObj=CFG.lastFindServers)
   if not VVPnF9:
    FFycel(VVoLtS, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVPnF9:
    FFzrXb(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VV8q00(self, VVoLtS, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  title = "Portal M3U Options"
  VVMVqr = []
  VVMVqr.append(("Browse as M3U"  , "browse"))
  VVMVqr.append(("Download M3U File" , "downld"))
  FF7ARM(self, BF(self.VVNH1a, VVoLtS, host, mac), title=title, VVMVqr=VVMVqr, width=600, VVy9CS=True)
 def VVNH1a(self, VVoLtS, host, mac, item):
  if item:
   title, item, ndx = item
   if   item == "browse": FFzW1w(VVoLtS, BF(self.VVzGzW, VVoLtS, title, host, mac, item), title="Checking Server ...")
   elif item == "downld": FFo4dm(self, BF(FFzW1w, VVoLtS, BF(self.VVzGzW, VVoLtS, title, host, mac, item), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVzGzW(self, VVoLtS, title, host, mac, item):
  p = CCEgQt()
  m3u_Url = ""
  ok = p.VVb3Ec(host, mac, VVx3z3=False)
  err = ""
  if ok:
   m3u_Url, host, user1, pass1, err = p.VV5OAb(VVx3z3=False)
  if m3u_Url:
   if   item == "browse": self.VVgawD(title, m3u_Url)
   elif item == "downld": self.VVM37h(title, "%s/get.php?username=%s&password=%s&type=m3u" % (host, user1, pass1))
  else:
   FFzrXb(self, err or "No response from Server !", title=title)
 def VVavQT(self, VVoLtS, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVmEzC(VVoLtS, url, mac)
 def VVmtLW(self, path, VVoLtS, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCH94c(self, path, VVEStC=BF(self.VVyDPL, VVoLtS), curRowNum=rowNum)
  else    : FFZ5Ys(self, path)
 def VVFEFq(self, VVdtUh, path, VVoLtS, title, txt, colList):
  self.session.open(CCSCNk, barTheme=CCSCNk.VVSu4G
      , titlePrefix = "Checking Portals"
      , fncToRun  = BF(self.VVG7h5, VVoLtS)
      , VVEStC = BF(self.VVvcUA, VVdtUh, VVoLtS, path))
 def VVG7h5(self, VVoLtS, VV2ohY):
  VV2ohY.VVRTV9 = []
  VV2ohY.VVHJ4P(VVoLtS.VVgRm7())
  for row in VVoLtS.VVGkEL():
   if not VV2ohY or VV2ohY.isCancelled:
    return
   VV2ohY.VVc1xD(1, showFound=True)
   num, lNum, titl, host, mac, cmnt = row
   if self.VVb3Ec(host, mac, VVx3z3=False):
    token, profile, tErr = self.VVIZ9u(VVx3z3=False)
    if token and VV2ohY and not VV2ohY.isCancelled:
     res, err = self.VVHuq9(self.VVmQlk("itv"))
     if res and VV2ohY and not VV2ohY.isCancelled:
      try:
       tot = len(jLoads(res.text)["js"])
       VV2ohY.VVc1xD(0, showFound=True)
       VV2ohY.VVRTV9.append((titl, host, mac, cmnt))
      except:
       pass
   if not VV2ohY:
    return
 def VVvcUA(self, VVdtUh, VVoLtS, path, VVPnF9, VVRTV9, threadCounter, threadTotal, threadErr):
  if VVRTV9:
   VVoLtS.close()
   VVdtUh.close()
   newPath = "%s_OK_%s.txt" % (path, FF4rM4())
   with open(newPath, "w") as f:
    for titl, host, mac, cmnt in VVRTV9:
     f.write("%s\t%s\t%s\t%s\n" % (titl, host, mac, cmnt))
   if threadTotal == threadCounter:
    totChk = str(threadCounter)
    skipped = ""
   else:
    totChk = FFCzRx(str(threadCounter), VVtz60)
    skipped = FFCzRx(str(threadTotal - threadCounter), VVtz60)
   txt  = "Total Portals\t: %d\n" %  threadTotal
   txt += "Checked\t: %s\n"  %  totChk
   if skipped:
    txt += "Cancelled\t: %s\n" %  skipped
   txt += "Accessible\t: %d\n\n" %  len(VVRTV9)
   txt += "%s\n\n%s"    %  (FFCzRx("Result File:", VV61JF), newPath)
   FFtybv(self, txt, title="Accessible Portals")
  elif VVPnF9:
   FFzrXb(self, "No portal access found !", title="Accessible Portals")
 def VVTFKY(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":").replace("%3A", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFmDiU(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVJ0jg(self):
  token, profile, tErr = self.VVIZ9u()
  if token:
   dots = "." * self.VVhNXl
   dots += {"s":"", "p":"+", "q":"++", }.get(self.VV5k7U(), "")
   dots += "*" if not self.VVrHOQ == self.curUrl else ""
   VVMVqr  = self.VV5jeg()
   VVmKhE = self.VVWV6Y
   VVGygu = self.VVeDSe
   VVRZ74 = ("Home Menu", FFsago)
   VV0afn= ("Add to Menu", BF(CCfw0y.VV427a, self, True, self.VVrHOQ + "\t" + self.VVEHz9))
   VVdhQt = ("Bookmark Server", BF(CCfw0y.VVMXi1, self, True, self.VVrHOQ + "\t" + self.VVEHz9))
   VVdtUh = FF7ARM(self, None, title="Portal Resources (MAC=%s) %s" % (self.VVEHz9, dots), VVMVqr=VVMVqr, VVmKhE=VVmKhE, VVGygu=VVGygu, VVRZ74=VVRZ74, VV0afn=VV0afn, VVdhQt=VVdhQt)
   self.VVw79X(VVdtUh)
 def VVWV6Y(self, item=None):
  if item:
   VVdtUh, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFzW1w(VVdtUh, BF(self.VVnleE, mode), title="Reading Categories ...")
   else : FFzW1w(VVdtUh, BF(self.VVdCjD, VVdtUh, title), title="Reading Account ...")
 def VVdCjD(self, VVdtUh, title, forceMoreInfo=False):
  rows, totCols = self.VV5YZa(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVEHz9)
  VVKDDh  = ("Home Menu" , FFsago           , [])
  VVEXwE  = None
  if VVncAm:
   VVEXwE = ("Get JS"  , BF(self.VVrf1p, self.VVEB3G()) , [])
  if totCols == 2:
   VVJvWF = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   VVJvWF = ("More Info.", BF(self.VVsyyk, VVdtUh)    , [])
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
  FFldB6(self, None, title=title, width=1200, header=header, VVWsIU=rows, VVv3Wm=widths, VVHZHw=26, VVKDDh=VVKDDh, VVEXwE=VVEXwE, VVJvWF=VVJvWF, VVZYdg="#0a00292B", VVcwfs="#0a002126", VVLuY4="#0a002126", VVG27K="#00000000", searchCol=searchCol)
 def VVrf1p(self, url, VVoLtS, title, txt, colList):
  FFzW1w(VVoLtS, BF(self.VVwEMr, url), title="Getting JS ...")
 def VVwEMr(self, url):
  txt  = "// Host\t: %s\t%s\n" % (url, self.VVEHz9)
  ver, err = self.VVpMtS(url)
  txt += "// Version\t: %s\n\n" % (ver or err)
  js , err = self.VVpMtS(url, isJsFile=True)
  if err: txt += "Error : %s" % err
  else  : txt += js
  FFtybv(self, txt, title="JS Info", outputFileToSave="Server_xpcom.common.js")
 def VVsyyk(self, VVdtUh, VVoLtS, title, txt, colList):
  VVoLtS.cancel()
  FFzW1w(VVdtUh, BF(self.VVdCjD, VVdtUh, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VVnleE(self, mode):
  token, profile, tErr = self.VVIZ9u()
  if not token:
   return
  res, err = self.VVHuq9(self.VVmQlk(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList = tDict["js"]
     for item in chList:
      Id   = CCfw0y.VVEl8A(item, "id"       )
      Title  = CCfw0y.VVEl8A(item, "title"      )
      censored = CCfw0y.VVEl8A(item, "censored"     )
      Title = self.VV3PAZ(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVPdMM:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVAzis(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVZYdg, VVcwfs, VVLuY4, VVG27K = self.VVc2aF(mode)
   mName = self.VVAzis(mode)
   VV4ePT  = (""     , BF(self.VVbbyL, mode), [])
   VVd479   = ("Show List"   , BF(self.VVVqFj, mode)   , [])
   VVKDDh  = ("Home Menu"   , FFsago        , [])
   if mode in ("vod", "series"):
    VV7J8f = ("Find in %s" % mName , BF(self.VV81Xc, mode, False), [])
    VVJvWF = ("Find in Selected" , BF(self.VV81Xc, mode, True) , [])
   else:
    VV7J8f = None
    VVJvWF = None
   header   = None
   widths   = (100   , 0  )
   FFldB6(self, None, title=title, width=1200, header=header, VVWsIU=list, VVv3Wm=widths, VVHZHw=30, VVKDDh=VVKDDh, VV7J8f=VV7J8f, VVJvWF=VVJvWF, VV4ePT=VV4ePT, VVd479=VVd479, VVZYdg=VVZYdg, VVcwfs=VVcwfs, VVLuY4=VVLuY4, VVG27K=VVG27K, lastFindConfigObj=CFG.lastFindIptv)
  else:
   s = "Authorization failed"
   if err:
    txt = err
   elif s in res.text:
    txt = s
    if self.VVHUA4:
     txt += "\n\n( %s )" % self.VVHUA4
   else:
    txt = "Could not get Categories from server!"
   FFzrXb(self, txt, title=title)
 def VVtcfA(self, mode, VVoLtS, title, txt, colList):
  FFzW1w(VVoLtS, BF(self.VVNe9S, mode, VVoLtS, title, txt, colList), title="Downloading ...")
 def VVNe9S(self, mode, VVoLtS, title, txt, colList):
  token, profile, tErr = self.VVIZ9u()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVHuq9(self.VV4S3a(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList = tDict["js"]['data']
     for item in chList:
      Id    = CCfw0y.VVEl8A(item, "id"    )
      actors   = CCfw0y.VVEl8A(item, "actors"   )
      added   = CCfw0y.VVEl8A(item, "added"   )
      age    = CCfw0y.VVEl8A(item, "age"   )
      category_id  = CCfw0y.VVEl8A(item, "category_id" )
      description  = CCfw0y.VVEl8A(item, "description" )
      director  = CCfw0y.VVEl8A(item, "director"  )
      genres_str  = CCfw0y.VVEl8A(item, "genres_str"  )
      name   = CCfw0y.VVEl8A(item, "name"   )
      path   = CCfw0y.VVEl8A(item, "path"   )
      screenshot_uri = CCfw0y.VVEl8A(item, "screenshot_uri" )
      series   = CCfw0y.VVEl8A(item, "series"   )
      cmd    = CCfw0y.VVEl8A(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list.sort(key=lambda x: (x[1], int(x[2])))
   VV4ePT = (""     , BF(self.VVrkr4, mode, True)  , [])
   VVd479  = ("Play"    , BF(self.VVlftA, mode)       , [])
   VV1Jd7 = (""     , BF(self.VVsZyW, mode)     , [])
   VVKDDh = ("Home Menu"   , FFsago            , [])
   VVEXwE = ("Download Options" , BF(self.VVZoWP, mode, "sp", seriesName) , [])
   VV7J8f = ("Options"   , BF(self.VVoWAN, "pEp", mode, seriesName) , [])
   VVJvWF = ("Posters Mode"  , BF(self.VVs46a, mode, True)      , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VViqYN  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFldB6(self, None, title=seriesName, width=1200, header=header, VVWsIU=list, VViqYN=VViqYN, VVv3Wm=widths, VVHZHw=26, VV4ePT=VV4ePT, VVd479=VVd479, VV1Jd7=VV1Jd7, VVKDDh=VVKDDh, VVEXwE=VVEXwE, VV7J8f=VV7J8f, VVJvWF=VVJvWF, lastFindConfigObj=CFG.lastFindIptv, VVZYdg="#0a00292B", VVcwfs="#0a002126", VVLuY4="#0a002126", VVG27K="#00000000")
  else:
   FFzrXb(self, "Could not get Episodes from server!", title=seriesName)
 def VV81Xc(self, mode, searchInCat, VVoLtS, title, txt, colList):
  searchCatId = colList[1].strip() if searchInCat else ""
  VVMVqr = []
  VVMVqr.append(("Keyboard"  , "manualEntry"))
  VVMVqr.append(("From Filter" , "fromFilter"))
  FF7ARM(self, BF(self.VV5NpS, VVoLtS, mode, searchCatId), title="Input Type", VVMVqr=VVMVqr, width=400)
 def VV5NpS(self, VVoLtS, mode, searchCatId, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFBgSg(self, BF(self.VVmC6m, VVoLtS, mode, searchCatId), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCOe8b(self)
    filterObj.VVpQGc(BF(self.VVmC6m, VVoLtS, mode, searchCatId))
 def VVmC6m(self, VVoLtS, mode, searchCatId, item):
  if not item is None:
   searchName = item.strip()
   FF2tHk(CFG.lastFindIptv, searchName)
   title = self.VVJNVW(mode, searchName)
   if "," in searchName : FFzrXb(self, "Use only one word to search in Portal Servers !\n\nRemove the comma.", title=title)
   elif len(searchName) < 3: FFzrXb(self, "Enter at least 3 characters.", title=title)
   else     :
    if CFG.hideIptvServerAdultWords.getValue() and self.VVlVjJ([searchName]):
     FFzrXb(self, self.VVFpjk(), title=title)
    else:
     self.VV37LA(mode, searchName, "", searchName, searchCatId)
 def VVVqFj(self, mode, VVoLtS, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.curPortalCatId = catID
  self.VV37LA(mode, bName, catID, "", "")
 def VV37LA(self, mode, bName, catID, searchName, searchCatId):
  self.session.open(CCSCNk, barTheme=CCSCNk.VV7KPr
      , titlePrefix = "Reading from server"
      , fncToRun  = BF(self.VViF8V, mode, bName, catID, searchName, searchCatId)
      , VVEStC = BF(self.VVEsQv, mode, bName, catID, searchName, searchCatId))
 def VVEsQv(self, mode, bName, catID, searchName, searchCatId, VVPnF9, VVRTV9, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVJNVW(mode, searchName)
  else   : title = "%s : %s" % (self.VVAzis(mode), bName)
  if VVRTV9:
   VVEXwE = None
   VV7J8f = None
   if mode == "series":
    VVZYdg, VVcwfs, VVLuY4, VVG27K = self.VVc2aF("series2")
    VVd479  = ("Episodes"   , BF(self.VVtcfA, mode)           , [])
   else:
    VVZYdg, VVcwfs, VVLuY4, VVG27K = self.VVc2aF("")
    VVd479  = ("Play"    , BF(self.VVlftA, mode)           , [])
    VVEXwE = ("Download Options" , BF(self.VVZoWP, mode, "vp" if mode == "vod" else "", "") , [])
    VV7J8f = ("Options"   , BF(self.VVoWAN, "pCh", mode, bName)      , [])
   VV4ePT = (""      , BF(self.VVrkr4, mode, False)      , [])
   VV1Jd7 = (""      , BF(self.VV3SFj, mode)         , [])
   VVKDDh = ("Home Menu"    , FFsago                , [])
   VVJvWF = ("Posters Mode"   , BF(self.VVs46a, mode, False)         , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" , "Cat./Genre" , "Logo", "play", "actors" , "descr" , "director")
   widths   = (9  , 60  , 0   , 0     , 0  , 0  , 25   , 6  , 0  , 0   , 0   , 0   )
   VViqYN  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , LEFT , LEFT   , CENTER, LEFT , LEFT  , LEFT  , LEFT  )
   VVoLtS = FFldB6(self, None, title=title, header=header, VVWsIU=VVRTV9, VViqYN=VViqYN, VVv3Wm=widths, VVHZHw=26, VVKDDh=VVKDDh, VVEXwE=VVEXwE, VV7J8f=VV7J8f, VVJvWF=VVJvWF, lastFindConfigObj=CFG.lastFindIptv, VVd479=VVd479, VV4ePT=VV4ePT, VV1Jd7=VV1Jd7, VVZYdg=VVZYdg, VVcwfs=VVcwfs, VVLuY4=VVLuY4, VVG27K=VVG27K, VV65AN=True, searchCol=1)
   if not VVPnF9:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVoLtS.VVTWCM(VVoLtS.VVqJjk() + tot)
    if threadErr: FFycel(VVoLtS, "Error while reading !", 2000)
    else  : FFycel(VVoLtS, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FFzrXb(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FFzrXb(self, "Could not get list from server !", title=title)
 def VV3SFj(self, mode, VVoLtS, title, txt, colList):
  ttl = lambda x, y: "%s:\n%s\n\n" % (FFCzRx(x, VV61JF), str(y)) if y.strip() and not "N/A" in y else ""
  tab = lambda x, y: "%s\t: %s\n" % (x, y) if y.strip() and not "N/A" in y else ""
  Num, Name, catID, genreID, Icon, cmd, Cat_Genre, Logo, play, actors, descr, director = colList
  txt  = tab("Number"  , Num)
  txt += tab("Name"  , Name)
  txt += tab("Cat./Genre" , Cat_Genre)
  txt += tab("Director" , director)
  txt += "\n"
  txt += ttl("Actors"  , actors)
  txt += ttl("Description", descr)
  play = play.strip()
  if play and not play.startswith("[No "):
   txt += ttl("Cur. Playing", play)
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFp5JP(self, fncMode=CCoD37.VVYfui, portalHost=self.VVrHOQ, portalMac=self.VVEHz9, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VVgNEE(mode, VVoLtS, title, txt, colList)
 def VVsZyW(self, mode, VVoLtS, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FFCzRx(colList[10], VVzv5p)
  txt += "Description:\n%s" % FFCzRx(colList[11], VVzv5p)
  self.VVgNEE(mode, VVoLtS, title, txt, colList)
 def VVgNEE(self, mode, VVoLtS, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVxFLI(mode, colList)
  refCode, chUrl = self.VViO0E(self.VVrHOQ, self.VVEHz9, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFp5JP(self, fncMode=CCoD37.VVMXbL, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId, portalEpgUrl=chUrl)
 def VViF8V(self, mode, bName, catID, searchName, searchCatId, VV2ohY):
  try:
   token, profile, tErr = self.VVIZ9u()
   if not token:
    return
   if VV2ohY.isCancelled:
    return
   VV2ohY.VVRTV9, total_items, max_page_items, err = self.VVqraG(mode, catID, 1, 1, searchName, searchCatId)
   if VV2ohY.isCancelled:
    return
   if VV2ohY.VVRTV9 and total_items > -1 and max_page_items > -1:
    VV2ohY.VVHJ4P(total_items)
    VV2ohY.VVc1xD(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if VV2ohY.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVqraG(mode, catID, page, counter, searchName, searchCatId)
     if err:
      VV2ohY.VV358a()
     if VV2ohY.isCancelled:
      return
     if list:
      VV2ohY.VVRTV9 += list
      VV2ohY.VVc1xD(len(list), True)
  except:
   pass
 def VVqraG(self, mode, catID, page, counter, searchName, searchCatId):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VVyDe7(mode, searchName, searchCatId, page)
  else   : url = self.VV300Y(mode, catID, page)
  res, err = self.VVHuq9(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVzFsF(CCfw0y.VVEl8A(item, "total_items" ))
     max_page_items = self.VVzFsF(CCfw0y.VVEl8A(item, "max_page_items" ))
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCfw0y.VVEl8A(item, "id"    )
      name   = CCfw0y.VVEl8A(item, "name"   )
      o_name   = CCfw0y.VVEl8A(item, "o_name"   )
      category_id  = CCfw0y.VVEl8A(item, "category_id" )
      tv_genre_id  = CCfw0y.VVEl8A(item, "tv_genre_id" )
      number   = CCfw0y.VVEl8A(item, "number"   ) or str(counter)
      logo   = CCfw0y.VVEl8A(item, "logo"   )
      screenshot_uri = CCfw0y.VVEl8A(item, "screenshot_uri" )
      pic    = CCfw0y.VVEl8A(item, "pic"   )
      cmd    = CCfw0y.VVEl8A(item, "cmd"   )
      censored  = CCfw0y.VVEl8A(item, "censored"  )
      genres_str  = CCfw0y.VVEl8A(item, "genres_str"  )
      curPlay   = CCfw0y.VVEl8A(item, "cur_playing" )
      actors   = CCfw0y.VVEl8A(item, "actors"   )
      descr   = CCfw0y.VVEl8A(item, "description" )
      director  = CCfw0y.VVEl8A(item, "director"  )
      catID   = category_id or tv_genre_id
      if name == "video_name_format" and o_name:
       name = o_name
      if " " in cmd and cmdStr in cmd:
       cmd = cmd.split(" ")[1]
      if mode == "itv" and not cmdStr in cmd and not cmd.endswith(".m3u8") and not "ffrt" in cmd:
       if "token=" in cmd and "d=Mag" in cmd:
        cmd = "Zz1" + FFxHdY(cmd)
       else:
        span = iSearch(r"stream=(.+)&", cmd)
        if span:
         cmd = "%s%s_" % (cmdStr, span.group(1))
        else:
         span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
         if span:
          cmd = "%s%s_" % (cmdStr, span.group(1))
      if   logo.startswith("http")   : picon = logo
      elif pic.startswith("http")    : picon = pic
      elif screenshot_uri.startswith("http") : picon = screenshot_uri
      else         : picon = logo or screenshot_uri or pic
      sp = "/stalker_portal"
      if picon.startswith(sp):
       picon = (self.VVrHOQ + picon).replace(sp * 2, sp)
      isIcon = "Yes" if picon.startswith("http") else ""
      counter += 1
      name = self.VVba4j(name, censored)
      if name:
       list.append((number, name, Id, catID, picon, cmd, genres_str, isIcon, curPlay, actors, descr, director))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVzFsF(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVlftA(self, mode, VVoLtS, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVxFLI(mode, colList)
  refCode, chUrl = self.VViO0E(self.VVrHOQ, self.VVEHz9, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VVV5BR(chName):
   FFycel(VVoLtS, "This is a marker!", 300)
  else:
   FFzW1w(VVoLtS, BF(self.VV5PaV, mode, VVoLtS, chUrl), title="Playing ...")
 def VV5PaV(self, mode, VVoLtS, chUrl):
  FFrvm6(self, chUrl, VViFts=False)
  CCA3uT.VV1gQV(self.session, iptvTableParams=(self, VVoLtS, mode))
 def VV9kBQ(self, mode, VVoLtS, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVxFLI(mode, colList)
  refCode, chUrl = self.VViO0E(self.VVrHOQ, self.VVEHz9, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VVxFLI(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "_")
  else:
   chNum = colList[0]
   chName = colList[1]
   stID = colList[2]
   catID = colList[3]
   picUrl = colList[4]
   chCm = colList[5]
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VV1Ewa(SELF, install=True, cbFnc=None):
  try:
   import requests
   return True
  except:
   if install:
    title = 'Install "Requests"'
    VVMVqr = []
    VVMVqr.append((title        , "inst" ))
    VVMVqr.append(("Update Packages then %s" % title , "updInst" ))
    FF7ARM(SELF, BF(CCGolS.VV4Jiy, SELF, cbFnc=cbFnc), title='This requires Python "Requests" library', VVMVqr=VVMVqr)
   return False
 @staticmethod
 def VV4Jiy(SELF, item=None, cbFnc=None):
  if item:
   cmdUpd = FF1dKx(VV4pgO, "")
   if cmdUpd:
    cmdInst = FF4ZaS(VVLFdd, "python-requests")
    if pyVersion[0] >= 3:
     cmdInst = cmdInst.replace("python-", "python3-")
    if   item == "inst"  : cmd = cmdInst
    elif item == "updInst" : cmd = cmdUpd + " && " + cmdInst
    FFHguD(SELF, cmd, checkNetAccess=True, title='Installing "Requests" Library', VVFgpi=cbFnc)
   else:
    FFV7xB(SELF)
 def VVRsgv(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFmvpz(self)
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = self.VVfC9q(decodedUrl)
  return mode, host, catID, stID, epNum.replace("%3a", ":"), epId.replace("%3a", ":")
 def VVw79X(self, VVdtUh):
  curMode, curHost, curCat, curStID, curEpNum, curEpId = self.VVRsgv()
  if all((curMode, curHost, curCat)) and curHost == self.VVrHOQ:
   VVdtUh.VVT53N({"itv": 0, "vod": 1, "series": 2}.get(curMode, 0))
 def VVbbyL(self, mode, VVoLtS, title, txt, colList):
  curMode, curHost, curCat, curStID, curEpNum, curEpId = self.VVRsgv()
  if all((curMode, curHost, curCat)) and curMode == mode and curHost == self.VVrHOQ:
   VVoLtS.VVQ2Hx({1:curCat})
 def VVrkr4(self, mode, isEp, VVoLtS, title, txt, colList):
  curMode, curHost, curCat, curStID, curEpNum, curEpId = self.VVRsgv()
  if all((curMode, curHost, curCat)) and curCat == self.curPortalCatId and curMode == mode and curHost == self.VVrHOQ:
   if mode in ("itv", "vod"):
    VVoLtS.VVQ2Hx({2:curStID})
   else: #series
    if isEp:
     VVoLtS.VVQ2Hx({2:curEpNum, 4:curEpId})
    elif mode == "series":
     ser1 = curEpId.split(":")[0]
     ser2 = "%s:%s" % (ser1, ser1)
     ok = VVoLtS.VVQ2Hx({2:ser2})
     if not ok: VVoLtS.VVQ2Hx({2:ser1})
class CCfw0y(Screen, CCGolS, CCaV2Y, CCbA6i):
 VVi2aW    = 0
 VVMmGX    = 1
 VVw3o3    = 2
 VVntPv    = 3
 VVu8DR     = 4
 VVYXFs     = 5
 VVSCIZ     = 6
 VVyQGk     = 7
 VVdrSb     = 8
 VV3aYJ     = 9
 VVqbA5      = 10
 VVOlWy     = 11
 VVg1fJ     = 12
 VV0SAd     = 13
 VVkftG     = 14
 VVnMD0      = 15
 VVsCB9      = 16
 VV4sjN      = 17
 VVcxdi      = 18
 VVHaaj      = 19
 VVYBoz    = 0
 VV1LVs   = 1
 VVgfJL   = 2
 VVFsH1   = 3
 VVKPA8  = 4
 VVDHPw  = 5
 VVZsQj   = 6
 VVJwAe   = 7
 VV4xmt  = 8
 VVrfk1  = 9
 VVLGGT  = 10
 VVANmR = 0
 VVRyxq = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FF5TEn(VVL1I3, 1050, 1050, 50, 40, 30, "#0a001a20", "#0a001a20", 28, topRightBtns=1)
  self.session     = session
  self.m3uOrM3u8File    = m3uOrM3u8File
  self.m3uOrM3u8BName    = ""
  self.VVoLtS    = None
  self.tableTitle     = "IPTV Channels List"
  self.VVXBtWData    = {}
  self.localIptvFilterInFilter = False
  self.iptvFileAvailable   = CCfw0y.VVvkN7(atLeastOne=True)
  self.isFirstTime    = True
  self.curUrl      = ""
  CCGolS.__init__(self)
  CCaV2Y.__init__(self)
  VVMVqr = self.VVU5Om()
  FF32Yx(self, title="IPTV", VVMVqr=VVMVqr)
  self["myActionMap"].actions.update({
   "menu" : self.VVq23x
  })
  self.onShown.append(self.VVSDD3)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVjpKs)
  global VVHdUx
  VVHdUx = True
 def VVSDD3(self):
  self["myMenu"].setList(self.VVU5Om())
  FF0pG3(self)
  FFDoNq(self)
  if self.isFirstTime:
   self.isFirstTime = False
   FFWzaz(self["myMenu"])
   FFudBR(self)
   if self.m3uOrM3u8File:
    self.VVxoY0(self.m3uOrM3u8File)
   else:
    self.VVGCmj()
 def VVGCmj(self):
  qUrl, decodedUrl, iptvRef = CCfw0y.VVdDss(self)
  if qUrl or "chCode" in iptvRef:
   for ndx, item in enumerate(self["myMenu"].list):
    if item[0] == "IPTV Server Browser (from Current Channel)" and len(item) > 1:
     self["myMenu"].moveToIndex(ndx)
     break
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  FFzMsA("VVHdUx")
 def VVjpKs(self):
  if self["myMenu"].getCurrent()[1] in ("VVl1fS", "VVBO6RPortal") : self["keyMenu"].show()
  else                      : self["keyMenu"].hide()
 def VVq23x(self):
  if self["myMenu"].getVisible():
   title, item = self["myMenu"].getCurrent()
   if   item == "VVBO6RPortal" : confItem = CFG.favServerPortal
   elif item == "VVl1fS" : confItem = CFG.favServerPlaylist
   else         : return
   FFo4dm(self, BF(self.VVT9vI, confItem), 'Remove from menu ?', title=title)
 def VVT9vI(self, confItem):
  FF2tHk(confItem, "")
  self.VVSDD3()
 def VVU5Om(self):
  isFav1, isFav2 = CFG.favServerPlaylist.getValue(), CFG.favServerPortal.getValue()
  c = VVTKrH
  VVMVqr = []
  if isFav1: VVMVqr.append((c +  "Favourite Playlist Server"   , "VVl1fS" ))
  if isFav2: VVMVqr.append((c +  "Favourite Portal Server"    , "VVBO6RPortal" ))
  VVMVqr.append(("IPTV Server Browser (from Playlists)"     , "VVXBtW_fromPlayList" ))
  VVMVqr.append(("IPTV Server Browser (from Portal List)"    , "VVXBtW_fromMac"  ))
  VVMVqr.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)", "VVXBtW_fromM3u"  ))
  qUrl, decodedUrl, iptvRef = CCfw0y.VVdDss(self)
  fromCurCond = qUrl or "chCode" in iptvRef
  VVMVqr.append(FFwLFH("IPTV Server Browser (from Current Channel)", "VVXBtW_fromCurrChan", fromCurCond))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("M3U/M3U8 File Browser"        , "VVtvEi"   ))
  if self.iptvFileAvailable:
   VVMVqr.append(("Local IPTV Services"        , "iptvTable_all"   ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(FFwLFH("Update Current Bouquet EPG (from IPTV Server)" , "refreshIptvEPG"  , fromCurCond))
  VVMVqr.append(FFwLFH("Update Current Bouquet PIcons (from IPTV Server)" , "refreshIptvPicons", fromCurCond))
  if self.iptvFileAvailable:
   VVMVqr.append(VVpTvr)
   c1, c2 = VVYqlh, VV61JF
   t1 = FFCzRx("auto-match names", VVTKrH)
   t2 = FFCzRx("from xml file"  , VVTKrH)
   VVMVqr.append((c1 + "Count Available IPTV Channels"    , "VVCMi0"    ))
   VVMVqr.append((c1 + "Copy EPG/PIcons between Channels (%s)" % t2 , "copyEpgPicons"   ))
   VVMVqr.append(VVpTvr)
   VVMVqr.append((c2 + "Share Reference with DVB Channels (%s)" % t2 , "renumIptvRef_fromFile" ))
   VVMVqr.append((c2 + "Share Reference with DVB Channels (%s)" % t1 , "VVTIDg" ))
   VVMVqr.append((VVszO3 + "More Reference Tools ..."  , "VVwcer"   ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Reload Channels and Bouquets"       , "VV326Q"   ))
  VVMVqr.append(VVpTvr)
  if not CCXFYJ.VV39Bn():
   VVMVqr.append(("Download Manager"         , "dload_stat"    ))
  else:
   VVMVqr.append(("Download Manager ... No downloads"    ,       ))
  return VVMVqr
 def VVmouG(self, item):
  self.curUrl = ""
  tTitle = "Share Reference with DVB Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VVrYwl"   : self.VVrYwl()
   elif item == "VVgfdM" : FFo4dm(self, self.VVgfdM, "Change Current List References to Unique Codes ?")
   elif item == "VVRT7L_rows" : FFo4dm(self, BF(FFzW1w, self.VVoLtS, self.VVRT7L), "Change Current List References to Identical Codes ?")
   elif item == "VVV0ND"   : self.VVV0ND(tTitle)
   elif item == "VV0Bsj"   : self.VV0Bsj(tTitle)
   elif item == "VVl1fS" : self.VVBO6R(False)
   elif item == "VVBO6RPortal" : self.VVBO6R(True)
   elif item == "VVXBtW_fromPlayList" : FFzW1w(self, BF(self.VVHYUH, 1), title=title)
   elif item == "VVXBtW_fromM3u"  : FFzW1w(self, BF(self.VVWUCX, CCfw0y.VVANmR), title=title)
   elif item == "VVXBtW_fromMac"  : self.VVM1kc()
   elif item == "VVXBtW_fromCurrChan" : self.VV8Hpw()
   elif item == "VVtvEi"   : self.VVtvEi()
   elif item == "iptvTable_all"   : FFzW1w(self, BF(self.VVpD0E, self.VVi2aW), title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : CCfw0y.VVNX8T(self)
   elif item == "refreshIptvPicons"  : self.VVEnM2()
   elif item == "VVCMi0"    : FFzW1w(self, self.VVCMi0)
   elif item == "copyEpgPicons"   : self.VVh0LG(False)
   elif item == "renumIptvRef_fromFile" : self.VVh0LG(True)
   elif item == "VVTIDg" : FFo4dm(self, BF(FFzW1w, self, self.VVTIDg), VV66pG="Continue ?")
   elif item == "VVwcer"    : self.VVwcer()
   elif item == "VV326Q"   : FFzW1w(self, BF(CCh3Pq.VV326Q, self))
   elif item == "dload_stat"    : CCXFYJ.VVf574(self)
 def VVtvEi(self):
  if CCGolS.VV1Ewa(self):
   FFzW1w(self, BF(self.VVWUCX, CCfw0y.VVRyxq), title="Searching ...")
 def VVthYm(self):
  global VVBcOf
  VVBcOf = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVmouG(item)
 def VVpD0E(self, mode):
  VVpn2v = self.VVUkQk(mode)
  if VVpn2v:
   VVEXwE = ("Current Service", self.VVQ3zY , [])
   VV7J8f = ("Options"  , self.VVkkOE   , [])
   VVJvWF = ("Filter"   , self.VVkvoc   , [])
   VVd479  = ("Play"   , BF(self.VVyxPA)  , [])
   VV1Jd7 = (""    , self.VVtEZ5    , [])
   VV4ePT = (""    , self.VVRB5v     , [])
   header   = ("Num" , "Name", "Bouquet" , "Type", "Ref.", "URL" )
   widths   = (9  , 22 , 18  , 6  , 22 , 23 )
   VViqYN  = (CENTER , LEFT , LEFT  , CENTER, LEFT , LEFT )
   FFldB6(self, None, header=header, VVWsIU=VVpn2v, VViqYN=VViqYN, VVv3Wm=widths, VVHZHw=26
     , VVd479=VVd479, VVEXwE=VVEXwE, VV7J8f=VV7J8f, VVJvWF=VVJvWF, VV1Jd7=VV1Jd7, VV4ePT=VV4ePT
     , VVZYdg="#0a00292B", VVcwfs="#0a002126", VVLuY4="#0a002126", VVG27K="#00000000", VV65AN=True, searchCol=1)
  else:
   if mode == self.VV3aYJ: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFzrXb(self, err)
 def VVRB5v(self, VVoLtS, title, txt, colList):
  self.VVoLtS = VVoLtS
 def VVkkOE(self, VVoLtS, title, txt, colList):
  VVMVqr = []
  VVMVqr.append(("Add Current List to a New Bouquet"    , "VVrYwl"  ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Change Current List References to Unique Codes" , "VVgfdM"))
  VVMVqr.append(("Change Current List References to Identical Codes", "VVRT7L_rows" ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Share Reference with DVB Service (manual entry)" , "VVV0ND"   ))
  VVMVqr.append(("Share Reference with DVB Service (auto-find)"  , "VV0Bsj"   ))
  FF7ARM(self, self.VVmouG, title="IPTV Tools", VVMVqr=VVMVqr)
 def VVkvoc(self, VVoLtS, title, txt, colList):
  FFzW1w(VVoLtS, BF(self.VVaqnf, VVoLtS))
 def VVaqnf(self, VVoLtS):
  VVMVqr = []
  VVMVqr.append(("All"         , "all"   ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Prefix of Selected Channel"   , "sameName" ))
  VVMVqr.append(("Suggest Words from Selected Channel" , "partName" ))
  VVMVqr.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVMVqr.append(("Duplicate References"     , "depRef"  ))
  VVMVqr.append(("Reference x:x:x:x:0:0:0:0:0:0:"  , "ref00"  ))
  VVMVqr.append(("Stream Relay"       , "SRelay"  ))
  VVMVqr.append(FFfdOi("Category"))
  VVMVqr.append(("Live TV"        , "live"  ))
  VVMVqr.append(("VOD"         , "vod"   ))
  VVMVqr.append(("Series"        , "series"  ))
  VVMVqr.append(("Uncategorised"      , "uncat"  ))
  VVMVqr.append(FFfdOi("Media"))
  VVMVqr.append(("Video"        , "video"  ))
  VVMVqr.append(("Audio"        , "audio"  ))
  VVMVqr.append(FFfdOi("File Type"))
  VVMVqr.append(("MKV"         , "MKV"   ))
  VVMVqr.append(("MP4"         , "MP4"   ))
  VVMVqr.append(("MP3"         , "MP3"   ))
  VVMVqr.append(("AVI"         , "AVI"   ))
  VVMVqr.append(("FLV"         , "FLV"   ))
  VVMVqr.extend(CCrfsB.VVcVdn(prefix="__b__", onlyIptv=True))
  inFilterFnc = BF(self.VVNlFL, VVoLtS) if VVoLtS.VVqJjk().startswith("IPTV Filter ") else None
  filterObj = CCOe8b(self)
  filterObj.VViYlv(VVMVqr, VVMVqr, BF(self.VVnvv9, VVoLtS, False), inFilterFnc=inFilterFnc)
 def VVNlFL(self, VVoLtS, VVdtUh, item):
  self.VVnvv9(VVoLtS, True, item)
 def VVnvv9(self, VVoLtS, inFilter, item=None):
  self.localIptvFilterInFilter = inFilter
  prefix = VVoLtS.VVh7wm(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVi2aW , ""  , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVMmGX , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVw3o3 , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVntPv , ""  , f + "= Names with Non-English Characters"
   elif item == "depRef"   : mode, words, title = self.VVSCIZ  , ""  , f + "= Duplicate References"
   elif item == "ref00"   : mode, words, title = self.VVyQGk  , ""  , f + "= Reference x:x:x:x:0:0:0:0:0:0:"
   elif item == "SRelay"   : mode, words, title = self.VVdrSb  , ""  , f + "= Stream Relay"
   elif item == "live"    : mode, words, title = self.VV3aYJ  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVqbA5   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVOlWy  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVg1fJ  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VV0SAd  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVkftG  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVnMD0   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVsCB9   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VV4sjN   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVcxdi   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVHaaj   , ""  , f + "= FLV"
   elif item.startswith("__b__") : mode, words, title = self.VVu8DR  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVYXFs  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVw3o3:
   VVMVqr = []
   chName = VVoLtS.VVh7wm(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVMVqr.append((item, item))
    if not VVMVqr and chName:
     VVMVqr.append((chName, chName))
    FF7ARM(self, BF(self.VVoRa4, title), title="Words from Current Selection", VVMVqr=VVMVqr)
   else:
    VVoLtS.VVOPq5("Invalid Channel Name")
  else:
   words, asPrefix = CCOe8b.VVjxXj(words)
   if not words and mode in (self.VVu8DR, self.VVYXFs):
    FFycel(self.VVoLtS, "Incorrect filter", 2000)
   else:
    FFzW1w(self.VVoLtS, BF(self.VVtTUM, mode, words, asPrefix, title), clearMsg=False, title="Filtering ...")
 def VVoRa4(self, title, word=None):
  if word:
   words = [word.lower()]
   FFzW1w(self.VVoLtS, BF(self.VVtTUM, self.VVw3o3, words, False, title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VV5Gqm(txt):
  return "#f#11ffff00#" + txt
 def VVtTUM(self, mode, words, asPrefix, title):
  if self.localIptvFilterInFilter : VVpn2v = self.VVmg3u(mode=mode, words=words, asPrefix=asPrefix)
  else       : VVpn2v = self.VVUkQk(mode=mode, words=words, asPrefix=asPrefix)
  if VVpn2v : self.VVoLtS.VVkYNn(VVpn2v, title)
  else  : self.VVoLtS.VVOPq5("Not found")
 def VVmg3u(self, mode=0, words=None, asPrefix=False):
  VVpn2v = []
  for row in self.VVoLtS.VVGkEL():
   row = list(map(str.strip, row))
   chNum, chName, VVxZ1m, chType, refCode, url = row
   if self.VVrDYS(mode, refCode, FFKkPs(url).lower(), chName, words, VVxZ1m.lower(), asPrefix):
    VVpn2v.append(row)
  VVpn2v = self.VVNS6N(mode, VVpn2v)
  return VVpn2v
 def VVUkQk(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  patt = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+"
  if isStripChan: patt += r"[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : patt += r"(.+)"
  VVpn2v = []
  files = CCfw0y.VVvkN7()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFpCvR(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVxZ1m = span.group(1)
    else : VVxZ1m = ""
    VVxZ1m_lCase = VVxZ1m.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVV5BR(chName): chNameMod = self.VV5Gqm(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVxZ1m, chType + (" SRel" if FFYKlk(url) else ""), refCode, url)
     if self.VVrDYS(mode, refCode, FFKkPs(url).lower(), chName, words, VVxZ1m_lCase, asPrefix):
      VVpn2v.append(row)
      chNum += 1
  VVpn2v = self.VVNS6N(mode, VVpn2v)
  return VVpn2v
 def VVNS6N(self, mode, VVpn2v):
  newRows = []
  if VVpn2v and mode == self.VVSCIZ:
   counted  = iCounter(elem[4] for elem in VVpn2v)
   for item in VVpn2v:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   return newRows
  else:
   return VVpn2v
 def VVrDYS(self, mode, refCode, tUrl, chName, words, VVxZ1m_lCase, asPrefix):
  if   mode == self.VVi2aW : return True
  elif mode == self.VVSCIZ : return True
  elif mode == self.VVyQGk  : return ":0:0:0:0:0:0:" in refCode
  elif mode == self.VVdrSb : return FFYKlk(tUrl)
  elif mode == self.VV0SAd  : return CCfw0y.VVKCk4(tUrl, getAudVid=True) == "vid"
  elif mode == self.VVkftG  : return CCfw0y.VVKCk4(tUrl, getAudVid=True) == "aud"
  elif mode == self.VV3aYJ  : return CCfw0y.VVKCk4(tUrl, compareType="live")
  elif mode == self.VVqbA5  : return CCfw0y.VVKCk4(tUrl, compareType="movie")
  elif mode == self.VVOlWy : return CCfw0y.VVKCk4(tUrl, compareType="series")
  elif mode == self.VVg1fJ  : return CCfw0y.VVKCk4(tUrl, compareType="")
  elif mode == self.VVnMD0  : return CCfw0y.VVKCk4(tUrl, compareExt="mkv")
  elif mode == self.VVsCB9  : return CCfw0y.VVKCk4(tUrl, compareExt="mp4")
  elif mode == self.VV4sjN  : return CCfw0y.VVKCk4(tUrl, compareExt="mp3")
  elif mode == self.VVcxdi  : return CCfw0y.VVKCk4(tUrl, compareExt="avi")
  elif mode == self.VVHaaj  : return CCfw0y.VVKCk4(tUrl, compareExt="flv")
  elif mode == self.VVMmGX: return chName.lower().startswith(words[0])
  elif mode == self.VVw3o3: return words[0] in chName.lower()
  elif mode == self.VVntPv: return bool(iSearch(r"[^\x00-\x7F]", chName))
  elif mode == self.VVu8DR : return words[0] == VVxZ1m_lCase
  elif mode == self.VVYXFs :
   name = chName.lower()
   for word in words:
    if asPrefix:
     if name.startswith(word) : return True
    elif word in name    : return True
  return False
 def VVrYwl(self):
  picker = CCrfsB(self, self.VVoLtS, "Add to Bouquet", self.VVUIJ4)
 def VVUIJ4(self):
  chUrlLst = []
  for row in self.VVoLtS.VVGkEL():
   chUrlLst.append(row[4] + row[5])
  return chUrlLst
 def VVwcer(self):
  t1 = FFCzRx("Bouquet" , VV61JF)
  t2 = FFCzRx("ALL"  , VVszO3)
  t3 = FFCzRx("Unique"  , VVYqlh)
  t4 = FFCzRx("Identical" , VVTKrH)
  VVMVqr = []
  VVMVqr.append((VVJS3b + "Check System Acceptable Reference Types", "VVLA7U"))
  VVMVqr.append(FFwLFH("Check Reference Codes Format", "VVjfCp", self.iptvFileAvailable, VVJS3b))
  VVMVqr.append(VVpTvr)
  txt = "Change %s Ref. Types to (1/4097/5001/5002/8192/8193) .."
  VVMVqr.append((txt % t1, "VVUD5Q" ))
  VVMVqr.append((txt % t2, "VVLjeB_all"  ))
  VVMVqr.append(VVpTvr)
  txt = "Change %s References to %s Codes .."
  VVMVqr.append((txt % (t1, t3), "VVtebu" ))
  VVMVqr.append((txt % (t2, t3), "VVnI24"  ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Change %s References to %s Codes" % (t2, t4) , "VVRT7L_all"))
  VVmKhE = self.VVYqpp
  FF7ARM(self, None, width=1150, title="IPTV Reference Tools", VVMVqr=VVMVqr, VVmKhE=VVmKhE, VVZYdg="#22002233", VVcwfs="#22001122")
 def VVYqpp(self, item=None):
  if item:
   ques = "Continue ?"
   VVdtUh, txt, item, ndx = item
   if   item == "VVLA7U"    : FFzW1w(VVdtUh, self.VVLA7U)
   elif item == "VVjfCp"     : FFzW1w(VVdtUh, self.VVjfCp)
   elif item == "VVUD5Q" : self.VVfueI(VVdtUh, self.VVIEJw)
   elif item == "VVLjeB_all"  : self.VVIEJw(VVdtUh, None, None)
   elif item == "VVtebu" : self.VVtebu(VVdtUh, txt)
   elif item == "VVnI24"  : FFo4dm(self, BF(self.VVnI24 , VVdtUh, txt), title=txt, VV66pG=ques)
   elif item == "VVRT7L_all"  : FFo4dm(self, BF(FFzW1w, VVdtUh, self.VVRT7L), title=txt, VV66pG=ques)
 def VVIEJw(self, VVdtUh, bName, bPath):
  VVMVqr = []
  for rt in CCfw0y.VVpEpL():
   VVMVqr.append(("%s\t ... %s" % (rt, CCfw0y.VVLrgM(rt)), rt))
  FF7ARM(self, BF(self.VV0xcf, VVdtUh, bName, bPath), VVMVqr=VVMVqr, width=800, title="Change Reference Types to:")
 def VV0xcf(self, VVdtUh, bName, bPath, rType=None):
  if rType:
   self.VVcfHw(VVdtUh, bName, bPath, rType)
 def VVfueI(self, VVdtUh, fnc):
  VVMVqr = CCrfsB.VVcVdn()
  if VVMVqr:
   FF7ARM(self, BF(self.VVWx5c, VVdtUh, fnc), VVMVqr=VVMVqr, title="IPTV Bouquets", VVy9CS=True)
  else:
   FFycel(VVdtUh, "No bouquets Found !", 1500)
 def VVWx5c(self, VVdtUh, fnc, item=None):
  if item:
   bName, bRef, ndx = item
   span = iSearch(r'BOUQUET "(.+)" ORDER', bRef, IGNORECASE)
   if span:
    bPath = VVTAUs + span.group(1)
    if fileExists(bPath): fnc(VVdtUh, bName, bPath)
    else    : FFycel(VVdtUh, "Bouquet file not found!", 2000)
   else:
    FFycel(VVdtUh, "Cannot process bouquet !", 2000)
 def VVcfHw(self, VVdtUh, bName, bPath, rType):
  if bPath: title = "Change for Bouquet : %s" % FFCzRx(bName, VVRJhR)
  else : title = "Change for %s" % FFCzRx("All IPTV Services", VVRJhR)
  FFo4dm(self, BF(FFzW1w, VVdtUh, BF(self.VVUcC2, VVdtUh, bName, bPath, rType), title="Changing Type ...")
    , "Change to : %s ?" % FFCzRx(rType, VVRJhR), title=title)
 def VVUcC2(self, VVdtUh, bName, bPath, rType):
  totChange = 0
  if bPath: files = [bPath]
  else : files = CCfw0y.VVvkN7()
  if files:
   newRType = rType + ":"
   piconPath = CCxrlm.VVjBFN()
   for path in files:
    if   not fileExists(path)      : err = "Cannot read the file:\n\n%s" % path
    elif not CCUGPF.VV1eSU(self, path) : err = "File is not in 'UTF-8' Encoding:\n\n%s" % path
    else           : err = ""
    if err:
     FFzrXb(self, err)
     return
    newpFile = path + ".tmp"
    totMod = 0
    with open(newpFile, "w") as tFile:
     with ioOpen(path, "r", encoding="utf-8") as f:
      for line in f:
       span = iSearch(r"#SERVICE\s+([A-Fa-f0-9]+[:]).+http.+", line)
       if span:
        oldRType = span.group(1)
        if not oldRType == newRType:
         totMod += 1
         totChange += 1
         span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
         if span : oldPicon = piconPath + span.group(1).strip(":").replace(":", "_") + ".png"
         else : oldPicon = ""
         line = iSub(r"(#SERVICE)\s+[A-Fa-f0-9]+[:](.+http.+)", r"\1 %s\2" % newRType, line)
         if fileExists(oldPicon):
          span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
          if span:
           FFgSm7("mv -f '%s' '%s'" % (oldPicon, piconPath + span.group(1).strip(":").replace(":", "_") + ".png"))
       tFile.write(line)
    if totMod: cmd = "mv -f '%s' '%s'" % (newpFile, path)
    else  : cmd = "rm -f '%s'" % newpFile
    FFgSm7(cmd)
  self.VViVH4(totChange > 0, 'Change Ref. Codes to "%s"' % rType, "Changes = %d" % totChange)
 def VVCMi0(self):
  totFiles = 0
  files  = CCfw0y.VVvkN7()
  if files:
   totFiles = len(files)
  totChans = 0
  VVpn2v = self.VVUkQk()
  if VVpn2v:
   totChans = len(VVpn2v)
  FFtybv(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVjfCp(self):
  files = CCfw0y.VVvkN7()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFpCvR(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVXF4f
   else    : color = VVtz60
   totInvalid = FFCzRx(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFCzRx("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFtybv(self, txt, title="Check IPTV References")
 def VVLA7U(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  chPrefix = "Testing RType "
  rTypeList = CCfw0y.VVpEpL()
  chUrlLst = []
  for rType in (rTypeList):
   ref = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:Testing RType %s" % (rType, rType)
   chUrlLst.append(ref)
  CCrfsB.VVMouF(self, "", bName, "", chUrlLst, showRes=False)
  acceptedList = []
  VVI8Xk = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVI8Xk:
   VVfIxf = FFwksx(VVI8Xk)
   if VVfIxf:
    for service in VVfIxf:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVTAUs + userBName
  bFile = VVTAUs + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFgeXp("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += FFgeXp("rm -f '%s'" % path)
  FFgSm7(cmd)
  FFwQUx()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = ""
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVXF4f
    else     : res, color = "No" , VVtz60
    pl = CCfw0y.VVLrgM(item)
    txt += "    %s\t: %s%s\n" % (item, FFCzRx(res, color), FFCzRx("\t... %s" % pl, VVzv5p) if pl else "")
   FFtybv(self, txt, title=title)
  else:
   txt = FFzrXb(self, "Could not complete the test on your system!", title=title)
 def VVTIDg(self):
  VVAv8X, err = CCh3Pq.VVM6i7(self, CCh3Pq.VVQqvd)
  if VVAv8X:
   totChannels = 0
   totChange = 0
   for path in CCfw0y.VVvkN7():
    toSave = False
    txt = FFpCvR(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = VVAv8X.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VViVH4(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFzrXb(self, 'No channels in "lamedb" !')
 def VVnI24(self, VVdtUh, title):
  bFiles = CCfw0y.VVvkN7()
  if bFiles: self.VVC7T8(bFiles, title)
  else  : FFycel(VVdtUh, "No bouquets files !", 1500)
 def VVtebu(self, VVdtUh, title):
  self.VVfueI(VVdtUh, BF(self.VVRz0n, title))
 def VVRz0n(self, title, VVdtUh, bName, bPath):
  self.VVC7T8([bPath], title)
 def VVC7T8(self, bFiles, title):
  self.session.open(CCSCNk, barTheme=CCSCNk.VVSu4G
      , titlePrefix = "Renumbering References"
      , fncToRun  = BF(self.VVl7h6, bFiles)
      , VVEStC = BF(self.VVqhgM, title))
 def VVl7h6(self, bFiles, VV2ohY):
  VV2ohY.VVRTV9 = ""
  VV2ohY.VVKDNk("Calculating Reference ...")
  totLines = 0
  patt = r"#SERVICE\s+(?:[A-Fa-f0-9]+[:]){10}(.+\/\/.+)"
  for path in bFiles:
   if fileExists(path):
    lines = FF2WPS(path)
    for line in lines:
     span = iSearch(patt, line)
     if span:
      totLines += 1
  if not VV2ohY or VV2ohY.isCancelled:
   return
  elif not totLines:
   VV2ohY.VVRTV9 = "No IPTV Services !"
   return
  else:
   VV2ohY.VVHJ4P(totLines)
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VV2ohY or VV2ohY.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName  = os.path.basename(path)
    lines  = FF2WPS(path)
    for ndx, line in enumerate(lines):
     if not VV2ohY or VV2ohY.isCancelled:
      return
     if ndx == 0:
      span = iSearch(r"#NAME\s+(.+)", line, IGNORECASE)
      if span:
       bName = span.group(1)
      if VV2ohY:
       VV2ohY.VVKDNk("Processing : %s " % bName)
     span = iSearch(patt, line)
     if span:
      if VV2ohY:
       VV2ohY.VVc1xD(1)
      refCode, startId, startNS = CCrfsB.VVjeuE(rType, CCrfsB.VVgyuu, [], startId, startNS)
      if refCode:
       lines[ndx] = "#SERVICE %s" % (refCode + span.group(1))
       toSave = True
      else:
       if VV2ohY:
        VV2ohY.VVRTV9 = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
 def VVqhgM(self, title, VVPnF9, VVRTV9, threadCounter, threadTotal, threadErr):
  txt  = "Found\t: %d\n"  % threadTotal
  txt += "Changed\t: %d\n" % threadCounter
  if VVRTV9:
   txt += "\n\n%s\n%s" % (FFCzRx("Ended with Error:", VVtz60), VVRTV9)
  self.VViVH4(True, title, txt)
 def VVgfdM(self):
  bFiles = CCfw0y.VVvkN7()
  if not bFiles:
   FFycel(self.VVoLtS, "No bouquets files !", 1500)
   return
  tableRefList = []
  for row in self.VVoLtS.VVGkEL():
   tableRefList.append((row[4], row[5]))
  if not tableRefList:
   FFycel(self.VVoLtS, "Cannot read list", 1500)
   return
  self.session.open(CCSCNk, barTheme=CCSCNk.VVSu4G
      , titlePrefix = "Renumbering References"
      , fncToRun  = BF(self.VVlzhJ, bFiles, tableRefList)
      , VVEStC = BF(self.VVqhgM, "Change Current List References to Unique Codes"))
 def VVlzhJ(self, bFiles, tableRefList, VV2ohY):
  VV2ohY.VVRTV9 = ""
  VV2ohY.VVKDNk("Reading System References ...")
  refLst = CCrfsB.VVaKV4(CCrfsB.VVgyuu, stripRType=True)
  if not VV2ohY or VV2ohY.isCancelled:
   return
  VV2ohY.VVHJ4P(len(tableRefList))
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VV2ohY or VV2ohY.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName = os.path.basename(path)
    txt  = FFpCvR(path)
    span = iSearch(r"#NAME\s+(.+)", txt, IGNORECASE)
    if span:
     bName = span.group(1)
    if not VV2ohY or VV2ohY.isCancelled:
     return
    VV2ohY.VVKDNk("Processing : %s " % bName)
    for ref, url in tableRefList:
     if not VV2ohY or VV2ohY.isCancelled:
      return
     fullRef = ref + url
     if fullRef in txt:
      VV2ohY.VVc1xD(1)
      refCode, startId, startNS = CCrfsB.VVjeuE(rType, CCrfsB.VVgyuu, refLst, startId, startNS)
      if refCode:
       tot = txt.count(fullRef)
       if tot > 0:
        txt = txt.replace(fullRef, refCode + url)
        toSave = True
      else:
       if VV2ohY:
        VV2ohY.VVRTV9 = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
 def VVRT7L(self):
  list = None
  if self.VVoLtS:
   list = []
   for row in self.VVoLtS.VVGkEL():
    list.append(row[4] + row[5])
  files = CCfw0y.VVvkN7()
  totChange = 0
  if files:
   for path in files:
    lines = FF2WPS(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
  self.VViVH4(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VViVH4(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFwQUx()
   if refreshTable and self.VVoLtS:
    VVpn2v = self.VVUkQk()
    if VVpn2v and self.VVoLtS:
     self.VVoLtS.VVkYNn(VVpn2v, self.tableTitle)
     self.VVoLtS.VVOPq5(txt)
   FFtybv(self, txt, title=title)
  else:
   FFuXZg(self, "No changes.")
 @staticmethod
 def VVvkN7(atLeastOne=False, onlyFileName=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVTAUs + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFpCvR(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(os.path.basename(path) if onlyFileName else path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVtEZ5(self, VVoLtS, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFKkPs(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFp5JP(self, fncMode=CCoD37.VVPXCI, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVuGgJ(self, VVoLtS, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VVyxPA(self, VVoLtS, title, txt, colList):
  chName, chUrl = self.VVuGgJ(VVoLtS, colList)
  self.VVvjFh(VVoLtS, chName, chUrl, "localIptv")
 def VVDEiy(self, mode, VVoLtS, colList):
  chName, chUrl, picUrl, refCode = self.VVZebY(mode, colList)
  return chName, chUrl
 def VVkjNJ(self, mode, VVoLtS, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVZebY(mode, colList)
  self.VVvjFh(VVoLtS, chName, chUrl, mode)
 def VVvjFh(self, VVoLtS, chName, chUrl, playerFlag):
  chName = FFQdrB(chName)
  if self.VVV5BR(chName):
   FFycel(VVoLtS, "This is a marker!", 300)
  else:
   FFzW1w(VVoLtS, BF(self.VVr8mv, VVoLtS, chUrl, playerFlag), title="Playing ...")
 def VVr8mv(self, VVoLtS, chUrl, playerFlag):
  FFrvm6(self, chUrl, VViFts=False)
  CCA3uT.VV1gQV(self.session, iptvTableParams=(self, VVoLtS, playerFlag))
 @staticmethod
 def VVV5BR(chName):
  mark = ("--", "__", "==", "##",  "**", str(u"\u2605" * 2))
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVQ3zY(self, VVoLtS, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFmvpz(self)
  if refCode:
   url1 = FFKkPs(origUrl.strip())
   for ndx, row in enumerate(VVoLtS.VVGkEL()):
    if refCode in row[4]:
     tableRow = FFKkPs(row[5].strip())
     if url1 in tableRow or tableRow in url1:
      VVoLtS.VV7qpv(ndx)
      break
   else:
    FFycel(VVoLtS, "No found", 1000)
 def VVWUCX(self, m3uMode):
  lines = self.VVVqEO(3)
  if lines:
   lines.sort()
   VVMVqr = []
   for line in lines:
    VVMVqr.append((line, line))
   if m3uMode == CCfw0y.VVANmR:
    title = "Browse Server from M3U URLs"
    VVdhQt = ("All to Playlist", self.VVePxJ)
   else:
    title = "M3U/M3U8 File Browser"
    VVdhQt = None
   VVmKhE = BF(self.VVDcHa, m3uMode, title)
   VVGygu = self.VV5hU4
   FF7ARM(self, None, title=title, VVMVqr=VVMVqr, width=1200, VVmKhE=VVmKhE, VVGygu=VVGygu, VVYpxU="", VVdhQt=VVdhQt, VVZYdg="#11221122", VVcwfs="#11221122")
 def VVDcHa(self, m3uMode, title, item=None):
  if item:
   VVdtUh, txt, path, ndx = item
   if m3uMode == CCfw0y.VVANmR:
    FFzW1w(VVdtUh, BF(self.VV7KQI, title, path))
   else:
    FFzW1w(VVdtUh, BF(self.VVxoY0, path))
 def VVxoY0(self, path, m3uFilterParam=None, VVoLtS=None):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(path))[0]
  txt = FFpCvR(path)
  span = iSearch(r"#EXTINF:.+\n(.+)\n.+", txt, IGNORECASE)
  if span:
   self.curUrl = span.group(1)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(?:#EXTGRP:(.+)\n)*(http.+)", txt, IGNORECASE)
  groups = []
  mode, words, asPrefix, fTitle = m3uFilterParam or (0, (), False, "")
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, group, url = list(map(str.strip, cols))
   if not group:
    group = self.VVpH5c(propLine, "group-title") or "-"
   if not group == "-" and self.VV3PAZ(group):
    if not chName or self.VVba4j(chName):
     if self.VVrDYS(mode, "", url.lower(), chName, words, "", asPrefix):
      groups.append(group)
  VVpn2v = []
  if groups:
   totAll = 0
   for name, tot in iCounter(groups).items():
    VVpn2v.append((name, str(tot), name))
    totAll += tot
   VVpn2v.sort(key=lambda x: x[0].lower())
   VVpn2v.insert(0, ("ALL", str(totAll), ""))
  if VVpn2v:
   title = "Groups" + m3uFilterParam[3] if m3uFilterParam else ""
   if VVoLtS:
    VVoLtS.VVkYNn(VVpn2v, newTitle=title, VVz586Msg=True)
   else:
    VVNYAK = self.VVJaFb
    VVd479  = ("Select" , BF(self.VVtuEo, path, m3uFilterParam)  , [])
    VVJvWF = ("Filter" , BF(self.VVnYrg, path, m3uFilterParam), [])
    header   = ("Group" , "Total" , "grp" )
    widths   = (85  , 15  , 0  )
    VViqYN  = (LEFT  , CENTER , LEFT )
    FFldB6(self, None, title=title, header=header, VVWsIU=VVpn2v, VViqYN=VViqYN, VVv3Wm=widths, width= 1400, height= 1000, VVHZHw=28, VVd479=VVd479, VVJvWF=VVJvWF, VVNYAK=VVNYAK, lastFindConfigObj=CFG.lastFindIptv
      , VVZYdg="#11110022", VVcwfs="#11110022", VVLuY4="#11110022", VVG27K="#00444400")
  elif VVoLtS:
   FFhcEU(VVoLtS, "Not found !", 1500)
  else:
   self.VVsulA(FFpCvR(path), "", m3uFilterParam)
 def VVtuEo(self, path, m3uFilterParam, VVoLtS, title, txt, colList):
  self.VVsulA(FFpCvR(path), colList[2], m3uFilterParam)
 def VVnYrg(self, path, m3uFilterParam, VVoLtS, title, txt, colList):
  VVMVqr = []
  VVMVqr.append(("All"      , "all"  ))
  VVMVqr.append(FFfdOi("Category"))
  VVMVqr.append(("Live TV"     , "live" ))
  VVMVqr.append(("VOD"      , "vod"  ))
  VVMVqr.append(("Series"     , "series" ))
  VVMVqr.append(("Uncategorised"   , "uncat" ))
  VVMVqr.append(FFfdOi("Media"))
  VVMVqr.append(("Video"     , "video" ))
  VVMVqr.append(("Audio"     , "audio" ))
  VVMVqr.append(FFfdOi("File Type"))
  VVMVqr.append(("MKV"      , "MKV"  ))
  VVMVqr.append(("MP4"      , "MP4"  ))
  VVMVqr.append(("MP3"      , "MP3"  ))
  VVMVqr.append(("AVI"      , "AVI"  ))
  VVMVqr.append(("FLV"      , "FLV"  ))
  filterObj = CCOe8b(self, VVZYdg="#11332244", VVcwfs="#11222244")
  filterObj.VViYlv(VVMVqr, [], BF(self.VVWLLt, VVoLtS, path), inFilterFnc=None)
 def VVWLLt(self, VVoLtS, path, item):
  if item is not None:
   if   item == "all"    : mode, words, fTitle = self.VVi2aW , ""  , ""
   elif item == "live"    : mode, words, fTitle = self.VV3aYJ  , ""  , "Live"
   elif item == "vod"    : mode, words, fTitle = self.VVqbA5  , ""  , "VOD"
   elif item == "series"   : mode, words, fTitle = self.VVOlWy  , ""  , "Series"
   elif item == "uncat"   : mode, words, fTitle = self.VVg1fJ  , ""  , "Uncategorised"
   elif item == "video"   : mode, words, fTitle = self.VV0SAd  , ""  , "Video"
   elif item == "audio"   : mode, words, fTitle = self.VVkftG  , ""  , "Audio"
   elif item == "MKV"    : mode, words, fTitle = self.VVnMD0  , ""  , "MKV"
   elif item == "MP4"    : mode, words, fTitle = self.VVsCB9  , ""  , "MP4"
   elif item == "MP3"    : mode, words, fTitle = self.VV4sjN  , ""  , "MP3"
   elif item == "AVI"    : mode, words, fTitle = self.VVcxdi  , ""  , "AVI"
   elif item == "FLV"    : mode, words, fTitle = self.VVHaaj  , ""  , "FLV"
   elif item.startswith("__w__") : mode, words, fTitle = self.VVYXFs  , item[5:] , item[5:]
   else       : return
   words, asPrefix = CCOe8b.VVjxXj(words)
   if not mode == self.VVi2aW:
    fTitle = "  Filter: %s" % (",".join(words) if words else fTitle)
    if len(fTitle) > 40: fTitle = fTitle[:40] + ".."
    fTitle = FFCzRx(fTitle, VVzv5p)
   m3uFilterParam = (mode, words, asPrefix, fTitle)
   FFzW1w(VVoLtS, BF(self.VVxoY0, path, m3uFilterParam, VVoLtS), title="Filtering ...")
 def VVsulA(self, txt, filterGroup="", m3uFilterParam=None):
  lst   = iFindall(r"#EXTINF:(.+),(.+)\n(?:#EXTGRP:(.+)\n)*(http.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = ("Group : %s" % (filterGroup or "ALL")) + m3uFilterParam[3] if m3uFilterParam else ""
  if lst:
   self.session.open(CCSCNk, barTheme=CCSCNk.VV7KPr
       , titlePrefix = "Reading File Lines", endTitle="Loading channels ..."
       , fncToRun  = BF(self.VVRiQ6, lst, filterGroup, m3uFilterParam)
       , VVEStC = BF(self.VVqJJV, title, bName))
  else:
   self.VVflRE("No valid lines found !", title)
 def VVRiQ6(self, lst, filterGroup, m3uFilterParam, VV2ohY):
  VV2ohY.VVRTV9 = []
  VV2ohY.VVHJ4P(len(lst))
  num = 0
  for cols in lst:
   if not VV2ohY or VV2ohY.isCancelled:
    return
   VV2ohY.VVc1xD(1, True)
   propLine, chName, group, url = list(map(str.strip, cols))
   if not group:
    group = self.VVpH5c(propLine, "group-title") or "-"
   picon = self.VVpH5c(propLine, "tvg-logo")
   if not filterGroup or filterGroup == group:
    skip = False
    if   group and not self.VV3PAZ(group) : skip = True
    elif chName and not self.VVba4j(chName)   : skip = True
    elif m3uFilterParam:
     mode, words, asPrefix, fTitle = m3uFilterParam
     skip = not self.VVrDYS(mode, "", FFKkPs(url).lower(), chName, words, "", asPrefix)
    if not skip and VV2ohY:
     num += 1
     VV2ohY.VVRTV9.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
 def VVqJJV(self, title, bName, VVPnF9, VVRTV9, threadCounter, threadTotal, threadErr):
  if VVRTV9:
   VVNYAK = self.VVJaFb
   VVd479  = ("Select"   , BF(self.VVdvF2, title)   , [])
   VV1Jd7 = (""    , self.VV3R5s        , [])
   VVEXwE = ("Download PIcons", self.VVDjUv       , [])
   VV7J8f = ("Options"  , BF(self.VVoWAN, "m3Ch", "", bName) , [])
   VVJvWF = ("Posters Mode" , BF(self.VVs46a, "m3u", 0)    , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VViqYN  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FFldB6(self, None, title=title, header=header, VVWsIU=VVRTV9, VViqYN=VViqYN, VVv3Wm=widths, VVHZHw=28, VVd479=VVd479, VVNYAK=VVNYAK, VV1Jd7=VV1Jd7, VVEXwE=VVEXwE, VV7J8f=VV7J8f, VVJvWF=VVJvWF, lastFindConfigObj=CFG.lastFindIptv, VV65AN=True, searchCol=1
     , VVZYdg="#0a00192B", VVcwfs="#0a00192B", VVLuY4="#0a00192B", VVG27K="#00000000")
  else:
   self.VVflRE("Not found !", title)
 def VVDjUv(self, VVoLtS, title, txt, colList):
  self.VVHbtJ(VVoLtS, "m3u/m3u8")
 def VVapBy(self, rowNum, url, chName):
  refCode = self.VV0kQN(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FF6XZy(url), chName)
  return chUrl
 def VV0kQN(self, rowNum, url, chName):
  fName = os.path.basename(url)
  catID = "333"
  stID  =  "444"
  if fName:
   num = os.path.splitext(fName)[0]
   if num.isdigit() and int(num) < 0xeeee0000:
    stID = num
  chNum = str(rowNum + 1)
  refCode = self.VV1K8x(catID, stID, chNum)
  return refCode
 def VVpH5c(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VVdvF2(self, Title, VVoLtS, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FFzW1w(VVoLtS, BF(self.VVkaOL, Title, VVoLtS, colList), title="Checking Server ...")
  else:
   self.VV2MvX(VVoLtS, url, chName)
 def VVkaOL(self, title, VVoLtS, colList):
  if not CCGolS.VV1Ewa(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CCEgQt.VVAAns(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VVMVqr = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CCfw0y.VV7Ttk(url, fPath)
     VVMVqr.append((resol, fullUrl))
    if VVMVqr:
     if len(VVMVqr) > 1:
      FF7ARM(self, BF(self.VVDn2Z, VVoLtS, chName), VVMVqr=VVMVqr, title="Resolution", VVy9CS=True, VVMTvd=True)
     else:
      self.VV2MvX(VVoLtS, VVMVqr[0][1], chName)
    else:
     span = iSearch(r"(http.+)", txt, IGNORECASE)
     if span:
      self.VV2MvX(VVoLtS, span.group(1), chName)
     else:
      span = iSearch(r"#EXT-X-STREAM-INF.*\n(.+)", txt, IGNORECASE)
      if span:
       fullUrl = CCfw0y.VV7Ttk(url, span.group(1))
       self.VV2MvX(VVoLtS, fullUrl, chName)
      else:
       self.VVvL0a("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VVsulA(txt, filterGroup="")
      return
    self.VV2MvX(VVoLtS, url, chName)
   else:
    self.VVflRE("Cannot process this channel !", title)
  else:
   self.VVflRE(err, title)
 def VVDn2Z(self, VVoLtS, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VV2MvX(VVoLtS, resolUrl, chName)
 def VV2MvX(self, VVoLtS, url, chName):
  FFzW1w(VVoLtS, BF(self.VVQUrR, VVoLtS, url, chName), title="Playing ...")
 def VVQUrR(self, VVoLtS, url, chName):
  chUrl = self.VVapBy(VVoLtS.VVqeSa(), url, chName)
  FFrvm6(self, chUrl, VViFts=False)
  CCA3uT.VV1gQV(self.session, iptvTableParams=(self, VVoLtS, "m3u/m3u8"))
 def VVfvso(self, VVoLtS, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VVapBy(VVoLtS.VVqeSa(), url, chName)
  return chName, chUrl
 def VV3R5s(self, VVoLtS, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FFp5JP(self, fncMode=CCoD37.VVPXCI, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VVflRE(self, err, title):
  FFzrXb(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VVJaFb(self, VVoLtS):
  if self.m3uOrM3u8File:
   self.close()
  VVoLtS.cancel()
 def VVePxJ(self, selectionObj, item=None):
  FFzW1w(selectionObj, BF(self.VV4wKx, selectionObj, item))
 def VV4wKx(self, selectionObj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(selectionObj.VVMVqr):
    path = item[1]
    if fileExists(path):
     enc = CCscRA.VVf2n6(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = CCfw0y.VVlCRU(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CCfw0y.VVmtt9()
    pListF = "%sPlaylist_%s.txt" % (path, FF4rM4())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(selectionObj.VVMVqr)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFtybv(self, txt, title=title)
   else:
    FFzrXb(self, "Could not obtain URLs from this file list !", title=title)
 def VVHYUH(self, mode):
  if   mode == 1: title, okFnc = "Select Playlist File", self.VVk4a4
  elif mode == 2: title, okFnc = "Select Portal File"  , self.VVDjl3
  lines = self.VVVqEO(mode)
  if lines:
   lines.sort()
   VVMVqr = []
   for line in lines:
    VVMVqr.append((FFCzRx(line, VV61JF) if "Bookmarks" in line else line, line))
   VVGygu = self.VV5hU4
   FF7ARM(self, None, title=title, VVMVqr=VVMVqr, width=1200, VVmKhE=okFnc, VVGygu=VVGygu, VVYpxU="")
 def VV5hU4(self, VVdtUh, txt, ref, ndx):
  txt = ref
  sz = FFPLWs(ref)
  if sz > 0:
   txt += "\n\nSize: %s" % CCUGPF.VVuy4U(sz)
  FFtybv(self, txt, title="File Path")
 def VVk4a4(self, item=None):
  if item:
   VVdtUh, txt, path, ndx = item
   FFzW1w(VVdtUh, BF(self.VVqoxO, VVdtUh, path), title="Processing File ...")
 def VVqoxO(self, VVQTZr, path):
  enc = CCscRA.VVf2n6(path, self)
  if enc == -1:
   return
  VVpn2v = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0].strip("'\"")
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FF5DjF(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCfw0y.VVGYws(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VVpn2v:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(list(filter(None, [item[5], item[0]])))
     num += 1
     VVpn2v.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VVpn2v:
   title = "Playlist File : %s" % os.path.basename(path)
   VVd479  = ("Start"    , BF(self.VVbuLf, "Playlist File")      , [])
   VVKDDh = ("Home Menu"   , FFsago             , [])
   VVEXwE = ("Download M3U File" , self.VV2qJ5         , [])
   VV7J8f = ("Edit File"   , BF(self.VVE86b, path)        , [])
   VVJvWF = ("Check & Filter"  , BF(self.VVFadr, VVQTZr, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VViqYN  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FFldB6(self, None, title=title, header=header, VVWsIU=VVpn2v, VViqYN=VViqYN, VVv3Wm=widths, VVHZHw=26, VVd479=VVd479, VVKDDh=VVKDDh, VVJvWF=VVJvWF, VVEXwE=VVEXwE, VV7J8f=VV7J8f, VVZYdg="#11001116", VVcwfs="#11001116", VVLuY4="#11001116", VVG27K="#00003635", VVQ9hc="#0a333333", VVGpiI="#11331100", VV65AN=True, searchCol=2, lastFindConfigObj=CFG.lastFindServers)
  else:
   FFzrXb(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VV2qJ5(self, VVoLtS, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FFo4dm(self, BF(FFzW1w, VVoLtS, BF(self.VVM37h, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVM37h(self, title, url):
  path, err = FFOecp(url, "ajp_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FFzrXb(self, err, title=errTitle)
  elif fileExists(path):
   txt = FFpCvR(path)
   if '{"user_info":{"auth":0}}' in txt:
    FFnPMX(path)
    FFzrXb(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    FFnPMX(path)
    FFzrXb(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CCfw0y.VVmtt9() + fName
    FFgSm7("mv -f '%s' '%s'" % (path, newPath))
    if fileExists(newPath):
     path = newPath
    FFuXZg(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FFzrXb(self, "Could not download the M3U file!", title=errTitle)
 def VVbuLf(self, Title, VVoLtS, title, txt, colList):
  url = colList[6]
  FFzW1w(VVoLtS, BF(self.VVgawD, Title, url), title="Checking Server ...")
 def VVE86b(self, path, VVoLtS, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCH94c(self, path, VVEStC=BF(self.VVyDPL, VVoLtS), curRowNum=rowNum)
  else    : FFZ5Ys(self, path)
 def VVyDPL(self, VVoLtS, fileChanged):
  if fileChanged:
   VVoLtS.cancel()
 def VVV0ND(self, title):
  curChName = self.VVoLtS.VVh7wm(1)
  FFBgSg(self, BF(self.VVRy5N, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVRy5N(self, title, name):
  if name:
   VVAv8X, err = CCh3Pq.VVM6i7(self, CCh3Pq.VVI8wC, VVkOYc=False, VVLya0=False)
   list = []
   if VVAv8X:
    name = self.VV5ZIs(name)
    ratio = "1"
    for item in VVAv8X:
     if name in item[0].lower():
      list.append((item[0], FFhPna(item[2]), item[3], ratio))
   if list : self.VVIVqO(list, title)
   else : FFzrXb(self, "Not found:\n\n%s" % name, title=title)
 def VV0Bsj(self, title):
  curChName = self.VVoLtS.VVh7wm(1)
  self.session.open(CCSCNk, barTheme=CCSCNk.VV7KPr
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVHEr9
      , VVEStC = BF(self.VVhe0K, title, curChName))
 def VVHEr9(self, VV2ohY):
  curChName = self.VVoLtS.VVh7wm(1)
  VVAv8X, err = CCh3Pq.VVM6i7(self, CCh3Pq.VVPia1, VVkOYc=False, VVLya0=False)
  if not VVAv8X or not VV2ohY or VV2ohY.isCancelled:
   return
  VV2ohY.VVRTV9 = []
  VV2ohY.VVHJ4P(len(VVAv8X))
  curCh = self.VV5ZIs(curChName)
  for refCode in VVAv8X:
   chName, sat, inDB = VVAv8X.get(refCode, ("", "", 0))
   ratio = CCxrlm.VV90Gn(chName.lower(), curCh)
   if not VV2ohY or VV2ohY.isCancelled:
    return
   VV2ohY.VVc1xD(1, True)
   if VV2ohY and ratio > 50:
    VV2ohY.VVRTV9.append((chName, FFhPna(sat), refCode.replace("_", ":"), str(ratio)))
 def VVhe0K(self, title, curChName, VVPnF9, VVRTV9, threadCounter, threadTotal, threadErr):
  if VVRTV9: self.VVIVqO(VVRTV9, title)
  elif VVPnF9: FFzrXb(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVIVqO(self, VVpn2v, title):
  curChName = self.VVoLtS.VVh7wm(1)
  VVJ2Pt = self.VVoLtS.VVh7wm(4)
  curUrl  = self.VVoLtS.VVh7wm(5)
  VVpn2v.sort(key=lambda x: (100-int(x[3]), x[0].lower()))
  VVd479  = ("Share Sat/C/T Ref.", BF(self.VVfDRz, title, curChName, VVJ2Pt, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFldB6(self, None, title=title, header=header, VVWsIU=VVpn2v, VVv3Wm=widths, VVHZHw=26, VVd479=VVd479, VVZYdg="#0a00112B", VVcwfs="#0a001126", VVLuY4="#0a001126", VVG27K="#00000000")
 def VVfDRz(self, newtitle, curChName, VVJ2Pt, curUrl, VVoLtS, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, VVJ2Pt, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFo4dm(self.VVoLtS, BF(FFzW1w, self.VVoLtS, BF(self.VVwSVK, VVoLtS, data)), ques, title=newtitle, VVxcAw=True)
 def VVwSVK(self, VVoLtS, data):
  VVoLtS.cancel()
  title, curChName, VVJ2Pt, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  VVJ2Pt = VVJ2Pt.strip()
  newRefCode = newRefCode.strip()
  if not VVJ2Pt.endswith(":") : VVJ2Pt += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", VVJ2Pt, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = VVJ2Pt + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in CCfw0y.VVvkN7():
    txt = FFpCvR(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFwQUx()
    newRow = []
    for i in range(6):
     newRow.append(self.VVoLtS.VVh7wm(i))
    newRow[4] = newRefCode
    done = self.VVoLtS.VVlhah(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FFA9HA(BF(FFuXZg , self, resTxt, title=title))
  elif resErr: FFA9HA(BF(FFzrXb, self, resErr, title=title))
 def VVFadr(self, VVQTZr, path, VVoLtS, title, txt, colList):
  self.session.open(CCSCNk, barTheme=CCSCNk.VVSu4G
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = BF(self.VVDymq, VVoLtS)
      , VVEStC = BF(self.VVppOE, VVQTZr, path, VVoLtS))
 def VVDymq(self, VVoLtS, VV2ohY):
  VV2ohY.VVHJ4P(VVoLtS.VVaeaf())
  VV2ohY.VVRTV9 = []
  for row in VVoLtS.VVGkEL():
   if not VV2ohY or VV2ohY.isCancelled:
    return
   VV2ohY.VVc1xD(1, True)
   qUrl = self.VVnBsR(self.VVYBoz, row[6])
   txt, err = self.VVtidF(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVEl8A(item, "auth") == "0":
       VV2ohY.VVRTV9.append(qUrl)
    except:
     pass
 def VVppOE(self, VVQTZr, path, VVoLtS, VVPnF9, VVRTV9, threadCounter, threadTotal, threadErr):
  if VVPnF9:
   list = VVRTV9
   title = "Authorized Servers"
   if list:
    totChk = VVoLtS.VVaeaf()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FF4rM4()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVHYUH(1)
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FFCzRx(str(totAuth), VVXF4f)
     txt += "%s\n\n%s"    %  (FFCzRx("Result File:", VV61JF), newPath)
     FFtybv(self, txt, title=title)
     VVoLtS.close()
     VVQTZr.close()
    else:
     FFuXZg(self, "All URLs are authorized.", title=title)
   else:
    FFzrXb(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVtidF(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   resCode = res.code
   if resCode == 200 :
    cont = res.headers.get("Content-Type")
    if cont:
     if not any(x in cont for x in ("/json", "/ld+json", "text/html")):
      return "", "Unexpected server data type ( %s )" % cont
     res = res.read().decode("UTF-8")
     if res:
      if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server."
      else           : return res, ""
     else:
      return "", "No data from server."
    else:
     return "", "No data received from server"
   elif resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", err
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVGYws(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVKCk4(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None, justRetDotExt=False):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) >= 2:
   username = parts[0]
   password = parts[1]
   if len(parts) > 2:
    tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  streamId, dotExt = os.path.splitext(fileName)
  ext = dotExt[1:]
  if justRetDotExt:
   return dotExt
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    tDict = CC87Iy.VVbM6s()
    if   ext in list(tDict["mov"]): return "vid"
    elif ext in list(tDict["mus"]): return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 @staticmethod
 def VVDOzu(decodedUrl):
  return CCfw0y.VVKCk4(decodedUrl, justRetDotExt=True)
 def VVnBsR(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVGYws(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVYBoz   : return "%s"            % url
  elif mode == self.VV1LVs   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVgfJL   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVFsH1  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVKPA8  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVDHPw : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVZsQj   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVJwAe    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VV4xmt  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVLGGT : return "%s&action=get_live_streams"      % url
  elif mode == self.VVrfk1  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VVEl8A(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFgCM6(int(val))
    elif is_base64 : val = FFmDiU(val)
    elif isToHHMMSS : val = FFRTnP(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VV7KQI(self, title, path):
  if fileExists(path):
   enc = CCscRA.VVf2n6(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = CCfw0y.VVlCRU(line)
     if qUrl:
      break
   if qUrl : self.VVgawD(title, qUrl)
   else : FFzrXb(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FFzrXb(self, "Cannot open file :\n\n%s" % path, title=title)
 def VV8Hpw(self):
  title = "Current Channel Server"
  qUrl, decodedUrl, iptvRef = CCfw0y.VVdDss(self)
  if qUrl or "chCode" in iptvRef:
   p = CCEgQt()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVfC9q(decodedUrl)
   if valid:
    self.VVmEzC(self, host, mac)
    return
   elif qUrl:
    FFzW1w(self, BF(self.VVgawD, title, qUrl), title="Checking Server ...")
    return
  FFzrXb(self, "Error in current channel URL !", title=title)
 @staticmethod
 def VVdDss(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFmvpz(SELF)
  qUrl = CCfw0y.VVlCRU(decodedUrl)
  return qUrl, decodedUrl, iptvRef
 @staticmethod
 def VVlCRU(url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("live/") : path = path[5:]
  elif path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) == 3 and len(parts[0]) > 1: return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else         : return ""
 def VVgawD(self, title, url):
  self.curUrl = url
  self.VVXBtWData = {}
  qUrl = self.VVnBsR(self.VVYBoz, url)
  txt, err = self.VVtidF(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVXBtWData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVXBtWData["username"    ] = self.VVEl8A(item, "username"        )
    self.VVXBtWData["password"    ] = self.VVEl8A(item, "password"        )
    self.VVXBtWData["message"    ] = self.VVEl8A(item, "message"        )
    self.VVXBtWData["auth"     ] = self.VVEl8A(item, "auth"         )
    self.VVXBtWData["status"    ] = self.VVEl8A(item, "status"        )
    self.VVXBtWData["exp_date"    ] = self.VVEl8A(item, "exp_date"    , isDate=True )
    self.VVXBtWData["is_trial"    ] = self.VVEl8A(item, "is_trial"        )
    self.VVXBtWData["active_cons"   ] = self.VVEl8A(item, "active_cons"       )
    self.VVXBtWData["created_at"   ] = self.VVEl8A(item, "created_at"   , isDate=True )
    self.VVXBtWData["max_connections"  ] = self.VVEl8A(item, "max_connections"      )
    self.VVXBtWData["allowed_output_formats"] = self.VVEl8A(item, "allowed_output_formats"    )
    key = "allowed_output_formats"
    val = item.get(key, None)
    if isinstance(val, list):
     self.VVXBtWData[key] = " , ".join(val)
    item = tDict["server_info"]
    self.VVXBtWData["url"    ] = self.VVEl8A(item, "url"        )
    self.VVXBtWData["port"    ] = self.VVEl8A(item, "port"        )
    self.VVXBtWData["https_port"  ] = self.VVEl8A(item, "https_port"      )
    self.VVXBtWData["server_protocol" ] = self.VVEl8A(item, "server_protocol"     )
    self.VVXBtWData["rtmp_port"   ] = self.VVEl8A(item, "rtmp_port"       )
    self.VVXBtWData["timezone"   ] = self.VVEl8A(item, "timezone"       )
    self.VVXBtWData["timestamp_now"  ] = self.VVEl8A(item, "timestamp_now"  , isDate=True )
    self.VVXBtWData["time_now"   ] = self.VVEl8A(item, "time_now"       )
    VVMVqr  = self.VV5jeg(True)
    VVmKhE = self.VVdSEn
    VVGygu = self.VVeDSe
    VVRZ74 = ("Home Menu", FFsago)
    VV0afn= ("Add to Menu", BF(CCfw0y.VV427a, self, False, self.VVXBtWData["playListURL"]))
    VVdhQt = ("Bookmark Server", BF(CCfw0y.VVMXi1, self, False, self.VVXBtWData["playListURL"]))
    VVdtUh = FF7ARM(self, None, title="IPTV Server Resources", VVMVqr=VVMVqr, VVmKhE=VVmKhE, VVGygu=VVGygu, VVRZ74=VVRZ74, VV0afn=VV0afn, VVdhQt=VVdhQt)
    self.VVyeLH(VVdtUh)
   else:
    err = "Could not get data from server !"
  if err:
   FFzrXb(self, err, title=title)
  FFycel(self)
 def VVdSEn(self, item=None):
  if item:
   VVdtUh, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FFzW1w(VVdtUh, BF(self.VVWu5D, self.VV1LVs  , title=title), title=wTxt)
   elif ref == "vod"   : FFzW1w(VVdtUh, BF(self.VVWu5D, self.VVgfJL  , title=title), title=wTxt)
   elif ref == "series"  : FFzW1w(VVdtUh, BF(self.VVWu5D, self.VVFsH1 , title=title), title=wTxt)
   elif ref == "catchup"  : FFzW1w(VVdtUh, BF(self.VVWu5D, self.VVKPA8 , title=title), title=wTxt)
   elif ref == "accountInfo" : FFzW1w(VVdtUh, BF(self.VVSRif           , title=title), title=wTxt)
 def VVyeLH(self, VVdtUh):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFmvpz(self)
  if   FFkUBK(decodedUrl) : VVdtUh.VVT53N(1)
  elif FFtJft(decodedUrl): VVdtUh.VVT53N(2)
 def VVeDSe(self, VVdtUh, txt, ref, ndx):
  FFzW1w(VVdtUh, self.VVJINF)
 def VVJINF(self):
  txt = self.curUrl
  if VVncAm:
   ver, err = self.VVpMtS(self.VVEB3G())
   txt += "\n\n"
   txt += "Original\t: %s\n" % self.curUrl
   txt += "Modified\t: %s\n" % self.VVrHOQ
   txt += "PHP\t: %s\n"  % self.VVzCbv
   txt += "Extra\t: %s\n"  % {2:"Big", 3:"Sml"}.get(self.VVhNXl, "-")
   txt += "Version\t: %s"  % (ver or err)
  FFtybv(self, txt, title="Current Server URL")
 def VVSRif(self, title):
  rows = []
  for key, val in self.VVXBtWData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.VV4VS1
   else:
    num, part = "1", self.VVv7iM
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows.sort(key=lambda x: (x[0], x[2]))
  VVKDDh  = ("Home Menu", FFsago, [])
  VVEXwE  = None
  if VVncAm:
   VVEXwE = ("Get JS" , BF(self.VVrf1p, "/".join(self.VVXBtWData["playListURL"].split("/")[:-1])), [])
  header    = ("Num", "User/Server" , "Subject" , "Value" )
  widths    = (0 , 15   , 35  , 50  )
  FFldB6(self, None, title=title, width=1200, header=header, VVWsIU=rows, VVv3Wm=widths, VVHZHw=26, VVKDDh=VVKDDh, VVEXwE=VVEXwE, VVZYdg="#0a00292B", VVcwfs="#0a002126", VVLuY4="#0a002126", VVG27K="#00000000", searchCol=2)
 def VVGCTj(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    if mode in (self.VVZsQj, self.VVrfk1):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVEl8A(item, "num"         )
      name     = self.VVEl8A(item, "name"        )
      stream_id    = self.VVEl8A(item, "stream_id"       )
      stream_icon    = self.VVEl8A(item, "stream_icon"       )
      epg_channel_id   = self.VVEl8A(item, "epg_channel_id"      )
      added     = self.VVEl8A(item, "added"    , isDate=True )
      is_adult    = self.VVEl8A(item, "is_adult"       )
      category_id    = self.VVEl8A(item, "category_id"       )
      tv_archive    = self.VVEl8A(item, "tv_archive"       )
      direct_source   = self.VVEl8A(item, "direct_source"      )
      tv_archive_duration  = self.VVEl8A(item, "tv_archive_duration"     )
      name = self.VVba4j(name, is_adult)
      if name:
       if mode == self.VVZsQj or mode == self.VVrfk1 and tv_archive == "1":
        hasPicon = "Yes" if stream_icon else ""
        catchupTxt = ""
        if tv_archive == "1":
         catchupTxt = "Yes"
         if tv_archive_duration:
          if tv_archive_duration == "1" : catchupTxt = "1 day"
          else       : catchupTxt = "%s days" % tv_archive_duration
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source))
    elif mode == self.VVJwAe:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVEl8A(item, "num"         )
      name    = self.VVEl8A(item, "name"        )
      stream_id   = self.VVEl8A(item, "stream_id"       )
      stream_icon   = self.VVEl8A(item, "stream_icon"       )
      added    = self.VVEl8A(item, "added"    , isDate=True )
      is_adult   = self.VVEl8A(item, "is_adult"       )
      category_id   = self.VVEl8A(item, "category_id"       )
      container_extension = self.VVEl8A(item, "container_extension"     ) or "mp4"
      name = self.VVba4j(name, is_adult)
      if name:
       isPicon = "Yes" if stream_icon else ""
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon))
    elif mode == self.VV4xmt:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVEl8A(item, "num"        )
      name    = self.VVEl8A(item, "name"       )
      series_id   = self.VVEl8A(item, "series_id"      )
      cover    = self.VVEl8A(item, "cover"       )
      genre    = self.VVEl8A(item, "genre"       )
      episode_run_time = self.VVEl8A(item, "episode_run_time"    )
      category_id   = self.VVEl8A(item, "category_id"      )
      container_extension = self.VVEl8A(item, "container_extension"    ) or "mp4"
      name = self.VVba4j(name)
      if name:
       isPicon = "Yes" if cover else ""
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover, isPicon))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVWu5D(self, mode, title):
  cList, err = self.VVOpe3(mode)
  if cList and mode == self.VVKPA8:
   cList = self.VVmhqu(cList)
  if err:
   FFzrXb(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVZYdg, VVcwfs, VVLuY4, VVG27K = self.VVc2aF(mode)
   mName = self.VVAzis(mode)
   if   mode == self.VV1LVs  : fMode = self.VVZsQj
   elif mode == self.VVgfJL  : fMode = self.VVJwAe
   elif mode == self.VVFsH1 : fMode = self.VV4xmt
   elif mode == self.VVKPA8 : fMode = self.VVrfk1
   if mode == self.VVKPA8:
    VV7J8f = None
    VVJvWF = None
   else:
    VV7J8f = ("Find in %s" % mName , BF(self.VVSaGj, fMode, True) , [])
    VVJvWF = ("Find in Selected" , BF(self.VVSaGj, fMode, False) , [])
   VVd479   = ("Show List"   , BF(self.VV7d2O, mode)  , [])
   VVKDDh  = ("Home Menu"   , FFsago         , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFldB6(self, None, title=title, width=1200, header=header, VVWsIU=cList, VVv3Wm=widths, VVHZHw=30, VVKDDh=VVKDDh, VV7J8f=VV7J8f, VVJvWF=VVJvWF, VVd479=VVd479, VVZYdg=VVZYdg, VVcwfs=VVcwfs, VVLuY4=VVLuY4, VVG27K=VVG27K, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFzrXb(self, "No list from server !", title=title)
  FFycel(self)
 def VVOpe3(self, mode):
  qUrl  = self.VVnBsR(mode, self.VVXBtWData["playListURL"])
  txt, err = self.VVtidF(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    for item in tDict:
     category_id  = self.VVEl8A(item, "category_id"  )
     category_name = self.VVEl8A(item, "category_name" )
     parent_id  = self.VVEl8A(item, "parent_id"  )
     category_name = self.VV3PAZ(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVmhqu(self, catList):
  mode  = self.VVrfk1
  qUrl  = self.VVnBsR(mode, self.VVXBtWData["playListURL"])
  txt, err = self.VVtidF(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VVGCTj(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VV7d2O(self, mode, VVoLtS, title, txt, colList):
  title = colList[1]
  FFzW1w(VVoLtS, BF(self.VVGzPX, mode, VVoLtS, title, txt, colList), title="Downloading ...")
 def VVGzPX(self, mode, VVoLtS, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVAzis(mode) + " : "+ bName
  if   mode == self.VV1LVs  : mode = self.VVZsQj
  elif mode == self.VVgfJL  : mode = self.VVJwAe
  elif mode == self.VVFsH1 : mode = self.VV4xmt
  elif mode == self.VVKPA8 : mode = self.VVrfk1
  qUrl  = self.VVnBsR(mode, self.VVXBtWData["playListURL"], catID)
  txt, err = self.VVtidF(qUrl)
  list  = []
  if not err and mode in (self.VVZsQj, self.VVJwAe, self.VV4xmt, self.VVrfk1):
   list, err = self.VVGCTj(mode, txt)
  if err:
   FFzrXb(self, err, title=title)
  elif list:
   VVKDDh  = ("Home Menu"   , FFsago            , [])
   if mode in (self.VVZsQj, self.VVrfk1):
    VVZYdg, VVcwfs, VVLuY4, VVG27K = self.VVc2aF(mode)
    VV1Jd7 = (""     , BF(self.VVySyb, mode)      , [])
    VVEXwE = ("Download Options" , BF(self.VVZoWP, mode, "", "")   , [])
    VV7J8f = ("Options"   , BF(self.VVoWAN, "lv", mode, bName)   , [])
    VVJvWF = ("Posters Mode"  , BF(self.VVs46a, mode, False)     , [])
    if mode == self.VVZsQj:
     VVd479 = ("Play"    , BF(self.VVkjNJ, mode)       , [])
    else:
     VVd479 = ("Programs"   , BF(self.VVYRku, mode, bName) , [])
   elif mode == self.VVJwAe:
    VVZYdg, VVcwfs, VVLuY4, VVG27K = self.VVc2aF(mode)
    VVd479  = ("Play"    , BF(self.VVkjNJ, mode)       , [])
    VV1Jd7 = (""     , BF(self.VVySyb, mode)      , [])
    VVEXwE = ("Download Options" , BF(self.VVZoWP, mode, "v", "")   , [])
    VV7J8f = ("Options"   , BF(self.VVoWAN, "v", mode, bName)   , [])
    VVJvWF = ("Posters Mode"  , BF(self.VVs46a, mode, False)     , [])
   elif mode == self.VV4xmt:
    VVZYdg, VVcwfs, VVLuY4, VVG27K = self.VVc2aF("series2")
    VVd479  = ("Show Seasons"  , BF(self.VVpdo1, mode)       , [])
    VV1Jd7 = (""     , BF(self.VVpyH7, mode)     , [])
    VVEXwE = None
    VV7J8f = None
    VVJvWF = ("Posters Mode"  , BF(self.VVs46a, mode, True)      , [])
   header, widths, VViqYN = self.VVpUeB(mode)
   FFldB6(self, None, title=title, header=header, VVWsIU=list, VViqYN=VViqYN, VVv3Wm=widths, VVHZHw=26, VVd479=VVd479, VVKDDh=VVKDDh, VVEXwE=VVEXwE, VV7J8f=VV7J8f, VVJvWF=VVJvWF, lastFindConfigObj=CFG.lastFindIptv, VV1Jd7=VV1Jd7, VVZYdg=VVZYdg, VVcwfs=VVcwfs, VVLuY4=VVLuY4, VVG27K=VVG27K, VV65AN=True, searchCol=1)
  else:
   FFzrXb(self, "No Channels found !", title=title)
  FFycel(self)
 def VVpUeB(self, mode):
  if mode in (self.VVZsQj, self.VVrfk1):
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult", "Logo", "Catch-up", "Link")
   widths   = (8  , 55  , 0   , 0   , 0  , 22  , 0   , 0   , 6  , 9   , 0.03 )
   VViqYN  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER , CENTER, CENTER , CENTER)
  elif mode == self.VVJwAe:
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" , "Logo")
   widths   = (8  , 62  , 0   , 0   , 0  , 24  , 0   , 0  , 6  )
   VViqYN  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER, CENTER)
  elif mode == self.VV4xmt:
   header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" , "Logo" )
   widths   = (8  , 56  , 0   , 0   , 30  , 0  , 0  , 0   , 6   )
   VViqYN  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  , CENTER )
  return header, widths, VViqYN
 def VVYRku(self, mode, bName, VVoLtS, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VVXBtWData["playListURL"]
  ok_fnc  = BF(self.VV29u0, hostUrl, chName, catId, streamId)
  FFzW1w(VVoLtS, BF(CCfw0y.VV2a0V, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VV29u0(self, chUrl, chName, catId, streamId, VVoLtS, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCfw0y.VVGYws(chUrl)
   chNum = "333"
   refCode = CCfw0y.VV1K8x(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFrvm6(self, chUrl, VViFts=False)
   CCA3uT.VV1gQV(self.session)
  else:
   FFzrXb(self, "Incorrect Timestamp", pTitle)
 def VVpdo1(self, mode, VVoLtS, title, txt, colList):
  title = colList[1]
  FFzW1w(VVoLtS, BF(self.VVjn5l, mode, VVoLtS, title, txt, colList), title="Downloading ...")
 def VVjn5l(self, mode, VVoLtS, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVnBsR(self.VVDHPw, self.VVXBtWData["playListURL"], series_id)
  txt, err = self.VVtidF(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVEl8A(tDict["info"], "name"   )
      category_id = self.VVEl8A(tDict["info"], "category_id" )
      icon  = self.VVEl8A(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVEl8A(EP, "id"     )
        episode_num   = self.VVEl8A(EP, "episode_num"   )
        epTitle    = self.VVEl8A(EP, "title"     )
        container_extension = self.VVEl8A(EP, "container_extension" )
        seasonNum   = self.VVEl8A(EP, "season"    )
        epTitle = self.VVba4j(epTitle)
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFzrXb(self, err, title=title)
  elif list:
   VVKDDh = ("Home Menu"   , FFsago          , [])
   VVEXwE = ("Download Options" , BF(self.VVZoWP, mode, "s", title), [])
   VV7J8f = ("Options"   , BF(self.VVoWAN, "s", mode, title) , [])
   VVJvWF = ("Posters Mode"  , BF(self.VVs46a, mode, False)   , [])
   VV1Jd7 = (""     , BF(self.VVySyb, mode)    , [])
   VVd479  = ("Play"    , BF(self.VVkjNJ, mode)     , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VViqYN  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFldB6(self, None, title=title, header=header, VVWsIU=list, VViqYN=VViqYN, VVv3Wm=widths, VVHZHw=26, VVKDDh=VVKDDh, VVEXwE=VVEXwE, VVd479=VVd479, VV1Jd7=VV1Jd7, VV7J8f=VV7J8f, VVJvWF=VVJvWF, lastFindConfigObj=CFG.lastFindIptv, VVZYdg="#0a00292B", VVcwfs="#0a002126", VVLuY4="#0a002126", VVG27K="#00000000")
  else:
   FFzrXb(self, "No Channels found !", title=title)
  FFycel(self)
 def VVSaGj(self, mode, isAll, VVoLtS, title, txt, colList):
  onlyCatID = None if isAll else colList[1]
  VVMVqr = []
  VVMVqr.append(("Keyboard"  , "manualEntry"))
  VVMVqr.append(("From Filter" , "fromFilter"))
  FF7ARM(self, BF(self.VVMlVz, VVoLtS, mode, onlyCatID), title="Input Type", VVMVqr=VVMVqr, width=400)
 def VVMlVz(self, VVoLtS, mode, onlyCatID, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFBgSg(self, BF(self.VVKbcJ, VVoLtS, mode, onlyCatID), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCOe8b(self)
    filterObj.VVpQGc(BF(self.VVKbcJ, VVoLtS, mode, onlyCatID))
 def VVKbcJ(self, VVoLtS, mode, onlyCatID, item):
  if not item is None:
   title = "Find in names"
   words = None
   toFind = item.strip()
   FF2tHk(CFG.lastFindIptv, toFind)
   if toFind:
    words, asPrefix = CCOe8b.VVjxXj(toFind)
    if words:
     if len(words) == 1 and len(words[0]) < 3:
      FFzrXb(self, "Enter at least 3 characters.", title=title)
      return
     else:
      for word in words:
       if len(word) < 3:
        FFzrXb(self, "All words must be at least 3 characters !", title=title)
        return
     if CFG.hideIptvServerAdultWords.getValue() and self.VVlVjJ(words):
      FFzrXb(self, self.VVFpjk(), title="Find: %s" % " , ".join(words))
      return
     else:
      self.session.open(CCSCNk, barTheme=CCSCNk.VV7KPr
          , titlePrefix = "Searching for:%s" % toFind[:15]
          , fncToRun  = BF(self.VVUYJ1, VVoLtS, mode, onlyCatID, title, words, toFind, asPrefix)
          , VVEStC = BF(self.VVfQqs, mode, toFind, title))
   if not words:
    FFycel(VVoLtS, "Nothing to find !", 1500)
 def VVUYJ1(self, VVoLtS, mode, onlyCatID, title, words, toFind, asPrefix, VV2ohY):
  VV2ohY.VVHJ4P(VVoLtS.VVgRm7() if onlyCatID is None else 1)
  VV2ohY.VVRTV9 = []
  for row in VVoLtS.VVGkEL():
   catName = row[0]
   catID = row[1]
   if not onlyCatID is None and not catID == onlyCatID:
    continue
   if not VV2ohY or VV2ohY.isCancelled:
    return
   VV2ohY.VVc1xD(1)
   VV2ohY.VVjFqZ(catName)
   qUrl  = self.VVnBsR(mode, self.VVXBtWData["playListURL"], catID)
   txt, err = self.VVtidF(qUrl)
   if not err:
    tList, err = self.VVGCTj(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = self.VVba4j(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if not VV2ohY or VV2ohY.isCancelled:
        return
       VV2ohY.VVRTV9.append(item)
       VV2ohY.VVjFqZ(catName)
 def VVfQqs(self, mode, toFind, title, VVPnF9, VVRTV9, threadCounter, threadTotal, threadErr):
  if VVRTV9:
   title = self.VVJNVW(mode, toFind)
   if mode == self.VVZsQj or mode == self.VVJwAe:
    if mode == self.VVJwAe : typ = "v"
    else          : typ = ""
    bName   = CCfw0y.VV02WJ(toFind)
    VVd479  = ("Play"     , BF(self.VVkjNJ, mode)     , [])
    VVEXwE = ("Download Options" , BF(self.VVZoWP, mode, typ, "") , [])
    VV7J8f = ("Options"   , BF(self.VVoWAN, "fnd", mode, bName), [])
    VVJvWF = ("Posters Mode"  , BF(self.VVs46a, mode, False)   , [])
    VV1Jd7 = (""     , BF(self.VVySyb, mode)    , [])
   elif mode == self.VV4xmt:
    VVd479  = ("Show Seasons"  , BF(self.VVpdo1, mode)     , [])
    VV7J8f = None
    VVEXwE = None
    VVJvWF = ("Posters Mode"  , BF(self.VVs46a, mode, True)    , [])
    VV1Jd7 = (""     , BF(self.VVpyH7, mode)   , [])
   VVKDDh  = ("Home Menu"   , FFsago          , [])
   header, widths, VViqYN = self.VVpUeB(mode)
   VVoLtS = FFldB6(self, None, title=title, header=header, VVWsIU=VVRTV9, VViqYN=VViqYN, VVv3Wm=widths, VVHZHw=26, VVd479=VVd479, VVKDDh=VVKDDh, VVEXwE=VVEXwE, VV7J8f=VV7J8f, VVJvWF=VVJvWF, VV1Jd7=VV1Jd7, VVZYdg="#0a00292B", VVcwfs="#0a002126", VVLuY4="#0a002126", VVG27K="#00000000", VV65AN=True, searchCol=1)
   if not VVPnF9:
    FFycel(VVoLtS, "Stopped" , 1000)
  else:
   if VVPnF9:
    FFzrXb(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVZebY(self, mode, colList):
  colList = list(map(str.strip, colList))
  if mode in (self.VVZsQj, self.VVrfk1):
   num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "", ""
  elif mode == self.VVJwAe:
   num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "." + container_extension, "movie/"
  else:
   seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = "222", epTitle, category_id, stream_id, icon, "." + container_extension, "series/"
  chName = FFQdrB(chName)
  url = self.VVXBtWData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVGYws(url)
  refCode = self.VV1K8x(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVySyb(self, mode, VVoLtS, title, txt, colList):
  FFzW1w(VVoLtS, BF(self.VVZn08, mode, VVoLtS, title, txt, colList))
 def VVZn08(self, mode, VVoLtS, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVZebY(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFp5JP(self, fncMode=CCoD37.VVENG6, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVpyH7(self, mode, VVoLtS, title, txt, colList):
  FFzW1w(VVoLtS, BF(self.VVvpTF, mode, VVoLtS, title, txt, colList))
 def VVvpTF(self, mode, VVoLtS, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFp5JP(self, fncMode=CCoD37.VVwflt, chName=name, text=txt, picUrl=Cover)
 def VVs46a(self, mode, isSerNames, VVoLtS, title, txt, colList):
  if   mode in ("itv"  , CCfw0y.VVZsQj, CCfw0y.VVrfk1): category = "live"
  elif mode in ("vod"  , CCfw0y.VVJwAe )          : category = "vod"
  elif mode in ("series" , CCfw0y.VV4xmt)          : category = "series"
  elif mode == "m3u"                      : category = "m3u"
  if mode == "m3u":
   nameCol, picCol, descCol, descTxt = 1, 4, 2, "Group"
  elif mode in ("itv", "vod", "series"):
   if isSerNames: nameCol, picCol, descCol, descTxt = 0, 12, 9, "Genre"
   else   : nameCol, picCol, descCol, descTxt = 1, 4 , 6, "Category/Genre"
  else:
   nameCol = 1
   if isSerNames         : picCol, descCol, descTxt = 7, 4, "Genre"
   elif mode == self.VVZsQj : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVrfk1 : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVJwAe  : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VV4xmt : picCol, descCol, descTxt = 5, 0, "Season"
  FFzW1w(VVoLtS, BF(self.session.open, CCL4zi, VVoLtS, category, nameCol, picCol, descCol, descTxt))
 def VVZoWP(self, mode, typ, seriesName, VVoLtS, title, txt, colList):
  VVMVqr = []
  isMulti = VVoLtS.VVzBSi
  tot  = VVoLtS.VVv3mu()
  if isMulti:
   if tot < 1:
    FFycel(VVoLtS, "Select rows first.", 1000)
    return
   else:
    name = "%d Selected" % tot
  else:
   name = "ALL"
  VVMVqr.append(("Download %s PIcon%s" % (name, FFoTxy(tot)), "dnldPicons" ))
  if typ:
   VVMVqr.append(VVpTvr)
   tName = "Movie" if typ.startswith("v") else "Series"
   VVMVqr.append(("Download Current %s" % tName    , "dnldSel"  ))
   VVMVqr.append(("Add Current %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VVMVqr.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CCXFYJ.VV39Bn():
    VVMVqr.append(VVpTvr)
    VVMVqr.append(("Download Manager"      , "dload_stat" ))
  FF7ARM(self, BF(self.VVG2Tb, VVoLtS, mode, typ, seriesName, colList), title="Download Options", VVMVqr=VVMVqr)
 def VVG2Tb(self, VVoLtS, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VVHbtJ(VVoLtS, mode)
   elif item == "dnldSel"  : self.VVZLPV(VVoLtS, mode, typ, colList, True)
   elif item == "addSel"  : self.VVZLPV(VVoLtS, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VV79Uj(VVoLtS, mode, typ, seriesName)
   elif item == "dload_stat" : CCXFYJ.VVf574(self, VVoLtS)
 def VVZLPV(self, VVoLtS, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VVIIle(mode, typ, colList)
  if startDnld:
   CCXFYJ.VVIFnw(self, decodedUrl)
  else:
   self.VVUjns(VVoLtS, "Add to Download list", chName, [decodedUrl], startDnld)
 def VV79Uj(self, VVoLtS, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVoLtS.VVGkEL():
   chName, decodedUrl = self.VVIIle(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVUjns(VVoLtS, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVUjns(self, VVoLtS, title, chName, decodedUrl_list, startDnld):
  FFo4dm(self, BF(self.VVKmJt, VVoLtS, decodedUrl_list, startDnld), chName, title=title)
 def VVKmJt(self, VVoLtS, decodedUrl_list, startDnld):
  added, skipped = CCXFYJ.VVjQu1(decodedUrl_list)
  FFycel(VVoLtS, "Added", 1000)
 def VVIIle(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VVZebY(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVxFLI(mode, colList)
   refCode, chUrl = self.VViO0E(self.VVrHOQ, self.VVEHz9, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FFAE0u(chUrl)
  return chName, decodedUrl
 def VVHbtJ(self, VVoLtS, mode):
  if FFlgKV("ffmpeg"):
   self.session.open(CCSCNk, barTheme=CCSCNk.VVSu4G
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = BF(self.VVs7Ei, VVoLtS, mode)
       , VVEStC = self.VVj93w)
  else:
   FFo4dm(self, BF(CCfw0y.VVxwjW, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VVj93w(self, VVPnF9, VVRTV9, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVRTV9["proces"], VVRTV9["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVRTV9["ok"], VVRTV9["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVRTV9["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVRTV9["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVRTV9["badURL"]
  txt += "Download Failure\t: %d\n"   % VVRTV9["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VVRTV9["path"]
  if not VVPnF9  : color = "#11402000"
  elif VVRTV9["err"]: color = "#11201000"
  else     : color = "#22001122"
  if VVRTV9["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVRTV9["err"], txt)
  title = "PIcons Download Result"
  if not VVPnF9:
   title += "  (cancelled)"
  FFtybv(self, txt, title=title, VVLuY4=color)
 def VVs7Ei(self, VVoLtS, mode, VV2ohY):
  isMulti = VVoLtS.VVzBSi
  if isMulti : totRows = VVoLtS.VVv3mu()
  else  : totRows = VVoLtS.VVgRm7()
  VV2ohY.VVHJ4P(totRows)
  VV2ohY.VVd7yy(0)
  counter     = VV2ohY.counter
  maxValue    = VV2ohY.maxValue
  pPath     = CCxrlm.VVjBFN()
  VV2ohY.VVRTV9 = {   "total" : totRows
         , "proces" : 0
         , "attempt" : 0
         , "fail" : 0
         , "ok"  : 0
         , "size0" : 0
         , "exist" : 0
         , "badURL" : 0
         , "path" : pPath
         , "err"  : "" }
  try:
   for rowNum, row in enumerate(VVoLtS.VVGkEL()):
    if VV2ohY.isCancelled:
     break
    if not isMulti or VVoLtS.VV4pjK(rowNum):
     VV2ohY.VVRTV9["proces"] += 1
     VV2ohY.VVc1xD(1)
     if mode in ("itv", "vod", "series"):
      chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVxFLI(mode, row)
      refCode = CCfw0y.VV1K8x(catID, stID, chNum)
     elif mode == "m3u/m3u8":
      chName = row[1].strip()
      url  = row[3].strip()
      picUrl = row[4].strip()
      refCode = self.VV0kQN(rowNum, url, chName)
     else:
      chName, chUrl, picUrl, refCode = self.VVZebY(mode, row)
     if picUrl:
      picon = refCode.replace(":", "_").rstrip("_") + ".png"
      if not fileExists(pPath + picon):
       VV2ohY.VVRTV9["attempt"] += 1
       path, err = FFOecp(picUrl, picon, timeout=1, mustBeImage=True)
       if path:
        if VV2ohY:
         VV2ohY.VVRTV9["ok"] += 1
         VV2ohY.VVd7yy(VV2ohY.VVRTV9["ok"])
        if FFPLWs(path) > 0:
         cmd = CCoD37.VVBGeg(path)
         cmd += FFgeXp("mv -f '%s' '%s'" % (path, pPath))
         FFgSm7(cmd)
        else:
         if VV2ohY:
          VV2ohY.VVRTV9["size0"] += 1
         FFnPMX(path)
       elif err:
        if VV2ohY:
         VV2ohY.VVRTV9["fail"] += 1
        if any(x in err.lower() for x in ("time-out", "unauthorized")):
         if VV2ohY:
          VV2ohY.VVRTV9["err"] = err.title()
         break
      else:
       if VV2ohY:
        VV2ohY.VVRTV9["exist"] += 1
     else:
      if VV2ohY:
       VV2ohY.VVRTV9["badURL"] += 1
  except:
   pass
 def VVEnM2(self):
  title = "Download PIcons for Current Bouquet"
  if FFlgKV("ffmpeg"):
   self.session.open(CCSCNk, barTheme=CCSCNk.VVSu4G
       , titlePrefix = ""
       , fncToRun  = self.VVSOxS
       , VVEStC = BF(self.VVv8B3, title))
  else:
   FFo4dm(self, BF(CCfw0y.VVxwjW, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title=title)
 def VVSOxS(self, VV2ohY):
  bName = CCrfsB.VVGByY()
  pPath = CCxrlm.VVjBFN()
  totNotIptv = totServErr = totParseErr = totUnauth = totCh = totIptv = totPic = totPicOK = totInvServ = totInvPicUrl = totSize0 = totExist = 0
  VV2ohY.VVRTV9 = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
  services = CCrfsB.VVKfvZ()
  if not VV2ohY or VV2ohY.isCancelled:
   return
  if not services or len(services) == 0:
   VV2ohY.VVRTV9 = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   return
  totCh = len(services)
  VV2ohY.VVHJ4P(totCh)
  VV2ohY.VVd7yy(0)
  for serv in services:
   if not VV2ohY or VV2ohY.isCancelled:
    return
   VV2ohY.VVRTV9 = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   VV2ohY.VVc1xD(1)
   VV2ohY.VVd7yy(totPic)
   fullRef  = serv[0]
   if FF3dcV(fullRef):
    totIptv += 1
   else:
    totNotIptv += 1
    continue
   refCode, decodedUrl, origUrl, iptvRef = FFAE0u(fullRef)
   picon = refCode.replace(":", "_").rstrip("_") + ".png"
   if fileExists(pPath + picon):
    totExist += 1
    continue
   span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
   if span:
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query, m3u_Url, host1, user1, pass1, streamId, err = CCEgQt.VVCt6q(decodedUrl)
    uHost, uUser, uPass, uId, uChName = host, user1, pass1, streamId, span.group(1)
   else:
    m3u_Url = decodedUrl
    uType, uHost, uUser, uPass, uId, uChName = CCfw0y.VVKCk4(m3u_Url)
   if not all([uHost, uUser, uPass, uId]):
    totInvServ += 1
    continue
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCfw0y.VVtidF(qUrl)
   if err:
    totServErr += 1
    if "Unauth" in err:
     totUnauth += 1
    continue
   try:
    epg, picUrl = CCoD37.VVAIrc(jLoads(txt))
   except:
    totParseErr += 1
    continue
   if not picUrl:
    totInvPicUrl += 1
    continue
   totPic += 1
   path, err = FFOecp(picUrl, picon, timeout=1, mustBeImage=True)
   if path:
    if VV2ohY:
     VV2ohY.VVd7yy(totPic)
    if FFPLWs(path) > 0:
     cmd = CCoD37.VVBGeg(path)
     cmd += FFgeXp("mv -f '%s' '%s'" % (path, pPath))
     FFgSm7(cmd)
     totPicOK += 1
    else:
     totSize0
     FFnPMX(path)
  if VV2ohY:
   VV2ohY.VVRTV9 = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
 def VVv8B3(self, title, VVPnF9, VVRTV9, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist = VVRTV9
  if err:
   FFzrXb(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "\n"
   txt += "PIcons Found\t: %d\n" % totPic
   txt += "PIcons Added\t: %d\n" % totPicOK
   if totUnauth or totExist or totNotIptv or totServErr or totParseErr or totInvServ or totInvPicUrl or totSize0:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totExist  : txt += "PIcons Exist\t: %s\n"  % FFCzRx(str(totExist)  , VVtz60)
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFCzRx(str(totNotIptv)  , VVtz60)
    if totServErr : txt += "Server Errors\t: %s\n" % FFCzRx(str(totServErr) + t1, VVtz60)
    if totParseErr : txt += "Parse Errors\t: %s\n"  % FFCzRx(str(totParseErr) , VVtz60)
    if totInvServ : txt += "Invalid Ser. URL\t: %s\n" % FFCzRx(str(totInvServ)  , VVtz60)
    if totInvPicUrl : txt += "Invalid Pic. URL\t: %s\n" % FFCzRx(str(totInvPicUrl) , VVtz60)
    if totSize0  : txt += "PIcons Size = 0\t: %s\n" % FFCzRx(str(totSize0)  , VVtz60)
   if not VVPnF9:
    title += "  (stopped)"
   FFtybv(self, txt, title=title)
 @staticmethod
 def VVxwjW(SELF):
  cmd = FF4ZaS(VVLFdd, "ffmpeg")
  if cmd : FFHguD(SELF, cmd, title="Installing FFmpeg")
  else : FFV7xB(SELF)
 @staticmethod
 def VVNX8T(SELF):
  SELF.session.open(CCSCNk, barTheme=CCSCNk.VVSu4G
      , titlePrefix = ""
      , fncToRun  = CCfw0y.VViUew
      , VVEStC = BF(CCfw0y.VVTlgU, SELF))
 @staticmethod
 def VViUew(VV2ohY):
  bName = CCrfsB.VVGByY()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  VV2ohY.VVRTV9 = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = CCrfsB.VVKfvZ()
  if not VV2ohY or VV2ohY.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   VV2ohY.VVHJ4P(totCh)
   for serv in services:
    if not VV2ohY or VV2ohY.isCancelled:
     return
    VV2ohY.VVc1xD(1)
    fullRef = serv[0]
    if FF3dcV(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFAE0u(fullRef)
     span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
     pList, err = [], ""
     if span:
      pList, err = CCEgQt.VV101m(decodedUrl, retLst=True)
     else:
      uType, uHost, uUser, uPass, uId, uChName = CCfw0y.VVKCk4(decodedUrl)
      if all([uHost, uUser, uPass, uId]):
       url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
       pList, err = CCfw0y.VVox0S(url, uId)
      else:
       totInv += 1
     if err:
      totServErr += 1
      if "Unauth" in err:
       totUnauth += 1
     if VV2ohY:
      VV2ohY.VVpD7B(totEpgOK, uChName)
     if pList:
      totEv, totOK = CCL7is.VVNpl5(refCode, pList)
      totEpg += totEv
      totEpgOK += totOK
    else:
     totNotIptv += 1
    if VV2ohY:
     VV2ohY.VVRTV9 = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   VV2ohY.VVRTV9 = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 @staticmethod
 def VVTlgU(SELF, VVPnF9, VVRTV9, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VVRTV9
  title = "IPTV EPG Import"
  if err:
   FFzrXb(SELF, err, title=title)
  else:
   if VVPnF9 and totEpgOK > 0:
    CCL7is.VV2crm()
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFCzRx(str(totNotIptv), VVtz60)
    if totServErr : txt += "Server Errors\t: %s\n" % FFCzRx(str(totServErr) + t1, VVtz60)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FFCzRx(str(totInv), VVtz60)
   if not VVPnF9:
    title += "  (stopped)"
   FFtybv(SELF, txt, title=title)
 @staticmethod
 def VVox0S(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCfw0y.VVGYws(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CCfw0y.VVtidF(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CCfw0y.VVEl8A(item, "description" , is_base64=True ).replace("\n", " .. ")
    lang    = CCfw0y.VVEl8A(item, "lang"        ).upper()
    now_playing   = CCfw0y.VVEl8A(item, "now_playing"      )
    start    = CCfw0y.VVEl8A(item, "start"        )
    start_timestamp  = CCfw0y.VVEl8A(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CCfw0y.VVEl8A(item, "start_timestamp"     )
    stop_timestamp  = CCfw0y.VVEl8A(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CCfw0y.VVEl8A(item, "stop_timestamp"      )
    tTitle    = CCfw0y.VVEl8A(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VV1K8x(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCfw0y.VVRa5n(catID, MAX_4b)
  TSID = CCfw0y.VVRa5n(chNum, MAX_4b)
  ONID = CCfw0y.VVRa5n(chNum, MAX_4b)
  NS  = CCfw0y.VVRa5n(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVRa5n(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VV02WJ(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VVc2aF(mode):
  if   mode in ("itv"  , CCfw0y.VV1LVs)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCfw0y.VVgfJL)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCfw0y.VVFsH1) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CCfw0y.VVKPA8) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CCfw0y.VVrfk1    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 def VVVqEO(self, mode):
  err = excl = ""
  dirs = []
  path = "/"
  if CFG.iptvHostsMode.getValue() == VVAHuZ:
   excl = FFWdDQ(1)
  else:
   lst = list(set(list(map(str.strip, CFG.iptvHostsDirs.getValue().split(",")))))
   tList = []
   for Dir in lst:
    if pathExists(Dir):
     tList.append(Dir)
   lst = sorted(tList, key=len)
   for Dir in lst:
    for dir1 in dirs:
     if len(Dir) > len(dir1) and Dir.startswith(dir1):
      break
    else:
     dirs.append(Dir)
   if   len(dirs) == 1 : path = dirs[0]
   elif len(dirs) > 1 : path = "{%s}" % ",".join(dirs)
   if not dirs:
    FFzrXb(self, 'Directory not found !\n\nCheck your settings option:\n\n"IPTV Hosts Files Path (Playlist, Portal, M3U)"')
    return []
  if   mode == 1: par = '-iname "*playlist*" | grep -i ".txt"'
  elif mode == 2: par = '\( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf\|\.json"'
  elif mode == 3: par = "-iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'"
  files = FFSInC('find %s %s %s' % (path, excl, par))
  if files:
   err = CCUGPF.VVnFIi(files)
   if err : FFzrXb(self, err + FFCzRx('\n\n( Change "IPTV Hosts Files Path" to "Custom" and try again )', VV61JF))
   else : return files
  else:
   if   path == "/": txt = "!"
   elif dirs  : txt = "in directories listed in settings !"
   else   : txt = "in :\n%s" % path
   if   mode == 1: err = 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt
   elif mode == 2: err = 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt
   elif mode == 3: err = 'No ".m3u" files found %s' % txt
   FFzrXb(self, err)
  return []
 @staticmethod
 def VVmtt9():
  for path in (CFG.backupPath.getValue(), CFG.exportedTablesPath.getValue(), "/tmp/"):
   if pathExists(path):
    return FF5DjF(path)
  return "/"
 @staticmethod
 def VV2a0V(SELF, hostUrl, chName, streamId, ok_fnc):
  pList, err = CCfw0y.VVox0S(hostUrl, streamId, True)
  title = "Catch-up TV Programs"
  if err:
   FFzrXb(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVZYdg, VVcwfs, VVLuY4, VVG27K = CCfw0y.VVc2aF("")
   VVKDDh = ("Home Menu" , FFsago, [])
   VVd479  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VViqYN  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FFldB6(SELF, None, title="Programs for : " + chName, header=header, VVWsIU=pList, VViqYN=VViqYN, VVv3Wm=widths, VVHZHw=24, VVd479=VVd479, VVKDDh=VVKDDh, VVZYdg=VVZYdg, VVcwfs=VVcwfs, VVLuY4=VVLuY4, VVG27K=VVG27K)
  else:
   FFzrXb(SELF, "No Programs from server", title=title)
 @staticmethod
 def VV7Ttk(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 def VV427a(self, isPortal, line, selectionObj, item):
  title = "Add server to IPTV Menu (for easy access)"
  if isPortal : txt, confItem = "Portal" , CFG.favServerPortal
  else  : txt, confItem = "Playlist", CFG.favServerPlaylist
  if confItem.getValue().strip() == line.strip():
   FFo4dm(self, BF(self.VVnKxE, title, confItem), "Already in IPTV Menu !\n\nRemove ?", title=title)
  else:
   FF2tHk(confItem, line)
   FFuXZg(self, 'Added to IPTV Menu.\n\nWill be shown as "Favourite %s Server"' % txt, title=title)
 def VVnKxE(self, title, confItem):
  FF2tHk(confItem, "")
  FFuXZg(self, "Removed from IPTV Menu.", title=title)
 def VVBO6R(self, isPortal):
  if isPortal:
   span = iSearch(r"(.+)\s((?:[A-Fa-f0-9]+:){5}.+[A-Fa-f0-9]+)", CFG.favServerPortal.getValue(), IGNORECASE)
   if span:
    self.VVmEzC(self, span.group(1), span.group(2))
    return
  else:
   span = iSearch(r"(http.+\/\/.+\/.+username=.+&password=\w+)", CFG.favServerPlaylist.getValue(), IGNORECASE)
   if span:
    FFzW1w(self, BF(self.VVgawD, "Favourite Playlist Server", span.group(1)), title="Checking Server ...")
    return
  FFzrXb(self, "Incorrect server data !")
 @staticmethod
 def VVMXi1(SELF, isPortal, line, selectionObj, item):
  myPath = "/media/usb/AAA/IPTV-Files/"
  if pathExists(myPath) : path = myPath
  else     : path = CCfw0y.VVmtt9()
  if isPortal : path += "Portal_Bookmarks.txt"
  else  : path += "Playlist_Bookmarks.txt"
  title = "Bookmark Current Server"
  try:
   if fileExists(path):
    with ioOpen(path, "r", encoding="utf-8") as f:
     for fLine in f:
      if str(line) in str(fLine):
       FFzrXb(SELF, "Already added to file:\n\n%s" % path, title=title)
       return
   with open(path, "a") as f:
    f.write(line + "\n")
   FFuXZg(SELF, "Added to file:\n\n%s" % path, title=title)
  except Exception as e:
   FFzrXb(SELF, "Error:\n\n%s" % str(e), title=title)
 def VVoWAN(self, source, mode, curBName, VVoLtS, title, txt, colList):
  isMulti = VVoLtS.VVzBSi
  itemsOK = True
  totTxt = "ALL"
  if isMulti:
   tot = VVoLtS.VVv3mu()
   totTxt = "%d Service%s" % (tot, FFoTxy(tot))
   if tot < 1:
    itemsOK = False
  totTxt = FFCzRx(totTxt, VV61JF)
  curBName2 = ""
  if self.curUrl:
   name = iUrlparse(self.curUrl).netloc
   if name:
    curBName2 = "%s (%s)" % (curBName, name.split(":")[0])
  title = "Add to Bouquet"
  mSel = CC74Cn(self, VVoLtS, addSep=False)
  thTxt = "Adding Services ..."
  VVMVqr, cbFncDict = [], None
  VVMVqr.append(VVpTvr)
  if itemsOK:
   VVMVqr.append(("Add %s to New Bouquet : %s"    % (totTxt, FFCzRx(curBName , VVXF4f)), "addToCur1"))
   if curBName2: VVMVqr.append(("Add %s to New Bouquet : %s" % (totTxt, FFCzRx(curBName2, VVAaU5)) , "addToCur2"))
   VVMVqr.append(("Add %s to Existing Bouquet ..."   % (totTxt)            , "addToNew" ))
   cbFncDict = { "addToCur1": BF(FFzW1w, mSel.VVoLtS, BF(self.VVgl7O,source, mode, curBName , VVoLtS, title), title=thTxt)
      , "addToCur2": BF(FFzW1w, mSel.VVoLtS, BF(self.VVgl7O,source, mode, curBName2, VVoLtS, title), title=thTxt)
      , "addToNew" : BF(self.VVbNqF, source, mode, curBName, VVoLtS, title)
      }
  else:
   VVMVqr.append(("Add to Bouquet (nothing selected)", ))
  mSel.VVKonP(VVMVqr, cbFncDict, width=1400)
 def VVgl7O(self, source, mode, curBName, VVoLtS, Title):
  chUrlLst = self.VV47tj(source, mode, VVoLtS)
  CCrfsB.VVMouF(self, Title, curBName, "", chUrlLst)
 def VVbNqF(self, source, mode, curBName, VVoLtS, Title):
  picker = CCrfsB(self, VVoLtS, Title, BF(self.VV47tj, source, mode, VVoLtS), defBName=curBName)
 def VV47tj(self, source, mode, VVoLtS):
  totChange = 0
  isMulti = VVoLtS.VVzBSi
  chUrlLst = []
  rowNum = 0
  for ndx, row in enumerate(VVoLtS.VVGkEL()):
   if not isMulti or VVoLtS.VV4pjK(ndx):
    chUrl = chName = 0
    if source in ("pEp", "pCh"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVxFLI(mode, row)
     refCode, chUrl = self.VViO0E(self.VVrHOQ, self.VVEHz9, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    elif source == "m3Ch":
     chName = row[1].strip()
     url  = row[3].strip()
     chUrl = self.VVapBy(rowNum, url, chName)
     rowNum += 1
    elif source in ("lv", "v", "s", "fnd"):
     chName, chUrl, picUrl, refCode = self.VVZebY(mode, row)
    if chUrl and chName:
     chUrlLst.append(chUrl)
  return chUrlLst
 @staticmethod
 def VVPCsn():
  return {"1": "DVB Stream", "4097": "servicemp3", "5001": "GST Player", "5002": "Ext-3 EPlayer", "8192": "HDMI input", "8193": "eServiceUri"}
 @staticmethod
 def VVpEpL():
  return sorted(tuple(CCfw0y.VVPCsn()))
 @staticmethod
 def VVLrgM(rt):
  return CCfw0y.VVPCsn().get(str(rt), "")
 @staticmethod
 def VVgRqy(refCode):
  span = iSearch(r"(?:([A-Fa-f0-9]+):){1}(?:[A-Fa-f0-9]+:){8}", refCode)
  return CCfw0y.VVLrgM(span.group(1)) if span else ""
 @staticmethod
 def VVP4kA(rt):
  if   rt == "1"  : return True
  elif rt == "4097": return True
  elif rt == "5001": return fileExists("/usr/bin/gstplayer") or fileExists("/usr/bin/gstplayer_gst-1.0")
  elif rt == "5002": return fileExists("/usr/bin/exteplayer3")
  elif rt == "8192": return False
  elif rt == "8193": return os.path.exists("/usr/bin/apt-get")
  else    : return False
 @staticmethod
 def VVOqDo():
  defRt = CFG.iptvAddToBouquetRefType.getValue()
  VVMVqr = []
  for ndx, rt in enumerate(CCfw0y.VVpEpL()):
   VVMVqr.append(FFwLFH("%s\t... %s" % (CCfw0y.VVLrgM(rt), rt), rt, CCfw0y.VVP4kA(rt), VVJS3b if rt == defRt else ""))
   if ndx < 4 and ndx % 2: VVMVqr.append(VVpTvr)
  return VVMVqr
class CCkujJ(object):
 def __init__(self, SELF):
  SELF["mySbFrm"] = Label()
  SELF["mySbBak"] = Label()
  SELF["mySbSld"] = Label()
  self.frm, self.bak, self.sld = SELF["mySbFrm"], SELF["mySbBak"], SELF["mySbSld"]
  self.frmI = self.bakI = self.sldI = None
  self.sldX = self.sldY = self.sldW = self.sldH = 0
  for obj in (self.frm, self.bak, self.sld): obj.hide()
 def VVJDhU(self, x, y, w, h, bW=1, frmColor="#11aaaaaa", bakColor="#11003344", sldColor="#11ff8000"):
  x, y, w, h = int(x), int(y), int(w), int(h)
  FFzBm8(self.frm, frmColor)
  FFzBm8(self.bak, bakColor)
  FFzBm8(self.sld, sldColor)
  self.frmI, self.bakI, self.sldI = self.frm.instance, self.bak.instance, self.sld.instance
  self.frmI.move(ePoint(x, y))
  self.frmI.resize(eSize(w, h))
  self.bakI.move(ePoint(x + bW, y + bW))
  self.bakI.resize(eSize(w - bW * 2, h - bW * 2))
  self.sldX = x + bW
  self.sldY = y + bW
  self.sldW = w - bW * 2
  self.sldH = h - bW * 2
  self.sldI.move(ePoint(self.sldX, self.sldY))
  self.sldI.resize(eSize(self.sldW, self.sldH))
 def VVurz2(self, val, maxN):
  if maxN < 2:
   for obj in (self.frm, self.bak, self.sld): obj.hide()
  else:
   for obj in (self.frm, self.bak, self.sld): obj.show()
   visH = max(self.sldH / maxN, self.sldH * 0.05)
   self.sldI.resize(eSize(self.sldW, int(visH)))
   y = FFpM97(val, 1, maxN, 0, self.sldH - visH)
   self.sldI.move(ePoint(self.sldX, int(self.sldY + y)))
class CCnMHH(CCkujJ):
 def __init__(self, rows, cols, colorCfg):
  self.TOTAL_ROWS   = rows
  self.TOTAL_COLS   = cols
  self.PAGE_ITEMS   = self.TOTAL_ROWS * self.TOTAL_COLS
  self.colorCfg   = colorCfg
  self.totalItems   = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.isBusy    = False
  CCkujJ.__init__(self, self)
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)] = Label()
    self["myPosterPic%d%d" % (row, col)] = Pixmap()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)] = Label()
    self["myPosterLbl%d%d" % (row, col)].hide()
  self.VV8GvX()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(VVjUqm,
  {
   "up" : self.VVL9bj   ,
   "down" : self.VVRnLl  ,
   "left" : self.VVgzL2  ,
   "right" : self.VVPVKV  ,
   "next" : self.VVKdZC ,
   "last" : self.VVV1Tm
  }, -1)
 def VVrPH5(self):
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterPic%d%d" % (row, col)].instance.setScale(1)
  gap = int(self.skinParam["marginLeft"] / 1)
  topBox = self["myPosterPic%d%d" % (0, 0)].instance
  botBox = self["myPosterPic%d%d" % (self.TOTAL_ROWS - 1, self.TOTAL_COLS - 1)].instance
  w = 20
  y = topBox.position().y() - int(self.skinParam["marginTop"] / 2) + 2
  h = self.skinParam["height"] - self.skinParam["barHeight"] - y - 2
  x = self.skinParam["width"] - w - 2
  self.VVJDhU(x, y, w, h)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    try:
     inst = (self["myPosterLbl%d%d" % (row, col)]).instance
     inst.setBorderColor(parseColor("#000000"))
     inst.setBorderWidth(2)
    except:
     pass
  self.VV3iVY()
  self["myPiconPtr"].hide()
 def VV1RWd(self):
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > self.totalItems: f1 = self.totalItems
  if f2 > self.totalItems: f2 = self.totalItems
  return f1, f2
 def VVL9bj(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVia7k()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VV0Itx()
 def VVRnLl(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVJ6ng()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VV0Itx()
 def VVgzL2(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVia7k()
  else:
   self.curCol -= 1
   self.VV0Itx()
 def VVPVKV(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVJ6ng()
  else:
   self.curCol += 1
   self.VV0Itx()
 def VVV1Tm(self):
  oldPage = self.curPage
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VV0Itx(oldPage != self.curPage)
 def VVKdZC(self):
  oldPage = self.curPage
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VV0Itx(oldPage != self.curPage)
 def VVJ6ng(self):
  force = self.curPage != 0
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VV0Itx(force)
 def VVia7k(self):
  force = self.curPage != self.totalPages - 1
  self.curPage = self.totalPages - 1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VV0Itx(force)
 def VV0Itx(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVCPU4 = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVCPU4: self.curPage = VVCPU4
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  self.VV19lw()
  self["myPiconPtr"].hide()
  self.VVurz2(self.curPage + 1, self.totalPages)
  FFA9HA(BF(self.VVB6If, force or not oldPage == self.curPage, VVCPU4))
 def VVB6If(self, force, VVCPU4):
  try:
   if force:
    self.VV2mlZ()
   if self.curPage == VVCPU4:
    if self.curRow > self.lastRow:
     self.curRow = self.lastRow
    if self.curRow == self.lastRow and self.curCol > self.lastCol:
     self.curCol = self.lastCol
   self.curIndex = self.curPage * self.PAGE_ITEMS + self.curRow * self.TOTAL_COLS + self.curCol
   self.VV19lw()
   boxX, boxY, boxW, boxH = self.skinParam["extraPar"]
   self["myPiconPtr"].instance.move(ePoint(int(boxX + boxW * self.curCol), int(boxY + boxH * self.curRow)))
  except:
   pass
  self["myPiconPtr"].show()
 def VV4BdY(self, ndx):
  if ndx > -1 and ndx < self.totalItems:
   oldPage   = self.curPage
   self.curPage = int(ndx / self.PAGE_ITEMS)
   firstInPage  = self.curPage * self.PAGE_ITEMS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VV0Itx(False if oldPage == self.curPage else True)
  else:
   FFycel(self, "Not found", 1000)
 def VVpUyB(self):
  self.VV4BdY(self.totalItems - 1 if self.curIndex == 0 else 0)
 def VV8GvX(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)].hide()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)].hide()
 def VVvrFK(self):
  if self.colorCfg:
   fg = bg = self.colorCfg.getValue()
   self.session.openWithCallback(self.VVXiv3, CCFKE9, defFG=fg, defBG=bg, onlyBG=True)
 def VVXiv3(self, fg, bg):
  if self.colorCfg and bg:
   FF2tHk(self.colorCfg, bg)
   self.VV3iVY()
 def VV3iVY(self):
  if self.colorCfg:
   for row in range(self.TOTAL_ROWS):
    for col in range(self.TOTAL_COLS):
     FFzBm8(self["myPosterRep%d%d" % (row, col)], self.colorCfg.getValue())
 def VVwv4c(self, lbl, txt, color=""):
  CCnMHH.VVHkW9(lbl, txt, color)
 @staticmethod
 def VVHkW9(lbl, txt, color=""):
  lbl.show()
  lbl.setText(txt)
  txtW = lbl.instance.calculateSize().width()
  lblW = lbl.instance.size().width() - 15
  if txtW > lblW:
   for i in range(len(txt), 5, -1):
    txt = txt[:-1]
    lbl.setText("%s.." % txt)
    txtW = lbl.instance.calculateSize().width()
    if txtW < lblW:
     break
  if color:
   lbl.setText("%s%s" % (color, txt))
 @staticmethod
 def VVQQ8t(pic, path):
  pic.show()
  if fileExists(path):
   try:
    png = LoadPixmap(path)
    pic.instance.setScale(1)
    pic.instance.setPixmap(png)
    return png
   except:
    pass
  return None
class CCL4zi(Screen, CCnMHH):
 def __init__(self, session, VVoLtS, category, nameCol, picCol, descCol, descTxt):
  self.skin, self.skinParam = FF5TEn(VV2FRr, 1870, 1030, 50, 3, 3, "#33000000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "Server Browser"
  self.VVoLtS  = VVoLtS
  self.category   = category
  self.nameCol   = nameCol
  self.picCol    = picCol
  self.descCol   = descCol
  self.descTxt   = descTxt
  self.timer    = eTimer()
  self.myThread   = None
  self.totDownloads  = 0
  self.stopThread   = False
  self.VVWsIU    = []
  self.totPosterUrls  = 0
  self.totalItems   = 0
  FF32Yx(self, self.Title)
  CCnMHH.__init__(self, 2, 6, CFG.transpColorPosters)
  subPath = ""
  if   category == "live"  : subPath = "Live/"
  elif category == "vod"  : subPath = "VOD/"
  elif category == "series" : subPath = "Series/"
  elif category == "m3u"  : subPath = "M3U/"
  self.pPath = "%sPosters/%s" % (VVYfYu, subPath)
  if not pathExists(self.pPath):
   FFgSm7("mkdir -p '%s'" % self.pPath)
   if not pathExists(self.pPath):
    self.pPath = "/tmp/"
  self["myAction"].actions.update(
  {
   "ok" : self.VVthYm    ,
   "cancel": self.close    ,
   "menu" : self.VVqCcn ,
   "info" : self.VV9g9s  ,
   "0"  : self.VVpUyB
  })
  self.onShown.append(self.VVSDD3)
  self.onClose.append(self.onExit)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  FFDoNq(self)
  FFieY3(self)
  self.VVrPH5()
  self.VVGRzB()
 def onExit(self):
  self.stopThread = True
  self.timer.stop()
 def VVqCcn(self):
  chName, subj, desc, fName, picUrl = self.VVWsIU[self.curIndex]
  VVMVqr = []
  VVMVqr.append(FFwLFH("Show Selected Picture"        , "VVEw3u"  , fName))
  VVMVqr.append(FFwLFH("Copy Selected Picture to Export-Directory"   , "VV7B6s" , fName))
  VVMVqr.append(FFwLFH("Set Selected Picture as a Poster for a Local Media" , "VV4gGE", fName))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Cache details"       , "VVWBoV"  ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Change Poster/Picon Transparency Color" , "VVvrFK" ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Help (Keys)"        , "help"     ))
  FF7ARM(self, self.VV9qn4, title=self.Title, VVMVqr=VVMVqr)
 def VV9qn4(self, item=None):
  if item is not None:
   if   item == "VVEw3u"   : self.VVEw3u()
   elif item == "VV7B6s"   : self.VV7B6s()
   elif item == "VV4gGE"  : self.VV4gGE()
   elif item == "VVWBoV"  : FFzW1w(self, self.VVWBoV, title="Calculating ...")
   elif item == "VVvrFK": self.VVvrFK()
   elif item == "help"     : FFGkYk(self, "_help_servBr", "Server Browser (Keys)")
 def VVthYm(self):
  self.VVoLtS.VV7qpv(self.curIndex)
  self.VVoLtS.VVl5Rs()
 def VV9g9s(self):
  self.VVoLtS.VV7qpv(self.curIndex)
  self.VVoLtS.VVQCCW()
 def VVGRzB(self):
  for colList in self.VVoLtS.VVGkEL():
   chName = colList[self.nameCol]
   url  = colList[self.picCol]
   desc = colList[self.descCol]
   fName = picUrl = ""
   if url:
    tmpFile = self.VVIzy2(url)
    if fileExists(self.pPath + tmpFile):
     fName = tmpFile
    else:
     picUrl = url
     self.totPosterUrls += 1
   self.VVWsIU.append((chName, self.descTxt, desc, fName, picUrl))
  self.totalItems = len(self.VVWsIU)
  self.totalPages = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  ndx = self.VVoLtS.VVqeSa()
  self.curPage = int(ndx / self.PAGE_ITEMS)
  ndx     -= self.curPage * self.PAGE_ITEMS
  self.curRow  = int((ndx / self.TOTAL_COLS))
  ndx     -= self.curRow * self.TOTAL_COLS
  self.curCol  = int((ndx % self.TOTAL_COLS))
  self.VV0Itx(True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV2MOu)
  except:
   self.timer.callback.append(self.VV2MOu)
  self.timer.start(500, False)
  self.myThread = iThread(name="ajp_progBar", target=self.VVuwLw)
  self.myThread.start()
 def VVIzy2(self, url):
  fName = os.path.basename(url)
  span = iSearch(r'(.+\.(?:png|jpg))', fName, IGNORECASE)
  return span.group(1) if span else fName
 def VVuwLw(self):
  try:
   for ndx, (chName, subj, desc, fName, picUrl) in enumerate(self.VVWsIU):
    if not self.stopThread:
     if picUrl and not fName:
      fName = self.VVIzy2(picUrl)
      path, err = FFOecp(picUrl, fName, timeout=1, mustBeImage=True)
      if path:
       self.totDownloads += 1
       FFgSm7("mv -f '%s' '%s'" % (path, self.pPath + fName))
       self.VVWsIU[ndx] = (chName, subj, desc, fName, "-")
  except:
   pass
 def VV2MOu(self):
  txt = ""
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
  else:
   txt = VVfMEC + "   >> Downloading %d/%d ..." % (self.totDownloads, self.totPosterUrls)
  self["myTitle"].setText("  %s%s" % (self.Title, txt))
  last = self.totalItems
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVWsIU[ndx]
   if fName and picUrl == "-":
    path = self.pPath + fName
    if fileExists(path):
     self.VVWsIU[ndx] = (chName, subj, desc, fName, "")
     CCnMHH.VVQQ8t(self["myPosterPic%d%d" % (row, col)], path)
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VV2mlZ(self):
  self.VV8GvX()
  f1, f2 = self.VV1RWd()
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVWsIU[ndx]
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVwv4c(lbl, chName)
   path = ""
   if fName    : path = self.pPath + fName
   if not fileExists(path) : path = VVLS8v + "iptv.png"
   CCnMHH.VVQQ8t(pic, path)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VV19lw(self):
  chName, subj, desc, fName, picUrl = self.VVWsIU[self.curIndex]
  self["myPiconInf0"].setText("  " + chName + "  ")
  self["myPiconInf1"].setText("   " + "%s : %s" % (subj, desc) if desc else "" + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VVEw3u(self):
  chName, subj, desc, fName, picUrl = self.VVWsIU[self.curIndex]
  if fName and fileExists(self.pPath + fName) : CCwf80.VVR0Px(self, self.pPath + fName)
  else          : FFycel(self, "File not found", 1500)
 def VV7B6s(self):
  title = "Copy Poster/PIcon"
  chName, subj, desc, fName, picUrl = self.VVWsIU[self.curIndex]
  if fName:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = dstPath + (chName + os.path.splitext(fName)[1] if chName else fName)
   if FFgSm7("cp -f '%s' '%s'" % (self.pPath + fName, dstF)):
    FFuXZg(self, "File copied to:\n\n%s" % dstF, title=title)
   else:
    FFzrXb(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstPath), title=title)
  else:
   FFzrXb(self, "No Poster/PIcon found", title=title)
 def VV4gGE(self):
  self.session.openWithCallback(self.VVbWg6, BF(CCUGPF, patternMode="movies", VVRawy=CFG.MovieDownloadPath.getValue()))
 def VVbWg6(self, path):
  if path:
   title = "Set Selected Picture as a Poster for a Local Media"
   chName, subj, desc, fName, picUrl = self.VVWsIU[self.curIndex]
   if fName:
    srcF = self.pPath + fName
    dstF = "%s%s" % (os.path.splitext(path)[0], os.path.splitext(srcF)[1])
    if FFgSm7("cp -f '%s' '%s'" % (srcF, dstF)):
     FFuXZg(self, "File copied to:\n\n%s" % dstF, title=title)
    else:
     FFzrXb(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstF), title=title)
    CCEldE.VVfUxB(dstF)
   else:
    FFzrXb(self, "No Poster/PIcon found", title=title)
 def VVWBoV(self):
  txt = "\n"
  totSize = 0
  for path in ("Live/", "VOD/", "Series/", "M3U/"):
   path = "%sPosters/%s" % (VVYfYu, path)
   size = "Dir. not found !"
   if pathExists(path):
    size = FFwTnb("find '%s' ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
    if size.isdigit():
     size = int(size)
     totSize += size
     size = CCUGPF.VVuy4U(size)
   txt += "%s\n    %s\n\n" % (FFCzRx(path, VV61JF), size)
  mainPath = "%sPosters" % VVYfYu
  totFiles = FFwTnb("find '%s' ! -type d | wc -l" % mainPath)
  totFTxt = " (%s file%s)" % (totFiles, FFoTxy(int(totFiles))) if totFiles.isdigit() else ""
  txt += "%s\n    %s\n\n" % (FFCzRx("Total space used by Posters/PIcons%s:" % totFTxt, VVRJhR), CCUGPF.VVuy4U(totSize))
  mountPath = CCUGPF.VVqkhN(mainPath)
  if pathExists(mountPath):
   totSize  = CCUGPF.VVIwRI(mountPath)
   freeSize = CCUGPF.VV5yeR(mountPath)
   usedSize = CCUGPF.VVuy4U(totSize - freeSize)
   totSize  = CCUGPF.VVuy4U(totSize)
   freeSize = CCUGPF.VVuy4U(freeSize)
   txt += "%s\n" % SEP
   txt += FFCzRx("Media Space:\n", VVTKrH)
   txt += "    Media Path\t: %s\n" % FFCzRx(mountPath, VVYqlh)
   txt += "    Total Size\t: %s\n" % totSize
   txt += "    Used Size\t: %s\n" % usedSize
   txt += "    Free Size\t: %s\n" % freeSize
  FFtybv(self, txt, title="Cache Used Size", height=1000)
class CCEldE(Screen, CCnMHH):
 def __init__(self, session, title, lst):
  self.skin, self.skinParam = FF5TEn(VV1MVU, 1870, 1030, 50, 3, 3, "#33440000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = title
  self.VVWsIU    = lst
  FF32Yx(self, self.Title)
  CCnMHH.__init__(self, 2, 6, CFG.transpColorMovies)
  self["myAction"].actions.update(
  {
   "ok" : self.VVthYm    ,
   "cancel": self.close    ,
   "menu" : self.VVttxC ,
   "info" : self.VVgTnn  ,
   "0"  : self.VVpUyB
  })
  self.onShown.append(self.VVSDD3)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  FFDoNq(self)
  FFieY3(self)
  self.VVrPH5()
  self.totalItems = len(self.VVWsIU)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VV0Itx(True)
 def VV2mlZ(self):
  self.VV8GvX()
  f1, f2 = self.VV1RWd()
  mPath = CFG.MovieDownloadPath.getValue()
  row = col = 0
  for ndx in range(f1, f2):
   path, movie, poster = self.VVWsIU[ndx]
   path = os.path.join(mPath, path)
   path = os.path.join(path, movie)
   if poster: poster = os.path.join(os.path.dirname(path), poster)
   else  : poster = VVLS8v + "noPos.png"
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVwv4c(lbl, os.path.splitext(os.path.basename(path))[0])
   CCnMHH.VVQQ8t(pic, poster)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVFONG(self):
  path, movie, poster = self.VVWsIU[self.curIndex]
  path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
  path = os.path.join(path, movie)
  if poster:
   poster = os.path.join(os.path.dirname(path), poster)
  return path, poster
 def VV19lw(self):
  path, poster = self.VVFONG()
  self["myPiconInf0"].setText("  " + os.path.splitext(os.path.basename(path))[0] + "  ")
  self["myPiconInf1"].setText("   " + os.path.dirname(path) + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VVttxC(self):
  path, poster = self.VVFONG()
  VVMVqr = []
  VVMVqr.append(("Go to movie ...", "VVUIoO"))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(FFwLFH("Show Poster"      , "VVEw3u" , poster))
  VVMVqr.append(FFwLFH("Copy Poster to Export-Directory" , "VV7B6s", poster))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Change Poster/Picon Transparency Color"  , "VVvrFK" ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Change Poster (from current movie path) ..." , "VVnDY31"  ))
  VVMVqr.append(("Change Poster (locate manually) ..."   , "VVnDY32"  ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Help (Keys)"         , "help"     ))
  FF7ARM(self, self.VV7LEx, title=self.Title, VVMVqr=VVMVqr)
 def VV7LEx(self, item=None):
  if item is not None:
   if   item == "VVUIoO"    : self.VVUIoO()
   elif item == "VV7B6s"    : self.VV7B6s()
   elif item == "VVEw3u"    : self.VVEw3u()
   elif item == "VVvrFK" : self.VVvrFK()
   elif item == "VVnDY31"  : self.VVnDY3()
   elif item == "VVnDY32"  : self.VVnDY3(True)
   elif item == "help"      : FFGkYk(self, "_help_movBr", "Movies Browser (Keys)")
 def VVUIoO(self):
  VVpn2v = []
  for ndx, item in enumerate(self.VVWsIU):
   path, movie, poster = item
   path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
   VVpn2v.append((os.path.splitext(movie)[0], path, str(ndx)))
  VVpn2v.sort(key=lambda x: x[0].lower())
  VVd479 = ("Select" , self.VV0ynk, [])
  header  = ("Name" , "Path", "NDX.")
  widths  = (60  , 40 , 0  )
  FFldB6(self, None, title="Select Movie", width=1800, height=1000, header=header, VVWsIU=VVpn2v, VVv3Wm=widths, VVHZHw=26, VVd479=VVd479, lastFindConfigObj=CFG.lastFindMovie)
 def VV0ynk(self, VVoLtS, title, txt, colList):
  self.VV4BdY(int(colList[2].strip()))
  VVoLtS.cancel()
 def VVthYm(self):
  path, poster = self.VVFONG()
  FFzW1w(self, BF(CCUGPF.VV0bc3, self, path), title="Playing Media ...")
 def VVgTnn(self):
  path, poster = self.VVFONG()
  txt = "%s:\n%s\n\n" % (FFCzRx("Path", VV61JF), path)
  size = FFPLWs(path)
  if size > -1:
   txt += "%s:\n%s\n\n" % (FFCzRx("File Size", VV61JF), CCUGPF.VVuy4U(size))
  if poster:
   txt += "%s:\n%s" % (FFCzRx("Poster", VV61JF), poster)
  FFtybv(self, txt, title="Media File Information")
 def VVEw3u(self):
  path, poster = self.VVFONG()
  if fileExists(poster): CCwf80.VVR0Px(self, poster)
  else     : FFycel(self, "No Poster", 1500)
 def VV7B6s(self):
  title = "Copy Poster"
  path, poster = self.VVFONG()
  if poster:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = os.path.join(dstPath, os.path.basename(poster))
   if FFgSm7("cp -f '%s' '%s'" % (poster, dstF)):
    FFuXZg(self, "File copied to:\n\n%s" % dstF, title=title)
   else:
    FFzrXb(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (poster, dstPath), title=title)
  else:
   FFycel(self, "No Poster", 1500)
 def VVnDY3(self, isManual=False):
  path, poster = self.VVFONG()
  sDir = FF5DjF(os.path.dirname(path))
  if isManual:
   self.session.openWithCallback(BF(self.VVxAD5, sDir, path), BF(CCUGPF, patternMode="poster", VVRawy=sDir))
  else:
   VVMVqr = []
   for item in [f for f in os.listdir(sDir) if iSearch(r"^.*\.(jpg|png)", f, IGNORECASE)]:
    VVMVqr.append((os.path.basename(item), sDir + item))
   if VVMVqr:
    VVMVqr.sort(key=lambda x: x[0].lower())
    VVGygu = self.VVR3h8
    FF7ARM(self, BF(self.VVxAD5, sDir, path), VVMVqr=VVMVqr, title="Posters", VVGygu=VVGygu, VVYpxU=sDir)
   else:
    FFycel(self, "No jpg/png in current dir", 1500)
 def VVR3h8(self, VVdtUh, txt, ref, ndx):
  CCwf80.VVR0Px(self, VVxlEn=ref)
 def VVxAD5(self, sDir, path, pPath=None):
  if pPath:
   newPath = sDir + os.path.splitext(os.path.basename(path))[0] + os.path.splitext(pPath)[1].lower()
   if FFgSm7("cp -f '%s' '%s'" % (pPath, newPath)) or pPath == newPath:
    self.VVWsIU[self.curIndex] = (self.VVWsIU[self.curIndex][0], self.VVWsIU[self.curIndex][1], os.path.basename(newPath))
    FFzW1w(self, self.VV2mlZ)
    CCEldE.VVfUxB(newPath)
   else:
    FFycel(self, "Cannot copy file", 1000)
 @staticmethod
 def VVfUxB(path):
  if path.endswith(".png"):
   fileNoExt = path[:-4]
   jpgF = fileNoExt + ".jpg"
   if fileExists(jpgF):
    c = 1
    newF = "%s_%d.jpg" % (fileNoExt, c)
    while fileExists(newF):
     c += 1
     newF = "%s_%d.jpg" % (fileNoExt, c)
    FFgSm7("mv -f '%s' '%s'" % (jpgF, newF))
 @staticmethod
 def VV4Pej(SELF):
  eLst = CC87Iy.VVbM6s()["mov"]
  mPath = CFG.MovieDownloadPath.getValue()
  lst = []
  for (Dir, dirs, files) in os.walk(mPath):
   for f in files:
    if os.path.splitext(f)[1].lstrip(".").lower() in eLst:
     path = os.path.join(Dir, f)
     poster = ""
     for ext in ("jpg", "png"):
      pic = "%s.%s" % (os.path.splitext(path)[0], ext)
      if fileExists(pic):
       poster = os.path.basename(pic)
       break
     lst.append((os.path.dirname(path).replace(mPath, ""), os.path.basename(path), poster))
  title = "Movies Browser"
  lst.sort(key=lambda x: x[1].lower())
  if lst: SELF.session.open(CCEldE, title, lst)
  else  : FFzrXb(SELF, "No movies found in:\n\n%s\n\nYou can change the path from settings." % mPath, title=title)
class CCr9Lm(Screen, CCnMHH):
 def __init__(self, session, bName, lst):
  self.skin, self.skinParam = FF5TEn(VV6hMT, 1840, 1040, 50, 3, 3, "#22003344", "#22001122", 45, barHeight=40, topRightBtns=1, vSliderW=20)
  self.session   = session
  self.Title    = bName
  self.VVWsIU    = lst
  self.pPath    = CCxrlm.VVjBFN()
  self.totalItems   = 0
  self.isFirstTime  = True
  FF32Yx(self, self.Title)
  FFCDDm(self["keyRed"] , "OK = Zap (Review)")
  FFCDDm(self["keyGreen"] , "Zap & Exit")
  FFCDDm(self["keyYellow"], "Find Current Service")
  CCnMHH.__init__(self, 5, 7, CFG.transpColorChannels)
  self["myAction"].actions.update(
  {
   "ok"  : BF(self.VVuUKy, False),
   "cancel" : self.VVmU2O      ,
   "menu"  : self.VVWW9Y   ,
   "red"  : self.VVmU2O      ,
   "green"  : BF(self.VVuUKy, True) ,
   "yellow" : BF(self.VVLNoQ, True)  ,
   "0"   : self.VVpUyB
  })
  self.onShown.append(self.VVSDD3)
 def VVSDD3(self):
  if self.isFirstTime:
   force = True
   self.isFirstTime = False
   FFDoNq(self)
   FFieY3(self)
   FFzBm8(self["keyRed"], "#0a333333")
   self.VVrPH5()
  else:
   pName, srvLst = CCr9Lm.VVdugh()
   if srvLst and not srvLst == self.VVWsIU:
    force = True
    self.Title = pName
    self["myTitle"].setText("  %s  " % self.Title)
    self.VVWsIU = srvLst
   else:
    force = False
  self.totalItems = len(self.VVWsIU)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VV0Itx(force)
  self.VVLNoQ()
 def VVWW9Y(self):
  VVMVqr = []
  VVMVqr.append(("Find Name (sorted list)" , "findSrt"  ))
  VVMVqr.append(("Find Name (as listed)" , "findNoSrt"))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Change Background Color" , "VVvrFK"))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Help (Keys)", "help"))
  FF7ARM(self, self.VVjdcU, title="Options", VVMVqr=VVMVqr)
 def VVjdcU(self, item=None):
  if item:
   if   item == "findSrt"    : self.VV92VD(True)
   elif item == "findNoSrt"   : self.VV92VD(False)
   elif item == "VVvrFK": self.VVvrFK()
   elif item == "help"     : FFGkYk(self, "_help_srvcBr", "Services Browser (Keys)")
 def VV92VD(self, isSort):
  VVMVqr = []
  for ndx, item in enumerate(self.VVWsIU):
   VVMVqr.append((item[1], ndx))
  if isSort:
   VVMVqr.sort(key=lambda x: x[0].lower())
  FF7ARM(self, self.VVLFA2, title="Find Name", VVMVqr=VVMVqr, width=1300)
 def VVLFA2(self, ndx=None):
  if ndx is not None:
   self.VV4BdY(ndx)
 def VVmU2O(self):
  if self.shown: self.close()
  else   : self.show()
 def VVuUKy(self, isExit):
  FFzW1w(self, BF(self.VVLE8f, isExit), title="Starting ...")
 def VVLE8f(self, isExit):
  try:
   if self.shown:
    FFrvm6(self, self.VVWsIU[self.curIndex][0], VViFts=False)
    if isExit: self.close()
    else  : CCA3uT.VV1gQV(self.session)
   else:
    self.show()
  except:
   pass
 def VVLNoQ(self, VVx3z3=False):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  err = ""
  if serv:
   curRef = serv.toString()
   for ndx, item in enumerate(self.VVWsIU):
    if curRef == item[0]:
     self.VV4BdY(ndx)
     return ndx
   else:
    err = "Not found"
  else:
   err = "No active service"
  if VVx3z3 and err:
   FFycel(self, err, 500)
  return -1
 def VV2mlZ(self):
  self.VV8GvX()
  f1, f2 = self.VV1RWd()
  row = col = 0
  noPos = VVLS8v + "noPos.png"
  for ndx in range(f1, f2):
   ref, name = self.VVWsIU[ndx]
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVwv4c(lbl, name)
   path = CCxrlm.VVoQXZ(self.pPath, ref, name) or noPos
   CCnMHH.VVQQ8t(pic, path)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VV19lw(self):
  ref, name = self.VVWsIU[self.curIndex]
  self["myPiconInf0"].setText("  %s  " % name)
  self["myPiconInf1"].setText("   %s" % ref)
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 @staticmethod
 def VVH11o():
  refCode = refName = rootRef = rootName = ""
  inBouquet = False
  VV8OMp = InfoBar.instance
  if VV8OMp:
   csel = VV8OMp.servicelist
   if csel:
    currSel  = csel.getCurrentSelection()
    rootRef  = csel.getRoot().toString()
    refCode  = currSel.toString()
    rootName = FFj4lz(rootRef)
    refName  = FFj4lz(refCode)
    inBouquet = csel.inBouquet()
  return refCode, refName, rootRef, rootName, inBouquet
 @staticmethod
 def VVdugh(refCode="", refName="", rootRef="", rootName="", inBouquet=False):
  refCode, rootRef = refCode.strip(), rootRef.strip()
  if not refCode and not rootRef:
   refCode, refName, rootRef, rootName, inBouquet = CCr9Lm.VVH11o()
   refCode, rootRef = refCode.strip(), rootRef.strip()
  pName, srvLst = "", []
  if refCode and rootRef:
   if   refCode.startswith("1:7:") : ref, name = refCode, refName
   elif rootRef.startswith("1:7:") : ref, name = rootRef, rootName
   else       : return "", []
   srvLst = FFwksx(eServiceReference(ref))
   pName = name or "No-Name"
   if not inBouquet: srvLst.sort(key=lambda x: x[1].lower())
  else:
   srvLst = CCrfsB.VVKfvZ()
   pName  = CCrfsB.VVGByY() or "ALL (Group)"
  return pName, srvLst
 @staticmethod
 def VVAFvj(SELF):
  pName, srvLst = CCr9Lm.VVdugh()
  if srvLst: SELF.session.open(CCr9Lm, pName, srvLst)
  else  : FFzrXb(SELF, "No services found:\n\n%s" % pName, title="Channels Browser")
class CCG5tV(Screen, CCnMHH):
 def __init__(self, session, title, lst):
  self.skin, self.skinParam = FF5TEn(VVkay5, 1600, 1000, 50, 20, 20, "#2200202a", "#2200101a", 45, barHeight=40, topRightBtns=2, vSliderW=20, morePar={"gapX":30, "gapY":30, "mGap":5, "lblC":"#2200101a", "lblTr":1, "picBgTr":1, "cursC":"#00336070"})
  self.session   = session
  self.Title    = title
  self.VVWsIU    = CCG5tV.VVFSGF(lst)
  self.totalItems   = 0
  self.useOrigSize  = False
  self.firstTime   = True
  FF32Yx(self, self.Title)
  FFCDDm(self["keyRed"] , "Remove Plugins")
  FFCDDm(self["keyGreen"] , "Download New Plugins")
  FFCDDm(self["keyYellow"], "Package Info.")
  FFCDDm(self["keyBlue"] , "Plugins Group")
  CCnMHH.__init__(self, 4, 5, "")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVFILF   ,
   "cancel" : self.close    ,
   "menu"  : self.VVKRFV ,
   "info"  : self.VVtNFV  ,
   "red"  : BF(self.VVySqR, False)   ,
   "green"  : BF(self.VVySqR, True)   ,
   "yellow" : BF(FFzW1w, self, self.VVp8H1),
   "blue"  : self.VVrRVh  ,
   "0"   : self.VVpUyB
  })
  self.onShown.append(self.VVSDD3)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  FFDoNq(self)
  FFieY3(self)
  self.VVrPH5()
  self.VVa3LE()
 def VVa3LE(self):
  self.totalItems = len(self.VVWsIU)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VV0Itx(True)
 def VVHuOg(self):
  lst = CCG5tV.VVAxDM(PluginDescriptor.WHERE_PLUGINMENU)
  if lst:
   lst = CCG5tV.VVFSGF(lst)
   if lst != self.VVWsIU:
    self.VVWsIU = lst
    self.VVa3LE()
  else:
   self.close()
 def VVySqR(self, isInstall):
  FFycel(self, "Processing ...")
  try:
   from Screens.PluginBrowser import PluginDownloadBrowser as pb
   if isInstall:
    self.session.openWithCallback(self.VVHuOg, pb, pb.DOWNLOAD, self.firstTime)
    self.firstTime = False
   else:
    self.session.openWithCallback(self.VVHuOg, pb, pb.REMOVE)
  except:
   try:
    from Screens.PluginBrowser import PluginAction as pa
    self.session.openWithCallback(self.VVHuOg, pa, pa.DOWNLOAD if isInstall else pa.REMOVE)
   except:
    try:
     from Plugins.SystemPlugins.SoftwareManager.plugin import PluginManager as pb
     self.session.openWithCallback(self.VVHuOg, pb)
    except Exception as e:
     FFzrXb(self, 'Cannot open "Extensions Management" !', title=self.Title)
  FFycel(self)
 def VVFILF(self):
  name, desc = self.VVwDM3(self.curIndex)
  if name == PLUGIN_NAME and "VVwi7L" in globals() and VVwi7L:
   FFycel(self, "Already running.", 500)
  else:
   try:
    p = self.VVWsIU[self.curIndex]
    p(session=self.session)
   except:
    FFzrXb(self, "Cannot start from here !", title="Error in : %s" % name)
 def VVtNFV(self):
  def VVchnh(key, val):
   return key + "\t: " + str(val) + "\n"
  p = self.VVWsIU[self.curIndex]
  txt = ""
  try:
   txt += VVchnh("Path"  , p.path  )
   txt += VVchnh("Description" , p.description )
   txt += VVchnh("Icon"  , p.iconstr  )
   txt += VVchnh("Wakeup Fnc" , p.wakeupfnc )
   txt += VVchnh("NeedsRestart", p.needsRestart)
   txt += VVchnh("Internal" , p.internal )
   txt += VVchnh("Weight"  , p.weight  )
  except:
   pass
  name, desc = self.VVwDM3(self.curIndex)
  if txt : FFtybv(self, txt, title=name)
  else : FFzrXb(self, "Could not read plugin info.", title=name)
 def VVp8H1(self):
  p = self.VVWsIU[self.curIndex]
  name, desc = self.VVwDM3(self.curIndex)
  path = p.path
  pkg, err = CCvztK.VVf3Qd(path)
  if pkg : CCvztK.VVo7RC(self, pkg, name)
  else : FFhcEU(self, err, 1000)
 def VVKRFV(self):
  path = self.VVWsIU[self.curIndex].path
  VVMVqr = []
  txt = "Open Plugin Path in File Manager"
  VVMVqr.append(FFwLFH("Open Plugin Path in File Manager", "inFileMan", pathExists(path)))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Use Original Icon Size", "setOrigSize"))
  FF7ARM(self, self.VVYGrN, title="Plugins Group", VVMVqr=VVMVqr)
 def VVYGrN(self, item=None):
  if item:
   if item == "inFileMan":
    self.session.open(CCUGPF, mode=CCUGPF.VV6Mn2, VVRawy=self.VVWsIU[self.curIndex].path)
   elif item == "setOrigSize":
    self.useOrigSize = True
    self.VV0Itx(True)
 def VVrRVh(self):
  FF7ARM(self, self.VVXDPi, title="Plugins Group", VVMVqr=CCG5tV.VVaYUw(True, True), width=700, VVy9CS=True)
 def VVXDPi(self, item=None):
  if item:
   title, where, ndx = item
   self["myTitle"].setText("  %s (%s)" % (self.Title, title))
   lst = CCG5tV.VVAxDM(where)
   if lst:
    self.VVWsIU = CCG5tV.VVFSGF(lst)
    self.curPage = self.curCol = self.curRow = self.curIndex = 0
    self.totalItems = len(self.VVWsIU)
    self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
    self.VV0Itx(True)
   else:
    FFzrXb(self, "Not found !", title=self.Title)
 def VV2mlZ(self):
  self.VV8GvX()
  f1, f2 = self.VV1RWd()
  row = col = 0
  for ndx in range(f1, f2):
   name, desc = self.VVwDM3(ndx)
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVwv4c(lbl, name)
   iconOk = False
   pngSz = None
   if self.VVWsIU[ndx].icon:
    try:
     pngSz = self.VVWsIU[ndx].icon.size()
     pic.instance.setScale(1)
     pic.instance.setPixmap(self.VVWsIU[ndx].icon)
     pic.show()
     iconOk = True
    except:
     pass
   if not iconOk:
    icons = []
    path = self.VVWsIU[ndx].path
    if pathExists(path):
     for f in ("iconfhd.png", "iconhd.png", "icon.png"):
      icons.append(os.path.join(path, f))
    icons.append(resolveFilename(SCOPE_CURRENT_SKIN, "icons/plugin.png"))
    icons.append(VVLS8v + "plugin.png")
    for path in icons:
     pixMap = CCnMHH.VVQQ8t(pic, path)
     if pixMap:
      pngSz = pixMap.size()
      break
   if self.useOrigSize and pngSz:
    try:
     boxSz = pic.instance.size()
     picPos = pic.instance.position()
     pngW, pngH = pngSz.width(), pngSz.height()
     boxW, boxH = boxSz.width(), boxSz.height()
     if boxW > pngW and boxH > pngH:
      pic.instance.resize(pngSz)
      pic.instance.move(ePoint(picPos.x() + (boxW - pngW) // 2, picPos.y() + (boxH - pngH) // 2))
    except:
     pass
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVwDM3(self, ndx):
  name = str(self.VVWsIU[ndx].name).strip()
  desc = str(self.VVWsIU[ndx].description).strip().replace("\n", " >> ")
  if not name or name == "Plugin":
   name = desc or FFZ5fy(self.VVWsIU[ndx].path)
  return name, desc
 def VV19lw(self):
  name, desc = self.VVwDM3(self.curIndex)
  self["myPiconInf0"].setText("  %s  " % name)
  self["myPiconInf1"].setText("   %s" % desc)
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 @staticmethod
 def VVaYUw(isMenu=False, addTot=False):
  lst =[("Plugin Menu"   , PluginDescriptor.WHERE_PLUGINMENU    )
   , ("Audio Menu"    , PluginDescriptor.WHERE_AUDIOMENU    )
   , ("Auto-Start Menu"  , PluginDescriptor.WHERE_AUTOSTART    )
   , ("Channel Context Menu" , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU )
   , ("Event Info"    , PluginDescriptor.WHERE_EVENTINFO    )
   , ("Extensions Menu"  , PluginDescriptor.WHERE_EXTENSIONSMENU   )
   , ("File Scan"    , PluginDescriptor.WHERE_FILESCAN    )
   , ("Main Menu"    , PluginDescriptor.WHERE_MAINMENU    )
   , ("Menu"     , PluginDescriptor.WHERE_MENU     )
   , ("Movie List"    , PluginDescriptor.WHERE_MOVIELIST    )
   , ("Network Configuration" , PluginDescriptor.WHERE_NETWORKCONFIG_READ  )
   , ("Network Setup"   , PluginDescriptor.WHERE_NETWORKSETUP   )
   , ("Session Start"   , PluginDescriptor.WHERE_SESSIONSTART   )
   , ("Software Manager"  , PluginDescriptor.WHERE_SOFTWAREMANAGER  )
   , ("Teletext"    , PluginDescriptor.WHERE_TELETEXT    )
   , ("Wizard"     , PluginDescriptor.WHERE_WIZARD     )]
  if addTot:
   for ndx, item in enumerate(lst):
    tot = len(CCG5tV.VVAxDM(item[1]))
    lst[ndx] = ("%s   %s(%d)" % (lst[ndx][0], VVzv5p, tot), lst[ndx][1])
  if isMenu: lst.insert(1, VVpTvr)
  else  : lst.sort(key=lambda x: x[0].lower())
  return lst
 @staticmethod
 def VVAxDM(where):
  try: return iPlugins.getPlugins(where)
  except: return []
 @staticmethod
 def VVFSGF(lst):
  tmp = []
  for item in lst:
   name = str(item.name).strip()
   if not name or name == "Plugin":
    name = str(item.description).strip() or FFZ5fy(item.path)
   tmp.append((name, item))
  tmp.sort(key=lambda x: x[0].lower())
  lst = []
  for nm, obj in tmp:
   lst.append(obj)
  return lst
 @staticmethod
 def VVsjBg(session):
  title = "Plugins Browser"
  lst = CCG5tV.VVAxDM(PluginDescriptor.WHERE_PLUGINMENU)
  if lst : session.open(CCG5tV, title, lst)
  else : FFBAQq(session, "No plugins found !", title=title)
class CCOtMo(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", isFind=False):
  self.skin, self.skinParam = FF5TEn(VVL1I3, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.isFindMode     = isFind
  self.VV1KN2  = 0
  self.VVvsaV = 1
  self.VVzzhi  = 2
  VVMVqr = []
  VVMVqr.append(("Find in All Service (from filter)" , "VVbEaG" ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Find in All (Manual Entry)"   , "VVs4SJ"    ))
  VVMVqr.append(("Find in TV"       , "VVpfOK"    ))
  VVMVqr.append(("Find in Radio"      , "VVSu7D"   ))
  if self.VVmH49():
   VVMVqr.append(VVpTvr)
   VVMVqr.append(("Hide Channel: %s" % self.servName , "VVHQVx"   ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Zap History"       , "VVBvQc"    ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("IPTV Tools"       , "iptv"      ))
  VVMVqr.append(("PIcons Tools"       , "PIconsTools"     ))
  VVMVqr.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  VVMVqr.append(("EPG Tools"       , "epgTools"     ))
  FF32Yx(self, VVMVqr=VVMVqr, title=title)
  self.onShown.append(self.VVSDD3)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  FFWzaz(self["myMenu"])
  FF0pG3(self)
  if self.isFindMode:
   self.VVEYRH(self.VV9eCN())
 def VVthYm(self):
  global VVBcOf
  VVBcOf = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVs4SJ"    : self.VVs4SJ()
   elif item == "VVbEaG" : self.VVbEaG()
   elif item == "VVpfOK"    : self.VVpfOK()
   elif item == "VVSu7D"   : self.VVSu7D()
   elif item == "VVHQVx"   : self.VVHQVx()
   elif item == "VVBvQc"    : self.VVBvQc()
   elif item == "iptv"       : self.session.open(CCfw0y)
   elif item == "PIconsTools"     : self.session.open(CCxrlm)
   elif item == "ChannelsTools"    : self.session.open(CCh3Pq)
   elif item == "epgTools"      : self.session.open(CCL7is)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VVpfOK(self) : self.VVEYRH(self.VV1KN2)
 def VVSu7D(self) : self.VVEYRH(self.VVvsaV)
 def VVs4SJ(self) : self.VVEYRH(self.VVzzhi)
 def VVEYRH(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFBgSg(self, BF(self.VVI3ct, mode), defaultText=self.findTxt, title=title, message="Enter Name:")
 def VVbEaG(self):
  filterObj = CCOe8b(self)
  filterObj.VVpQGc(self.VVLFUR)
 def VVLFUR(self, item):
  self.VVI3ct(self.VVzzhi, item)
 def VVmH49(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FF3dcV(self.refCode)        : return False
  return True
 def VVI3ct(self, mode, VVF0tQ):
  FFzW1w(self, BF(self.VVwp4l, mode, VVF0tQ), title="Searching ...")
 def VVwp4l(self, mode, VVF0tQ):
  if VVF0tQ:
   VVF0tQ = VVF0tQ.strip()
  if VVF0tQ:
   self.findTxt = VVF0tQ
   CFG.lastFindContextFind.setValue(VVF0tQ)
   if   mode == self.VV1KN2  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVvsaV : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVF0tQ)
   if len(title) > 55:
    title = title[:55] + ".."
   VVpn2v = self.VVMw58(VVF0tQ, servTypes)
   if self.isFindMode or mode == self.VVzzhi:
    VVpn2v += self.VV3RWc(VVF0tQ)
   if VVpn2v:
    VVpn2v.sort(key=lambda x: x[0].lower())
    VVNYAK = self.VVzqeJ
    VVd479  = ("Zap"   , self.VVyQKC    , [])
    VVEXwE = ("Current Service", self.VV6MZC , [])
    VV7J8f = ("Options"  , self.VVnuTn , [])
    VV1Jd7 = (""    , self.VV6OPm , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VViqYN  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFldB6(self, None, title=title, header=header, VVWsIU=VVpn2v, VViqYN=VViqYN, VVv3Wm=widths, VVHZHw=26, VVd479=VVd479, VVNYAK=VVNYAK, VVEXwE=VVEXwE, VV7J8f=VV7J8f, VV1Jd7=VV1Jd7, lastFindConfigObj=CFG.lastFindContextFind)
   else:
    self.VVEYRH(self.VV9eCN())
    FFuXZg(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVMw58(self, VVF0tQ, servTypes):
  VVWsIU = CCh3Pq.VVrNhE(servTypes)
  VVpn2v = []
  if VVWsIU:
   VV9tU5, VVRXrA = FFs2e5()
   tp = CC9Nee()
   words, asPrefix = CCOe8b.VVjxXj(VVF0tQ)
   colorYellow  = CCy1Yy.VVHUiW(VVRJhR)
   colorWhite  = CCy1Yy.VVHUiW(VViypC)
   for s in VVWsIU:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFKMDj(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VV9tU5:
        STYPE = VVRXrA[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVsUQe(refCode)
       if not "-S" in syst:
        sat = syst
       VVpn2v.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVpn2v
 def VV3RWc(self, VVF0tQ):
  VVF0tQ = VVF0tQ.lower()
  VVpn2v = []
  colorYellow  = CCy1Yy.VVHUiW(VVRJhR)
  colorWhite  = CCy1Yy.VVHUiW(VViypC)
  for b in CCrfsB.VVUPlX():
   VVxZ1m  = b[0]
   VVzqlF  = b[1].toString()
   VVI8Xk = eServiceReference(VVzqlF)
   VVfIxf = FFwksx(VVI8Xk)
   for service in VVfIxf:
    refCode  = service[0]
    if FF3dcV(refCode):
     servName = service[1]
     if VVF0tQ in servName.lower():
      servName = iSub(r"(%s)" % iEscape(VVF0tQ), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
      VVpn2v.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVpn2v
 def VV9eCN(self):
  mode = CCPClU.VV2iJm(default=-1)
  return self.VVzzhi if mode == -1 else mode
 def VVzqeJ(self, VVoLtS):
  self.close()
  VVoLtS.cancel()
 def VVyQKC(self, VVoLtS, title, txt, colList):
  FFrvm6(VVoLtS, colList[2], VViFts=False, checkParentalControl=True)
 def VV6MZC(self, VVoLtS, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFmvpz(VVoLtS)
  if refCode:
   VVoLtS.VVVRgf(2, FFp8oe(refCode, iptvRef, chName), True)
 def VVnuTn(self, VVoLtS, title, txt, colList):
  servName = colList[0]
  mSel = CC74Cn(self, VVoLtS)
  VVMVqr, cbFncDict = CCh3Pq.VVxSFC(self, VVoLtS, servName, 2)
  mSel.VVKonP(VVMVqr, cbFncDict)
 def VV6OPm(self, VVoLtS, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFp5JP(self, fncMode=CCoD37.VVUQoW, refCode=refCode, chName=chName, text=txt)
 def VVHQVx(self):
  FFo4dm(self, self.VVXhhx, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVXhhx(self):
  ret = FF33MI(self.refCode, True)
  if ret:
   self.VVRPh1()
   self.close()
  else:
   FFycel(self, "Cannot change state" , 1000)
 def VVRPh1(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVnttO()
  except:
   self.VV8gWt()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFlT79(self, serviceRef)
 def VVnttO(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VV8OMp = InfoBar.instance
   if VV8OMp:
    VV2NxO = VV8OMp.servicelist
    if VV2NxO:
     hList = VV2NxO.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VV2NxO.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VV2NxO.history  = newList
       VV2NxO.history_pos = pos
 def VV8gWt(self):
  VV8OMp = InfoBar.instance
  if VV8OMp:
   VV2NxO = VV8OMp.servicelist
   if VV2NxO:
    VV2NxO.history  = []
    VV2NxO.history_pos = 0
 def VVBvQc(self):
  VV8OMp = InfoBar.instance
  VVpn2v = []
  if VV8OMp:
   VV2NxO = VV8OMp.servicelist
   if VV2NxO:
    VV9tU5, VVRXrA = FFs2e5()
    for serv in VV2NxO.history:
     refCode = serv[-1].toString()
     chName = FFj4lz(refCode)
     path = serv[-1].getPath()
     isLocal = path and path.startswith("/")
     isIptv = FF3dcV(refCode)
     isSRel = FFYKlk(refCode)
     sat = "-" if isIptv and not isSRel or isLocal else FFKMDj(refCode, True)
     if isIptv : STYPE = "Stream Relay" if isSRel else "IPTV"
     elif isLocal: STYPE = "Local Media"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VV9tU5:
       STYPE = VVRXrA[sTypeInt]
     VVpn2v.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVpn2v:
   VVd479  = ("Zap"   , self.VVoBaF   , [])
   VV7J8f = ("Clear History" , self.VV4IPx   , [])
   VV1Jd7 = (""    , self.VVCvea , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VViqYN  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFldB6(self, None, title=title, header=header, VVWsIU=VVpn2v, VViqYN=VViqYN, VVv3Wm=widths, VVHZHw=28, VVd479=VVd479, VV7J8f=VV7J8f, VV1Jd7=VV1Jd7)
  else:
   FFuXZg(self, "History is empty.", title=title)
 def VVoBaF(self, VVoLtS, title, txt, colList):
  FFrvm6(VVoLtS, colList[3], VViFts=False, checkParentalControl=True)
 def VV4IPx(self, VVoLtS, title, txt, colList):
  FFo4dm(self, BF(self.VV6qZW, VVoLtS), "Clear Zap History ?")
 def VV6qZW(self, VVoLtS):
  self.VV8gWt()
  VVoLtS.cancel()
 def VVCvea(self, VVoLtS, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFp5JP(self, fncMode=CCoD37.VVWlCC, refCode=refCode, chName=chName, text=txt)
 @staticmethod
 def VVK326():
  try:
   global VVvj6M
   if VVvj6M is None:
    VVvj6M    = ChannelContextMenu.__init__
   ChannelContextMenu.__init__   = CCOtMo.VVGdmO
   ChannelContextMenu.VVb6iq = CCOtMo.VVb6iq
  except:
   pass
 @staticmethod
 def VVGdmO(SELF, session, csel):
  from Components.ChoiceList import ChoiceEntryComponent
  VVvj6M(SELF, session, csel)
  if CFG.showInChannelListMenu.getValue():
   for ndx, title in enumerate(("Channels Browser", "Find", "Bouquet Editor", "Channels Tools")):
    title = "%s - %s" % (PLUGIN_NAME, title)
    SELF["menu"].list.insert(ndx, ChoiceEntryComponent(key=" ", text=(title , BF(SELF.VVb6iq, csel, ndx, title))))
 @staticmethod
 def VVb6iq(SELF, csel, mode, title):
  try:
   currSel  = csel.getCurrentSelection()
   refCode  = currSel.toString()
   refName  = FFj4lz(refCode)
  except:
   refCode = refName = ""
  if   mode == 0: CCr9Lm.VVAFvj(SELF)
  elif mode == 2: SELF.session.open(CCPClU)
  else    : SELF.session.open(CCOtMo, title=title, csel=csel, refCode=refCode, servName=refName, isFind=True if mode == 1 else False)
  SELF.close()
class CCPClU(Screen):
 def __init__(self, session, refCode="", servName=""):
  self.skin, self.skinParam = FF5TEn(VV1bnu, 10, 10, 30, 0, 0, "#ff000000", "#ff000000", 30)
  self.session = session
  self.Title  = "Bouquet Editor"
  self.pPath  = CCxrlm.VVjBFN()
  self.bTables = []
  FF32Yx(self)
  self.onShown.append(self.VVSDD3)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  self.VVIHAy()
 def VVG1S9(self, tbl, bName, bRef):
  self.bTables.append(tbl)
  tbl.bouqName = bName
  tbl.bouqRef  = bRef
 def VVIHAy(self):
  rootStr = CCPClU.VVgyL6()
  rows = self.VVfXUy(rootStr)
  if rows :
   self.VVwYJ7(self, "Main Bouquets List", rootStr, rows)
   refCode, refName, rootRef, rootName, inBouquet = CCr9Lm.VVH11o()
   if not self.bTables[-1].VVQ2Hx({3:refCode}):
    self.bTables[-1].VVQ2Hx({3:rootRef})
  else:
   FFzrXb(self, "No bouquets Found !", title=self.Title)
   self.close()
 def VVSD9d(self):
  self.bTables[-1].cancel()
  if len(self.bTables) > 0: del self.bTables[-1]
  if not len(self.bTables): self.close()
 def VVfXUy(self, bRef=None):
  blkLst = CCPClU.VVI4bc()
  rows = []
  for ndx, row in enumerate(FFwksx(eServiceReference(bRef), mode=1), start=1):
   ref, name, flags = row
   fTxt, fColor = CCPClU.VV4J3z(flags)
   lck = "1" if CCPClU.VV1YEv(ref, blkLst) > -1 else ""
   rows.append((str(ndx), "", fColor + name, ref, fTxt, str(flags), lck))
  return rows
 def VVwYJ7(self, selfObj, bName, bRef, rows):
  totTbl = len(self.bTables)
  title = {0:"Main Bouquets List", 1:"%s %s" % (FFCzRx("Fav: ", VVzv5p), bName), 2:"%s %s" % (FFCzRx("Sub: ", VVzv5p), bName)}.get(totTbl, bName)
  bg  = {0:"#11002233", 1:"#0a112222"}.get(totTbl, "#0a131111")
  VVNYAK = self.VV1cD3
  VV1Jd7 = (""    , self.VVrO5i  , [])
  VVd479  = ("Enter Bouquet" , self.VVzwV5 , [])
  VVKDDh = ("Delete"   , self.VVncok , [])
  VV7J8f = ("Options"  , self.VVak12 , [])
  VVJvWF = ("Move Here"  , self.VVdavl , [])
  picParams  = (1, self.VVEnGT, None)
  widths  = (12   , 7   , 81 , 0  , 0   , 0   , 0   )
  VViqYN = (CENTER  , CENTER , LEFT , LEFT , LEFT  , CENTER , CENTER )
  tbl = FFldB6(self, None, title=title, VVWsIU=rows, VViqYN=VViqYN, width=1500, height=1000, VVv3Wm=widths, VVHZHw=28, addSort=False, VV1Jd7=VV1Jd7, VVd479=VVd479, VVNYAK=VVNYAK, VVKDDh=VVKDDh, VV7J8f=VV7J8f, VVJvWF=VVJvWF, VV65AN=True, searchCol=1, picParams=picParams, lastFindConfigObj=CFG.lastFindServices
     , VVZYdg=bg, VVcwfs=bg, VVLuY4=bg, VVG27K="#0a442200", borderWidth=0, VVGpiI="#11330000")
  tbl.VVKoPU(BF(self.VVsWK6, tbl), True)
  self.VVG1S9(tbl, bName, bRef)
 def VVQzoB(self, VVoLtS, mutableList, tot, jumpDict=None):
  if tot:
   if mutableList:
    mutableList.flushChanges()
   FFwQUx()
   rows = self.VVfXUy(VVoLtS.bouqRef)
   if rows:
    VVoLtS.VV14UF(False)
    VVoLtS.VVkYNn(rows, VVz586Msg=True, isSort=False, tableRefreshCB=BF(self.VVhOOi, jumpDict))
   else:
    self.VVSD9d()
    totTbl = len(self.bTables)
    FFycel(self.bTables[-1] if totTbl > 0 else self, "Empty List !", 1500)
  else:
   FFhcEU(VVoLtS, "No change !", 1500)
 def VVhOOi(self, jumpDict, VVoLtS, title, txt, colList):
  if jumpDict:
   VVoLtS.VVQ2Hx(jumpDict)
 def VVsWK6(self, VVoLtS):
  VVoLtS["keyRed"].hide()
  VVoLtS["keyBlue"].hide()
  if VVoLtS.VVzBSi:
   if VVoLtS.VVv3mu() > 0:
    VVoLtS["keyRed"].show()
    VVoLtS["keyBlue"].show()
  else:
   VVoLtS["keyRed"].show()
 def VVrO5i(self, VVoLtS, title, txt, colList):
  c1, c2, c3 = VVRJhR, VVAaU5, VVtz60
  ttl = lambda x, y, color=c1: "%s:\n%s\n\n" % (FFCzRx(x, color), y) if y else ""
  num, picon, name, ref, rem, flags, lck = colList
  path = CCPClU.VVvm6J(ref, mode=1)
  txt  = ttl("Name"    , name)
  txt += ttl("Bouquet File"  , path if path.startswith("/") else "")
  txt += ttl("Parent Bouquet"  , VVoLtS.bouqName, c2)
  txt += ttl("Parent Bouquet File", CCPClU.VVvm6J(VVoLtS.bouqRef, mode=1), c2)
  txt += ttl("Ref."    , ref, c3) if VVncAm else ""
  txt += ttl("Remarks"   , rem, c3) if VVncAm else ""
  path = CCxrlm.VVoQXZ(self.pPath, ref, name)
  FFp5JP(self, fncMode=CCoD37.EPG_MODE_BOUQUET_EDITOR, text=txt, picPath=path)
 def VVzwV5(self, VVoLtS, title, txt, colList):
  FFzW1w(VVoLtS, BF(self.VVbWOS, VVoLtS, colList) )
 def VVbWOS(self, VVoLtS, colList):
  maxLev = 2
  num, picon, name, ref, rem, flags, lck = colList
  if FFaD7A(ref):
   if len(self.bTables) <= maxLev:
    rows = self.VVfXUy(ref)
    if rows : self.VVwYJ7(VVoLtS, name, ref, rows)
    else : FFhcEU(VVoLtS, "Empty list !", 1500)
   else:
    FFzrXb(self, "Maximum Level of Recursive Bouquets (%d) !" % maxLev, title=self.Title)
  elif CCPClU.VVvUVE(ref) == 0:
   FFrvm6(self, ref, VViFts=False)
   FFKRQG(self, "Cancel to go back to table")
  else:
   FFycel(VVoLtS, "No action", 300)
 def VV1cD3(self, VVoLtS):
  if VVoLtS.VVzBSi:
   VVoLtS.VV14UF(False)
   self.VVsWK6(VVoLtS)
  else:
   self.VVSD9d()
 def VVak12(self, VVoLtS, title, txt, colList):
  VVMVqr = []
  iMulSel = VVoLtS.VVyLkw()
  sortItem = ("Sort", )
  if iMulSel:
   tot = VVoLtS.VVv3mu()
   if tot > 1: sortItem = ("Sort", "sort")
   isSel = tot > 0
   bTxt = "Bouquet%s" % FFoTxy(tot)
  else:
   isSel = True
   bTxt = "Bouquet"
  inMain = len(self.bTables) == 1
  okToMain = False
  if not inMain:
   for ref in self.VVEIxc(VVoLtS):
    if not FFaD7A(ref) and not ref.startswith("1:64:"): break
   else:
    okToMain = True
  totDel = len(self.VVLjGo())
  c1, c2, c3, c4 = VVAaU5, VVJS3b, VV61JF, VVtz60
  VVMVqr.append(FFwLFH("Rename"   , "renm" , not iMulSel, c1))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(FFwLFH("Add Marker"  , "mrkr" , not iMulSel, c2))
  VVMVqr.append(FFwLFH("Add Empty Bouquet", "addBouq" , not iMulSel and inMain, c2))
  if totDel:
   VVMVqr.append(VVpTvr)
   VVMVqr.append((c4 + 'Delete %d Unused ".del" Bouquets File%s' % (totDel, FFoTxy(totDel)), "unused"))
  if inMain:
   VVMVqr.append(VVpTvr)
   VVMVqr.append(FFwLFH("Hide %s" % bTxt , "hidOn" , isSel, c3))
   VVMVqr.append(FFwLFH("Unhide %s" % bTxt , "hidOff" , isSel, c3))
   VVMVqr.append(VVpTvr)
   VVMVqr.append(FFwLFH("Protect %s" % bTxt , "lckOn" , isSel, c3))
   VVMVqr.append(FFwLFH("Unprotect %s" % bTxt , "lckOff" , isSel, c3))
   VVZYdg, VVcwfs = "#22001122", "#22000a15"
  else:
   VVZYdg, VVcwfs = "#2200120a", "#2200120a"
  VVMVqr.append(VVpTvr)
  VVMVqr.append(sortItem)
  VVMVqr.append(FFwLFH("Copy to Main Bouquets List" , "toMain", okToMain))
  VVMVqr.append(FFwLFH("Copy to a Bouquet"   , "toBouq", isSel))
  cbFncDict = { "renm" : BF(self.VVCu5v  , VVoLtS)
     , "mrkr" : BF(self.VVr4Sa , VVoLtS)
     , "addBouq" : BF(self.VVHMSx, VVoLtS)
     , "unused" : BF(self.VV5IDd , VVoLtS)
     , "hidOn" : BF(self.VVhVGa  , VVoLtS, True)
     , "hidOff" : BF(self.VVhVGa  , VVoLtS, False)
     , "lckOn" : BF(self.VVa2JZ  , VVoLtS, True)
     , "lckOff" : BF(self.VVa2JZ  , VVoLtS, False)
     , "sort" : BF(self.VVyHMh  , VVoLtS)
     , "toMain" : BF(self.VVeE2U , VVoLtS)
     , "toBouq" : BF(self.VVn9WG , VVoLtS) }
  fnc = BF(self.VVsWK6, VVoLtS)
  mSel = CC74Cn(self, VVoLtS)
  mSel.VVKonP(VVMVqr, cbFncDict, okFnc=fnc, onMultiSelFnc=fnc, height=1000, VVZYdg=VVZYdg, VVcwfs=VVcwfs)
 def VVncok(self, VVoLtS, title, txt, colList):
  txt, totSel = "", 0
  if VVoLtS.VVyLkw():
   totSel = VVoLtS.VVv3mu()
   if totSel:
    txt = "Delete %s item%s" % (FFCzRx(str(totSel), VVRJhR), FFoTxy(totSel))
  else:
   num, picon, name, ref, rem, flags, lck = colList
   txt = "Delete : %s" % FFCzRx(name, VVRJhR)
  if txt:
   FFo4dm(self, BF(self.VVrG72, VVoLtS), "%s\n\nContinue ?" % txt, title=self.Title)
 def VVrG72(self, VVoLtS):
  FFzW1w(VVoLtS, BF(self.VVBoPx, VVoLtS))
 def VVBoPx(self, VVoLtS):
  lst, mutableList, csel, bServ = self.VVeqOh(VVoLtS)
  if mutableList is not None:
   tot = 0
   for ref in lst:
    serv = eServiceReference(ref)
    if serv.valid() and not mutableList.removeService(serv):
     tot += 1
     bFile = CCrfsB.VVGT0Q(ref)
     if bFile:
      bFile = VVTAUs + bFile
      FFgSm7("rm -f '%s' '%s.del'" % (bFile, bFile))
   self.VVQzoB(VVoLtS, mutableList, tot)
 def VVdavl(self, VVoLtS, title, txt, colList):
  FFzW1w(VVoLtS, BF(self.VVFEQB, VVoLtS))
 def VVFEQB(self, VVoLtS):
  lst, mutableList, csel, bServ = self.VVeqOh(VVoLtS)
  if mutableList is not None:
   curNdx = VVoLtS.VVqeSa()
   if curNdx <= VVoLtS.VVwg1G(): lst = reversed(lst)
   else             : curNdx -= 1
   tot = 0
   for ref in lst:
    serv = eServiceReference(ref)
    if serv.valid() and not mutableList.moveService(serv, curNdx):
     tot += 1
   self.VVQzoB(VVoLtS, mutableList, tot)
 def VVyHMh(self, VVoLtS):
  FFzW1w(VVoLtS, BF(self.VVN9Vp, VVoLtS))
 def VVN9Vp(self, VVoLtS):
  lst, mutableList, csel, bServ = self.VVeqOh(VVoLtS)
  if mutableList is not None:
   nmlst = VVoLtS.VVCtEG(2)
   lst = list(zip(nmlst, lst))
   lst.sort(key=lambda x: x[0].lower())
   curNdx = VVoLtS.VVwg1G()
   tot = 0
   for name, ref in reversed(lst):
    serv = eServiceReference(ref)
    if serv.valid() and not mutableList.moveService(serv, curNdx):
     tot += 1
   self.VVQzoB(VVoLtS, mutableList, tot)
 def VVCu5v(self, VVoLtS, item=None):
  name = VVoLtS.VVkHbA()[2]
  FFBgSg(self, BF(self.VVEu3g, VVoLtS), defaultText=name, title="Rename", message="Enter new name")
 def VVEu3g(self, VVoLtS, name):
  lst, mutableList, csel, bServ = self.VVeqOh(VVoLtS)
  if name and csel and mutableList:
   name = name.strip()
   if name:
    ref = VVoLtS.VVkHbA()[3]
    if FFaD7A(ref):
     CCrfsB.VVxaH6(ref, name)
    else:
     serv = eServiceReference(ref)
     if serv.valid():
      serv.setName(name)
      mutableList.removeService(serv)
      mutableList.addService(serv)
      mutableList.moveService(serv, VVoLtS.VVqeSa())
    self.VVQzoB(VVoLtS, mutableList, 1)
 def VVr4Sa(self, VVoLtS):
  name = "%s Marker %s" % ("=" * 7, "=" * 7)
  FFzW1w(VVoLtS, BF(self.VVKBTr, VVoLtS, name))
 def VVKBTr(self, VVoLtS, name):
  lst, mutableList, csel, bServ = self.VVeqOh(VVoLtS)
  if mutableList is not None:
   curServ = eServiceReference(VVoLtS.VVkHbA()[3])
   cnt = tot = 0
   while mutableList:
    serv = eServiceReference("1:64:%d:0:0:0:0:0:0:0::%s" % (cnt, name))
    if curServ and curServ.valid():
     if not mutableList.addService(serv, curServ):
      csel.servicelist.addService(serv, True)
      tot += 1
      break
    elif not mutableList.addService(serv):
     csel.servicelist.addService(serv, True)
     tot += 1
     break
    cnt += 1
   self.VVQzoB(VVoLtS, mutableList, tot)
 def VVHMSx(self, VVoLtS):
  names = VVoLtS.VVpQnT(2)
  name = "Bouquet-1"
  num = 0
  while name in names:
   num += 1
   name = "Bouquet-%s" % num
  FFBgSg(self, BF(self.VVj18s, VVoLtS), defaultText=name, title="New Bouquet", message="Enter Bouquet name")
 def VVj18s(self, VVoLtS, name=None):
  if name and name.strip():
   FFzW1w(VVoLtS, BF(self.VVf1qJ, VVoLtS, name.strip()))
 def VVf1qJ(self, VVoLtS, bName):
  CCrfsB.VVSSgW(bName)
  self.VVQzoB(VVoLtS, None, 1, jumpDict={2:bName})
 def VVLjGo(self):
  lst = []
  for fil in os.listdir(VVTAUs):
   if fil.endswith(".tv.del") or fil.endswith(".radio.del"):
    lst.append(fil)
  return lst
 def VV5IDd(self, VVoLtS):
  lst = self.VVLjGo()
  for fil in lst:
   FFnPMX(VVTAUs + fil)
  VVoLtS.VVOPq5("Done")
 def VVEIxc(self, VVoLtS):
  if VVoLtS.VVzBSi : return VVoLtS.VVCtEG(3)
  else        : return [VVoLtS.VVkHbA()[3]]
 def VVeE2U(self, VVoLtS):
  dstFile = "bouquets.%s" % ("tv" if CCPClU.VV2iJm() == 0 else "radio")
  FFzW1w(VVoLtS, BF(self.VV6Dn3, VVoLtS, "Main Bouquets List", dstFile, True))
 def VVn9WG(self, VVoLtS):
  bRows = CCrfsB.VVldUx()
  lst = self.VVEIxc(VVoLtS)
  VVMVqr = []
  for name, ref in bRows:
   if not ref in lst:
    VVMVqr.append((name, ref))
  if VVMVqr : FF7ARM(self,  BF(self.VVLGE1, VVoLtS), VVMVqr=VVMVqr, width=1100, height=900, VVZYdg="#22220000", VVcwfs="#22110000", title="Destination Bouquet", VVy9CS=True)
  else  : FFycel(VVoLtS, "No bouquets left !", 1000)
 def VVLGE1(self, VVoLtS, item=None):
  if item:
   bName, bRef, ndx = item
   dstFile = CCrfsB.VVGT0Q(bRef)
   FFzW1w(VVoLtS, BF(self.VV6Dn3, VVoLtS, bName, dstFile))
 def VV6Dn3(self, VVoLtS, bName, dstFile, mainToo=False):
  lst = self.VVEIxc(VVoLtS)
  tot = 0
  for ref in lst:
   ok = CCrfsB.VVt6zw(ref, dstFile)
   if ok:
    tot += 1
  self.VVQzoB(VVoLtS, None, tot)
  if mainToo:
   rootStr = CCPClU.VVgyL6()
   rows = self.VVfXUy(rootStr)
   self.bTables[0].VVkYNn(rows, VVz586Msg=True)
  ttl = lambda x, y: "%s:\n%s\n\n" % (FFCzRx(x, VV61JF), y)
  txt  = ttl("Source Bouquet"  , VVoLtS.bouqName)
  txt += ttl("Destination Bouquet", bName)
  txt += ttl("Copied Services" , tot)
  FFtybv(VVoLtS, txt, title="Copy Services")
 def VVhVGa(self, VVoLtS, isHide):
  FFzW1w(VVoLtS, BF(self.VVMzDp, VVoLtS, isHide))
 def VVMzDp(self, VVoLtS, isHide):
  lst, mutableList, csel, bServ = self.VVeqOh(VVoLtS)
  mode = CCPClU.VV2iJm()
  path = VVTAUs + "bouquets.%s" % ("tv" if mode==0 else "radio")
  if fileExists(path):
   tot = 0
   lines = list(map(str.strip, FF2WPS(path)))
   for ref in lst:
    if FFaD7A(ref):
     ref = "#SERVICE " + ref
     nrm = ref.replace("1:519:", "1:7:")
     hid = ref.replace("1:7:"  , "1:519:")
     if isHide: r1, r2 = nrm, hid
     else  : r1, r2 = hid, nrm
     if r1 in lines:
      ndx = lines.index(r1)
      lines[ndx] = r2
      tot += 1
   if tot:
    with open(path, "w") as f:
     for line in lines:
      f.write("%s\n" % line)
    self.VVQzoB(VVoLtS, None, tot)
 def VVa2JZ(self, VVoLtS, isLck):
  FFzW1w(VVoLtS, BF(self.VVCvoc, VVoLtS, isLck))
 def VVCvoc(self, VVoLtS, isLck):
  lst, mutableList, csel, bServ = self.VVeqOh(VVoLtS)
  blkLst = CCPClU.VVI4bc()
  tot = 0
  for ref in lst:
   if FFaD7A(ref):
    ndx = CCPClU.VV1YEv(ref, blkLst)
    if isLck:
     if ndx == -1:
      ref = ref.replace("1:519:", "1:0:").replace("1:7:", "1:0:")
      blkLst.append(ref)
      tot += 1
    else:
     if ndx > -1:
      blkLst[ndx] = ""
      tot += 1
  if tot:
   with open(VVz9hY, "w") as f:
    for line in blkLst:
     if line.strip():
      f.write("%s\n" % line)
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   self.VVQzoB(VVoLtS, None, tot)
 def VVeqOh(self, VVoLtS, bServ=None):
  lst = self.VVEIxc(VVoLtS)
  mutableList = csel = None
  VV8OMp = InfoBar.instance
  if VV8OMp:
   csel = VV8OMp.servicelist
   if csel:
    if not bServ:
     bServ = eServiceReference(VVoLtS.bouqRef)
    if bServ.valid():
     mutableList = csel.getMutableList(bServ)
  return lst,  mutableList, csel, bServ
 def VVEnGT(self, colList):
  num, picon, name, ref, rem, flags, lck = colList
  png = lambda x: "%s%s.png" % (VVLS8v, x)
  if   rem == "Marker"   : return png("mrk1")
  elif rem == "Numbered Marker" : return png("mrk2")
  elif rem == "Group"    : return png("grp")
  elif FFaD7A(ref):
   if   lck == "1" and rem == "Invisible" : return png("dirLckInvis")
   elif lck == "1"       : return png("dirLck")
   elif rem == "Invisible"     : return png("dirInvis")
   else         : return png("dir1")
  else:
   return CCxrlm.VVoQXZ(self.pPath, ref, name)
 @staticmethod
 def VV4J3z(flag):
  t = c = ""
  try:
   if   flag & eServiceReference.isInvisible  : t, c = "Invisible"  , "#f#00ff7722#"
   elif flag & eServiceReference.isNumberedMarker : t, c = "Numbered Marker" , "#f#00ffffaa#"
   elif flag & eServiceReference.isGroup   : t, c = "Group"   , "#f#00bbffbb#"
   elif flag & eServiceReference.isMarker   : t, c = "Marker"   , "#f#00ffffaa#"
   elif flag & eServiceReference.isDirectory  : t, c = "Directory"  , ""
  except:
   pass
  return t, c
 @staticmethod
 def VVvm6J(ref, mode=0):
  path = ""
  serv = eServiceReference(ref)
  if serv.valid():
   path = serv.getPath()
   if path and not VVncAm:
    path = iSub(r"[&?]mode=.+end=", r"", path, flags=IGNORECASE)
   if mode == 1:
    span = iSearch(r'FROM\s+BOUQUET\s+"(.+)"\s+ORDER\s+BY\s+bouquet', path, IGNORECASE)
    if span:
     path = VVTAUs + span.group(1)
  return path
 @staticmethod
 def VVvUVE(ref):
  path = ""
  serv = eServiceReference(ref)
  if serv.valid():
   return serv.flags
  return -1
 @staticmethod
 def VV2iJm(default=0):
  VV8OMp = InfoBar.instance
  if VV8OMp:
   csel = VV8OMp.servicelist
   if csel:
    return csel.mode
  return default
 @staticmethod
 def VVgyL6():
  VV8OMp = InfoBar.instance
  if VV8OMp:
   csel = VV8OMp.servicelist
   if csel:
    return csel.bouquet_rootstr
  return ""
 @staticmethod
 def VVI4bc():
  return FF2WPS(VVz9hY) if fileExists(VVz9hY) else []
 @staticmethod
 def VV1YEv(ref, lst=None):
  if not lst:
   lst = CCPClU.VVI4bc()
  if FFaD7A(ref):
   ref1 = ref.replace("1:7:", "1:0:")
   ref2 = ref.replace("1:519:", "1:0:")
   if   ref1 in lst: return lst.index(ref1)
   elif ref2 in lst: return lst.index(ref2)
  return -1
class CCxrlm(Screen, CCnMHH, CCaV2Y):
 VViH8C   = 0
 VV1xsP  = 1
 VVIXfW  = 2
 VVsHfU  = 3
 VVjZnK  = 4
 VV9HR1  = 5
 VV87x2  = 6
 VVv3bP  = 7
 VV8gK8 = 8
 VVbEg5 = 9
 VVWIMm = 10
 VVllZ4 = 11
 def __init__(self, session):
  self.skin, self.skinParam = FF5TEn(VVikgj, 1400, 840, 30, 0, 0, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "PIcons Tools"
  self.pPath    = CCxrlm.VVjBFN()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVWsIU    = []
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastTimeStamp  = 0
  self.lastSTypeList  = 0
  self.lastFind   = ""
  self.filterTitle  = ""
  FF32Yx(self, self.Title)
  FFCDDm(self["keyRed"] , "OK = Zap")
  FFCDDm(self["keyGreen"] , "Current Service")
  FFCDDm(self["keyYellow"], "Page Options")
  FFCDDm(self["keyBlue"] , "Filter")
  CCnMHH.__init__(self, 5, 7, CFG.transpColorPicons)
  CCaV2Y.__init__(self)
  self["myAction"].actions.update(
  {
   "ok"  : self.VVJCsC     ,
   "green"  : self.VVG95q    ,
   "yellow" : self.VVHUbo     ,
   "blue"  : self.VVG7c6     ,
   "menu"  : self.VVXW9h     ,
   "info"  : self.VV7iVp    ,
   "pageUp" : BF(self.VVb7qi, True) ,
   "chanUp" : BF(self.VVb7qi, True) ,
   "pageDown" : BF(self.VVb7qi, False) ,
   "chanDown" : BF(self.VVb7qi, False) ,
   "0"   : self.VVpUyB  ,
   "cancel" : self.close
  })
  self.onShown.append(self.VVSDD3)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  FFDoNq(self)
  FFieY3(self)
  FFzBm8(self["keyRed"], "#0a333333")
  self.VVrPH5()
  FFzW1w(self, BF(self.VVRW8u, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVXW9h(self):
  if not self.isBusy:
   VVMVqr = []
   VVMVqr.append(("Statistics"           , "VVrlkV"    ))
   VVMVqr.append(VVpTvr)
   VVMVqr.append(("Suggest PIcons for Current Channel"     , "VVOtTs"   ))
   VVMVqr.append(("Set to Current Channel (copy file)"     , "VVQMFn_file"  ))
   VVMVqr.append(("Set to Current Channel (as SymLink)"     , "VVQMFn_link"  ))
   VVMVqr.append(VVpTvr)
   VVMVqr.append(("Export Current File Names List"      , "VVBP7j" ))
   VVMVqr.append(CCxrlm.VV6haG())
   VVMVqr.append(VVpTvr)
   c, cond = VVszO3, self.filterTitle == "PIcons without Channels"
   VVMVqr.append(FFwLFH("Move Unused PIcons to a Directory", "VVRO4z" , cond, c))
   VVMVqr.append(FFwLFH("DELETE Unused PIcons"    , "VVMZUR" , cond, c))
   VVMVqr.append(VVpTvr)
   VVMVqr.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVZrjj"  ))
   VVMVqr.append(VVpTvr)
   VVMVqr += CCxrlm.VVvOz2()
   VVMVqr.append(VVpTvr)
   VVMVqr.append(("Change Poster/Picon Transparency Color"    , "VVvrFK" ))
   VVMVqr.append(("Keys Help"           , "VV9tmQ"    ))
   FF7ARM(self, self.VVmouG, width=1100, height=1050, title=self.Title, VVMVqr=VVMVqr)
 def VVmouG(self, item=None):
  if item is not None:
   if   item == "VVrlkV"    : self.VVrlkV()
   elif item == "VVOtTs"   : self.VVOtTs()
   elif item == "VVQMFn_file"  : self.VVQMFn(0)
   elif item == "VVQMFn_link"  : self.VVQMFn(1)
   elif item == "VVBP7j"  : self.VVBP7j()
   elif item == "VV4loV"  : CCxrlm.VV4loV(self)
   elif item == "VVRO4z"   : self.VVRO4z()
   elif item == "VVMZUR"  : self.VVMZUR()
   elif item == "VVZrjj"  : self.VVZrjj()
   elif item == "VVHmS7"  : CCxrlm.VVHmS7(self)
   elif item == "findPiconBrokenSymLinks" : CCxrlm.VVzMRY(self, True)
   elif item == "FindAllBrokenSymLinks" : CCxrlm.VVzMRY(self, False)
   elif item == "VVvrFK" : self.VVvrFK()
   elif item == "VV9tmQ"     : FFGkYk(self, "_help_picons", "PIcons Tools (Keys Help)")
 def VVHUbo(self):
  if not self.isBusy:
   VVMVqr = []
   VVMVqr.append(("Go to First PIcon"  , "VVJ6ng"  ))
   VVMVqr.append(("Go to Last PIcon"   , "VVia7k"  ))
   VVMVqr.append(VVpTvr)
   VVMVqr.append(("Sort by Channel Name"     , "sortByChan" ))
   VVMVqr.append(("Sort by File Name"  , "sortByFile" ))
   VVMVqr.append(VVpTvr)
   VVMVqr.append(("Find from File List .." , "VV6QYH" ))
   FF7ARM(self, self.VVdzOW, title=self.Title, VVMVqr=VVMVqr)
 def VVdzOW(self, item=None):
  if item is not None:
   if   item == "VVJ6ng"   : self.VVJ6ng()
   elif item == "VVia7k"   : self.VVia7k()
   elif item == "sortByChan"  : self.VVtihu(2)
   elif item == "sortByFile"  : self.VVtihu(0)
   elif item == "VV6QYH"  : self.VV6QYH()
 def VV6QYH(self):
  VVMVqr = []
  for item in self.VVWsIU:
   VVMVqr.append((item[0], item[0]))
  FF7ARM(self, self.VVupeZ, title='PIcons ".png" Files', VVMVqr=VVMVqr, VVy9CS=True)
 def VVupeZ(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VV4BdY(ndx)
 def VVJCsC(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVC3nS()
   if refCode:
    FFrvm6(self, refCode)
    self.VVtrhL()
    self.VV19lw()
 def VVb7qi(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVtrhL()
   self.VV19lw()
  except:
   pass
 def VVG95q(self):
  if self["keyGreen"].getVisible():
   self.VV4BdY(self.curChanIndex)
 def VVtihu(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFzW1w(self, BF(self.VVRW8u, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVQMFn(self, mode):
  title = "Change Current Channel PIcon"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFmvpz(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVC3nS()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVMVqr = []
     VVMVqr.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVMVqr.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FF7ARM(self, BF(self.VV5XNA, mode, curChF, selPiconF), VVMVqr=VVMVqr, title="Current Channel PIcon (already exists)")
    else:
     self.VV5XNA(mode, curChF, selPiconF, "overwrite")
   else:
    FFzrXb(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFzrXb(self, "Could not read current channel info. !", title=title)
 def VV5XNA(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   FFgSm7(cmd)
   FFzW1w(self, BF(self.VVRW8u, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVRO4z(self):
  defDir = FF5DjF(CCxrlm.VVjBFN() + "picons_backup")
  FFgSm7("mkdir '%s'" % defDir)
  self.session.openWithCallback(BF(self.VVZIKo, defDir), BF(CCUGPF
         , mode=CCUGPF.VVGIMp, VVRawy=CCxrlm.VVjBFN()))
 def VVZIKo(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CCxrlm.VVjBFN():
    FFzrXb(self, "Cannot move to same directory !", title=title)
   else:
    if not FF5DjF(path) == FF5DjF(defDir):
     self.VVYF4H(defDir)
    FFo4dm(self, BF(FFzW1w, self, BF(self.VVsJiM, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VVWsIU), path), title=title)
  else:
   self.VVYF4H(defDir)
 def VVsJiM(self, title, defDir, toPath):
  if not iMove:
   self.VVYF4H(defDir)
   FFzrXb(self, "Module not found:\n\nshutil", title=title)
   return
  toPath = FF5DjF(toPath)
  pPath = CCxrlm.VVjBFN()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VVWsIU:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VVWsIU)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FFtybv(self, txt, title=title, VVLuY4="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VVhByN("all")
 def VVYF4H(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VVMZUR(self):
  title = "Delete Unused PIcons"
  tot = len(self.VVWsIU)
  FFo4dm(self, BF(FFzW1w, self, BF(self.VVnwCo, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, FFoTxy(tot)), title=title)
 def VVnwCo(self, title):
  pPath = CCxrlm.VVjBFN()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VVWsIU:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VVWsIU)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FFCzRx(str(totErr), VVtz60)
  FFtybv(self, txt, title=title)
 def VVZrjj(self):
  lines = FFSInC("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   FFo4dm(self, BF(self.VVpirA, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, FFoTxy(tot)), VVxcAw=True)
  else:
   FFuXZg(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVpirA(self, fList):
  FFgSm7("find -L '%s' -type l -delete" % self.pPath)
  FFuXZg(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VV7iVp(self):
  FFzW1w(self, self.VVomRj)
 def VVomRj(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVC3nS()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFCzRx("PIcon Directory:\n", VVAaU5)
   txt += "  Path\t: %s\n"  % self.pPath
   target = FF964d(self.pPath)
   if target:
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FF964d(path)
   txt += FFCzRx("PIcon File:\n", VVAaU5)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   slLst = []
   if not os.path.islink(path):
    OrigRealPath = os.path.realpath(path)
    for fName in os.listdir(self.pPath):
     fPath = os.path.join(self.pPath, fName)
     if os.path.islink(fPath):
      fRealPath = os.path.realpath(fPath)
      if fRealPath == OrigRealPath:
       slLst.append(fRealPath)
    if slLst:
     tot = len(slLst)
     txt += FFCzRx("Found %d SymLink%s to this file from:\n" % (tot, FFoTxy(tot)), VVAaU5)
     for fPath in slLst:
      txt += "  %s\n" % FFCzRx(fPath, VVzv5p)
     txt += "\n"
   if chName:
    txt += FFCzRx("Channel:\n", VVAaU5)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFCzRx(chName, VVXF4f)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not slLst:
    txt += FFCzRx("Remarks:\n", VVAaU5)
    txt += "  %s\n" % FFCzRx("Unused", VVtz60)
  else:
   txt = "No info found"
  FFp5JP(self, fncMode=CCoD37.VVdXsX, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VVC3nS(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalItems:
   fName, fType, chName, sat, inDB = self.VVWsIU[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFhPna(sat)
  return fName, refCode, chName, sat, inDB
 def VVtrhL(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFmvpz(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVWsIU):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VV19lw(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVC3nS()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalItems)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFCzRx("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVAaU5))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVC3nS()[1]))
  if self.curChanIptvRef : typ = "Stream Relay" if FFYKlk(self.curChanIptvRef) else "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFCzRx(self.curChanName, VVRJhR)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
  filName, refCode, chName, sat, inDB = self.VVC3nS()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVrlkV(self):
  VV9tU5, VVRXrA = FFs2e5()
  sTypeNameDict = {}
  for key, val in VVRXrA.items():
   sTypeNameDict[key] = 0
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  totNoRefCode = 0
  totNoSType  = 0
  sTypeDict  = {}
  for fName, fType, chName, sat, inDB in self.VVWsIU:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
   span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
   if span:
    stNum = int(span.group(1), 16)
    if stNum in VVRXrA: sTypeDict[VVRXrA[stNum]] = sTypeDict.get(VVRXrA[stNum], 0) + 1
    else     : totNoSType += 1
   else:
    totNoRefCode += 1
  totBrokSL = FFwTnb("find -L '%s' -type l -print | wc -l" % self.pPath)
  VVpn2v = []
  c = "#b#11003333#"
  VVpn2v.append((c + "PIcons" , "%d\tUsed = %s" % (self.totalItems, totUsedFiles + totUsedLinks)))
  VVpn2v.append((c + "Files" , "%d\tUsed = %s" % (self.totalItems - totSymLinks, totUsedFiles)))
  VVpn2v.append((c + "SymLinks" , "%d\tUsed = %s" % (totSymLinks, totUsedLinks)))
  c = "#b#11004040#"
  VVpn2v.append((c + "In Database (lamedb)"  , str(totInDB)))
  VVpn2v.append((c + "Not In Database (lamedb)" , str(self.totalItems - totInDB)))
  VVpn2v.append((c + "Satellites"    , str(len(self.nsList))))
  VVpn2v.append((c + "Broken SymLinks"   , str(totBrokSL)))
  if totNoRefCode : VVpn2v.append((c + "File name is not a Reference Code" , str(totNoRefCode)))
  if totNoSType : VVpn2v.append((c + "Unknown Service Type"    , str(totNoSType)))
  s = "Service Type "
  if sTypeDict:
   sTypeRows = []
   for key, val in sTypeDict.items():
    sTypeRows.append(("Service Type (%s)" % key, str(val)))
   sTypeRows.sort(key=lambda x: x[0].lower())
   VVpn2v.extend(sTypeRows)
  FFldB6(self, None, title=self.Title, VVWsIU=VVpn2v, VVHZHw=28, VVG27K="#00003333", VVQ9hc="#00222222")
 def VVBP7j(self):
  if self.filterTitle:
   txt = iSub(r"([^a-zA-Z0-9])", r"_", self.filterTitle, flags=IGNORECASE)
   while "__" in txt: txt = txt.replace("__", "_")
   txt = "FilteredBy_%s_" % txt.strip("_")
  else:
   txt = "All_"
  path = "%sPIconsList_%s%s.txt" % (FF5DjF(CFG.exportedTablesPath.getValue()), txt, FF4rM4())
  with open(path, "w") as f:
   for fName, fType, chName, sat, inDB in self.VVWsIU:
    f.write("%s%s.png\n" % (self.pPath, fName))
  FFuXZg(self, "List exported to file:\n\n%s" % path, title=self.Title)
 def VVG7c6(self):
  if not self.isBusy:
   VVMVqr = []
   VVMVqr.append(("All"        , "all"  ))
   VVMVqr.append(VVpTvr)
   VVMVqr.append(("Used by Channels"     , "used" ))
   VVMVqr.append(("Unused PIcons"     , "unused" ))
   VVMVqr.append(("IPTV PIcons"      , "iptv" ))
   VVMVqr.append(VVpTvr)
   VVMVqr.append(("PIcons Files"      , "pFiles" ))
   VVMVqr.append(("SymLinks to PIcons"    , "pLinks" ))
   VVMVqr.append(("PIcons Files Targeted by SymLinks", "pTargets"))
   VVMVqr.append(("By Files Date ..."    , "pDate" ))
   VVMVqr.append(("By Service Type ..."    , "servType"))
   if self.nsList:
    VVMVqr.append(FFfdOi("Satellites"))
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFjpbV(val)
      VVMVqr.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCOe8b(self)
   filterObj.VViYlv(VVMVqr, self.nsList, self.VVtiEb)
 def VVtiEb(self, item=None):
  if item is not None:
   self.VVhByN(item)
 def VVhByN(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VViH8C   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VV1xsP   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVIXfW  , ""  , "PIcons without Channels"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VV87x2   , "iptv" , "IPTV PIcons"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVsHfU  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVjZnK  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VV9HR1  , ""  , "Targets"
   elif item == "pDate"   : mode, words, self.filterTitle = self.VVWIMm , ""  , "Date"
   elif item == "servType"   : mode, words, self.filterTitle = self.VVllZ4 , ""  , "Service Type"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVv3bP   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VV8gK8 , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VV9HR1:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFSInC("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = FFZ5fy(f)
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFycel(self, "Not found", 1000)
     return
   elif mode == self.VVWIMm:
    self.VVY0wq(mode)
    return
   elif mode == self.VVllZ4:
    self.VVWZCI(mode)
    return
   elif mode == self.VVbEg5:
    return
   else:
    words, asPrefix = CCOe8b.VVjxXj(words)
   if not words and mode in (self.VVv3bP, self.VV8gK8):
    FFycel(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFzW1w(self, BF(self.VVRW8u, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVY0wq(self, mode):
  VVMVqr = []
  VVMVqr.append(("Today"   , "today" ))
  VVMVqr.append(("Since Yesterday" , "yest" ))
  VVMVqr.append(("Since 7 days"  , "week" ))
  FF7ARM(self, BF(self.VV81kL, mode), VVMVqr=VVMVqr, title="Filter by Added/Modified Date")
 def VV81kL(self, mode, item=None):
  if item:
   if   item == "today": stamp, self.filterTitle = FFAj3k(0) , "Today"
   elif item == "yest" : stamp, self.filterTitle = FFAj3k(-1), "Yesterday"
   elif item == "week" : stamp, self.filterTitle = FFAj3k(-7), "Last 7 Days"
   self.filterTitle = "File Date (%s)" % self.filterTitle
   if not self.lastMode == mode or not self.lastTimeStamp == stamp:
    FFzW1w(self, BF(self.VVRW8u, mode=mode, timeStamp=stamp), title="Filtering ...", clearMsg=False)
 def VVWZCI(self, mode):
  VV9tU5, VVRXrA = FFs2e5()
  lst = set()
  for key, val in VVRXrA.items():
   lst.add(val)
  VVMVqr = []
  for item in lst:
   VVMVqr.append((item, item))
  VVMVqr.sort(key=lambda x: x[0])
  FF7ARM(self, BF(self.VVHHO7, mode), VVMVqr=VVMVqr, title="Filter by Service Type")
 def VVHHO7(self, mode, item=None):
  if item:
   VV9tU5, VVRXrA = FFs2e5()
   sTypeList = []
   for key, val in VVRXrA.items():
    if item == val:
     self.filterTitle = val
     sTypeList.append(("%01x" % key).upper())
   if not self.lastMode == mode or not self.lastSTypeList == sTypeList:
    FFzW1w(self, BF(self.VVRW8u, mode=mode, sTypeList=sTypeList), title="Filtering ...", clearMsg=False)
 def VVOtTs(self):
  self.session.open(CCSCNk, barTheme=CCSCNk.VV7KPr
      , titlePrefix = ""
      , fncToRun  = self.VVKbjE
      , VVEStC = self.VVEIG7)
 def VVKbjE(self, VV2ohY):
  VVAv8X, err = CCh3Pq.VVM6i7(self, CCh3Pq.VVPia1, VVkOYc=False, VVLya0=False)
  files = []
  words = []
  if not VV2ohY or VV2ohY.isCancelled:
   return
  VV2ohY.VVRTV9 = []
  VV2ohY.VVHJ4P(len(VVAv8X))
  if VVAv8X:
   curCh = self.VV5ZIs(self.curChanName)
   for refCode in VVAv8X:
    if not VV2ohY or VV2ohY.isCancelled:
     return
    VV2ohY.VVc1xD(1, True)
    chName, sat, inDB = VVAv8X.get(refCode, ("", "", 0))
    ratio = CCxrlm.VV90Gn(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCxrlm.VVjdnd(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = FFZ5fy(f)
       fil = f.replace(".png", "")
       if not fil in VV2ohY.VVRTV9:
        VV2ohY.VVRTV9.append(fil)
 def VVEIG7(self, VVPnF9, VVRTV9, threadCounter, threadTotal, threadErr):
  if VVRTV9 : FFzW1w(self, BF(self.VVRW8u, mode=self.VVbEg5, words=VVRTV9), title="Loading ...")
  else   : FFycel(self, "Not found", 2000)
 def VVRW8u(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True, timeStamp=None, sTypeList=None):
  if not self.VVxZaQ(isFirstTime):
   return
  self.isBusy = True
  VVLya0 = True if isFirstTime else False
  VVAv8X, err = CCh3Pq.VVM6i7(self, CCh3Pq.VVPia1, VVkOYc=False, VVLya0=VVLya0)
  if err:
   self.close()
  iptvRefList = self.VViKIm()
  tList = []
  for fName, fType in CCxrlm.VVVwfb(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and VVAv8X:
    if fName in VVAv8X:
     chName, sat, inDB = VVAv8X.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VViH8C:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VV1xsP  and chName         : isAdd = True
   elif mode == self.VVIXfW and not chName        : isAdd = True
   elif mode == self.VVsHfU  and fType == 0        : isAdd = True
   elif mode == self.VVjZnK  and fType == 1        : isAdd = True
   elif mode == self.VV9HR1  and fName in words       : isAdd = True
   elif mode == self.VVbEg5 and fName in words       : isAdd = True
   elif mode == self.VV87x2  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVv3bP  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VV8gK8:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   elif mode == self.VVWIMm:
    try:
     if os.stat("%s%s.png" % (self.pPath, fName)).st_ctime >= timeStamp   : isAdd = True
    except:
     pass
   elif mode == self.VVllZ4:
    span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
    if span and span.group(1) in sTypeList           : isAdd = True
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVWsIU   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   self.lastTimeStamp = timeStamp
   self.lastSTypeList = sTypeList
   FFycel(self)
  else:
   self.isBusy = False
   FFycel(self, "Not found", 1000)
   return
  self.VVWsIU.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVtrhL()
  self.totalItems = len(self.VVWsIU)
  self.totalPages = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self.isBusy = False
  self.VV0Itx(True)
 def VVxZaQ(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCxrlm.VVVwfb(self.pPath):
    if fName:
     return True
   if isFirstTime : FFzrXb(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFycel(self, "Not found", 1000)
  else:
   FFzrXb(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VViKIm(self):
  VVpn2v = {}
  files  = CCfw0y.VVvkN7()
  if files:
   for path in files:
    txt = FFpCvR(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVpn2v[refCode] = item[1]
  return VVpn2v
 def VV2mlZ(self):
  self.VV8GvX()
  f1, f2 = self.VV1RWd()
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVWsIU[ndx]
   fName = self.VVWsIU[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   if CCnMHH.VVQQ8t(pic, path) : color = VVXF4f if inDB else ""
   elif not chName           : color = ""
   else             : color = VVMVIx
   self.VVwv4c(lbl, chName or "-", color)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VV90Gn(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VV6haG():
  return ("Copy Current Channel PIcon (to PIcons Export Path)", "VV4loV")
 @staticmethod
 def VVvOz2():
  VVMVqr = []
  VVMVqr.append(("Find SymLinks (to PIcon Directory)"   , "VVHmS7"  ))
  VVMVqr.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks" ))
  VVMVqr.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks" ))
  return VVMVqr
 @staticmethod
 def VV4loV(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFmvpz(SELF)
  png, path = CCxrlm.VV9eBq(refCode)
  if path : CCxrlm.VVKLHi(SELF, png, path)
  else : FFzrXb(SELF, "No PIcon found for current channel in:\n\n%s" % CCxrlm.VVjBFN())
 @staticmethod
 def VVHmS7(SELF):
  if VVRJhR:
   sed1 = FFC7pV("->", VVRJhR)
   sed2 = FFC7pV("picon", VVtz60)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVMVIx, VViypC)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFK0Ik(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFWdDQ(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVzMRY(SELF, isPIcon):
  sed1 = FFC7pV("->", VVMVIx)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFC7pV("picon", VVtz60)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFK0Ik(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFWdDQ(), grep, sed1, sed2))
 @staticmethod
 def VVKLHi(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFC7pV("%s%s" % (dest, png), VVXF4f))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFC7pV(errTxt, VVfMEC))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFH2jW(SELF, cmd)
 @staticmethod
 def VVVwfb(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVjBFN():
  path = CFG.PIconsPath.getValue()
  return FF5DjF(path)
 @staticmethod
 def VV9eBq(refCode, chName=None):
  if FF3dcV(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFAE0u(refCode)
  allPath, fName, refCodeFile, pList = CCxrlm.VVjdnd(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return "", ""
 @staticmethod
 def VVoQXZ(pPath, refCode, chName):
  span = iSearch(r"^((?:[A-Fa-f0-9]+:){10})", refCode.strip())
  if span:
   exts = ("png", "jpg")
   refCode = span.group(1).rstrip(":").replace(":", "_")
   tPath = "%s%s." % (pPath, refCode)
   for ext in exts:
    path = tPath + ext
    if fileExists(path):
     return path
   refParts = refCode.split("_", 1)
   for rType in CCfw0y.VVpEpL():
    if not rType == refParts[0]:
     for ext in exts:
      path = "%s%s_%s.%s" %  (pPath, rType, refParts[1], ext)
      if fileExists(path):
       return path
   chName = FFQdrB(chName)
   chName1 = chName.replace(" ", "")
   for name in (chName, chName.lower(), chName.upper(), chName1.lower(), chName1.upper()):
    for ext in exts:
     path = "%s%s.%s" % (pPath, name, ext)
     if fileExists(path):
      return path
  return ""
 @staticmethod
 def VVjdnd(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   fName = fName.rstrip(":")
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCxrlm.VVjBFN()
   pList = []
   lst = FFY7QR(allPath, "*_" + "_".join(fName.split("_")[3:]))
   if lst:
    pList += lst
   if chName:
    chName = FFQdrB(chName)
    path = allPath + chName + ".png"
    if fileExists(path):
     pList.append(chName + ".png")
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == FFZ5fy(item):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCnDpI():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVQ6aZ  = None
  self.VVyHUy = ""
  self.VVAf6a  = noService
  self.VVhxt0 = 0
  self.VVhnWd  = noService
  self.VVDlU4 = 0
  self.VVzskH  = "-"
  self.VVtQfZ = 0
  self.VVHe3W  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVrsur(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVQ6aZ = frontEndStatus
     self.VVSwhL()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVSwhL(self):
  if self.VVQ6aZ:
   val = self.VVQ6aZ.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVyHUy = "%3.02f dB" % (val / 100.0)
   else         : self.VVyHUy = ""
   val = self.VVQ6aZ.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVhxt0 = int(val)
   self.VVAf6a  = "%d%%" % val
   val = self.VVQ6aZ.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVDlU4 = int(val)
   self.VVhnWd  = "%d%%" % val
   val = self.VVQ6aZ.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVzskH  = "%d" % val
   val = int(val * 100 / 500)
   self.VVtQfZ = min(500, val)
   val = self.VVQ6aZ.get("tuner_locked", 0)
   if val == 1 : self.VVHe3W = "Locked"
   else  : self.VVHe3W = "Not locked"
 def VVQbcc(self)   : return self.VVyHUy
 def VVBLNo(self)   : return self.VVAf6a
 def VVQCCu(self)  : return self.VVhxt0
 def VVj6jA(self)   : return self.VVhnWd
 def VVw713(self)  : return self.VVDlU4
 def VVgAAh(self)   : return self.VVzskH
 def VVQ6G7(self)  : return self.VVtQfZ
 def VVWJd3(self)   : return self.VVHe3W
 def VVba7A(self) : return self.serviceName
class CC9Nee():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVcHQD(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFUMuc(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVaW3Q(self.ORPOS  , mod=1   )
      self.sat2  = self.VVaW3Q(self.ORPOS  , mod=2   )
      self.freq  = self.VVaW3Q(self.FREQ  , mod=3   )
      self.sr   = self.VVaW3Q(self.SR   , mod=4   )
      self.inv  = self.VVaW3Q(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVaW3Q(self.POL  , self.D_POL )
      self.fec  = self.VVaW3Q(self.FEC  , self.D_FEC )
      self.syst  = self.VVaW3Q(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVaW3Q("modulation" , self.D_MOD )
       self.rolof = self.VVaW3Q("rolloff"  , self.D_ROLOF )
       self.pil = self.VVaW3Q("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVaW3Q("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVaW3Q("pls_code"  )
       self.iStId = self.VVaW3Q("is_id"   )
       self.t2PlId = self.VVaW3Q("t2mi_plp_id" )
       self.t2PId = self.VVaW3Q("t2mi_pid"  )
 def VVaW3Q(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFjpbV(val)
  elif mod == 2   : return FFZbc3(val)
  elif mod == 3   : return str(int(val) // 1000)
  elif mod == 4   : return str(int(val) // 1000)
  else     : return str(val)
 def VVBCQT(self, refCode):
  txt = ""
  self.VVcHQD(refCode)
  if self.data:
   def VVchnh(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVchnh("System"   , self.syst)
    txt += VVchnh("Satellite"  , self.sat2)
    txt += VVchnh("Frequency"  , self.freq)
    txt += VVchnh("Inversion"  , self.inv)
    txt += VVchnh("Symbol Rate"  , self.sr)
    txt += VVchnh("Polarization" , self.pol)
    txt += VVchnh("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVchnh("Modulation" , self.mod)
     txt += VVchnh("Roll-Off" , self.rolof)
     txt += VVchnh("Pilot"  , self.pil)
     txt += VVchnh("Input Stream", self.iStId)
     txt += VVchnh("T2MI PLP ID" , self.t2PlId)
     txt += VVchnh("T2MI PID" , self.t2PId)
     txt += VVchnh("PLS Mode" , self.plsMod)
     txt += VVchnh("PLS Code" , self.plsCod)
   else:
    txt += VVchnh("System"   , self.txMedia)
    txt += VVchnh("Frequency"  , self.freq)
  return txt, self.namespace
 def VVibqX(self, refCode):
  txt = "Transpoder : ?"
  self.VVcHQD(refCode)
  tpTxt = "?"
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s" % (self.freq, self.pol[:1], self.fec, self.sr)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return tpTxt, self.sat2
 def VVsUQe(self, refCode):
  if refCode and refCode.count(":") > 8: servRef = eServiceReference(refCode)
  else         : servRef = None
  self.data = None
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFUMuc(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVaW3Q(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVaW3Q(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVaW3Q(self.SYST, self.D_SYS_S)
     freq = self.VVaW3Q(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVaW3Q(self.POL , self.D_POL)
      fec = self.VVaW3Q(self.FEC , self.D_FEC)
      sr = self.VVaW3Q(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVnM6L(self, refCode):
  self.data = None
  self.VVcHQD(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCH94c():
 def __init__(self, VV6j4q, path, VVEStC=None, curRowNum=-1):
  self.VV6j4q  = VV6j4q
  self.origFile   = path
  self.Title    = "File Editor: " + FFZ5fy(path)
  self.VVEStC  = VVEStC
  self.tmpFile   = "/tmp/ajp_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  self.lastLineNum  = -1
  self.editorTable  = None
  if FFgSm7("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)):
   FFzW1w(self.VV6j4q, BF(self.VVVeyX, curRowNum), title="Loading file ...")
  else:
   FFzrXb(self.VV6j4q, "Error while preparing edit!")
 def VVVeyX(self, curRowNum):
  VVpn2v = self.VVqeZF()
  VVEXwE = ("Save Changes" , self.VV9vAF   , [])
  VVd479  = ("Edit Line"  , self.VVZO32    , [])
  VV7J8f = ("Options"  , self.VVMO5x  , [])
  VVJvWF = ("Line Options" , self.VVVmJy   , [])
  VV4ePT = (""    , self.VV2fWA , [])
  VVNYAK = self.VVc82I
  VVX8rQ  = self.VVT3gr
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VViqYN  = (CENTER  , LEFT  )
  bg    = "#11001111"
  self.editorTable = FFldB6(self.VV6j4q, None, title=self.Title, header=header, VVWsIU=VVpn2v, VViqYN=VViqYN, VVv3Wm=widths, width=1600, height=1000, VVHZHw=26, isEditor=True, VVEXwE=VVEXwE, VVd479=VVd479, VV7J8f=VV7J8f, VVJvWF=VVJvWF, VVNYAK=VVNYAK, VVX8rQ=VVX8rQ, VV4ePT=VV4ePT, VV65AN=True, searchCol=1, lastFindConfigObj=CFG.lastFindEditor
        , VVZYdg=bg, VVcwfs=bg, VVLuY4=bg, VVG27K="#05333333", VVQ9hc="#00303030", VVGpiI="#11331133")
  self.editorTable.VV7qpv(curRowNum)
 def VVT3gr(self, VVoLtS):
  VVoLtS.VVSiJd()
 def VVMO5x(self, VVoLtS, title, txt, colList):
  VVMVqr = []
  VVMVqr.append(("Go to Line Num" , "toLine"))
  VVMVqr.append(("Find & Replace" , "repl"))
  FF7ARM(self.VV6j4q, self.VV2HeW, VVMVqr=VVMVqr, width=500, title="Options", VVy9CS=True)
 def VV2HeW(self, item=None):
  if item:
   title, ref, ndx = item
   if   ref == "toLine" : self.VVzFpx()
   elif ref == "repl"  : self.VVSoO4(title)
 def VVSoO4(self, title):
  fnd = CFG.lastFindRepl_fnd.getValue()
  rpl = CFG.lastFindRepl_rpl.getValue()
  lst = [(" Find", fnd, str(len(fnd))), (" Replace with", rpl, str(len(rpl)))]
  bg = "#11101010"
  VVd479  = ("Change" , BF(self.VV9Zi9, title, lst) , [])
  VVEXwE = ("Start" , BF(self.VVQrI6, title)  , [])
  header  = (" Subject", " Text" , "Len.")
  widths  = (20   , 70  , 10 )
  VViqYN = (LEFT   , LEFT  , CENTER)
  FFldB6(self.VV6j4q, None, title=title, VVWsIU=lst, header=header, VViqYN=VViqYN, VVv3Wm=widths, width=1200, VVHZHw=30, isEditor=True, VVd479=VVd479, VVEXwE=VVEXwE, VVcK1v=2
    , VVZYdg=bg, VVcwfs=bg, VVLuY4=bg, VVG27K="#06224455", VVQ9hc="#0a303030")
 def VV9Zi9(self, Title, lst, VVoLtS, title, txt, colList):
  title = VVoLtS.VVh7wm(0)
  ndx = VVoLtS.VVqeSa()
  txt = CFG.lastFindRepl_fnd.getValue() if ndx == 0 else CFG.lastFindRepl_rpl.getValue()
  FFBgSg(self.VV6j4q, BF(self.VVJknu, VVoLtS, ndx), title=title, defaultText=txt, message="New entry")
 def VVJknu(self, VVoLtS, ndx, newTxt=None):
  if newTxt:
   if ndx == 0 : FF2tHk(CFG.lastFindRepl_fnd, newTxt)
   else  : FF2tHk(CFG.lastFindRepl_rpl, newTxt)
   VVoLtS.VVLLe5({1:newTxt, 2:len(newTxt)})
 def VVQrI6(self, Title, VVoLtS, title, txt, colList):
  fnd = CFG.lastFindRepl_fnd.getValue()
  rpl = CFG.lastFindRepl_rpl.getValue()
  if len(fnd) > 0:
   txt = FFpCvR(self.tmpFile)
   tot = txt.count(fnd)
   if tot > 0:
    FFo4dm(self.VV6j4q, BF(FFzW1w, VVoLtS, BF(self.VVGRXY, VVoLtS, fnd, rpl), title="Replacing ..."), "Replace %d occurrences ?" % tot, title=Title)
   else:
    FFycel(VVoLtS, "Not found in file !", 1000)
    VVoLtS.VV7qpv(0)
  else:
   FFycel(VVoLtS, "Nothing to find", 1000)
 def VVGRXY(self, VVoLtS, fnd, rpl):
  txt = FFpCvR(self.tmpFile)
  txt = txt.replace(fnd, rpl)
  with open(self.tmpFile, "w") as f:
   f.write(txt)
  VVoLtS.cancel()
  self.fileChanged = True
  self.editorTable.VVQoym()
  VVpn2v = self.VVqeZF()
  self.editorTable.VVkYNn(VVpn2v)
 def VVzFpx(self):
  totRows = self.editorTable.VVgRm7()
  lineNum = self.editorTable.VVqeSa() + 1 if self.lastLineNum == -1 else self.lastLineNum
  FFBgSg(self.VV6j4q, BF(self.VVPofk, lineNum, totRows), title="Go to Line Num (1 - %d)" % totRows, defaultText="%d" % lineNum, message="Enter Line Number")
 def VVPofk(self, lineNum, totRows, VVEKeH):
  if VVEKeH:
   VVEKeH = VVEKeH.strip()
   if VVEKeH.isdigit():
    num = FFrrt7(int(VVEKeH) - 1, 0, totRows)
    self.editorTable.VV7qpv(num)
    self.lastLineNum = num + 1
   else:
    FFycel(self.editorTable, "Incorrect number", 1500)
 def VVVmJy(self, VVoLtS, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVoLtS.VVaeaf()
  VVMVqr = []
  VVMVqr.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVMVqr.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVTb6A"  ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVEith:
   VVMVqr.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(  ("Delete Line"         , "deleteLine"   ))
  FF7ARM(self.VV6j4q, BF(self.VVhfg6, lineNum), VVMVqr=VVMVqr, title="Line Options")
 def VVhfg6(self, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VV6mls("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile))
   elif item == "VVTb6A"  : self.VVTb6A(lineNum)
   elif item == "copyToClipboard"  : self.VVrdbj(lineNum)
   elif item == "pasteFromClipboard" : self.VVePtr(lineNum)
   elif item == "deleteLine"   : self.VV6mls("sed -i '%dd' '%s'" % (lineNum, self.tmpFile))
 def VV2fWA(self, VVoLtS, title, txt, colList):
  if   self.insertMode == 1: VVoLtS.VVxvln()
  elif self.insertMode == 2: VVoLtS.VV18ki()
  self.insertMode = 0
 def VVTb6A(self, lineNum):
  if lineNum == self.editorTable.VVaeaf():
   self.insertMode = 1
   self.VV6mls("echo '' >> '%s'" % self.tmpFile)
  else:
   self.insertMode = 2
   self.VV6mls("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile))
 def VVrdbj(self, lineNum):
  global VVEith
  VVEith = FFwTnb("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  self.editorTable.VVOPq5("Copied to clipboard")
 def VV9vAF(self, VVoLtS, title, txt, colList):
  if self.fileChanged:
   if FFkECb(self.origFile):
    if FFgSm7("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)):
     VVoLtS.VVOPq5("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVoLtS.VVSiJd()
    else:
     FFzrXb(self.VV6j4q, "Cannot save file!")
   else:
    FFzrXb(self.VV6j4q, "Cannot create backup copy of original file!")
 def VVc82I(self, VVoLtS):
  if self.fileChanged:
   FFo4dm(self.VV6j4q, BF(self.VVOLyR, VVoLtS), "Cancel changes ?")
  else:
   FFgSm7("cp -f '%s' '%s'" % (self.tmpFile, self.origFile))
   self.VVOLyR(VVoLtS)
 def VVOLyR(self, VVoLtS):
  VVoLtS.cancel()
  FFnPMX(self.tmpFile)
  if self.VVEStC:
   self.VVEStC(self.fileSaved)
 def VVZO32(self, VVoLtS, title, txt, colList):
  lineNum = int(VVoLtS.VVh7wm(0))
  lineTxt = VVoLtS.VVh7wm(1, isStrip=False)
  message = VViypC + "ORIGINAL TEXT:\n" + VVzv5p + lineTxt
  FFBgSg(self.VV6j4q, BF(self.VVnxzS, lineNum), title="File Line", defaultText=lineTxt, message=message)
 def VVnxzS(self, lineNum, VVEKeH):
  if not VVEKeH is None:
   if self.editorTable.VVaeaf() <= 1:
    self.VV6mls("echo %s > '%s'" % (VVEKeH, self.tmpFile))
   else:
    self.VV3Pfn(lineNum, VVEKeH)
 def VVePtr(self, lineNum):
  if lineNum == self.editorTable.VVaeaf() and self.editorTable.VVaeaf() == 1:
   self.VV6mls("echo %s >> '%s'" % (VVEith, self.tmpFile))
  else:
   self.VV3Pfn(lineNum, VVEith)
 def VV3Pfn(self, lineNum, newTxt):
  self.editorTable.VVwNb0("Saving ...")
  lines = FF2WPS(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  self.editorTable.VVQoym()
  VVpn2v = self.VVqeZF()
  self.editorTable.VVkYNn(VVpn2v)
 def VV6mls(self, cmd):
  tCons = CCG9Bk()
  tCons.ePopen(cmd, self.VVG4fY)
  self.fileChanged = True
  self.editorTable.VVQoym()
 def VVG4fY(self, result, retval):
  VVpn2v = self.VVqeZF()
  self.editorTable.VVkYNn(VVpn2v)
 def VVqeZF(self):
  if fileExists(self.tmpFile):
   lines = FF2WPS(self.tmpFile)
   VVpn2v = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVpn2v.append((str(ndx), line))
   if not VVpn2v:
    VVpn2v.append((str(1), ""))
   return VVpn2v
  else:
   FFZ5Ys(self.VV6j4q, self.tmpFile)
class CCOe8b():
 def __init__(self, callingSELF, VVZYdg="#22003344", VVcwfs="#22002233"):
  self.callingSELF = callingSELF
  self.VVMVqr  = []
  self.satList  = []
  self.VVZYdg  = VVZYdg
  self.VVcwfs   = VVcwfs
 def VVpQGc(self, VVEStC):
  self.VVMVqr = []
  VVMVqr, VVmkmv = CCOe8b.VVWl7I(self.callingSELF, False, True)
  if VVMVqr:
   self.VVMVqr += VVMVqr
   self.VVFwPY(VVEStC, VVmkmv)
 def VVcL71(self, mode, VVoLtS, satCol, VVEStC, inFilterFnc=None):
  VVoLtS.VVwNb0("Loading Filters ...")
  self.VVMVqr = []
  self.VVMVqr.append(("All Services" , "all"))
  if mode == 1:
   self.VVMVqr.append(VVpTvr)
   self.VVMVqr.append(("Parental Control", "parentalControl" ))
   self.VVMVqr.append(("Hidden Services" , "hiddenServices" ))
  elif mode == 2:
   self.VVMVqr.append(VVpTvr)
   self.VVMVqr.append(("Selected Transponder"   , "selectedTP" ))
   self.VVMVqr.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVmOZN(VVoLtS, satCol)
  VVMVqr, VVmkmv = CCOe8b.VVWl7I(self.callingSELF, True, False)
  if VVMVqr:
   VVMVqr.insert(0, FFfdOi("Custom Words"))
   self.VVMVqr += VVMVqr
  VVoLtS.VV6eCK()
  self.VVFwPY(VVEStC, VVmkmv, inFilterFnc)
 def VViYlv(self, VVMVqr, sats, VVEStC, inFilterFnc=None):
  self.VVMVqr = VVMVqr
  VVMVqr, VVmkmv = CCOe8b.VVWl7I(self.callingSELF, True, False)
  if VVMVqr:
   self.VVMVqr.append(FFfdOi("Custom Words"))
   self.VVMVqr += VVMVqr
  self.VVFwPY(VVEStC, VVmkmv, inFilterFnc)
 def VVFwPY(self, VVEStC, VVmkmv, inFilterFnc=None):
  VVYJ07  = ("Filter in Filter", inFilterFnc) if inFilterFnc else None
  VV0afn = ("Edit Filter"  , BF(self.VVBcvi, VVmkmv))
  VVdhQt  = ("Filter Help"  , BF(self.VVzvcp, VVmkmv))
  FF7ARM(self.callingSELF, BF(self.VVSl5p, VVEStC), VVMVqr=self.VVMVqr, title="Select Filter", VVYJ07=VVYJ07, VV0afn=VV0afn, VVdhQt=VVdhQt, VVMTvd=True, VVZYdg=self.VVZYdg, VVcwfs=self.VVcwfs)
 def VVSl5p(self, VVEStC, item):
  if item:
   VVEStC(item)
 def VVBcvi(self, VVmkmv, selectionObj, sel):
  if fileExists(VVmkmv) : CCH94c(self.callingSELF, VVmkmv, VVEStC=None)
  else       : FFZ5Ys(self.callingSELF, VVmkmv)
  selectionObj.cancel()
 def VVzvcp(self, VVmkmv, selectionObj, sel):
  FFGkYk(self.callingSELF, "_help_service_filter", "Service Filter")
 def VVmOZN(self, VVoLtS, satColNum):
  if not self.satList:
   satList = VVoLtS.VVpQnT(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFhPna(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, FFfdOi("Satellites"))
  if self.VVMVqr:
   self.VVMVqr += self.satList
 @staticmethod
 def VVWl7I(SELF, addTag, VVx3z3):
  FFW4ra()
  fileName  = "ajpanel_services_filter"
  VVmkmv = VVYfYu + fileName
  VVMVqr  = []
  if not fileExists(VVmkmv):
   FFgSm7("cp -f '%s' '%s'" % (VVLS8v + fileName, VVmkmv))
  fileFound = False
  if fileExists(VVmkmv):
   fileFound = True
   lines = FF2WPS(VVmkmv)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       lst = list(map(str.strip, line.split(",")))
       lst = list(filter(None, lst))
       if lst: line = ",".join(lst)
       else  : line = ""
      if line:
       if addTag: VVMVqr.append((line, "__w__" + line))
       else  : VVMVqr.append((line, line))
  if VVx3z3:
   if   not fileFound : FFZ5Ys(SELF, VVmkmv)
   elif not VVMVqr : FFYO45(SELF, VVmkmv)
  return VVMVqr, VVmkmv
 @staticmethod
 def VVjxXj(txt):
  txt = txt.strip()
  lst = []
  prefix = False
  if "," in txt:
   lst = list(map(str.strip, txt.split(",")))
   lst = list(filter(None, lst))
   if lst and len(lst) > 1 and lst[0] == "^":
    lst = lst[1:]
    prefix = True
  else:
   txt = txt.strip()
   if txt:
    if len(txt) > 1 and txt.startswith("^"):
     txt = txt[1:]
     prefix = True
    lst = [txt]
  return tuple(map(str.lower, lst)), prefix
class CC74Cn():
 def __init__(self, callingSELF, VVoLtS, addSep=True):
  self.callingSELF = callingSELF
  self.VVoLtS = VVoLtS
  self.VVMVqr = []
  iMulSel = self.VVoLtS.VVyLkw()
  if iMulSel : self.VVMVqr.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVMVqr.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVoLtS.VVv3mu()
  self.VVMVqr.append(    ("Select all"    , "selectAll"  ))
  if iMulSel and tot > 0:
   self.VVMVqr.append(   ("Unselect all"    , "unselectAll"  ))
  if addSep:
   self.VVMVqr.append(VVpTvr)
 def VVKonP(self, extraMenu, cbFncDict, okFnc=None, onMultiSelFnc=None, width=1000, height=850, VVZYdg="#22003344", VVcwfs="#22002233"):
  self.VVoLtS.onMultiSelFnc = onMultiSelFnc
  if extraMenu:
   self.VVMVqr.extend(extraMenu)
  FF7ARM(self.callingSELF, BF(self.VVFFBJ, cbFncDict, okFnc), width=width, height=height, title="Options", VVMVqr=self.VVMVqr, VVZYdg=VVZYdg, VVcwfs=VVcwfs)
 def VVFFBJ(self, cbFncDict, okFnc, item=None):
  if item:
   if   item == "multSelEnab" : self.VVoLtS.VV14UF(True)
   elif item == "MultSelDisab" : self.VVoLtS.VV14UF(False)
   elif item == "selectAll" : self.VVoLtS.VVfjV6()
   elif item == "unselectAll" : self.VVoLtS.VVAaK8()
   elif cbFncDict:
    fnc = cbFncDict.get(item)
    if fnc:
     fnc()
   if okFnc:
    okFnc()
class CCI94U(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF5TEn(VVnHWM, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FF32Yx(self)
  FFCDDm(self["keyRed"]  , "Exit")
  FFCDDm(self["keyGreen"]  , "Save")
  FFCDDm(self["keyYellow"] , "Refresh")
  FFCDDm(self["keyBlue"]  , "NTP Mode")
  self["curTime"]  = Label()
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self.timer   = eTimer()
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(VVjUqm,
  {
   "red" : self.VVrJyp  ,
   "green" : self.VV0Ku3 ,
   "yellow": self.VVs9Pb  ,
   "blue" : self.VV150L   ,
   "up" : self.VVL9bj    ,
   "down" : self.VVRnLl   ,
   "left" : self.VVgzL2   ,
   "right" : self.VVPVKV   ,
   "cancel": self.VVrJyp
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShown.append(self.VVSDD3)
  self.onClose.append(self.onExit)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  self.VVs9Pb()
  self.VVoxFs()
  FFieY3(self)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVlqLT)
  except:
   self.timer.callback.append(self.VVlqLT)
  self.timer.start(1000, False)
  self.VVlqLT()
 def onExit(self):
  self.timer.stop()
 def VVrJyp(self) : self.close(True)
 def VVarov(self) : self.close(False)
 def VV150L(self):
  self.session.openWithCallback(self.VVKnQs, BF(CCuXIG))
 def VVKnQs(self, closeAll):
  if closeAll:
   self.close()
 def VVlqLT(self):
  self["curTime"].setText(str(FFgCM6(iTime())))
 def VVL9bj(self):
  self.VVP0Dd(1)
 def VVRnLl(self):
  self.VVP0Dd(-1)
 def VVgzL2(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVoxFs()
 def VVPVKV(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVoxFs()
 def VVP0Dd(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVl14v(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVl14v(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVl14v(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VV9CuJ(year)):
   days += 1
  return days
 def VV9CuJ(self, year):
  if year % 4 == 0:
   if year % 100 == 0:
    if year % 400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVoxFs(self):
  for obj in self.list:
   FFzBm8(obj, "#11404040")
  FFzBm8(self.list[self.index], "#11ff8000")
 def VVs9Pb(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VV0Ku3(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCG9Bk()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVfi5i)
 def VVfi5i(self, result, retval):
  result = str(result.strip())
  if len(result) == 0 : FFuXZg(self, "Nothing returned from the system!")
  else    : FFuXZg(self, str(result))
class CCuXIG(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF5TEn(VVBwm7, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FF32Yx(self, addLabel=True)
  FFCDDm(self["keyRed"]  , "Exit")
  FFCDDm(self["keyGreen"]  , "Sync")
  FFCDDm(self["keyYellow"] , "Refresh")
  FFCDDm(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(VVjUqm,
  {
   "red" : self.VVrJyp   ,
   "green" : self.VVo6XL  ,
   "yellow": self.VVCwZg ,
   "blue" : self.VVRufv  ,
   "cancel": self.VVrJyp
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVz586()
  self.onShown.append(self.VVSDD3)
 def VVSDD3(self):
  FFieY3(self)
  FFA9HA(self.VVivph)
 def VVivph(self):
  self.VVk88x()
  self.VV3PE8(False)
 def VVrJyp(self)  : self.close(True)
 def VVRufv(self) : self.close(False)
 def VVz586(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVk88x(self):
  self.VVFIZ1()
  self.VV8TP4()
  self.VVu4md()
  self.VVE7ip()
 def VVCwZg(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVz586()
   self.VVk88x()
   FFA9HA(self.VVivph)
 def VVo6XL(self):
  if len(self["keyGreen"].getText()) > 0:
   FFo4dm(self, self.VVoo6F, "Synchronize with Internet Date/Time ?")
 def VVoo6F(self):
  self.VVk88x()
  FFA9HA(BF(self.VV3PE8, True))
 def VVFIZ1(self)  : self["keyRed"].show()
 def VVhbwk(self)  : self["keyGreen"].show()
 def VVIOiE(self) : self["keyYellow"].show()
 def VVVjA7(self)  : self["keyBlue"].show()
 def VV8TP4(self)  : self["keyGreen"].hide()
 def VVu4md(self) : self["keyYellow"].hide()
 def VVE7ip(self)  : self["keyBlue"].hide()
 def VV3PE8(self, sync):
  localTime = FFhvWN()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVHhAA(server)
   if epoch_time is not None:
    ntpTime = FFgCM6(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCG9Bk()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, BF(self.VVfi5i, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVIOiE()
  self.VVVjA7()
  if ok:
   self.VVhbwk()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVfi5i(self, syncAgain, result, retval):
  result = str(result.strip())
  if   len(result) == 0  : result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20: result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VV3PE8(False)
  except:
   pass
 def VVHhAA(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if CCYqD0.VVv6Xs():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCrWAJ(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF5TEn(VVECGg, 900, 300, 50, 20, 0, "#22000060", "#22000020", 35)
  self.session  = session
  FF32Yx(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVSDD3)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  FFA9HA(self.VVLMb9)
 def VVLMb9(self):
  if CCYqD0.VVv6Xs() : color, txt = "#22002020", "Internet Connection = Successful."
  else     : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFzBm8(self["myBody"], color)
   FFzBm8(self["myLabel"], color)
  except:
   pass
class CCHHqE(Screen):
 VVy2vU = None
 def __init__(self, session):
  size = CFG.signalSize.getValue()
  screenW = FFM4r3()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FF5TEn(VVAIje, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCW7qX(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCW7qX(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCW7qX(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCnDpI()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FF32Yx(self, title="Signal")
  self["myActionMap"] = ActionMap(VVjUqm,
  {
   "ok"  : self.close      ,
   "up"  : self.VVL9bj       ,
   "down"  : self.VVRnLl      ,
   "left"  : self.VVgzL2      ,
   "right"  : self.VVPVKV      ,
   "info"  : self.VVWCzN     ,
   "epg"  : self.VVWCzN     ,
   "menu"  : self.VV9tmQ      ,
   "cancel" : self.close      ,
   "red"  : self.close      ,
   "last"  : BF(self.VVY8R2, -1)  ,
   "next"  : BF(self.VVY8R2, 1)  ,
   "pageUp" : BF(self.VVv0rM, True) ,
   "chanUp" : BF(self.VVv0rM, True) ,
   "pageDown" : BF(self.VVv0rM, False) ,
   "chanDown" : BF(self.VVv0rM, False) ,
   "0"   : BF(self.VVY8R2, 0)  ,
   "1"   : BF(self.VVKmVK, pos=1) ,
   "2"   : BF(self.VVKmVK, pos=2) ,
   "3"   : BF(self.VVKmVK, pos=3) ,
   "4"   : BF(self.VVKmVK, pos=4) ,
   "5"   : BF(self.VVKmVK, pos=5) ,
   "6"   : BF(self.VVKmVK, pos=6) ,
   "7"   : BF(self.VVKmVK, pos=7) ,
   "8"   : BF(self.VVKmVK, pos=8) ,
   "9"   : BF(self.VVKmVK, pos=9) ,
  }, -1)
  self.onShown.append(self.VVSDD3)
  self.onClose.append(self.onExit)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  if not CCHHqE.VVy2vU:
   CCHHqE.VVy2vU = self
  self.sliderSNR.VVeeVD()
  self.sliderAGC.VVeeVD()
  self.sliderBER.VVeeVD(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVKmVK()
  self.VVpxhq()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVn9A0)
  except:
   self.timer.callback.append(self.VVn9A0)
  self.timer.start(500, False)
 def VVpxhq(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVrsur(service)
  serviceName = self.tunerInfo.VVba7A()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFmvpz(self)
  tp = CC9Nee()
  tpTxt, satTxt = tp.VVibqX(refCode)
  if tpTxt == "?" :
   tpTxt = FFCzRx("NO SIGNAL", VVszO3)
  self["myTPInfo"].setText(tpTxt + "  " + FFCzRx(satTxt, VV61JF))
 def VVn9A0(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVrsur(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVQbcc())
   self["mySNR"].setText(self.tunerInfo.VVBLNo())
   self["myAGC"].setText(self.tunerInfo.VVj6jA())
   self["myBER"].setText(self.tunerInfo.VVgAAh())
   self.sliderSNR.VVzGTQ(self.tunerInfo.VVQCCu())
   self.sliderAGC.VVzGTQ(self.tunerInfo.VVw713())
   self.sliderBER.VVzGTQ(self.tunerInfo.VVQ6G7())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVzGTQ(0)
   self.sliderAGC.VVzGTQ(0)
   self.sliderBER.VVzGTQ(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFmvpz(self)
    if state and not state == "Tuned":
     FFycel(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVWCzN(self):
  FFp5JP(self, fncMode=CCoD37.VVCzW3)
 def VV9tmQ(self):
  FFGkYk(self, "_help_signal", "Signal Monitor (Keys)")
 def VVL9bj(self)  : self.VVKmVK(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVRnLl(self) : self.VVKmVK(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVgzL2(self) : self.VVKmVK(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVPVKV(self) : self.VVKmVK(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVKmVK(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   FF2tHk(CFG.signalPos, self.curPosNum)
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVY8R2(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFrrt7(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   FF2tHk(CFG.signalSize, sizeNum)
   self.close(True)
 def onExit(self):
  self.timer.stop()
  CCHHqE.VVy2vU = None
 def VVv0rM(self, isUp):
  FFycel(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVpxhq()
  except:
   pass
class CCW7qX(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVeeVD(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFzBm8(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVLS8v +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFzBm8(self.covObj, self.covColor)
   else:
    FFzBm8(self.covObj, "#00006688")
    self.isColormode = True
  self.VVzGTQ(0)
 def VVzGTQ(self, val):
  val  = FFrrt7(val, self.minN, self.maxN)
  width = int(FFpM97(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFrrt7(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCSCNk(Screen):
 VV7KPr    = 0
 VVSu4G = 1
 VVbU23 = 2
 def __init__(self, session, titlePrefix="Processing ...", endTitle="Finishing ...", fncToRun=None, VVEStC=None, barTheme=VV7KPr, titleBg="#0a042328", bodyBg="#0a042328"):
  ratio = self.VVEkSm(barTheme)
  self.skin, self.skinParam = FF5TEn(VVdDCi, 900, 200, 30, 40, 30, titleBg, bodyBg, 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.endTitle  = endTitle
  self.fncToRun  = fncToRun
  self.VVEStC = VVEStC
  self.isCancelled = False
  self.isError  = False
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVRTV9 = None
  self.timer   = eTimer()
  self.myThread  = None
  FF32Yx(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(VVjUqm, { "cancel" : self.cancel }, -1)
  self.onShown.append(self.VVSDD3)
  self.onClose.append(self.onExit)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  self.VV1MMd()
  self["myProgBarVal"].setText("0%")
  FFzBm8(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVzG5j()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVzG5j)
  except:
   self.timer.callback.append(self.VVzG5j)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=BF(self.fncToRun, self))
  self.myThread.start()
 def VVHJ4P(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VVjFqZ(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVRTV9), self.counter, self.maxValue, catName)
 def VVpD7B(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VVd7yy(self, tot):
  self.newTitle = "Downloaded %d    Processed : %d of %d" % (tot, self.counter, self.maxValue)
 def VV0VIG(self, tot, evName):
  self.newTitle = "Translated: %d   ... %d/%d >> %s" % (tot, self.counter, self.maxValue, evName)
 def VVKQrf(self, action, tot, name):
  self.newTitle = "%s: %d   ... %d/%d >> %s" % (action, tot, self.counter, self.maxValue, name)
 def VV3aSA(self, tot, name):
  self.newTitle = "Added: %d   ... %d/%d >> %s" % (tot, self.counter, self.maxValue, name)
 def VVKDNk(self, txt):
  self.newTitle = txt
 def VVc1xD(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\t .. Processed : %d of %d" % (len(self.VVRTV9), self.counter, self.maxValue)
  except:
   pass
 def VVHvJ2(self, val):
  try:
   self.counter = val
  except:
   pass
 def VVmvtA(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VV358a(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FFycel(self, "Cancelling ...")
  self.isCancelled = True
  self.VV3z9g(False)
 def VV3z9g(self, isDone):
  FFA9HA(BF(self.VVF6bh, isDone))
 def VVF6bh(self, isDone):
  if self.VVEStC:
   self.VVEStC(isDone, self.VVRTV9, self.counter, self.maxValue, self.isError)
  self.close()
 def VVzG5j(self):
  val = FFrrt7(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFpM97(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self["myTitle"].setText("  %s  " % self.endTitle)
    self.VV3z9g(True)
 def VV1MMd(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VVSu4G, self.VVbU23):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VVEkSm(self, barTheme):
  if   barTheme == self.VVSu4G : return 0.7
  if   barTheme == self.VVbU23 : return 0.5
  else             : return 1
class CCG9Bk(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVEStC = {}
  self.commandRunning = False
  self.VV6sgm  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVEStC, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVEStC[name] = VVEStC
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VV6sgm:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(BF(self.VVDCx9, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(BF(self.VVkQkH , name))
   else:
    self.appContainers[name].dataAvail.append(BF(self.VVDCx9, name))
    self.appContainers[name].appClosed.append(BF(self.VVkQkH , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVkQkH(name, retval)
  return True
 def VVDCx9(self, name, data):
  try:
   data = data.decode("UTF-8")
  except:
   data = "%s%s\n" % ("" if self.appResults[name].endswith("\n") else "\n", FFCzRx("[UN-DECODED STRING]", VVszO3))
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVkQkH(self, name, retval):
  if not self.VV6sgm:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVEStC[name]:
   self.VVEStC[name](self.appResults[name], retval)
  del self.VVEStC[name]
 def VVYwEM(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCL7mk(Screen):
 def __init__(self, session, title="", VVEkBF=None, VVb2Gk=False, VV0NOL=False, VViiZ9=False, VVJ04z=False, VVQYkQ=False, VVlN16=False, VVr0Wh=VVdcIX, VVFgpi=None, VVeB0R=False, VVq3Yu=None, VVnUUN="", checkNetAccess=False, VVHZHw=30, consFont=False, enableSaveRes=True):
  self.skin, self.skinParam = FF5TEn(VVjziV, 1600, 1000, 50, 40, 20, "#22003040", "#22001122", VVHZHw, usefixedFont=consFont)
  self.session   = session
  self.VVnUUN = VVnUUN
  FF32Yx(self, addScrollLabel=True)
  self.VVb2Gk   = VVb2Gk
  self.VV0NOL   = VV0NOL
  self.VViiZ9   = VViiZ9
  self.VVJ04z  = VVJ04z
  self.VVQYkQ = VVQYkQ
  self.VVlN16 = VVlN16
  self.VVr0Wh   = VVr0Wh
  self.VVFgpi = VVFgpi
  self.VVeB0R  = VVeB0R
  self.VVq3Yu  = VVq3Yu
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CCG9Bk()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFcYIL()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVEkBF, str):
   self.VVEkBF = [VVEkBF]
  else:
   self.VVEkBF = VVEkBF
  if self.VViiZ9 or self.VVJ04z:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (SEP, SEP)
   self.VVEkBF.append("echo -e '\n%s\n' %s" % (restartNote, FFC7pV(restartNote, VVRJhR)))
   if self.VViiZ9:
    self.VVEkBF.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVEkBF.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVQYkQ:
   FFycel(self, "Processing ...")
  self.onLayoutFinish.append(self.VVfy0o)
  self.onClose.append(self.VVPqXQ)
 def VVfy0o(self):
  self["myLabel"].VVqlfR(outputFileToSave="console" if self.enableSaveRes else "")
  self["myLabel"].setText("   %s" % (self.VVnUUN or "Processing ..."))
  if self.VVb2Gk:
   self["myLabel"].VVteSG()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVipTF()
  else:
   self.VV1GEx()
 def VVipTF(self):
  if CCYqD0.VVv6Xs():
   self["myLabel"].setText("Processing ...")
   self.VV1GEx()
  else:
   self["myLabel"].setText(FFCzRx("\n   No connection to internet!", VVtz60))
 def VV1GEx(self):
  allOK = self.container.ePopen(self.VVEkBF[0], self.VV4bRZ, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VV4bRZ("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVlN16 or self.VViiZ9 or self.VVJ04z:
    self["myLabel"].setText(FFLhxe("STARTED", VVRJhR) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVq3Yu:
   colorWhite = CCy1Yy.VVHUiW(VViypC)
   color  = CCy1Yy.VVHUiW(self.VVq3Yu[0])
   words  = self.VVq3Yu[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVr0Wh=self.VVr0Wh)
 def VV4bRZ(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVEkBF):
   allOK = self.container.ePopen(self.VVEkBF[self.cmdNum], self.VV4bRZ, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VV4bRZ("Cannot connect to Console!", -1)
  else:
   if self.VVQYkQ and FFA72r(self):
    FFycel(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVlN16:
    self["myLabel"].appendText("\n" + FFLhxe("FINISHED", VVRJhR), self.VVr0Wh)
   if self.VVb2Gk or self.VV0NOL:
    self["myLabel"].VVteSG()
   if self.VVFgpi is not None:
    self.VVFgpi()
   if not retval and self.VVeB0R:
    self.VVPqXQ()
 def VVPqXQ(self):
  if self.container.VVYwEM():
   self.container.killAll()
class CC6CsJ(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FF5TEn(VVjziV, 1650, 950, 40, 20, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVYfYu + "ajpanel_terminal.history"
  self.customCommandsFile = ""
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFwTnb("pwd") or "/home/root"
  self.container   = CCG9Bk()
  self.commandsList  = []
  self.exitBtnText  = "Exit = Interrupt"
  FF32Yx(self, title="Terminal", addScrollLabel=True)
  FFCDDm(self["keyRed"] , self.exitBtnText)
  FFCDDm(self["keyGreen"] , "OK = History")
  FFCDDm(self["keyYellow"], "Menu = Custom Cmds")
  FFCDDm(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok" : self.VVjoyG ,
   "cancel": self.VVoOk6  ,
   "menu" : self.VVRw4t ,
   "last" : self.VVrQBk  ,
   "next" : self.VVrQBk  ,
   "1"  : self.VVrQBk  ,
   "2"  : self.VVrQBk  ,
   "3"  : self.VVrQBk  ,
   "4"  : self.VVrQBk  ,
   "5"  : self.VVrQBk  ,
   "6"  : self.VVrQBk  ,
   "7"  : self.VVrQBk  ,
   "8"  : self.VVrQBk  ,
   "9"  : self.VVrQBk  ,
   "0"  : self.VVrQBk
  })
  self.onShown.append(self.VVSDD3)
  self.onClose.append(self.VVD3wR)
 def VVSDD3(self):
  self["myLabel"].VVqlfR(isResizable=False, outputFileToSave="terminal")
  FFcdG1(self["keyRed"]  , "#00ff8000")
  FFzBm8(self["keyRed"]  , self.skinParam["titleColor"])
  FFzBm8(self["keyGreen"]  , self.skinParam["titleColor"])
  FFzBm8(self["keyYellow"] , self.skinParam["titleColor"])
  FFzBm8(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVP571(FFwTnb("date"), 5)
  result = FFwTnb("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVdHgt()
  if pathExists(VVYfYu):
   self.VVUqcu()
  else:
   FFzrXb(self, 'Cannot access the path:\n\n%s' % VVYfYu)
   self.close()
 def VVUqcu(self):
  userFile = CFG.terminalCmdFile.getValue()
  alterFile = VVYfYu + "LinuxCommands.lst"
  templPath = VVLS8v + "ajpanel_cmd_list"
  if   fileExists(userFile) : self.customCommandsFile = userFile
  elif fileExists(alterFile): self.customCommandsFile = alterFile
  else:
   if not FFgSm7("cp -f '%s' '%s'" % (templPath, alterFile)):
    FFErQ2("echo -e 'pwd\ncd\ncd /tmp\nls\nls -ls' > '%s'" % alterFile)
   self.customCommandsFile = alterFile
 def VVD3wR(self):
  if self.container.VVYwEM():
   self.container.killAll()
   self.VVP571("Process killed\n", 4)
   self.VVdHgt()
 def VVoOk6(self):
  if self.container.VVYwEM():
   self.VVD3wR()
  else:
   FFo4dm(self, self.close, "Exit ?", VVDfmh=False)
 def VVdHgt(self):
  self.VVP571(self.prompt, 1)
  self["keyRed"].hide()
 def VVP571(self, txt, mode):
  if   mode == 1 : color = VVRJhR
  elif mode == 2 : color = VVAaU5
  elif mode == 3 : color = VViypC
  elif mode == 4 : color = VVtz60
  elif mode == 5 : color = VVzv5p
  elif mode == 6 : color = VVHQpO
  else   : color = VViypC
  try:
   self["myLabel"].appendText(FFCzRx(txt, color))
  except:
   pass
 def VVjoyG(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVeKr9() == "":
   self.VVetK3("cd /tmp")
   self.VVetK3("ls")
  VVpn2v = []
  if fileExists(self.commandHistoryFile):
   lines  = FF2WPS(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VVpn2v.append((str(c), line, str(lNum)))
   self.VVYYWM(VVpn2v, title, self.commandHistoryFile, isHistory=True)
  else:
   FFZ5Ys(self, self.commandHistoryFile, title=title)
 def VVeKr9(self):
  lastLine = FFwTnb("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVetK3(self, cmd):
  try:
   with open(self.commandHistoryFile, "a") as f:
    f.write("%s\n" % cmd)
  except Exception as e:
   FFzrXb(self, str(e))
 def VVRw4t(self, VVoLtS=None):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines = FF2WPS(self.customCommandsFile)
   VVpn2v = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVpn2v.append((str(c), line, str(lNum)))
   if VVoLtS:
    VVoLtS.VVkYNn(VVpn2v)
    VVoLtS.VV7qpv(CFG.lastTerminalCustCmdLineNum.getValue())
   else:
    self.VVYYWM(VVpn2v, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFZ5Ys(self, self.customCommandsFile, title=title)
 def VVYYWM(self, VVpn2v, title, filePath=None, isHistory=False):
  if VVpn2v:
   VVG27K = "#05333333"
   if isHistory: VVZYdg = VVcwfs = VVLuY4 = "#11000020"
   else  : VVZYdg = VVcwfs = VVLuY4 = "#06002020"
   VVd479   = ("Send"   , BF(self.VV4lre, isHistory)  , [])
   VVEXwE  = ("Modify & Send" , self.VVAjtj     , [])
   if isHistory:
    VV7J8f = ("Clear History" , self.VVKWQi     , [])
    VVJvWF = None
    VV1Jd7 = None
   elif filePath:
    VV7J8f = ("Options"  , self.VVP8nD      , [])
    VVJvWF = ("Edit File"  , BF(self.VV9hM3, filePath) , [])
    VV1Jd7 = (""    , self.VV3Ugu     , [])
   header  = ("No." , "Commands", "LineNum" )
   widths  = (7  , 93   , 0    )
   VViqYN = (CENTER , LEFT   , CENTER )
   VVoLtS = FFldB6(self, None, title=title, header=header, VVWsIU=VVpn2v, VViqYN=VViqYN, VVv3Wm=widths, VVHZHw=26, VVd479=VVd479, VVEXwE=VVEXwE, VV7J8f=VV7J8f, VVJvWF=VVJvWF, VV1Jd7=VV1Jd7, lastFindConfigObj=CFG.lastFindTerminal, VV65AN=True, searchCol=1
         , VVZYdg=VVZYdg, VVcwfs=VVcwfs, VVLuY4=VVLuY4, VVG27K=VVG27K)
   if not isHistory:
    VVoLtS.VV7qpv(CFG.lastTerminalCustCmdLineNum.getValue())
  else:
   FFo4dm(self, BF(self.VVlXSn, None, "Change Custom Commands File"), "File is empty:\n\n%s\n\nSelect another file ?" % self.customCommandsFile, title=title)
 def VV3Ugu(self, VVoLtS, title, txt, colList):
  txt  = "%s\n%s\n\n" % (FFCzRx("Command:", VV61JF), colList[1])
  txt += "%s\n%s\n\n" % (FFCzRx("Line %s in File:" % colList[2], VV61JF), self.customCommandsFile)
  FFtybv(self, txt, title=title)
 def VVP8nD(self, VVoLtS, title, txt, colList):
  mSel = CC74Cn(self, VVoLtS)
  VVMVqr = []
  txt1 = "Change Custom Commands File"
  if VVoLtS.VVzBSi:
   VVMVqr.append((txt1, ))
   VVMVqr.append(VVpTvr)
   totSel = VVoLtS.VVv3mu()
   totTxt = str(totSel)
   txt2 = "Send %s Command%s" % (FFCzRx(totTxt, VVRJhR) if totSel else totTxt, FFoTxy(totSel))
   VVMVqr.append((txt2, "send") if totSel else (txt2,))
  else:
   VVMVqr.append((txt1, "newFile"))
   VVMVqr.append(VVpTvr)
   txt2 = "Send current line"
   VVMVqr.append((txt2, "send"))
  cbFncDict = { "newFile" : BF(self.VVlXSn, VVoLtS, txt1)
     , "send" : BF(self.VV4lre, False, VVoLtS, title, txt2, colList) }
  mSel.VVKonP(VVMVqr, cbFncDict, okFnc=BF(self.VVrubw, VVoLtS))
 def VVlXSn(self, VVoLtS, title):
  VVMVqr = []
  for fName in os.listdir(VVYfYu):
   path = os.path.join(VVYfYu, fName)
   if fName.lower().startswith(("ajpanel_cmd", "linuxcommands")) and os.path.isfile(path):
    VVMVqr.append((fName, path))
  VVMVqr.sort(key=lambda x: x[0].lower())
  if VVMVqr : FF7ARM(self, BF(self.VVD3RU, VVoLtS, title), VVMVqr=VVMVqr, title=title, minRows=3, VVZYdg="#11220000", VVcwfs="#11220000")
  else  : FFzrXb(self, "No valid files found in:\n\n%s" % VVYfYu, title=title)
 def VVD3RU(self, VVoLtS, title, path=None):
  if path:
   if CCUGPF.VViwWz(path):
    FFzrXb(self, "Incorrect file format:\n\n%s" % path, title=title)
   else:
    lines = FF2WPS(path)
    for line in lines:
     if line.strip():
      oldF = self.customCommandsFile
      self.customCommandsFile = path
      FF2tHk(CFG.terminalCmdFile, path)
      if not oldF == self.customCommandsFile:
       FF2tHk(CFG.lastTerminalCustCmdLineNum, 0)
      self.VVRw4t(VVoLtS)
      break
    else:
     FFzrXb(self, "File is empty:\n\n%s" % path, title=title)
 def VVrubw(self, VVoLtS):
  if VVoLtS.VVzBSi : VVoLtS.VVSiJd()
  else        : VVoLtS.VVQoym()
 def VV4lre(self, isHistory, VVoLtS, title, txt, colList):
  if VVoLtS.VVzBSi:
   lst = VVoLtS.VVCtEG(1)
   curNdx = VVoLtS.VVwg1G()
  else:
   lst = [colList[1]]
   curNdx = VVoLtS.VVqeSa()
  if not isHistory:
   FF2tHk(CFG.lastTerminalCustCmdLineNum, curNdx)
  self.commandsList = lst
  VVoLtS.cancel()
  FFA9HA(self.VVFTNd)
 def VVFTNd(self):
  if self.commandsList:
   cmd = self.commandsList[0]
   self.commandsList.pop(0)
   if not iMatch("^[a-zA-Z0-9_]", cmd):
    self.VVP571("\n%s\n" % cmd, 6)
    self.VVP571(self.prompt, 1)
    self.VVFTNd()
   else:
    self.VVfcdf(cmd)
 def VVfcdf(self, cmd):
  tot = len(self.commandsList)
  self["keyRed"].setText("%s%s" % (self.exitBtnText, " (%s)" % tot if tot > 0 else ""))
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VVP571(cmd, 2)
   self.VVP571("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VVP571(ch, 0)
   self.VVP571("\nor\n", 4)
   self.VVP571("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VVdHgt()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FFCzRx(parts[0].strip(), VVAaU5)
    right = FFCzRx("#" + parts[1].strip(), VVHQpO)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VVP571(txt, 2)
   lastLine = self.VVeKr9()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VVetK3(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VV4bRZ, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FFzrXb(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVP571(data, 3)
 def VV4bRZ(self, data, retval):
  if not retval == 0:
   self.VVP571("Exit Code : %d\n" % retval, 4)
  self.VVdHgt()
  if self.commandsList:
   self.VVFTNd()
 def VVAjtj(self, VVoLtS, title, txt, colList):
  if VVoLtS.VVehBR():
   cmd = colList[1]
   self.VVTnYU(VVoLtS, cmd)
 def VVKWQi(self, VVoLtS, title, txt, colList):
  FFo4dm(self, BF(self.VVGhu8, VVoLtS), "Reset History File ?", title="Command History")
 def VVGhu8(self, VVoLtS):
  FFErQ2("> '%s'" % self.commandHistoryFile)
  VVoLtS.cancel()
 def VV9hM3(self, filePath, VVoLtS, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCH94c(self, filePath, VVEStC=BF(self.VV1P3n, VVoLtS), curRowNum=rowNum)
  else     : FFZ5Ys(self, filePath)
 def VV1P3n(self, VVoLtS, fileChanged):
  if fileChanged:
   VVoLtS.cancel()
   FFA9HA(self.VVRw4t)
 def VVrQBk(self):
  self.VVTnYU(None, self.lastCommand)
 def VVTnYU(self, VVoLtS, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFBgSg(self, BF(self.VVHzhd, VVoLtS), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVHzhd(self, VVoLtS, cmd):
  if cmd and len(cmd) > 0:
   self.VVfcdf(cmd)
   if VVoLtS:
    VVoLtS.cancel()
class CCVjNB(Screen):
 def __init__(self, session, title="", message="", VVr0Wh=VVdcIX, width=1400, height=900, VVoDLt=False, titleBg="#22002020", VVLuY4="#22001122", VVHZHw=30, titleFontSize=50, outputFileToSave=""):
  self.skin, self.skinParam = FF5TEn(VVjziV, width, height, titleFontSize, 30, 20, titleBg, VVLuY4, VVHZHw)
  self.session   = session
  FF32Yx(self, title, addScrollLabel=True)
  self.VVr0Wh   = VVr0Wh
  self.VVoDLt   = VVoDLt
  self.outputFileToSave = outputFileToSave
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    pass
  self.message = str(message)
  self.onShown.append(self.VVSDD3)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  self["myLabel"].VVqlfR(VVoDLt=self.VVoDLt, outputFileToSave=self.outputFileToSave)
  self["myLabel"].setText(self.message, self.VVr0Wh)
  self["myLabel"].VVteSG()
class CC8r03(Screen):
 def __init__(self, session, txt):
  self.skin, self.skinParam = FF5TEn(VVMPlG, 1800, 60, 30, 30, 20, "#55000000", "#ff000000", 30)
  self.session  = session
  self.txt   = txt
  self["myWinTitle"] = Label()
  FF32Yx(self, " ", addCloser=True)
  self.onShown.append(self.VVSDD3)
 def VVSDD3(self):
  CCt8ct.VV0lyM(self, self.txt)
  self.instance.move(ePoint((getDesktop(0).size().width() - self.instance.size().width()) // 2, 20))
class CC2lJb(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FF5TEn(VVPpdF, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FF32Yx(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVSDD3)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  FFUK2c(self["errPic"], "err")
class CC86DI(Screen):
 def __init__(self, session, txt, fntSize):
  self.skin, self.skinParam = FF5TEn(VVMPlG, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", fntSize)
  self.session  = session
  self["myWinTitle"] = Label()
  FF32Yx(self, " ", addCloser=True)
class CCt8ct():
 def __init__(self, session, txt, timeout=1500, fonSize=24):
  self.session = session
  self.win  = CCt8ct.VVoIE1(session, txt, fonSize)
  self.timer  = eTimer()
  try: self.timer_conn = self.timer.timeout.connect(self.VVJBan)
  except: self.timer.callback.append(self.VVJBan)
  self.timer.start(timeout, True)
 def VVJBan(self):
  self.session.deleteDialog(self.win)
 @staticmethod
 def VVoIE1(session, txt, fonSize, shadW=2, shadColor="#440000", x=30, y=20):
  win = session.instantiateDialog(CC86DI, txt.strip(), fonSize)
  win.instance.move(ePoint(x, y))
  win.show()
  FFAF2D(win["myWinTitle"], shadColor, shadW)
  CCt8ct.VV0lyM(win, txt)
  return win
 @staticmethod
 def VV0lyM(win, txt):
  win["myWinTitle"].setText(txt.strip())
  inst = win["myWinTitle"].instance
  w = inst.calculateSize().width() + 30
  h = int(inst.size().height())
  inst.resize(eSize(*(w, h)))
  win.instance.resize(eSize(*(w, h)))
class CCXFYJ():
 VVG5Uk    = 0
 VV3406  = 1
 VVwRYj   = ""
 VVTsED    = "ajpDownload"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVoLtS   = None
  self.timer     = eTimer()
  self.VVFs4y   = 0
  self.VVl1Q7  = 1
  self.VV1jUt  = 2
  self.VVL1Gc   = 3
  self.VV4aba   = 4
  VVpn2v = self.VVp5Rd()
  if VVpn2v:
   self.VVoLtS = self.VVLbZy(VVpn2v)
  if not VVpn2v and mode == self.VVG5Uk:
   self.VVvL0a("Download list is empty !")
   self.cancel()
  if mode == self.VV3406:
   FFzW1w(self.VVoLtS or self.SELF, BF(self.VVNycu, startDnld, decodedUrl), title="Checking Server ...")
  self.VVbYMB(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVbYMB)
  except:
   self.timer.callback.append(self.VVbYMB)
  self.timer.start(1000, False)
 def VVLbZy(self, VVpn2v):
  VVpn2v.sort(key=lambda x: int(x[0]))
  VVNYAK = self.VVzNFs
  VVd479  = ("Play"  , self.VVZY0K , [])
  VV1Jd7 = (""   , self.VVzPd1  , [])
  VVKDDh = ("Stop"  , self.VVuMKP  , [])
  VVEXwE = ("Resume"  , self.VVqfF5 , [])
  VV7J8f = ("Options" , self.VVXW9h  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VViqYN  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FFldB6(self.SELF, None, title=self.Title, header=header, VVWsIU=VVpn2v, VViqYN=VViqYN, VVv3Wm=widths, VVHZHw=26, VVd479=VVd479, VV1Jd7=VV1Jd7, VVNYAK=VVNYAK, VVKDDh=VVKDDh, VVEXwE=VVEXwE, VV7J8f=VV7J8f, lastFindConfigObj=CFG.lastFindIptv, VVZYdg="#11220022", VVcwfs="#11110011", VVLuY4="#11110011", VVG27K="#00223025", VVQ9hc="#0a333333", VVGpiI="#0a400040", VV65AN=True, searchCol=1)
 def VVp5Rd(self):
  lines = CCXFYJ.VVcXuf()
  VVpn2v = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",", 1)
     left  = parts[0].strip()
     decodedUrl = parts[1].strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VVJOYp(decodedUrl)
      if fName:
       if   FFkUBK(decodedUrl) : sType = "Movie"
       elif FFtJft(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VVAUDm(decodedUrl, fName)
       if size > -1: sizeTxt = CCUGPF.VVuy4U(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VVpn2v.append((str(len(VVpn2v) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VVpn2v
 def VVj4FA(self):
  VVpn2v = self.VVp5Rd()
  if VVpn2v:
   if self.VVoLtS : self.VVoLtS.VVkYNn(VVpn2v, VVz586Msg=False)
   else     : self.VVoLtS = self.VVLbZy(VVpn2v)
  else:
   self.cancel()
 def VVbYMB(self, force=False):
  if self.VVoLtS:
   thrListUrls = self.VVWHnj()
   VVpn2v = []
   changed = False
   for ndx, row in enumerate(self.VVoLtS.VVGkEL()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VVFs4y
    if m3u8Log:
     percent = CCXFYJ.VVKhSs(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VVL1Gc , "%.2f %%" % percent
      else   : flag, progr = self.VV4aba , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FFPLWs(mPath)
     if curSize > -1:
      fSize = CCUGPF.VVuy4U(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CCUGPF.VVuy4U(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FFPLWs(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VVL1Gc , "%.2f %%" % percent
       else   : flag, progr = self.VV4aba , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CCUGPF.VVuy4U(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrListUrls:
     flag = self.VV1jUt
     if m3u8Log :
      if not speed and not force : flag = self.VVl1Q7
      elif curSize == -1   : self.VV7LzN(False)
    elif flag == self.VVFs4y  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VVFs4y  : color2 = "#f#00555555#"
    elif flag == self.VVl1Q7 : color2 = "#f#0000FFFF#"
    elif flag == self.VV1jUt : color2 = "#f#0000FFFF#"
    elif flag == self.VVL1Gc  : color2 = "#f#00FF8000#"
    elif flag == self.VV4aba  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VVuArE(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VVpn2v.append(row)
   if changed or force:
    self.VVoLtS.VVkYNn(VVpn2v, VVz586Msg=False)
 def VVuArE(self, flag):
  tDict = self.VVEv1C()
  return tDict.get(flag, "?")
 def VVRWEY(self, state):
  for flag, txt in self.VVEv1C().items():
   if txt == state:
    return flag
  return -1
 def VVEv1C(self):
  return { self.VVFs4y: "Not started", self.VVl1Q7: "Connecting", self.VV1jUt: "Downloading", self.VVL1Gc: "Stopped", self.VV4aba: "Completed" }
 def VVlkjr(self, title):
  colList = self.VVoLtS.VVkHbA()
  path = colList[6]
  url  = colList[8]
  if self.VVxitg() : self.VVvL0a("Cannot delete !\n\nFile is downloading.")
  else      : FFo4dm(self.SELF, BF(self.VVLFsi, path, url), "Delete ?\n\n%s" % path, title=title)
 def VVLFsi(self, path, url):
  m3u8Log = self.VVoLtS.VVkHbA()[12]
  if m3u8Log : FFgSm7("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9]))
  else  : FFgSm7("rm -rf '%s'" % path)
  self.VVl3RI(False)
  self.VVj4FA()
 def VVl3RI(self, VVx3z3=True):
  if self.VVxitg():
   FFycel(self.VVoLtS, self.VVuArE(self.VV1jUt), 500)
  else:
   colList  = self.VVoLtS.VVkHbA()
   state  = colList[4]
   decodedUrl = colList[9]
   if self.VVRWEY(state) in (self.VVFs4y, self.VV4aba, self.VVL1Gc):
    lines = CCXFYJ.VVcXuf()
    newLines = []
    found = False
    for line in lines:
     if CCXFYJ.VVvww9(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VVREGM(newLines)
     self.VVj4FA()
     FFycel(self.VVoLtS, "Removed.", 1000)
    else:
     FFycel(self.VVoLtS, "Not found.", 1000)
   elif VVx3z3:
    self.VVvL0a("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VVNJPc(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FFo4dm(self.SELF, BF(self.VVNcoh, flag), ques, title=title)
 def VVNcoh(self, flag):
  list = []
  for ndx, row in enumerate(self.VVoLtS.VVGkEL()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VVRWEY(state)
   if   flag == flagVal == self.VV4aba: list.append(decodedUrl)
   elif flag == flagVal == self.VVFs4y : list.append(decodedUrl)
  lines = CCXFYJ.VVcXuf()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VVREGM(newLines)
   self.VVj4FA()
   FFycel(self.VVoLtS, "%d removed." % totRem, 1000)
  else:
   FFycel(self.VVoLtS, "Not found.", 1000)
 def VVs7ij(self):
  colList  = self.VVoLtS.VVkHbA()
  path  = colList[6]
  decodedUrl = colList[9]
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FFycel(self.VVoLtS, "Poster exists", 1500)
  else    : FFzW1w(self.VVoLtS, BF(self.VVSsAL, decodedUrl, path, png), title="Checking Server ...")
 def VVSsAL(self, decodedUrl, path, png):
  err = self.VVhSue(decodedUrl, path, png)
  if err:
   FFzrXb(self.SELF, err, title="Poster Download")
 def VVhSue(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CCEgQt.VV08j2(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CCfw0y.VVKCk4(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCfw0y.VVtidF(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CCfw0y.VVEl8A(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if not pUrl:
   return "No Poster data from server !"
  ext = os.path.splitext(pUrl)[1] or ".png"
  tPath, err = FFOecp(pUrl, "ajp_tmp%s" % ext, timeout=2, mustBeImage=True)
  if err:
   return "Cannot download poster !\n\n%s" % err
  else:
   png = "%s%s" % (os.path.splitext(path)[0], ext)
   FFgSm7("mv -f '%s' '%s'" % (tPath, png))
   CCwf80.VVR0Px(self.SELF, VVxlEn=png, showGrnMsg="Downloaded")
   return ""
 def VVzPd1(self, VVoLtS, title, txt, colList):
  def VVulVX(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VVchnh(key, val) : return "\n%s:\n%s\n" % (FFCzRx(key, VV61JF), val.strip())
  heads  = self.VVoLtS.VVPdoF()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VVulVX(heads[i]  , CCUGPF.VVuy4U(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VVulVX("Downloaded" , CCUGPF.VVuy4U(int(curSize), mode=0))
   else:
    txt += VVulVX(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VVchnh(heads[i], colList[i])
  FFtybv(self.SELF, txt, title=title)
 def VVZY0K(self, VVoLtS, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CCUGPF.VV0bc3(self.SELF, path)
  else    : FFycel(self.VVoLtS, "File not found", 1000)
 def VVzNFs(self, VVoLtS):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVoLtS:
   self.VVoLtS.cancel()
  del self
 def VVXW9h(self, VVoLtS, title, txt, colList):
  c1, c2, c3 = VVTKrH, VVtz60, VV61JF
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  resumeTxt = "Disable" if CFG.downloadAutoResume.getValue() else "Enable"
  showMonitor = "Disable" if CFG.downloadMonitor.getValue() else "Enable"
  VVMVqr = []
  VVMVqr.append((c1 + "Remove current row"       , "VVl3RI" ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append((c1 + 'Remove all "Completed"'      , "remFinished"   ))
  VVMVqr.append((c1 + 'Remove all "Not started"'     , "remPending"   ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append((c2 + "Delete the file (and remove from list)"  , "VVlkjr"))
  VVMVqr.append(VVpTvr)
  VVMVqr.append((resumeTxt + " Auto Resume"       , "VV9P2q" ))
  VVMVqr.append((showMonitor + " On-screen Download Monitor"  , "toggleMonitor"  ))
  VVMVqr.append(VVpTvr)
  cond = FFkUBK(decodedUrl)
  VVMVqr.append(FFwLFH("Download Movie Poster %s" % ("(from server)" if cond else "... Movies only"), "VVs7ij", cond, c3))
  VVMVqr.append(FFwLFH("Open in File Manager", "inFileMan,%s" % path, fileExists(path), c3))
  FF7ARM(self.SELF, BF(self.VVJJwd, VVoLtS), VVMVqr=VVMVqr, title=self.Title, VVy9CS=True, width=800, VVMTvd=True, VVZYdg="#1a001122", VVcwfs="#1a001122")
 def VVJJwd(self, VVoLtS, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VVl3RI"  : self.VVl3RI()
   elif ref == "remFinished"   : self.VVNJPc(self.VV4aba, txt)
   elif ref == "remPending"   : self.VVNJPc(self.VVFs4y, txt)
   elif ref == "VVlkjr" : self.VVlkjr(txt)
   elif ref == "VVs7ij"  : self.VVs7ij()
   elif ref == "VV9P2q"  : FF2tHk(CFG.downloadAutoResume, not CFG.downloadAutoResume.getValue())
   elif ref == "toggleMonitor"   : FF2tHk(CFG.downloadMonitor, not CFG.downloadMonitor.getValue())
   elif ref.startswith("inFileMan,") :
    path = ref.split(",", 1)[1]
    if pathExists(path) : self.SELF.session.open(CCUGPF, mode=CCUGPF.VVpesc, jumpToFile=path)
    else    : FFycel(VVoLtS, "Path not found !", 1500)
 def VVNycu(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFmvpz(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CCEgQt.VV08j2(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VVvL0a("Could not get download link !\n\nTry again later.")
     return
  for line in CCXFYJ.VVcXuf():
   if CCXFYJ.VVvww9(decodedUrl, line):
    if self.VVoLtS:
     self.VVnjIB(decodedUrl)
     FFA9HA(BF(FFycel, self.VVoLtS, "Already listed !", 2000))
    break
  else:
   params = self.VV3aAi(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VVvL0a(params[0])
   elif len(params) == 2:
    FFo4dm(self.SELF, BF(self.VVitCw, params[0], decodedUrl), "Start downloading ?", title="Download (m3u8)")
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CCUGPF.VVuy4U(fSize)
    FFo4dm(self.SELF, BF(self.VVEuaP, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VVEuaP(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CCXFYJ.VVQ034(), "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VVj4FA()
  if self.VVoLtS:
   self.VVoLtS.VV18ki()
  if startDnld:
   threadName = "%s{%s,Sz,}%s" % (CCXFYJ.VVTsED, path, decodedUrl)
   self.VVL3tq(threadName, url, decodedUrl, path, resp)
 def VVnjIB(self, decodedUrl):
  if self.VVoLtS:
   for ndx, row in enumerate(self.VVoLtS.VVGkEL()):
    decodedUrl2 = row[9].strip()
    if decodedUrl == decodedUrl2 and self.VVoLtS:
     self.VVoLtS.VV7qpv(ndx)
     break
 def VV3aAi(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VVJOYp(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VVAUDm(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CCEgQt.VV08j2(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CCEgQt.VVIOWr()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head.get("Content-Length", "")
   cType = head.get("Content-Type", "")
   resumable = CCXFYJ.VVvLFg(resp)
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  if not "video" in cType and not "application/octet-stream" in cType:
   if resp.url.endswith(".m3u8"):
    return [resp, 1]
   elif not cType and resumable:
    pass
   else:
    return ["Cannot download this video !\n\nIncorrect download data (or not allowed by server)."]
  err = CCXFYJ.VV4AcM(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VVitCw(self, resp, decodedUrl):
  if not FFlgKV("ffmpeg"):
   FFo4dm(self.SELF, BF(CCfw0y.VVxwjW, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VVJOYp(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VVsliq(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FFo4dm(self.SELF, BF(self.VVdYCn, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VVdYCn(rTxt, rUrl)
  else:
   self.VVvL0a("Cannot process m3u8 file !")
 def VVsliq(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VVMVqr = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CCfw0y.VV7Ttk(rUrl, fPath)
   VVMVqr.append((resol, fullUrl))
  if VVMVqr:
   FF7ARM(self.SELF, self.VVSkeX, VVMVqr=VVMVqr, title="Resolution", VVy9CS=True, VVMTvd=True)
  else:
   self.VVvL0a("Cannot get Resolutions list from server !")
 def VVSkeX(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FFo4dm(self.SELF, BF(FFA9HA, BF(self.VViS49, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FFA9HA(BF(self.VViS49, resolUrl))
 def VViS49(self, resolUrl):
  txt, err = CCEgQt.VVAAns(resolUrl)
  if err : self.VVvL0a(err)
  else : self.VVdYCn(txt, resolUrl)
 def VVwouq(self, logF, decodedUrl):
  found = False
  lines = CCXFYJ.VVcXuf()
  with open(CCXFYJ.VVQ034(), "w") as f:
   for line in lines:
    if CCXFYJ.VVvww9(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CCXFYJ.VVQ034(), "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VVj4FA()
  if self.VVoLtS:
   self.VVoLtS.VV18ki()
 def VVdYCn(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  fName = fName.replace("(", "_").replace(")", "_")
  dest = dest.replace("(", "_").replace(")", "_")
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CCfw0y.VV7Ttk(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VVvL0a("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VVwouq(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFgeXp("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = "%s{%s,,%s}%s" % (CCXFYJ.VVTsED, dest, logF, decodedUrl)
  myThread = iThread(name=threadName, target=BF(os.system, cmd))
  myThread.start()
 @staticmethod
 def VVKhSs(dnldLog):
  if fileExists(dnldLog):
   dur = CCXFYJ.VVIomq(dnldLog)
   if dur > -1:
    tim = CCXFYJ.VVjqhe(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 @staticmethod
 def VVIomq(dnldLog):
  lines = FFSInC("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 @staticmethod
 def VVjqhe(dnldLog):
  lines = FFSInC("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVAUDm(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FFtJft(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    FFgSm7("mkdir '%s'" % path1)
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VVL3tq(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVoLtS.VVkHbA()[7])
  threadName = threadName.replace(",Sz,", ",%s," % totFileSize)
  myThread = iThread(name=threadName, target=BF(self.VVdX73, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VVdX73(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if self.VVwRYj == path:
       break
     else:
      break
  except:
   return
  if CCXFYJ.VVwRYj:
   CCXFYJ.VVwRYj = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FFPLWs(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VV3aAi(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VVdX73(url, decodedUrl, path, resp, totFileSize, True)
 def VVuMKP(self, VVoLtS, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VV7LGE() : FFycel(self.VVoLtS, self.VVuArE(self.VV4aba), 500)
  elif not self.VVxitg() : FFycel(self.VVoLtS, self.VVuArE(self.VVL1Gc), 500)
  elif m3u8Log      : FFo4dm(self.SELF, self.VV7LzN, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VVWHnj():
    CCXFYJ.VVwRYj = colList[6]
    FFycel(self.VVoLtS, "Stopping ...", 1000)
   else:
    FFycel(self.VVoLtS, "Stopped", 500)
 def VV7LzN(self, withMsg=True):
  if withMsg:
   FFycel(self.VVoLtS, "Stopping ...", 1000)
  FFgSm7("killall -INT ffmpeg")
 def VVqfF5(self, *args):
  if   self.VV7LGE() : FFycel(self.VVoLtS, self.VVuArE(self.VV4aba) , 500)
  elif self.VVxitg() : FFycel(self.VVoLtS, self.VVuArE(self.VV1jUt), 500)
  else:
   resume = False
   m3u8Log = self.VVoLtS.VVkHbA()[12]
   if m3u8Log:
    if fileExists(m3u8Log) : FFo4dm(self.SELF, BF(self.VVWuQG, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VVPoe2():
    resume = True
   if resume: FFzW1w(self.VVoLtS, BF(self.VVAs73), title="Checking Server ...")
   else  : FFycel(self.VVoLtS, "Cannot resume !", 500)
 def VVWuQG(self, m3u8Log):
  FFgSm7("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9]))
  FFzW1w(self.VVoLtS, BF(self.VVAs73), title="Checking Server ...")
 def VVAs73(self):
  colList  = self.VVoLtS.VVkHbA()
  path  = colList[6]
  size  = colList[7]
  decodedUrl = colList[9]
  if "j.php" in decodedUrl:
   url = CCEgQt.VV08j2(decodedUrl)
   if url:
    decodedUrl = self.VVDHTC(decodedUrl, url)
   else:
    self.VVvL0a("Could not get download link !\n\nTry again later.")
    return
  curSize = FFPLWs(path)
  params = self.VV3aAi(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VVvL0a(params[0])
   return
  elif len(params) == 2:
   self.VVitCw(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VVDHTC(decodedUrl, url, fSize)
  threadName = "%s{%s,Sz,}%s" % (CCXFYJ.VVTsED, path, decodedUrl)
  if resumable: self.VVL3tq(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VVvL0a("Cannot resume from server !")
 def VVJOYp(self, decodedUrl):
  fileExt = CCfw0y.VVDOzu(decodedUrl) or ".mp4"
  fixName = True
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(https?:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   span = iSearch(r"(.+)&mode.+&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url = span.group(1)
    chName = span.group(2)
   span = iSearch(r".+movie.php?.+stream=(.+\..{3,4})&.+", decodedUrl, IGNORECASE)
   if span     : fName = span.group(1)
   elif fileExt == ".php" : fName = ".mkv" if ".mkv" in decodedUrl else ".mp4"
   else     : fName = fileExt
  elif "get_download_link" in decodedUrl:
   span = iSearch(r"(.+)&mode.+chCm=(.+)&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = os.path.basename(span.group(2))
    chName = span.group(3).replace(":", "_").strip("_")
    fixName = False
  else:
   ok = False
   span = iSearch(r"(.+\/(.+.mp4).+m3u8).+:(.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = span.group(2)
    chName = span.group(3)
    fixName = False
    ok  = True
   if not ok:
    span = iSearch(r"(.+\/.+m3u8).*:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
     ok  = True
   if not ok and FFzo2Y(decodedUrl):
    span = iSearch(r"(.+)\?\:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
    else:
     span = iSearch(r"(.+):(.+)", decodedUrl, IGNORECASE)
     if span:
      url  = span.group(1)
      chName = span.group(2)
      fName = chName + fileExt
      fixName = False
  if url and fName and chName:
   if fixName:
    mix  = fName + chName
    parts = mix.split(":", 1)
    fName = parts[0]
    chName = parts[1]
    fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
    url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VVvL0a(self, txt):
  FFzrXb(self.SELF, txt, title=self.Title)
 def VVWHnj(self):
  thrListUrls = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{.+})*(.+)" % CCXFYJ.VVTsED, thr.name, IGNORECASE)
   if span:
    thrListUrls.append(span.group(1))
  return thrListUrls
 def VVxitg(self):
  decodedUrl = self.VVoLtS.VVkHbA()[9]
  return decodedUrl in self.VVWHnj()
 def VV7LGE(self):
  colList = self.VVoLtS.VVkHbA()
  path = colList[6]
  size = colList[7]
  m3u8Log = colList[12]
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FFPLWs(path)) == size
 def VVPoe2(self):
  colList = self.VVoLtS.VVkHbA()
  path = colList[6]
  size = int(colList[7])
  curSize = FFPLWs(path)
  if curSize > -1:
   size -= curSize
  err = CCXFYJ.VV4AcM(size)
  if err:
   FFzrXb(self.SELF, err, title=self.Title)
   return False
  return True
 def VVREGM(self, list):
  with open(CCXFYJ.VVQ034(), "w") as f:
   for line in list:
    f.write(line + "\n")
 def VVDHTC(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CCXFYJ.VVcXuf()
  url = decodedUrl
  with open(CCXFYJ.VVQ034(), "w") as f:
   for line in lines:
    if CCXFYJ.VVvww9(decodedUrl, line):
     parts = line.split(",", 1)
     oldUrl = parts[1].strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VVj4FA()
  return url
 @staticmethod
 def VVcXuf():
  list = []
  if fileExists(CCXFYJ.VVQ034()):
   for line in FF2WPS(CCXFYJ.VVQ034()):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VVvww9(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VV4AcM(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CCUGPF.VV5yeR(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CCUGPF.VVuy4U(size), CCUGPF.VVuy4U(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VVCUnt(SELF):
  tot = CCXFYJ.VVxwF5()
  if tot:
   FFzrXb(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VVxwF5():
  c = 0
  for thr in iEnumerate():
   if thr.name.startswith(CCXFYJ.VVTsED):
    c += 1
  return c
 @staticmethod
 def VVi8FB():
  lst = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{(.+),(.*),(.*)}).+" % CCXFYJ.VVTsED, thr.name, IGNORECASE)
   if span:
    lst.append((span.group(1), span.group(2), span.group(3)))
  return lst
 @staticmethod
 def VV39Bn():
  return len(CCXFYJ.VVcXuf()) == 0
 @staticmethod
 def VVklcw():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VV8R4P():
  mPoints = CCXFYJ.VVklcw()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    FFgSm7("mkdir '%s'" % path)
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VVQ034():
  f = "ajpanel_downloads"
  if pathExists("/home/root/"): return "/home/root/%s" % f
  else      : return "/home/%s" % f
 @staticmethod
 def VVf574(SELF, waitMsgObj=None):
  FFzW1w(waitMsgObj or SELF, BF(CCXFYJ.VVUBhd, SELF, CCXFYJ.VVG5Uk))
 @staticmethod
 def VV3TF7(SELF):
  CCXFYJ.VVUBhd(SELF, CCXFYJ.VV3406, startDnld=True)
 @staticmethod
 def VVIFnw(SELF, url):
  CCXFYJ.VVUBhd(SELF, CCXFYJ.VV3406, startDnld=True, decodedUrl=url)
 @staticmethod
 def VVTCSi(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFmvpz(SELF)
  added, skipped = CCXFYJ.VVjQu1([decodedUrl])
  FFycel(SELF, "Added", 1000)
 @staticmethod
 def VVjQu1(list):
  added = skipped = 0
  for line in CCXFYJ.VVcXuf():
   for ndx, url in enumerate(list):
    if url and CCXFYJ.VVvww9(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CCXFYJ.VVQ034(), "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VVUBhd(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CCGolS.VV1Ewa(SELF):
   return
  if mode == CCXFYJ.VVG5Uk and CCXFYJ.VV39Bn():
   FFzrXb(SELF, "Download list is empty !", title=title)
  else:
   inst = CCXFYJ(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
 @staticmethod
 def VVvLFg(res):
  if res.status_code == 206:
   return True
  else:
   hResume = res.headers.get("Accept-Ranges" , "")
   if hResume and not hResume == "none":
    return True
  return False
class CCA3uT(Screen, CCanC9):
 VVGbd7 = None
 def __init__(self, session, enableZapping=True, iptvTableParams=None, enableDownloadMenu=True):
  self.skin, self.skinParam = FF5TEn(VVolcU, 1600, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCanC9.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.iptvTableParams  = iptvTableParams
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.cutListBtn    = "Cut-List"
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.satInfo_TP    = ""
  self.lastPlayPos   = 0
  self.lastPlayPosTicker  = 0
  self.lastSubtitle   = None
  self.restoreLastPlayPos  = False
  self.autoReplay    = False
  FF32Yx(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVQ3w7())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<< || >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label(self.cutListBtn)
  self["myPlayTyp"] = Label()
  self["myPlayPic"] = Pixmap()
  self["myPlayDnld"] = Pixmap()
  self["myPlayRpt"] = Pixmap()
  self["myAction"] = ActionMap(VVjUqm,
  {
   "ok"  : self.VVthYm       ,
   "info"  : self.VVWCzN      ,
   "epg"  : self.VVWCzN      ,
   "menu"  : self.VViV8p     ,
   "cancel" : self.cancel       ,
   "red"  : self.VVguXw   ,
   "green"  : self.VVR64h  ,
   "blue"  : self.VVkg3r      ,
   "yellow" : self.VVVaY5 ,
   "left"  : BF(self.VVhANP, -1)    ,
   "right"  : BF(self.VVhANP,  1)    ,
   "play"  : self.VVUPkv      ,
   "pause"  : self.VVUPkv      ,
   "playPause" : self.VVUPkv      ,
   "stop"  : self.VVUPkv      ,
   "rewind" : self.VVRHPZ      ,
   "forward" : self.VVPCtd      ,
   "rewindDm" : self.VVRHPZ      ,
   "forwardDm" : self.VVPCtd      ,
   "last"  : self.VVQivS      ,
   "next"  : self.VVtldY      ,
   "pageUp" : BF(self.VVvy3D, True)  ,
   "pageDown" : BF(self.VVvy3D, False)  ,
   "chanUp" : BF(self.VVvy3D, True)  ,
   "chanDown" : BF(self.VVvy3D, False)  ,
   "up"  : BF(self.VVvy3D, True)  ,
   "down"  : BF(self.VVvy3D, False)  ,
   "audio"  : BF(self.VV4vqo, True)  ,
   "subtitle" : BF(self.VV4vqo, False)  ,
   "text"  : self.VVcVVL  ,
   "0"   : BF(self.VVuPGq , 10)   ,
   "1"   : BF(self.VVuPGq , 1)   ,
   "2"   : BF(self.VVuPGq , 2)   ,
   "3"   : BF(self.VVuPGq , 3)   ,
   "4"   : BF(self.VVuPGq , 4)   ,
   "5"   : BF(self.VVuPGq , 5)   ,
   "6"   : BF(self.VVuPGq , 6)   ,
   "7"   : BF(self.VVuPGq , 7)   ,
   "8"   : BF(self.VVuPGq , 8)   ,
   "9"   : BF(self.VVuPGq , 9)
  }, -1)
  self.onShown.append(self.VVSDD3)
  self.onClose.append(self.onExit)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  FFDoNq(self)
  if not CCA3uT.VVGbd7:
   CCA3uT.VVGbd7 = self
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  left -= self.skinParam["titleH"]
  self["myPlayDnld"].instance.move(ePoint(int(left), int(top)))
  self["myPlayDnld"].hide()
  FFUK2c(self["myPlayDnld"], "dnld")
  left -= self.skinParam["titleH"]
  self["myPlayRpt"].instance.move(ePoint(int(left), int(top)))
  self["myPlayRpt"].hide()
  FFUK2c(self["myPlayRpt"], "rpt")
  self.VVqwhp()
  self.instance.move(ePoint(40, 40))
  self.VVyGmi(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVGn4x)
  except:
   self.timer.callback.append(self.VVGn4x)
  self.timer.start(250, False)
  self.VVGn4x("Checking ...")
  if not bool(self.iptvTableParams):
   self.VVsvna()
 def VVR64h(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFmvpz(self)
  self.lastSubtitle = CCyEAP.VVzTN8()
  if "chCode" in iptvRef:
   if CCGolS.VV1Ewa(self):
    self.VVsvna(True)
  else:
   self.VVGn4x("Refreshing")
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv:
    self.session.nav.stopService()
    self.session.nav.playService(serv)
   self.restoreLastPlayPos = True
 def VVqwhp(self):
  self.satInfo_TP = ""
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVbDN3()
  chName = FFQdrB(chName)
  if refCode : self.Title = chName.replace("\n", " > ")
  else  : self.Title = VVszO3 + "No Service !"
  self["myTitle"].setText("  " + self.Title + "  ")
  FFzBm8(self["myTitle"], tColor)
  FFzBm8(self["myBody"], tColor)
  for item in ("Pos", "Skp", "Msg", "Rem", "Dur", "Jmp", "Dat", "Tim", "Mrk", "Res", "Fps", "Asp", "Pic", "Typ"):
   FFzBm8(self["myPlay%s" % item], tColor)
  picFile = ""
  if not iMatch("^\d*:(0:){9}\/.+", refCode):
   picFile = CCoD37.VVMUmM(refCode)
  if not fileExists(picFile):
   fPath, fDir, fName, picFile = CCoD37.VV0pTW(self)
  cl = CCty9w.VVu2OK(self["myPlayPic"], picFile, tColor)
  if cl:
   self["myPlayPic"].show()
   self["myPlayTyp"].hide()
  else:
   self["myPlayPic"].hide()
   self["myPlayTyp"].show()
   self["myPlayTyp"].setText(typeTxt)
 def VVGn4x(self, stateTxt="", highlight=False):
  if not self.shown:
   return
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  tot = CCXFYJ.VVxwF5()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVbDN3()
  if evName:
   evName = "    %s    " % FFCzRx(evName, VVzv5p)
  self["myTitle"].setText("  %s%s  " % (self.Title, evName))
  if seekable and self.VVRfCc():
   FFcdG1(self["myPlayBlu"], "#00FFFFFF")
   FFzBm8(self["myPlayBlu"], "#0a18188b")
   self["myPlayBlu"].setText(self.cutListBtn)
   self["myPlayBlu"].show()
  elif prov:
   FFcdG1(self["myPlayBlu"], "#00FFFF88")
   FFzBm8(self["myPlayBlu"], tColor)
   self["myPlayBlu"].setText(prov)
   self["myPlayBlu"].show()
  else:
   self["myPlayBlu"].hide()
  if not self.isManualSeek:
   player = CCfw0y.VVgRqy(refCode)
   if player:
    self["myPlaySkp"].show()
    self["myPlaySkp"].setText(VVHQpO + player)
   else:
    self["myPlaySkp"].hide()
  self["myPlayRes"].setText(res)
  self["myPlayFps"].setText(fr)
  self["myPlayAsp"].setText(ratio)
  self["myPlayPos"].setText(posTxt if posTxt else "")
  self["myPlayVal"].setText(percTxt if percTxt else "")
  self["myPlayRem"].setText("-%s" % remTxt if remTxt else "")
  self["myPlayDur"].setText(durTxt if durTxt else "")
  if durTxt:
   FFzBm8(self["myPlayBarBG"], "#11000000")
   self["myPlayBarBG"].show()
   self["myPlayBarF"].show()
   self["myPlayBar"].show()
   width = 0
   percent = FFrrt7(percVal, 0, 100)
   width = int(FFpM97(percent, 0, 100, 0, self.barWidth))
   self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  else:
   self["myPlayBarBG"].hide()
   self["myPlayBarF"].hide()
   self["myPlayBar"].hide()
   self["myPlayVal"].setText(">>>>")
   FFzBm8(self["myPlayBarBG"], tColor)
  if stateTxt:
   if highlight: FFcdG1(self["myPlayMsg"], "#0000ffff")
   else  : FFcdG1(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1:
   return
  else:
   self.noteTime = 0
   FFcdG1(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText("No system info")
  if isDvb:
   FFcdG1(self["myPlayMsg"], "#00aaaaaa")
   self["myPlayMsg"].setText(self.satInfo_TP)
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VVQKw0()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     if self.lastPlayPos > 0:
      move = end = False
      s = "." * self.lastPlayPosTicker
      stateTxt = ("%s Restoring Posistion %s" % (s, s)).strip()
      self.lastPlayPosTicker += 1
      diff = abs(posVal - self.lastPlayPos)
      if   diff < 10     : end = True
      elif self.lastPlayPosTicker == 1: move = True
      elif self.lastPlayPosTicker >= 10:
       if diff > 10:
        move = True
       end = True
      if move:
       self.VVqFCH(self.lastPlayPos * 90000.0)
      if end:
       self.lastPlayPosTicker = 0
       self.restoreLastPlayPos = False
       CCyEAP.VVU10z(self.lastSubtitle)
     else:
      self.restoreLastPlayPos = False
    else:
     self.lastPlayPos = posVal
   elif stateTxt == "End" and self.autoReplay:
    self.VVQivS()
  state = self.VVptoB()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFcdG1(self["myPlayMsg"], "#0000ff00")
  else     : FFcdG1(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVbDN3(self, isFromSession=False, addInfoObj=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFmvpz(self, addInfoObj=True)
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCA3uT.VVsJTo(self)
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCoD37.VV5V8k(serv)
  if   isDvb        : tColor = "#1100102a"
  elif isLocal       : tColor = "#0a401100"
  elif "chCode" in decodedUrl:
   if "get_download_link" in decodedUrl: tColor = "#1120101a"
   else        : tColor = "#1120002a"
  elif "/timeshift/" in decodedUrl  : tColor = "#11223322"
  elif isFtp        : tColor = "#11222222"
  else         : tColor = "#11001c1c"
  chPath = serv and serv.getPath() or ""
  satTxt = ""
  if isDvb and not self.satInfo_TP:
   tp = CC9Nee()
   tpTxt, satTxt = tp.VVibqX(refCode)
   self.satInfo_TP = tpTxt + "  " + FFCzRx(satTxt, VVYqlh)
  evName = evNameNext = ""
  evLst = CCL7is.VVAjJu(refCode)
  if evLst:
   evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt = evLst[0]
   if not durVal:
    if len(evLst) > 1:
     evNameNext = evLst[1][0]
    if evPos >= evDur:
     percVal = 100
     percTxt = "%d %%" % percVal
    else:
     percVal = float(evPos) * 100.0 / float(evDur)
     percTxt = "%.2f %%" % percVal
    posVal, remVal, percTxt, durTxt, posTxt, remTxt = evPos, evRem, percTxt, evDurTxt, evPosTxt, evRemTxt
  fr = res = ""
  if info:
   w = FFw1kT(info, iServiceInformation.sVideoWidth) or -1
   h = FFw1kT(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFw1kT(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  ratio = CCoD37.VV7ouL(info)
  return refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 @staticmethod
 def VVsJTo(SELF):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = SELF.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFRTnP(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFRTnP(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal + 1
      remTxt = FFRTnP(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
       remTxt = ""
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VViV8p(self):
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVbDN3()
  FFkUBKSeries = FFzo2Y(decodedUrl)
  VVMVqr = []
  if not "VVwi7L" in globals() and not "VVHdUx" in globals():
   VVMVqr.append((VVYqlh + "IPTV Menu", "iptv"))
   VVMVqr.append(VVpTvr)
  if isIptv and not "&end=" in decodedUrl and not FFkUBKSeries:
   uType, uHost, uUser, uPass, uId, uChName = CCfw0y.VVKCk4(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVMVqr.append((VVYqlh + "Catchup Programs", "catchup" ))
    VVMVqr.append(VVpTvr)
  if refCode:
   c = VVszO3
   VVMVqr.append((c + "Stop Current Service"  , "stop"  ))
   VVMVqr.append((c + "Restart Current Service" , "restart"  ))
   VVMVqr.append(FFwLFH("Replay with ..." , "replayWith", not isDvb, c))
   VVMVqr.append(VVpTvr)
  if FFkUBKSeries:
   VVMVqr.append((VVYqlh + "File Size (on server)", "fileSize" ))
   VVMVqr.append(VVpTvr)
  if self.enableDownloadMenu:
   c = VVYqlh
   addSep = False
   if isIptv and FFkUBKSeries:
    VVMVqr.append((c + "Start Download"  , "dload_cur" ))
    VVMVqr.append((c + "Add to Download List" , "addToDload" ))
    addSep = True
   if not CCXFYJ.VV39Bn():
    VVMVqr.append((VVYqlh + "Download Manager", "dload_stat" ))
    addSep = True
   if addSep:
    VVMVqr.append(VVpTvr)
  fPath, fDir, fName = CCUGPF.VVKW1S(self)
  if fPath:
   c = VVJS3b
   if not "VV48oF" in globals():
    VVMVqr.append((c + "Open path in File Manager", "VVqRZn"))
   VVMVqr.append((c + "Add to Bouquet"             , "VV14Hl" ))
   VVMVqr.append((c + "%s Auto-Repeat" % ("Disable" if self.autoReplay else "Enable") , "VV6Xsu"  ))
   VVMVqr.append(VVpTvr)
  elif isFtp:
   VVMVqr.append((VV61JF + "Add FTP Media to Bouquet"     , "VVRhga"))
  if isDvb:
   VVMVqr.append((VVYqlh + "Signal Monitor", "sigMon"))
  if posTxt and durTxt:
   VVMVqr.append((VV61JF + "Start Subtitle", "VVYhsl"))
   VVMVqr.append(VVpTvr)
  if CFG.playerPos.getValue() : VVMVqr.append(("Move Bar to Bottom" , "botm"))
  else      : VVMVqr.append(("Move Bar to Top" , "top" ))
  VVMVqr.append(("Help", "help"))
  FF7ARM(self, self.VVJ51e, VVMVqr=VVMVqr, width=600, title="Options")
 def VVJ51e(self, item=None):
  if item:
   if item == "iptv"     : self.close("close_iptvMenu")
   elif item == "catchup"    : self.VVVaY5()
   elif item == "stop"     : self.VVJP2O(0)
   elif item == "restart"    : self.VVJP2O(1)
   elif item == "replayWith"   : self.VVrRQE()
   elif item == "fileSize"    : FFzW1w(self, BF(CCoD37.VV7N1e, self), title="Checking Server")
   elif item == "dload_cur"   : CCXFYJ.VV3TF7(self)
   elif item == "addToDload"   : CCXFYJ.VVTCSi(self)
   elif item == "dload_stat"   : CCXFYJ.VVf574(self)
   elif item == "VVqRZn" : self.close("close_openInFileMan")
   elif item == "VV14Hl" : self.VV14Hl()
   elif item == "VVRhga" : self.VVRhga()
   elif item == "VVYhsl"  : self.VVdVPw()
   elif item == "VV6Xsu"  : self.VV6Xsu()
   elif item == "botm"     : self.VVyGmi(0)
   elif item == "top"     : self.VVyGmi(1)
   elif item == "sigMon"    : self.VVguXw()
   elif item == "help"     : FFGkYk(self, "_help_player", "Player Bar (Keys)")
 def onExit(self):
  self.timer.stop()
  CCA3uT.VVGbd7 = None
 def VVJP2O(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.show()
    self.VVqwhp()
   elif typ == 1:
    self.VVGn4x("Restarting Service ...")
    FFA9HA(BF(self.VVUDyx, serv))
 def VVUDyx(self, serv):
  self.session.nav.stopService()
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFmvpz(self)
  if "&end=" in decodedUrl: BF(self.VVsvna, True)
  else     : self.session.nav.playService(serv)
 def VVrRQE(self):
  FF7ARM(self, self.VV9G7J, VVMVqr=CCfw0y.VVOqDo(), width=650, title="Select Player", VVZYdg="#11220000", VVcwfs="#11220000")
 def VV9G7J(self, rType=None):
  if rType:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv : FFlT79(self, eServiceReference(rType + ":" + serv.toString().split(":", 1)[1]))
   else : self.VVGn4x("No active service !")
 def VV14Hl(self):
  fPath, fDir, fName = CCUGPF.VVKW1S(self)
  if fPath: picker = CCrfsB(self, self, "Add Current Movie to a Bouquet", BF(self.VVxi5N, [fPath]))
  else : FFycel(self, "Path not found !", 1500)
 def VVxi5N(self, pathLst):
  return CCrfsB.VVFi0q(pathLst)
 def VVRhga(self):
  picker = CCrfsB(self, self, "Add FTP Media to Bouquet", self.VV8atG)
 def VV8atG(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFmvpz(self)
  return CCrfsB.VVFi0q([origUrl], rType=refCode.split(":", 1)[0])
 def VV6Xsu(self):
  ok = False
  if self.autoReplay:
   self.autoReplay = False
   txt = "Auto-Repeat OFF"
   ok = True
  else:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCA3uT.VVsJTo(self)
   if seekable and durVal > 0:
    if durVal >= 60:
     self.autoReplay = True
     txt = "Auto-Repeat ON"
     ok = True
    else: txt = "Too short (min = 1 minute)"
   else: txt = "Cannot Auto-Repeat"
  if self.autoReplay : self["myPlayRpt"].show()
  else    : self["myPlayRpt"].hide()
  self.VVGn4x(txt, highlight=ok)
 def VVyGmi(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   FF2tHk(CFG.playerPos, pos)
 def VVguXw(self):
  if self.shown:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCoD37.VV5V8k(serv)
   if isDvb: self.close("close_sig")
   else : self.VVGn4x("No Signal for Current Service")
 def VVdVPw(self):
  self.session.openWithCallback(self.VVZwez, BF(CCyEAP))
 def VVcVVL(self):
  if self.shown:
   refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVbDN3()
   if posTxt and durTxt: self.VVdVPw()
   else    : self.VVGn4x("No duration Info. !")
 def VVZwez(self, reason):
  self.show()
  txt = ""
  if   reason == "subtExit" : pass
  elif reason == "subtCancel" : pass
  elif reason == "subtEnd" : txt = "End of subtitle reached"
  elif reason == "subtInval" : txt = "Invalid srt file"
  elif reason == "subtNoSrt" : txt = "Not found"
  elif reason == "subtZapUp" : self.VVvy3D(True)
  elif reason == "subtZapDn" : self.VVvy3D(False)
  elif reason == "pause"  : self.VVUPkv()
  elif reason == "audio"  : self.VV4vqo(True)
  elif reason == "subtitle" : self.VV4vqo(False)
  elif reason == "rewind"     : self.VVRHPZ()
  elif reason == "forward" : self.VVPCtd()
  elif reason == "rewindDm" : self.VVRHPZ()
  elif reason == "forwardDm" : self.VVPCtd()
  else      : txt = reason
  if txt:
   FFycel(self, txt, 2000)
 def VVthYm(self):
  if self.isManualSeek:
   self.VVS6sE()
   self.VVqFCH(self.manualSeekPts)
  elif self.shown:
   if CCyEAP.VVRkFL(self): self.VVdVPw()
   elif self.shown       : self.hide()
  else:
   self.show()
 def cancel(self):
  if self.isManualSeek: self.VVS6sE()
  else    : self.close()
 def VVWCzN(self):
  FFp5JP(self, fncMode=CCoD37.VVSl6s)
 def VVUPkv(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except:
   pass
  self.VVGn4x("Toggling Play/Pause ...")
 def VVS6sE(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVhANP(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCA3uT.VVsJTo(self)
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.VVFkvJ()
   else:
    self.manualSeekSec += direc * self.VVFkvJ()
    self.manualSeekSec = FFrrt7(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFpM97(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFRTnP(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVuPGq(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   self["myPlayJmp"].setText(self.VVQ3w7())
   FF2tHk(CFG.playerJumpMin, self.jumpMinutes)
  self.VVGn4x("Changed Seek Time to : %d%s" % (val, self.VVZcfl()))
 def VVQ3w7(self):
  return "Seek=%d%s" % (self.jumpMinutes, self.VVZcfl())
 def VVZcfl(self) : return "s"   if self.jumpMinutes == 10 else "m"
 def VV0Sqm(self): return "sec" if self.jumpMinutes == 10 else "min"
 def VVFkvJ(self) : return 10    if self.jumpMinutes == 10 else self.jumpMinutes * 60
 def VVQKw0(self):
  if "VVf6vh" in globals():
   global VVf6vh
   if VVf6vh:
    VVf6vh = VVf6vh[1:-1]
    if len(VVf6vh) == 3: VVf6vh = ""
    else     : return VVf6vh
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVkg3r(self):
  cList = self.VVRfCc()
  if cList:
   VVMVqr = []
   for pts, what in cList:
    txt = FFRTnP(int(pts) / 90000.0)
    if   what == 0 : t = "In"
    elif what == 1 : t = "Out"
    elif what == 2 : t = "Mark"
    elif what == 3 : t = "Last"
    else   : t = ""
    if t: txt += "  ( %s )" % t
    VVMVqr.append((txt, pts))
   FF7ARM(self, self.VVcdlK, VVMVqr=VVMVqr, title="Cut List")
  else:
   self.VVGn4x("No Cut-List for this channel !")
 def VVcdlK(self, item=None):
  if item:
   self.VVqFCH(item)
 def VVRfCc(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVPCtd(self) : self.VVQg1g(1)
 def VVRHPZ(self) : self.VVQg1g(-1)
 def VVQg1g(self, direc):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCA3uT.VVsJTo(self)
   if durVal > 0:
    maxPts = (durVal - posVal- 10) * 90000.0
    pts = direc * self.VVFkvJ() * 90000.0
    pts = min(maxPts, pts)
    inst = InfoBar.instance
    inst.doSeekRelative(int(pts))
    inst.hide()
    if   direc > 0 : txt = "Forawrd"
    else   : txt = "Rewind"
    txt += " (%d %s) ..." % (self.jumpMinutes, self.VV0Sqm())
    self.VVGn4x(txt)
  except:
   self.VVGn4x("Cannot jump")
 def VVqFCH(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVGn4x("Changing Time ...")
 def VVQivS(self):
  self.VVJP2O(1)
  self.VVGn4x("Replaying ...")
  self.VVS6sE()
 def VVtldY(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCA3uT.VVsJTo(self)
   if durVal > 0:
    pts = int((durVal - 10) * 90000.0)
    InfoBar.instance.doSeek(int(pts))
    self.VVGn4x("Jumping to end ...")
  except:
   pass
 def VVptoB(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVvy3D(self, isUp):
  if self.enableZapping:
   self.VVGn4x("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVS6sE()
   if self.iptvTableParams:
    FFA9HA(BF(self.VVi9gn, isUp))
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFmvpz(self)
    if "/timeshift/" in decodedUrl:
     self.VVGn4x("Cannot Zap Catch-up TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VVriZB()
  else:
   self.VVGn4x("Zap Disabled !")
 def VVriZB(self):
  self.lastPlayPos = 0
  self.VVqwhp()
  self.VVsvna()
 def VVi9gn(self, isUp):
  CCfw0y_inatance, VVoLtS, mode = self.iptvTableParams
  if isUp : VVoLtS.VVutJy()
  else : VVoLtS.VVdxRQ()
  colList = VVoLtS.VVkHbA()
  if mode == "localIptv":
   chName, chUrl = CCfw0y_inatance.VVuGgJ(VVoLtS, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CCfw0y_inatance.VVfvso(VVoLtS, colList)
  elif isinstance(mode, int):
   chName, chUrl = CCfw0y_inatance.VVDEiy(mode, VVoLtS, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CCfw0y_inatance.VV9kBQ(mode, VVoLtS, colList)
  else:
   self.VVGn4x("Cannot Zap")
   return
  FFrvm6(self, chUrl, VViFts=False)
  self.VVriZB()
 def VVsvna(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCA3uT.VVsJTo(self)
    if posTxt:
     return
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFmvpz(self)
   if not self.VVNFjN(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVGn4x("Refreshing Portal")
   FFA9HA(self.VVIttN)
  except:
   pass
 def VVIttN(self):
  self.restoreLastPlayPos = self.VVIERc()
 def VVVaY5(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFmvpz(self)
  if not decodedUrl or FFzo2Y(decodedUrl):
   self.VVGn4x("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CCfw0y.VVKCk4(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VVGn4x("Reading Program List ...")
   ok_fnc = BF(self.VVHQvJ, refCode, chName, streamId, uHost, uUser, uPass)
   FFA9HA(BF(CCfw0y.VV2a0V, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VVGn4x("Cannot process this channel")
 def VVHQvJ(self, refCode, chName, streamId, uHost, uUser, uPass, VVoLtS, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVoLtS.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VVGn4x("Changing Program ...")
   FFA9HA(BF(self.VVdRi1, chUrl))
  else:
   self.VVGn4x("Incorrect Timestamp !")
 def VVdRi1(self, chUrl):
  FFrvm6(self, chUrl, VViFts=False)
  self.lastPlayPos = 0
  self.VVqwhp()
 def VV4vqo(self, isAudio):
  try:
   VV8OMp = InfoBar.instance
   if VV8OMp:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VV8OMp)
    else  : self.session.open(SubtitleSelection, VV8OMp)
  except:
   pass
 @staticmethod
 def VVGtOv(session, mode=None):
  if   mode == "close_sig"   : FFGuKK(session, reopen=True)
  elif mode == "close_iptvMenu"  : session.open(CCfw0y)
  elif mode == "close_openInFileMan" : session.open(CCUGPF, gotoMovie=True)
 @staticmethod
 def VV1gQV(session, **kwargs):
  session.openWithCallback(BF(CCA3uT.VVGtOv, session), CCA3uT, **kwargs)
class CCTEY0(Screen):
 def __init__(self, session, title="", VV66pG="Continue?", VVDfmh=True, VVxcAw=False):
  self.skin, self.skinParam = FF5TEn(VVzzat, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VV66pG = VV66pG
  self.VVxcAw = VVxcAw
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVDfmh : VVMVqr = [no , yes]
  else   : VVMVqr = [yes, no ]
  FF32Yx(self, title, VVMVqr=VVMVqr, addLabel=True)
  self["myActionMap"] = ActionMap(VVjUqm,
  {
   "ok" : self.VVthYm ,
   "cancel": self.cancel ,
   "red" : self.cancel ,
  }, -1)
  self.onShown.append(self.VVSDD3)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VV66pG)
  if self.VVxcAw:
   self["myLabel"].instance.setHAlign(0)
  self.VVeVui()
  FFWzaz(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFA3Mq(self["myMenu"])
  FFNoWz(self, self["myMenu"])
 def VVthYm(self):
  item = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVeVui(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  diff  = textSize.height() - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCYGgB(Screen):
 def __init__(self, session, title="", VVMVqr=None, width=1000, height=850, VVHZHw=30, barText="", minRows=1, VVmKhE=None, VVGygu=None, VVRZ74=None, VVYJ07=None, VV0afn=None, VVdhQt=None, VVy9CS=False, VVMTvd=False, VVYpxU=None, VV9LXs=True, VVZYdg="#22003344", VVcwfs="#22002233"):
  self.skin, self.skinParam = FF5TEn(VVL1I3, width, height, 50, 40, 30, VVZYdg, VVcwfs, VVHZHw, barHeight=40, topRightBtns=3 if VVGygu else 0)
  self.session   = session
  self.VVMVqr   = VVMVqr
  self.barText   = barText
  self.minRows   = minRows
  self.VVmKhE   = VVmKhE
  self.VVGygu   = VVGygu
  self.VVRZ74   = VVRZ74
  self.VVYJ07  = VVYJ07
  self.VV0afn  = ("Delete File", BF(self.VVk6mo, VVYpxU)) if not VVYpxU is None else VV0afn
  self.VVdhQt   = VVdhQt
  self.VVy9CS  = VVy9CS
  self.VVMTvd  = VVMTvd
  self.Title    = title
  FF32Yx(self, title, VVMVqr=VVMVqr)
  self["myActionMap"] = ActionMap(VVjUqm,
  {
   "ok"  : self.VVthYm    ,
   "cancel" : self.cancel    ,
   "info"  : self.VVEO8T   ,
   "red"  : self.VV5FGK   ,
   "green"  : self.VV2UFj   ,
   "yellow" : self.VV8owS   ,
   "blue"  : self.VVj5xB   ,
   "pageUp" : self.VVP1r8 ,
   "chanUp" : self.VVP1r8 ,
   "pageDown" : self.VV6q16  ,
   "chanDown" : self.VV6q16  ,
   "0"   : BF(self.VVmEjq, 0) ,
   "1"   : BF(self.VVmEjq, 1) ,
   "2"   : BF(self.VVmEjq, 2) ,
   "3"   : BF(self.VVmEjq, 3) ,
   "4"   : BF(self.VVmEjq, 4) ,
   "5"   : BF(self.VVmEjq, 5) ,
   "6"   : BF(self.VVmEjq, 6) ,
   "7"   : BF(self.VVmEjq, 7) ,
   "8"   : BF(self.VVmEjq, 8) ,
   "9"   : BF(self.VVmEjq, 9)
  }, -1)
  if VV9LXs:
   FFwY39(self, self["myMenu"], isMenu=True)
  self.onShown.append(self.VVSDD3)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  FFWzaz(self["myMenu"])
  FF0pG3(self, minRows=self.minRows)
  FFDoNq(self)
  self.VVnpAQ(self["keyRed"]  , self.VVRZ74 )
  self.VVnpAQ(self["keyGreen"] , self.VVYJ07 )
  self.VVnpAQ(self["keyYellow"] , self.VV0afn )
  self.VVnpAQ(self["keyBlue"]  , self.VVdhQt )
  if self.barText      : self["myBar"].setText("  %s" % self.barText)
  elif not self["keyRed"].getVisible(): self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFieY3(self)
 def VVnpAQ(self, btnObj, btnFnc):
  if btnFnc:
   FFCDDm(btnObj, btnFnc[0])
 def VVnF2F(self, fnc=None):
  self.VVYJ07 = fnc
  if fnc : self.VVnpAQ(self["keyGreen"], self.VVYJ07)
  else : self["keyGreen"].hide()
 def VVmEjq(self, digit):
  digit = str(digit)
  VVMVqr = self["myMenu"].list
  for ndx, item in enumerate(VVMVqr):
   if len(item) == 2:
    span = iSearch(r"^\[(\d)\]\s.+", FFQdrB(item[0]), IGNORECASE)
    if span and span.group(1) == digit:
     self.VVT53N(ndx)
     self.VVthYm()
     break
 def VVthYm(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if item is not None:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   if self.VVmKhE:
    self.VVmKhE((self, txt, ref, ndx))
   else:
    if self.VVy9CS: self.close((txt, ref, ndx))
    else     : self.close(item)
 def VVEO8T(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if self.VVGygu and item:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   self.VVGygu(self, txt, ref, ndx)
 def cancel(self):
  self.close(None)
 def VV5FGK(self)  : self.VVoBBS(self.VVRZ74)
 def VV2UFj(self) : self.VVoBBS(self.VVYJ07)
 def VV8owS(self) : self.VVoBBS(self.VV0afn)
 def VVj5xB(self) : self.VVoBBS(self.VVdhQt)
 def VVoBBS(self, btnFnc):
  if btnFnc:
   item = self["myMenu"].l.getCurrentSelection()[1]
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVMTvd:
    self.cancel()
 def VVsFUY(self):
  ndx = self["myMenu"].getSelectedIndex()
  VVMVqr = self["myMenu"].list
  VVMVqr.pop(ndx)
  if len(VVMVqr) > 0: self["myMenu"].setList(VVMVqr)
  else    : self.close()
 def VVk6mo(self, basePath, menuObj, fName):
  FFo4dm(self, BF(self.VV9M7b, basePath + fName), "Delete this file ?\n\n%s" % fName, title=self.Title)
 def VV9M7b(self, path):
  FFnPMX(path)
  if fileExists(path) : FFycel(self, "Not deleted", 1000)
  else    : self.VVsFUY()
 def VVInEv(self, VVMVqr):
  if len(VVMVqr) > 0:
   newList = []
   for item in VVMVqr:
    newList.append((item, item))
   self["myMenu"].setList(newList)
   FF0pG3(self, minRows=self.minRows)
  else:
   self.close("")
 def VVe40s(self, newRow, isSort=False):
  lst = self["myMenu"].list
  lst.append(newRow)
  if isSort:
   lst.sort(key=lambda x: x[0].lower())
  self["myMenu"].setList(lst)
  FF0pG3(self, minRows=self.minRows)
  for ndx, item in enumerate(self["myMenu"].list):
   if item[1] == newRow[1]:
    self["myMenu"].moveToIndex(ndx)
    break
 def VVkpcz(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVT53N(self, ndx):
  self["myMenu"].moveToIndex(ndx)
 def VV4FTn(self, refTxt):
  for ndx, item in enumerate(self["myMenu"].list):
   if refTxt == item[1]:
    self.VVT53N(ndx)
    break
 def VVzELa(self, txt):
  for ndx, item in enumerate(self["myMenu"].list):
   if txt == item[0]:
    self.VVT53N(ndx)
    break
 def VVP1r8(self) : self["myMenu"].moveToIndex(0)
 def VV6q16(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCYFn3(Screen):
 def __init__(self, session, title="", width=1600, height=900, vMargin=5, header=None, VVWsIU=None, VViqYN=None, VVv3Wm=None, VVHZHw=26, isEditor=False, addSort=True, VV65AN=False, VVklCm=0, picParams=None, VVd479=None, VV1Jd7=None, menuButtonFnc=None, VVKDDh=None, VVEXwE=None, VV7J8f=None, VVJvWF=None, VVX8rQ=None, VV4ePT=None, VVNYAK=None, VVMYDy=-1, VVcK1v=0, searchCol=0, lastFindConfigObj=None, VVZYdg="#22003344", VVcwfs="#22002233", VVDO4H="#00dddddd", VVLuY4="#11002233", VVVU1s=None, VVG27K="#11111111", borderWidth=1, VVQ9hc="#0a555555", VVzAj3="#0affffff", VVGpiI="#11552200", VVbTmN="#0055ff55", VVbTmNRev="#0000bbff"):
  self.skin, self.skinParam = FF5TEn(VV2ZP4, width, height, 50, 10, vMargin, VVZYdg, VVcwfs, 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FF32Yx(self, title)
  self.Title     = title
  self.header     = header
  self.VVWsIU     = VVWsIU
  self.totalCols    = len(VVWsIU[0])
  self.VVklCm   = VVklCm
  self.picParams    = picParams
  self.lastSortModeIsReverese = False
  self.VV65AN   = VV65AN
  self.VVYmNn   = 0.01
  self.VVp78z   = 0.02
  self.VVOPpg = 0.03
  self.VVGMZr  = 1
  self.VVv3Wm = VVv3Wm
  self.colWidthPixels   = []
  self.VVd479   = VVd479
  self.OKButtonObj   = None
  self.VV1Jd7   = VV1Jd7
  self.VVKDDh   = VVKDDh
  self.VVEXwE   = VVEXwE
  self.VV7J8f  = VV7J8f
  self.VVJvWF   = VVJvWF
  self.VVX8rQ    = VVX8rQ
  self.VV4ePT   = VV4ePT
  self.tableRefreshCB   = None
  self.VVNYAK  = VVNYAK
  self.menuButtonFnc   = menuButtonFnc
  self.VVMYDy    = VVMYDy
  self.VVcK1v   = VVcK1v
  self.searchCol    = searchCol
  self.VViqYN    = VViqYN
  self.keyPressed    = -1
  self.VVHZHw    = FFsu0Y(VVHZHw)
  self.isEditor    = isEditor
  self.addSort    = addSort
  self.VVjcdW    = FFYyT1(self.VVHZHw, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVZYdg    = VVZYdg
  self.VVcwfs      = VVcwfs
  self.VVDO4H    = FFBCuC(VVDO4H)
  self.VVLuY4    = FFBCuC(VVLuY4)
  self.VVVU1s    = VVVU1s
  self.VVG27K    = FFBCuC(VVG27K)
  self.borderWidth   = borderWidth
  self.VVQ9hc   = FFBCuC(VVQ9hc)
  self.VVzAj3    = FFBCuC(VVzAj3)
  self.VVGpiI    = FFBCuC(VVGpiI)
  self.VVbTmN   = FFBCuC(VVbTmN)
  self.VVbTmNRev  = FFBCuC(VVbTmNRev)
  self.VVzBSi  = False
  self.selectedItems   = 0
  self.VVmn1H   = FFBCuC("#06542132")
  self.onMultiSelFnc   = None
  self.lastFindConfigObj  = lastFindConfigObj or CFG.lastFindGeneral
  if self.VVcK1v:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   if self.VVcK1v == 1: self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] = MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  = MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(VVjUqm,
  {
   "ok"  : self.VVl5Rs  ,
   "red"  : self.VVTdvt  ,
   "green"  : self.VVJ3o2 ,
   "yellow" : self.VVMOsM ,
   "blue"  : self.VVcxVd  ,
   "menu"  : self.VVbDWu ,
   "info"  : self.VVQCCW  ,
   "cancel" : self.VVT6A6  ,
   "up"  : self.VVdxRQ    ,
   "down"  : self.VVutJy  ,
   "left"  : self.VVV1Tm   ,
   "right"  : self.VVKdZC  ,
   "next"  : self.VVwK6F  ,
   "last"  : self.VVhMXe  ,
   "home"  : self.VV4DBv  ,
   "pageUp" : self.VV4DBv  ,
   "chanUp" : self.VV4DBv  ,
   "end"  : self.VV18ki  ,
   "pageDown" : self.VV18ki  ,
   "chanDown" : self.VV18ki
  }, -1)
  FFwY39(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVSDD3)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  FFDoNq(self)
  try:
   self.VVVGUu()
  except Exception as e:
   FFzrXb(self, str(e), title=self.Title)
   self.close(None)
 def VVVGUu(self):
  FFieY3(self)
  self.VVnpAQ(self.VVKDDh , self["keyRed"])
  self.VVnpAQ(self.VVEXwE , self["keyGreen"])
  self.VVnpAQ(self.VV7J8f, self["keyYellow"])
  self.VVnpAQ(self.VVJvWF , self["keyBlue"])
  if self.VVd479:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj and self.VVd479[0]:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVd479[0])
    FFzBm8(self.OKButtonObj, "#11000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVjcdW)
  self["myTableH"].l.setFont(0, gFont(VVXtOH, self.VVHZHw))
  self["myTable"].l.setItemHeight(self.VVjcdW)
  self["myTable"].l.setFont(0, gFont(VVXtOH, self.VVHZHw))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w = self["myTable"].instance.size().width()
  h = self["myTable"].instance.size().height()
  pos = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVjcdW)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVjcdW))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVjcdW)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVjcdW
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVjcdW * len(self.VVWsIU) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVv3Wm:
   self.VVv3Wm = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVv3Wm)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VViqYN:
   self.VViqYN = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VViqYN
   self.VViqYN = []
   for item in tmpList:
    self.VViqYN.append(item | RT_VALIGN_CENTER)
  self.VVoca7()
  if self.VVX8rQ:
   self.VVX8rQ(self)
 def VVnpAQ(self, btnFnc, btn):
  if btnFnc : FFCDDm(btn, btnFnc[0])
  else  : FFCDDm(btn, "")
 def VVSfg4(self, waitTxt):
  FFzW1w(self, self.VVoca7, title=waitTxt)
 def VVoca7(self, onlyHeader=False):
  try:
   if self.header:
    sortedFg = self.VVbTmNRev if self.lastSortModeIsReverese else self.VVbTmN
    self["myTableH"].setList([self.VVoD6W(0, self.header, self.VVzAj3, self.VVGpiI, None, self.VVGpiI, sortedFg)])
   if onlyHeader:
    return
   self["myTable"].list = []
   for c, row in enumerate(self.VVWsIU):
    self["myTable"].list.append(self.VVoD6W(c, row, self.VVDO4H, self.VVLuY4, self.VVVU1s, self.VVG27K, None))
   self.VVWsIU = []
   self["myTable"].setList(self["myTable"].list)
   if self.VVMYDy > -1:
    self["myTable"].moveToIndex(self.VVMYDy )
   self.VVwzbK()
   if self.VVcK1v:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVjcdW * len(self["myTable"].list)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
     FFRlMK(self, width, newH)
   if self.VV4ePT:
    self.VVoBBS(self.VV4ePT, None)
   if self.tableRefreshCB:
    self.VVoBBS(self.tableRefreshCB, None)
    self.tableRefreshCB = None
  except AttributeError as attrErr:
   pass
  except Exception as e:
   try:
    FFzrXb(self, str(e), title=self.Title)
    self.close()
   except:
    pass
 def VVoD6W(self, keyIndex, columns, VVDO4H, VVLuY4, VVVU1s, VVG27K, VVbTmN):
  row = [keyIndex]
  if VVVU1s:
   VVVU1s = FFBCuC(VVVU1s)
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVbTmN and ndx == self.VVklCm : textColor = VVbTmN
   else           : textColor = VVDO4H
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFBCuC(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVLuY4 = c
    entry = span.group(3)
   if not self.isEditor and self.VViqYN[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVjcdW)
           , font   = 0
           , flags   = self.VViqYN[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVLuY4
           , color_sel  = VVVU1s or textColor
           , backcolor_sel = VVG27K
           , border_width = self.borderWidth
           , border_color = self.VVQ9hc
           ))
   posX += self.colWidthPixels[ndx]
  if not VVbTmN and self.picParams:
   picPosCol, picFnc, pathCol = self.picParams
   if   picFnc : png = picFnc(columns)
   elif pathCol: png = columns[pathCol].strip()
   else  : png = ""
   if png.startswith("/"):
    try:
     pngX = sum(self.colWidthPixels[:picPosCol])
     row.append(CCYFn3.VVsoXp(pngX+2, picPosCol+2, self.colWidthPixels[picPosCol]-4, self.VVjcdW-4, LoadPixmap(png)))
    except:
     pass
  return row
 def VVQCCW(self):
  rowData = self.VVwSKe()
  if rowData:
   title, txt, colList = rowData
   if self.VV1Jd7:
    fnc  = self.VV1Jd7[1]
    params = self.VV1Jd7[2]
    fnc(self, title, txt, colList)
   else:
    FFtybv(self, txt, title)
 def VVl5Rs(self):
  if   self.VVzBSi : self.VVFObM(self.VVqeSa(), mode=2)
  elif self.VVd479  : self.VVoBBS(self.VVd479, None)
  else      : self.VVQCCW()
 def VVTdvt(self) : self.VVoBBS(self.VVKDDh , self["keyRed"])
 def VVJ3o2(self) : self.VVoBBS(self.VVEXwE , self["keyGreen"])
 def VVMOsM(self): self.VVoBBS(self.VV7J8f , self["keyYellow"])
 def VVcxVd(self) : self.VVoBBS(self.VVJvWF , self["keyBlue"])
 def VVoBBS(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFycel(self, buttonFnc[3])
    FFA9HA(BF(self.VVTbAR, buttonFnc))
   else:
    self.VVTbAR(buttonFnc)
 def VVTbAR(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVwSKe()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVFObM(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   isSelected = row[1][10] == self.VVmn1H
   if mode == 0 or (mode == 2 and isSelected):
    bg = self.VVLuY4
    if isSelected:
     self.selectedItems -= 1
   else:
    bg = self.VVmn1H
    if not isSelected:
     self.selectedItems += 1
   for col in range(1, len(row)):
    cols = list(row[col])
    if cols[0] == eListboxPythonMultiContent.TYPE_TEXT:
     cols[10] = bg
    row[col] = tuple(cols)
   self["myTable"].l.invalidate()
   if self.VVqeSa() < len(self["myTable"].list) - 1 : self.VVutJy()
   else              : self.VVwzbK()
   if self.onMultiSelFnc:
    self.onMultiSelFnc()
 def VVfjV6(self)  : FFzW1w(self, BF(self.VVBG0m, True ), title="Selecting all ..."  )
 def VVAaK8(self) : FFzW1w(self, BF(self.VVBG0m, False), title="Unselecting all ...")
 def VVBG0m(self, isSel=True):
  if isSel:
   bg = self.VVmn1H
   self.selectedItems = len(self["myTable"].list)
   self.VV14UF(True)
  else:
   bg = self.VVLuY4
   self.selectedItems = 0
  for ndx, row in enumerate(self["myTable"].list):
   isPainted = row[1][10] == self.VVmn1H
   if (isSel and not isPainted) or (not isSel and isPainted):
    for col in range(1, len(row)):
     cols = list(self["myTable"].list[ndx][col])
     if cols[0] == eListboxPythonMultiContent.TYPE_TEXT:
      cols[10] = bg
     self["myTable"].list[ndx][col] = tuple(cols)
  self["myTable"].l.invalidate()
 def VVwSKe(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVv3Wm[i] > 1 or self.VVv3Wm[i] == self.VVYmNn or self.VVv3Wm[i] == self.VVOPpg:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self["myTable"].list))
   return rowNum, txt, colList
  else:
   return None
 def VVT6A6(self):
  self["myTable"].onSelectionChanged = []
  if self.VVNYAK : self.VVNYAK(self)
  else     : self.close(None)
 def cancel(self):
  self["myTable"].onSelectionChanged = []
  self.close(None)
 def VVqJjk(self):
  return self["myTitle"].getText().strip()
 def VVPdoF(self):
  return self.header
 def VVTWCM(self, title):
  self.Title = title
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVyemz(self, title, color=None):
  self["myBar"].setText("  " + title.strip() + "  ")
  if color:
   FFcdG1(self["myBar"], color)
 def VVwNb0(self, txt):
  FFycel(self, txt)
 def VVOPq5(self, txt, Time=1000):
  FFycel(self, txt, Time)
 def VVQoym(self): self["keyGreen"].show()
 def VVSiJd(self): self["keyGreen"].hide()
 def VVehBR(self): return self["keyGreen"].visible
 def VV6eCK(self):
  FFycel(self)
 def VVKoPU(self, fnc, callFnc=False):
  self["myTable"].onSelectionChanged.append(fnc)
  if callFnc:
   fnc()
 def VVaeaf(self):
  return len(self["myTable"].list)
 def VVqeSa(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVgRm7(self):
  return len(self["myTable"].list)
 def VV14UF(self, isOn):
  self.VVzBSi = isOn
  if isOn:
   color = "#01883366"
   self["keyMenu"].hide()
   if self.VVJvWF: self["keyBlue"].hide()
   if self.VVd479 and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.VVZYdg
   self["keyMenu"].show()
   if self.VVJvWF: self["keyBlue"].show()
   if self.VVd479 and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVd479[0])
   self.VVAaK8()
  FFzBm8(self["myTitle"], color)
  FFzBm8(self["myBar"]  , color)
 def VVyLkw(self):
  return self.VVzBSi
 def VVv3mu(self):
  return self.selectedItems
 def VVxvln(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVwzbK()
 def VVXEBn(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self["myTable"].list:
    lst.add(item[colNum + 1][7])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVq35b(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVaeaf()
  txt += FFLhxe("Total Unique Items", VVtz60)
  for i in range(self.totalCols):
   if self.VVv3Wm[i - 1] > 1 or self.VVv3Wm[i - 1] == self.VVYmNn or self.VVv3Wm[i - 1] == self.VVOPpg:
    name, tot = self.VVXEBn(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFtybv(self, txt)
 def VVh7wm(self, colNum, isStrip=True):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip() if isStrip else item[colNum + 1][7]
  else : return None
 def VVkHbA(self):
  return self.VVTQjx(self["myTable"].l.getCurrentSelectionIndex())
 def VVTQjx(self, rowNdx):
  colList = []
  item = self["myTable"].list[rowNdx]
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVkYNn(self, newList, newTitle="", VVz586Msg=True, tableRefreshCB=None, isSort=True):
  if newTitle:
   self.VVTWCM(newTitle)
  if newList:
   self.VVWsIU = newList
   if tableRefreshCB:
    self.tableRefreshCB = ("", tableRefreshCB, [])
   isNum = False
   if self.VV65AN and self.VVklCm == 0:
    isNum = True
   else:
    for cols in self.VVWsIU:
     if not FFSxn2(cols[self.VVklCm]): break
    else:
     isNum = True
   if isSort:
    if isNum: self.VVWsIU.sort(key=lambda x: int(x[self.VVklCm])  , reverse=self.lastSortModeIsReverese)
    else : self.VVWsIU.sort(key=lambda x: x[self.VVklCm].lower() , reverse=self.lastSortModeIsReverese)
   if VVz586Msg : self.VVSfg4("Refreshing ...")
   else   : self.VVoca7()
  else:
   FFzrXb(self, "Cannot refresh list", title=self.Title)
   self.cancel()
 def VVY957(self, row, moveCurs=True):
  row = self["myTable"].list.append(self.VVoD6W(self.VVgRm7(), row, self.VVDO4H, self.VVLuY4, self.VVVU1s, self.VVG27K, None))
  self["myTable"].l.setList(self["myTable"].list)
  if moveCurs: self.VV18ki()
 def VVftBC(self):
  self["myTable"].list.pop(self.VVqeSa())
  self["myTable"].l.setList(self["myTable"].list)
 def VVlhah(self, data):
  ndx = self.VVqeSa()
  newRow = self.VVoD6W(ndx, data, self.VVDO4H, self.VVLuY4, self.VVVU1s, self.VVG27K, None)
  if newRow:
   self["myTable"].list[ndx] = newRow
   self.VVwzbK()
   return True
  else:
   return False
 def VVLLe5(self, tDict):
  ndx = self.VVqeSa()
  for colNum, val in tDict.items():
   txt = str(val)
   if not self.isEditor and self.VViqYN[ndx] & LEFT:
    txt = " %s " % txt.strip()
   col = list(self["myTable"].list[ndx][colNum + 1])
   col[7] = txt
   self["myTable"].list[ndx][colNum + 1] = tuple(col)
  self.VVCb7d()
 def VVzJT7(self, ndx, data):
  if ndx >=0 and ndx < len(self["myTable"].list):
   newRow = self.VVoD6W(ndx, data, self.VVDO4H, self.VVLuY4, self.VVVU1s, self.VVG27K, None)
   if newRow:
    self["myTable"].list[ndx] = newRow
    self.VVCb7d()
 def VVCb7d(self):
  self["myTable"].l.setList(self["myTable"].list)
  self.VVwzbK()
 def VVnSKz(self, colNum=0):
  for ndx, item in enumerate(self["myTable"].list):
   lst = list(self["myTable"].list[ndx][colNum + 1])
   lst[7] = str(ndx + 1)
   self["myTable"].list[ndx][colNum + 1] = tuple(lst)
  self["myTable"].l.setList(self["myTable"].list)
 def VVVRgf(self, colNum, textToFind, VVx3z3=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVwzbK()
    break
  else:
   if VVx3z3:
    FFycel(self, "Not found", 1000)
 def VVQ2Hx(self, colDict, VVx3z3=False):
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVwzbK()
    return
  if VVx3z3:
   FFycel(self, "Not found", 1000)
  return False
 def VVpQnT(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VV8Pb7(self, colNum):
  for i in range(len(self["myTable"].list)):
   if not FFSxn2(self["myTable"].list[i][colNum + 1][7].strip()):
    return False
  return True
 def VVCtEG(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][10] == self.VVmn1H:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVwg1G(self):
  if self.selectedItems:
   for ndx, row in enumerate(self["myTable"].list):
    if row[1][10] == self.VVmn1H:
     return ndx
  return -1
 def VV3z03(self):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][10] == self.VVmn1H:
    item = self["myTable"].list[ndx]
    colList = []
    for i in range(1, self.totalCols + 1):
     colList.append(item[i][7].strip())
    tList.append(colList)
  return tList
 def VV4pjK(self, colNum):
  row = self["myTable"].list[colNum]
  if row[1][10] == self.VVmn1H : return True
  else        : return False
 def VVGkEL(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVbDWu(self):
  if self.menuButtonFnc:
   self.VVTbAR(self.menuButtonFnc)
   return
  if not self["keyMenu"].getVisible() or self.VVcK1v:
   return
  txt  = self.lastFindConfigObj.getValue()
  curRow = self.VVqeSa()
  totRows = len(self["myTable"].list)
  itemOf = lambda cond, p1, p2: (p1, p2) if cond else (p1, )
  VVMVqr1, VVmkmv = CCOe8b.VVWl7I(self, False, False)
  VVMVqr = []
  VVMVqr.append(itemOf(txt and curRow < totRows - 1 , "Find Next\t\t>"     , "findNext"  ))
  VVMVqr.append(itemOf(txt and curRow > 0   , "Find Previous\t\t<"    , "findPrev"  ))
  VVMVqr.append(("Find ...\t\t%s" % (FFCzRx(txt, VVAaU5) if txt else ""), "findNew"   ))
  VVMVqr.append(itemOf(bool(VVMVqr1)    , "Find (from Filter) ..."   , "filter"   ))
  if self.header:
   VVMVqr.append(VVpTvr)
   VVMVqr.append(("Table Statistcis"            , "tableStat"  ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append((FFCzRx("Export Table to .html"     , VVtz60) , "VVaZPl" ))
  VVMVqr.append((FFCzRx("Export Table to .csv"     , VVtz60) , "VV7joT" ))
  VVMVqr.append((FFCzRx("Export Table to .txt (Tab Separated)", VVtz60) , "VVcny6" ))
  if self.addSort:
   sList = []
   tot  = 0
   for i in range(self.totalCols):
    if self.VVv3Wm[i] > 1 or self.VVv3Wm[i] == self.VVp78z:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     sList.append(("Sort by : %s" % name, i))
   if tot:
    VVMVqr.append(VVpTvr)
    if tot == 1 : VVMVqr.append(("Sort", sList[0][1]))
    else  : VVMVqr += sList
  VVdhQt = ("Keys Help", self.FFldB6Help)
  FF7ARM(self, self.VVrbAJ, VVMVqr=VVMVqr, title=self.VVqJjk(), VVdhQt=VVdhQt)
 def VVrbAJ(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "findNext"  : self.VV9JDE()
   elif item == "findPrev"  : self.VV9JDE(isPrev=True)
   elif item == "findNew"  : self.VVS9cn()
   elif item == "filter"  : self.VVTeDG()
   elif item == "tableStat" : self.VVq35b()
   elif item == "VVaZPl": FFzW1w(self, self.VVaZPl, title=title)
   elif item == "VV7joT" : FFzW1w(self, self.VV7joT , title=title)
   elif item == "VVcny6" : FFzW1w(self, self.VVcny6 , title=title)
   else:
    if self.VVklCm == item: self.lastSortModeIsReverese = not self.lastSortModeIsReverese
    else      : self.VVklCm, self.lastSortModeIsReverese = item, False
    if self.VV65AN and self.VVklCm == 0 or self.VV8Pb7(item):
     self["myTable"].list.sort(key=lambda x: int(x[item + 1][7]), reverse=self.lastSortModeIsReverese)
    else:
     self["myTable"].list.sort(key=lambda x: x[item + 1][7].lower(), reverse=self.lastSortModeIsReverese)
    self["myTable"].l.setList(self["myTable"].list)
    self.VVoca7(onlyHeader=True)
 def FFldB6Help(self, VVdtUh, path):
  FFGkYk(self, "_help_table", "Table (Keys Help)")
 def VVdxRQ(self):
  self["myTable"].up()
  self.VVwzbK()
 def VVutJy(self):
  self["myTable"].down()
  self.VVwzbK()
 def VVV1Tm(self):
  self["myTable"].pageUp()
  self.VVwzbK()
 def VVKdZC(self):
  self["myTable"].pageDown()
  self.VVwzbK()
 def VV4DBv(self):
  self["myTable"].moveToIndex(0)
  self.VVwzbK()
 def VV18ki(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVwzbK()
 def VV7qpv(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VVwzbK()
 def VVwK6F(self):
  if self.lastFindConfigObj.getValue():
   if self.VVqeSa() == len(self["myTable"].list) - 1 : FFycel(self, "End reached", 1000)
   else              : self.VV9JDE()
  else:
   FFycel(self, 'Set "Find" in Menu', 1500)
 def VVhMXe(self):
  if self.lastFindConfigObj.getValue():
   if self.VVqeSa() == 0 : FFycel(self, "Top reached", 1000)
   else       : self.VV9JDE(isPrev=True)
  else:
   FFycel(self, 'Set "Find" in Menu', 1500)
 def VVOnjm(self, txt):
  FF2tHk(self.lastFindConfigObj, txt)
 def VVS9cn(self):
  FFBgSg(self, self.VVeiYe, title="Find in Table", defaultText=self.lastFindConfigObj.getValue(), message="Enter Text:")
 def VVeiYe(self, VVEKeH):
  if not VVEKeH is None:
   txt = VVEKeH.strip()
   self.VVOnjm(txt)
   if VVEKeH: self.VV9JDE(reset=True)
   else  : FFycel(self, "Nothing to find !", 1500)
 def VVTeDG(self):
  VVMVqr, VVmkmv = CCOe8b.VVWl7I(self, False, False)
  VV0afn = ("Edit Filter", BF(self.VVrtnc, VVmkmv))
  if VVMVqr : FF7ARM(self, self.VVO5jN, VVMVqr=VVMVqr, VV0afn=VV0afn, title="Find from Filter")
  else  : FFycel(self, "Filter Error !", 1500)
 def VVO5jN(self, item=None):
  if item is not None:
   txt = item.strip()
   if txt:
    self.VVOnjm(txt)
    self.VV9JDE(reset=True)
   else:
    FFycel(self, "No entry !", 1500)
 def VVrtnc(self, VVmkmv, selectionObj, sel):
  if fileExists(VVmkmv) : CCH94c(self, VVmkmv, VVEStC=None)
  else       : FFZ5Ys(self, VVmkmv)
  selectionObj.cancel()
 def VV9JDE(self, reset=False, isPrev=False):
  curRow = self.VVqeSa()
  totRows = len(self["myTable"].list)
  if   reset : row1, row2, steps = 0, totRows, 1
  elif isPrev : row1, row2, steps = curRow - 1, -1, -1
  else  : row1, row2, steps = curRow + 1, totRows, 1
  tupl, asPrefix = CCOe8b.VVjxXj(self.lastFindConfigObj.getValue())
  if tupl:
   for i in range(row1, row2, steps):
    line = self["myTable"].list[i][self.searchCol + 1][7]
    line = line.strip().lower()
    if asPrefix:
     if line.startswith(tupl):
      self.VV7qpv(i)
      break
    elif any(x in line for x in tupl):
     self.VV7qpv(i)
     break
   else:
    FFycel(self, "Not found", 1000)
  else:
   FFycel(self, "Check your query", 1500)
 def VVcny6(self):
  expFile = self.VVjHc1() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVZVey()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for i in range(len(self["myTable"].list)):
    row = self.VVTQjx(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVv3Wm[ndx] > self.VVGMZr or self.VVv3Wm[ndx] == self.VVOPpg:
      col = self.VV1YH1(col)
      col = col.replace("\n", " _ ")
      newRow.append(col)
    f.write("\t".join(newRow) + "\n")
  self.VVc3ug(expFile)
 def VV7joT(self):
  expFile = self.VVjHc1() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVZVey()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for i in range(len(self["myTable"].list)):
    row = self.VVTQjx(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVv3Wm[ndx] > self.VVGMZr or self.VVv3Wm[ndx] == self.VVOPpg:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      col = self.VV1YH1(col)
      col = col.replace(",", ";").replace("\n", " _ ")
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVc3ug(expFile)
 def VVaZPl(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVqJjk(), PLUGIN_NAME, VVAnTo)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVqJjk()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVZVey()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVv3Wm:
   colgroup += '   <colgroup>'
   for w in self.VVv3Wm:
    if w > self.VVGMZr or w == self.VVOPpg:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVjHc1() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for i in range(len(self["myTable"].list)):
    row = self.VVTQjx(i)
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVv3Wm[ndx] > self.VVGMZr or self.VVv3Wm[ndx] == self.VVOPpg:
      col = self.VV1YH1(col)
      newRow += '<td>%s</td>' % col
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVc3ug(expFile)
 def VVZVey(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVv3Wm[ndx] > self.VVGMZr or self.VVv3Wm[ndx] == self.VVOPpg:
     newRow.append(col.strip())
  return newRow
 def VV1YH1(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FFQdrB(col)
 def VVjHc1(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVqJjk())
  fileName = fileName.replace("__", "_")
  path  = FF5DjF(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FF4rM4()
  return expFile
 def VVc3ug(self, expFile):
  FFuXZg(self, "File exported to:\n\n%s" % expFile, title=self.VVqJjk())
 def VVwzbK(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   totCols = len(row)
   if row[totCols - 1][0] == eListboxPythonMultiContent.TYPE_TEXT:
    lastCol = totCols - 1
   else:
    lastCol = totCols - 2
   x, y, w, h = row[lastCol][1:5]
   self["myTable"].l.setSelectionClip(eRect(0, 0, int(x + w), int(h)), True)
 @staticmethod
 def VVsoXp(x, y, w, h, png, bg=None, bgSel=None):
  typ = eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST
  if VV8rbD: return (typ, x, y, w, h, png, bg, bgSel, VV8rbD | CENTER)
  else   : return (typ, x, y, w, h, png, bg, bgSel)
class CCty9w():
 def __init__(self, pixmapObj, picPath, VVLuY4=None):
  from enigma import ePicLoad
  from Components.AVSwitch import AVSwitch
  self.picLoad  = ePicLoad()
  self.scale   = AVSwitch().getFramebufferScale()
  self.picload_conn = None
  self.pixmapObj  = pixmapObj
  self.picPath  = picPath
  self.VVLuY4  = VVLuY4 or "#2200002a"
 def VVfXaB(self):
  if self.pixmapObj and self.picPath and fileExists(self.picPath):
   try:
    try:
     self.picload_conn = self.picLoad.PictureData.connect(self.VV6MNY)
    except:
     self.picLoad.PictureData.get().append(self.VV6MNY)
    size = self.pixmapObj.instance.size()
    self.picLoad.setPara([size.width(), size.height(), self.scale[0], self.scale[1], False, 1, self.VVLuY4])
    self.picLoad.startDecode(self.picPath)
    return True
   except:
    pass
  return False
 def VV6MNY(self, pInfo=""):
  if self.picLoad and pInfo:
   ptr = self.picLoad.getData()
   if ptr != None:
    try:
     self.pixmapObj.instance.setPixmap(ptr)
    except:
     pass
 def VVeafN(self):
  del self.picLoad
  self.picLoad = None
  self.picload_conn = None
 @staticmethod
 def VVu2OK(pixmapObj, path, VVLuY4=None):
  cl = CCty9w(pixmapObj, path, VVLuY4)
  ok = cl.VVfXaB()
  if ok: return cl
  else : return None
class CCwf80(Screen):
 def __init__(self, session, VVxlEn, title="", showGrnMsg="", fileList=None, curIndex=0, fakePath=None, cbFnc=None):
  scrW, scrH = FFM4r3()
  w = 1700
  h = int(min(w * scrH / scrW + 51, 1040))
  self.skin, self.skinParam = FF5TEn(VV8Fi7, w, h, 30, 0, 0, "#22000060", "#2200002a", 30, topRightBtns=3)
  self.session  = session
  self.Title   = title
  self["myPic"]  = Pixmap()
  self.VVxlEn = VVxlEn
  self.showGrnMsg  = showGrnMsg
  self.fileList  = fileList
  self.curIndex  = curIndex
  self.fakePath  = fakePath
  self.cbFnc   = cbFnc
  self.picViewer  = None
  FF32Yx(self)
  self["myActionMap"] = ActionMap(VVjUqm,
  {
   "ok" : self.close    ,
   "red" : self.close    ,
   "cancel": self.close    ,
   "info" : self.VV1UbL  ,
   "up" : BF(self.VV67KE, -1),
   "down" : BF(self.VV67KE,  1),
   "left" : BF(self.VV67KE, -1),
   "right" : BF(self.VV67KE,  1)
  }, -1)
  self.onShown.append(self.VVSDD3)
  self.onClose.append(self.onExit)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  FFDoNq(self)
  self.VVjCf9()
  self.picViewer = CCty9w.VVu2OK(self["myPic"], self.VVxlEn)
  if self.picViewer:
   if self.showGrnMsg:
    FFycel(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FFzrXb(self, "Cannot view picture file:\n\n%s" % self.VVxlEn)
   self.close()
 def onExit(self):
  if self.picViewer: self.picViewer.VVeafN()
  if self.cbFnc  : self.cbFnc(self.VVxlEn)
 def VV67KE(self, direc):
  if self.fileList:
   oldNdx = self.curIndex
   self.curIndex += direc
   if direc == -1 and self.curIndex < 0      : self.curIndex = len(self.fileList) - 1
   if direc ==  1 and self.curIndex > len(self.fileList) - 1 : self.curIndex = 0
   if not oldNdx == self.curIndex:
    fName = self.fileList[self.curIndex]
    self.VVxlEn = FF5DjF(os.path.dirname(self.VVxlEn)) + fName
    self.picViewer.picPath = self.VVxlEn
    self.picViewer.VVfXaB()
    self.VVjCf9()
 def VV1UbL(self):
  txt = "%s:\n  %s" % (FFCzRx("Path", VV61JF), self.fakePath or self.VVxlEn)
  size, sizeTxt, resTxt, form, mode = CCz5Bp.VVdVZw(self.VVxlEn)
  if any((size, sizeTxt, resTxt, form, mode)):
   txt += "\n\n%s:\n" % FFCzRx("Properties", VV61JF)
   if sizeTxt: txt += "  File Size\t: %s\n" % sizeTxt
   if resTxt : txt += "  Dimensions\t: %s\n" % resTxt
   if form   : txt += "  Format\t: %s\n"  % form
   if mode   : txt += "  Mode\t: %s\n"   % mode
  FFtybv(self, txt, title="File Information")
 def VVjCf9(self):
  if self.fileList: title = "%d/%d : %s" % (self.curIndex + 1, len(self.fileList), self.fileList[self.curIndex])
  elif self.Title : title = self.Title
  else   : title = os.path.basename(self.VVxlEn)
  self["myTitle"].setText("  %s  " % title)
 @staticmethod
 def VVR0Px(SELF, VVxlEn, **kwargs):
  SELF.session.open(CCwf80, VVxlEn, **kwargs)
class CC6hh9(Screen):
 def __init__(self, session, mviFile=None):
  self.skin, self.skinParam = FF5TEn(VV1bnu, 400, 55, 30, 0, 0, "#22004455", "#00ff0000", 30)
  self.session  = session
  self.mviFile  = mviFile
  FF32Yx(self, "Click Cancel to exit", addCloser=True)
  self.onShown.append(self.VVSDD3)
  self.onClose.append(self.onExit)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  self.curServ = self.session.nav.getCurrentlyPlayingServiceOrGroup()
  self.session.nav.stopService()
  if not FFgSm7("showiframe %s" % self.mviFile):
   self.close(-1)
 def onExit(self):
  self.session.nav.playService(self.curServ, checkParentalControl=False, forceRestart=False)
 @staticmethod
 def VVeomu(SELF, mviFile):
  SELF.session.openWithCallback(BF(CC6hh9.VVOnp0, SELF), CC6hh9, mviFile)
 @staticmethod
 def VVOnp0(SELF, reason=None):
  if reason == -1: FFzrXb(SELF, "Error while viewing mvi file.", title="MVI Viewer")
class CCjmed(Screen, ConfigListScreen):
 VV6Ddl = "ajpanel_update_url"
 def __init__(self, session):
  self.skin, self.skinParam = FF5TEn(VV8Fcs, 1400, 1050, 50, 15, 15, "#11201010", "#11101010", 27, barHeight=40, topRightBtns=1)
  self.session  = session
  self.Title   = "%s Settings" % PLUGIN_NAME
  FF32Yx(self, title=self.Title)
  FFCDDm(self["keyGreen"], "Save")
  lst = []
  lst.append(getConfigListEntry("Show in Main Menu"           , CFG.showInMainMenu   ))
  lst.append(getConfigListEntry("Show in Extensions Menu"          , CFG.showInExtensionMenu  ))
  lst.append(getConfigListEntry("Show in Channel List Context Menu"       , CFG.showInChannelListMenu  ))
  lst.append(getConfigListEntry("Show in Events Info Menu"         , CFG.EventsInfoMenu   ))
  lst.append(getConfigListEntry("Input Type"             , CFG.keyboard     ))
  lst.append(getConfigListEntry("Exit-Button Action (in File Manager and FTP)"    , CFG.FileManagerExit   ))
  lst.append(getConfigListEntry("Player Bar Hotkey"           , CFG.hotkey_signal    ))
  lst.append(getConfigListEntry("Screenshot"             , CFG.screenshotFType   ))
  lst.append(getConfigListEntry("Subtitle Files Encoding Priority"       , CFG.subtDefaultEnc   ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("Default IPTV Reference Type (defines the player)"   , CFG.iptvAddToBouquetRefType ))
  lst.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"   , CFG.autoResetFrozenIptvChan ))
  lst.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"      , CFG.hideIptvServerAdultWords ))
  lst.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"   , CFG.hideIptvServerChannPrefix ))
  lst.append(getConfigListEntry("Portal Servers Connection Timeout (seconds)"     , CFG.portalConnTimeout   ))
  lst.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"    , CFG.iptvHostsMode    ))
  lst.append(getConfigListEntry("Local Movies and IPTV Download Path"       , CFG.MovieDownloadPath   ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("PIcons Path"             , CFG.PIconsPath    ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("Backup/Restore Path"           , CFG.backupPath    ))
  lst.append(getConfigListEntry("Created Package Files (IPK/DEB/etc.) + Package Projects"  , CFG.packageOutputPath   ))
  lst.append(getConfigListEntry("Downloaded Packages (from feeds)"       , CFG.downloadedPackagesPath ))
  lst.append(getConfigListEntry("Exported Tables"            , CFG.exportedTablesPath  ))
  lst.append(getConfigListEntry("Exported PIcons/Screenshots/Pictures"      , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, lst, session)
  self.VVbmSW()
  self.onShown.append(self.VVSDD3)
 def VVbmSW(self):
  kList = {
    "ok" : self.VVthYm   ,
    "green" : self.VVTwXt ,
    "menu" : self.VVwruU ,
    "cancel": self.VV7rny ,
    }
  kLeft = kRight = None
  try:
   from Components.config import ConfigSubList, KEY_LEFT as kLeft, KEY_RIGHT as kRight
  except:
   try:
    from Components.config import ConfigSubList, ACTIONKEY_LEFT as kLeft, ACTIONKEY_RIGHT as kRight
   except:
    pass
  if not (kLeft == kRight == None):
   kList["left"] = BF(self["config"].handleKey, kLeft)
   kList["right"] = BF(self["config"].handleKey, kRight)
   try:
    kList["chanUp"]  = self["config"].pageUp
    kList["chanDown"] = self["config"].pageDown
   except:
    try:
     kList["chanUp"]  = BF(self["config"].VV6wEk, 0)
     kList["chanDown"] = BF(self["config"].VV6wEk, len(self["config"].list) - 1)
    except:
     pass
   self["config_actions"] = ActionMap(VVjUqm, kList, -1)
  else:
   self["actions"] = ActionMap(VVjUqm, kList, -1)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  FFDoNq(self)
  FFWzaz(self["config"])
  FF0pG3(self, self["config"])
  FFieY3(self)
  self["config"].onSelectionChanged.append(self.VVhsNL)
  self.VVhsNL()
  FFzBm8(self["keyRed"], "#11000000")
  self["keyRed"].show()
 def VVhsNL(self):
  cfg = self["config"].getCurrent()[1]
  if   isinstance(cfg, ConfigDirectory): txt = "Change Path"
  else         : txt = "Show Choices"
  self["keyRed"].setText("OK = %s" % txt)
 def VVthYm(self):
  title, item = self["config"].getCurrent()
  if item:
   if   item == CFG.iptvHostsMode   : self.VVvGnx()
   elif item == CFG.MovieDownloadPath   : self.VVGwVj(item, self["config"].getCurrent()[0])
   elif item == CFG.subtDefaultEnc   : self.VVADt2()
   elif isinstance(item, ConfigDirectory) : self.VVEq56(item)
   else         : CCjmed.VVLGnu(self, item, title)
 @staticmethod
 def VVLGnu(SELF, confItem, title, lst=None, cbFnc=None, isSave=False):
  if not lst:
   if   isinstance(confItem, ConfigYesNo)  : lst = [(True, "ON"), (False, "OFF")]
   elif isinstance(confItem, ConfigSelectionNumber):
    lst = confItem.choices.choices
    if not isinstance(lst[0], tuple)  : lst = [(x, x) for x in lst]
   elif isinstance(confItem, ConfigSelection) : lst = confItem.choices.choices
   else          : return
  curNdx = defNdx = -1
  VVMVqr = []
  for ndx, item in enumerate(lst):
   if len(item) == 1:
    val, txt = ("dum",SEP)
   else:
    val, txt = item
    if   val == confItem.value : curNdx, txt = ndx, VVAaU5 + txt
    elif val == confItem.default: defNdx, txt = ndx, VVRJhR + txt
   VVMVqr.append((txt, val))
  if defNdx == -1: defNdx = curNdx
  VVdhQt  = ("Current", BF(CCjmed.VVPxnQ, curNdx))
  VV0afn = ("Default", BF(CCjmed.VVPxnQ, defNdx))
  VVdtUh = FF7ARM(SELF, BF(CCjmed.VVhraB, confItem, cbFnc, isSave), VVMVqr=VVMVqr, width=1200, VV0afn=VV0afn, VVdhQt=VVdhQt, title=title, VVZYdg="#33221111", VVcwfs="#33110011")
  VVdtUh.VVT53N(curNdx)
 @staticmethod
 def VVhraB(confItem, cbFnc, isSave, item=None):
  if not item is None:
   confItem.setValue(item)
   if isSave: FF2tHk(confItem, item)
   if cbFnc: cbFnc()
 @staticmethod
 def VVPxnQ(ndx, selectionObj, item):
  selectionObj.VVT53N(ndx)
 @staticmethod
 def VV4ypx(confItem, lst):
  for ndx, item in enumerate(lst):
   if item[0] == confItem.value:
    return ndx
  return -1
 def VVGwVj(self, item, title):
  tot = CCXFYJ.VVxwF5()
  if tot : FFzrXb(self, "Cannot change while downloading.", title=title)
  else : self.VVEq56(item)
 def VVADt2(self):
  curEnc = CFG.subtDefaultEnc.getValue()
  lst = CCscRA.VVEHHn(self, "", curEnc)
  if lst:
   VV0afn = ("Default", self.VVTmgN)
   VVdhQt  = ("Current", self.VVBIXo)
   VVdtUh = FF7ARM(self, self.VVtpWt, title="Select Priority Encoding", VVMVqr=lst, width=1000, height=1000, VVdhQt=VVdhQt, VV0afn=VV0afn, VVZYdg="#22220000", VVcwfs="#22220000", VVy9CS=True)
   VVdtUh.VV4FTn(curEnc)
 def VVtpWt(self, item=None):
  if item:
   txt, enc, ndx = item
   CFG.subtDefaultEnc.setValue(enc)
 def VVTmgN(self, VVdtUh, item): VVdtUh.VV4FTn(VVImSj)
 def VVBIXo(self, VVdtUh, item): VVdtUh.VV4FTn(CFG.subtDefaultEnc.getValue())
 def VVvGnx(self):
  VVMVqr = []
  VVMVqr.append(("Auto Find" , "auto"))
  VVMVqr.append(("Custom Path" , "cust"))
  FF7ARM(self, self.VVvBTI, VVMVqr=VVMVqr, title="IPTV Hosts Files Path")
 def VVvBTI(self, item=None):
  if item:
   if item == "auto":
    CFG.iptvHostsMode.setValue(VVAHuZ)
   elif item == "cust":
    VVpn2v = self.VV1HPv()
    if VVpn2v : self.VVkL9u(VVpn2v)
    else  : self.session.openWithCallback(self.VVlKEc, BF(CCUGPF, mode=CCUGPF.VVGIMp, VVRawy="/"))
 def VVkL9u(self, VVpn2v):
  VVNYAK = self.VV3L6Z
  VVKDDh = ("Remove"  , self.VVLYbr , [])
  VV7J8f = ("Add "  , self.VVjRkc, [])
  header   = ("Directory" , "Remarks" )
  widths   = (80   , 20  )
  VViqYN  = (LEFT   , LEFT  )
  FFldB6(self, None, title="IPTV Hosts Search Paths", header=header, VVWsIU=VVpn2v, width=1200, height=700, VViqYN=VViqYN, VVv3Wm=widths, VVHZHw=26, VVNYAK=VVNYAK, VVKDDh=VVKDDh, VV7J8f=VV7J8f
    , VVZYdg="#22220000", VVcwfs="#22110000", VVLuY4="#22110011", VVG27K="#11223025", VVQ9hc="#0a333333", VVGpiI="#11400040")
 def VV3L6Z(self, VVoLtS):
  if CFG.iptvHostsDirs.getValue():
   CFG.iptvHostsMode.setValue(VVcyVF)
  VVoLtS.cancel()
 def VVlKEc(self, path):
  if path:
   FF2tHk(CFG.iptvHostsDirs, FF5DjF(path.strip()))
   VVpn2v = self.VV1HPv()
   if VVpn2v : self.VVkL9u(VVpn2v)
   else  : FFycel(self, "Cannot add dir", 1500)
 def VV8SUJ(self):
  lst = CFG.iptvHostsDirs.getValue().split(",")
  lst = list(set(list(map(str.strip, lst))))
  if len(lst) == 0 or len(lst[0]) == 0 or lst[0] == VVAHuZ:
   return []
  return lst
 def VV1HPv(self):
  lst = self.VV8SUJ()
  if lst:
   VVpn2v = []
   for Dir in lst:
    VVpn2v.append((Dir, "#f#0000ff00#Dir exists" if pathExists(Dir) else "#f#00ffa000#Not found"))
   VVpn2v.sort(key=lambda x: x[0].lower())
   return VVpn2v
  else:
   return []
 def VVjRkc(self, VVoLtS, title, txt, colList):
  sDir = parent = os.path.abspath(os.path.join(colList[0], os.pardir))
  self.session.openWithCallback(BF(self.VVcSgK, VVoLtS)
         , BF(CCUGPF, mode=CCUGPF.VVGIMp, VVRawy=sDir))
 def VVcSgK(self, VVoLtS, path):
  if path:
   path = FF5DjF(path.strip())
   if self.VVyprZ(VVoLtS, path):
    FFycel(VVoLtS, "Already added", 1500)
   else:
    lst = self.VV8SUJ()
    lst.append(path)
    FF2tHk(CFG.iptvHostsDirs, ",".join(lst))
    VVpn2v = self.VV1HPv()
    VVoLtS.VVkYNn(VVpn2v, tableRefreshCB=BF(self.VVNRCI, path))
 def VVNRCI(self, path, VVoLtS, title, txt, colList):
  self.VVyprZ(VVoLtS, path)
 def VVyprZ(self, VVoLtS, path):
  for ndx, row in enumerate(VVoLtS.VVGkEL()):
   if row[0].strip() == path.strip():
    VVoLtS.VV7qpv(ndx)
    return True
  return False
 def VVLYbr(self, VVoLtS, title, txt, colList):
  path = colList[0]
  FFo4dm(self, BF(self.VVFnnj, VVoLtS), "Remove this path from list?\n\n%s" % path, title="Remove path from list")
 def VVFnnj(self, VVoLtS):
  row = VVoLtS.VVkHbA()
  path, rem = row[0], row[1]
  VVpn2v = []
  lst = []
  for ndx, row in enumerate(VVoLtS.VVGkEL()):
   tPath, tRem = row[0].strip(), row[1].strip()
   if not path == tPath:
    lst.append(tPath)
    VVpn2v.append((tPath, tRem))
  if len(VVpn2v) > 0:
   FF2tHk(CFG.iptvHostsDirs, ",".join(lst))
   VVoLtS.VVkYNn(VVpn2v)
   FFycel(VVoLtS, "Deleted", 1500)
  else:
   FF2tHk(CFG.iptvHostsMode, VVAHuZ)
   FF2tHk(CFG.iptvHostsDirs, "")
   VVoLtS.cancel()
   FFA9HA(BF(FFycel, self, "Changed to Auto-Find", 1500))
 def VVEq56(self, configObj):
  sDir = configObj.getValue()
  self.session.openWithCallback(BF(self.VV0VTy, configObj)
         , BF(CCUGPF, mode=CCUGPF.VVGIMp, VVRawy=sDir))
 def VV0VTy(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VV7rny(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFo4dm(self, self.VVTwXt, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVTwXt(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVEsee()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVwruU(self):
  VVMVqr = []
  txt = "Use Backup Path for Package/Download/Tables/PIcons"
  if not CFG.backupPath.isChanged() : VVMVqr.append((txt    , "VV58b6"   ))
  else        : VVMVqr.append((txt    ,       ))
  VVMVqr.append(("Change Text Color Scheme (fix Transparent Text)"  , "changeColorScheme" ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Reset %s Settings" % PLUGIN_NAME      , "VVLVk7"   ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Backup %s Settings" % PLUGIN_NAME      , "VVMbEr"  ))
  VVMVqr.append(("Restore %s Settings" % PLUGIN_NAME     , "VVtUEC"  ))
  if fileExists(VVYfYu + CCjmed.VV6Ddl):
   VVMVqr.append(VVpTvr)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable", "disableChkUpdate"
   else          : txt1, txt2 = "Enable" , "enableChkUpdate"
   VVMVqr.append(('%s Checking for Update' % txt1     , txt2     ))
   VVMVqr.append(("Reinstall %s" % PLUGIN_NAME      , "VVcfab"  ))
   VVMVqr.append(("Update %s" % PLUGIN_NAME      , "VVlNJ3"   ))
  FF7ARM(self, self.VV5Lou, VVMVqr=VVMVqr, title="Config. Options")
 def VV5Lou(self, item=None):
  if item:
   if   item == "VV58b6"  : FFo4dm(self, self.VV58b6 , "Use Backup directory in all other paths (and save) ?")
   elif item == "changeColorScheme": self.session.open(CCy1Yy)
   elif item == "VVLVk7"  : FFo4dm(self, BF(self.VVLVk7, True), "Clear all settings (including File Manager bookmarks) ?")
   elif item == "VVMbEr" : self.VVMbEr()
   elif item == "VVtUEC" : FFzW1w(self, self.VVtUEC, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : FF2tHk(CFG.checkForUpdateAtStartup, True)
   elif item == "disableChkUpdate" : FF2tHk(CFG.checkForUpdateAtStartup, False)
   elif item == "VVcfab" : FFzW1w(self, BF(self.VVLgrO, True ), "Checking Server ...")
   elif item == "VVlNJ3"  : FFzW1w(self, BF(self.VVLgrO, False), "Checking Server ...")
 def VVMbEr(self):
  path = "%sajpanel_settings_%s" % (VVYfYu, FF4rM4())
  FFErQ2("grep .%s. %s > %s" % (PLUGIN_NAME, VVrs06, path))
  FFuXZg(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVtUEC(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name  = "ajpanel_settings_"
  files = FFSInC("find / %s -iname '%s*' | grep %s" % (FFWdDQ(1), name, name))
  if files:
   err = CCUGPF.VVnFIi(files)
   if err:
    FFo4dm(self, BF(self.VVMQsl, title), "No valid settings files found !\n\nLocate Manually ?", title=title)
   else:
    files = sorted(files, key=lambda t: -os.stat(t).st_mtime)
    VVMVqr = []
    for line in files:
     VVMVqr.append((line, line))
    FF7ARM(self, BF(self.VVaxm1, title), title=title, VVMVqr=VVMVqr, width=1200, VVYpxU="")
  else:
   FFzrXb(self, "No settings files found !", title=title)
 def VVMQsl(self, title, path=None):
  sDir = "/"
  for path in (VVYfYu, "/media/usb/", "/media/hdd/", "/media/"):
   if pathExists(path):
    sDir = path
    break
  self.session.openWithCallback(BF(self.VVaxm1, title), BF(CCUGPF, patternMode="ajpSet", VVRawy=sDir))
 def VVaxm1(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FF2WPS(path)
    self.VVLVk7()
    for line in lines:
     name, _, val = line.partition("=")
     try:
      confItem = eval(name)
      if confItem is not None:
       if   isinstance(confItem, ConfigInteger)  : val = int(val)
       elif isinstance(confItem, ConfigSelectionNumber): val = int(val)
       elif isinstance(confItem, ConfigYesNo)   : val = { "true": True, "false": False }.get(val.lower())
       if not val is None:
        confItem.setValue(val)
        confItem.save()
     except:
      pass
    self.VVEsee()
    FFW4ra()
    FFycel(self, "Apllied", 1500, isGrn=True)
   else:
    FFZ5Ys(self, path, title=title)
 def VV58b6(self):
  newPath = FF5DjF(VVYfYu)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVEsee()
 @staticmethod
 def VVtwV0():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVLVk7(self, exit=False):
  for (key, cfg) in CFG.content.items.items():
   cfg.setValue(cfg.default)
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVEsee()
  if exit:
   self.close()
 def VVEsee(self):
  configfile.save()
  global VVYfYu
  VVYfYu = CFG.backupPath.getValue()
  FFxKxA()
 def VVLgrO(self, force):
  pre = "Reinstall" if force else "Update"
  title = "%s %s (from server)" % (pre, PLUGIN_NAME)
  curVer, webVer, url, isHigher, err = CCjmed.VVxRAl()
  if   err    : FFzrXb(self, err, title)
  elif isHigher or force : FFo4dm(self, BF(FFzW1w, self, BF(self.VVrSd0, webVer, url, title, force)), "%s v%s and Restart ?" % ("Reinstall" if force else "Upgrade to", webVer), title=title)
  else     : FFuXZg(self, FFCzRx("No update required.", VVXF4f) + "\n\nCurrent Version = v%s\n\nWeb Version = v%s" % (curVer, webVer), title)
 def VVrSd0(self, webVer, url, title, force):
  fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if FFNJvd() == "dpkg" else "ipk")
  path, err = FFOecp(url + fName, fName, timeout=2)
  if path:
   if force: cmd = FF4ZaS(VV8F5p, path)
   else : cmd = FF4ZaS(VVYC8S, path)
   if cmd:
    cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -rf '%s'" % (cmd, path)
    FFHguD(self, cmd, title=title)
   else:
    FFV7xB(self, title=title)
  else:
   FFzrXb(self, err, title=title)
 @staticmethod
 def VVxRAl():
  span = iSearch(r"v*(\d.\d.\d)", VVAnTo, IGNORECASE)
  if span : curVer = span.group(1)
  else : return "", "", "", False, "Incorrect local version format !"
  path = VVYfYu + CCjmed.VV6Ddl
  if fileExists(path):
   span = iSearch(r"(http.+)", FFpCvR(path), IGNORECASE)
   if span : url = FF5DjF(span.group(1))
   else : return curVer, "", "", False, err
  else:
   return curVer, "", "", False, "Update File not found:\n\n%s" % path
  path, err = FFOecp(url + "version", "ajp_tmp.ver", timeout=2)
  if err:
   return curVer, "", url, False, err
  if fileExists(path):
   txt  = FFpCvR(path).strip().replace(" ", "")
   FFnPMX(path)
   span = iSearch(r"v*(\d.\d.\d)", txt.partition("=")[2], IGNORECASE)
   if span:
    webVer = span.group(1)
    webTup = tuple(map(int, (webVer.split("."))))
    curTup = tuple(map(int, (curVer.split("."))))
    return curVer, webVer, url, webTup > curTup, ""
   else:
    return curVer, "", url, False, "Incorrect version format (from server) !"
  else:
   return curVer, "", url, False, "Cannot download Version File !"
class CCy1Yy(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FF5TEn(VVh24A, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVICwr
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FF32Yx(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVuVVx("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVuVVx("\c00888888", i) + sp + "GREY\n"
   txt += self.VVuVVx("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVuVVx("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVuVVx("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVuVVx("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVuVVx("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVuVVx("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVuVVx("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVuVVx("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVuVVx("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVuVVx("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(VVjUqm,
  {
   "ok" : self.VVthYm ,
   "green" : self.VVthYm ,
   "left" : self.VVgzL2 ,
   "right" : self.VVPVKV ,
   "cancel": self.close
  }, -1)
  self.onShown.append(self.VVSDD3)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  self.VV7TUZ()
 def VVthYm(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFo4dm(self, self.VV353e, "Change to : %s" % txt, title=self.Title)
 def VV353e(self):
  FF2tHk(CFG.mixedColorScheme, self.cursorPos)
  global VVICwr
  VVICwr = self.cursorPos
  self.VV2oAR()
  self.close()
 def VVgzL2(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VV7TUZ()
 def VVPVKV(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VV7TUZ()
 def VV7TUZ(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVuVVx(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVHUiW(color):
  if VVRJhR: return "\\" + color
  else    : return ""
 @staticmethod
 def VV2oAR():
  global VVHQpO, VVzv5p, VVfMEC, VVszO3, VVtz60, VVTKrH, VVCBLl, VVKcVb, VVXF4f, VVJS3b, VVRJhR, VV61JF, VVAaU5, VVYqlh, VVMVIx, VViypC
  VViypC   = CCy1Yy.VVuVVx("\c00FFFFFF", VVICwr)
  VVzv5p    = CCy1Yy.VVuVVx("\c00888888", VVICwr)
  VVHQpO  = CCy1Yy.VVuVVx("\c005A5A5A", VVICwr)
  VVKcVb    = CCy1Yy.VVuVVx("\c00FF0000", VVICwr)
  VVfMEC   = CCy1Yy.VVuVVx("\c00FF5000", VVICwr)
  VVszO3   = CCy1Yy.VVuVVx("\c00FFBB66", VVICwr)
  VVRJhR   = CCy1Yy.VVuVVx("\c00FFFF00", VVICwr)
  VV61JF = CCy1Yy.VVuVVx("\c00FFFFAA", VVICwr)
  VVXF4f   = CCy1Yy.VVuVVx("\c0000FF00", VVICwr)
  VVJS3b  = CCy1Yy.VVuVVx("\c00AAFFAA", VVICwr)
  VVCBLl    = CCy1Yy.VVuVVx("\c000066FF", VVICwr)
  VVAaU5    = CCy1Yy.VVuVVx("\c0000FFFF", VVICwr)
  VVYqlh  = CCy1Yy.VVuVVx("\c00AAFFFF", VVICwr)  #
  VVMVIx   = CCy1Yy.VVuVVx("\c00FA55E7", VVICwr)
  VVtz60    = CCy1Yy.VVuVVx("\c00FF8F5F", VVICwr)
  VVTKrH  = CCy1Yy.VVuVVx("\c00FFC0C0", VVICwr)
CCy1Yy.VV2oAR()
class CCfeee(Screen):
 def __init__(self, session, path, VV6sgm):
  self.skin, self.skinParam = FF5TEn(VVBwm7, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VV5rgV   = path
  self.VVUArD   = ""
  self.VVMstS   = ""
  self.VV6sgm    = VV6sgm
  self.VVVbzy    = ""
  self.VV8bD6  = ""
  self.VVTBuO    = False
  self.VV7Sqq  = False
  self.origPackageName  = ""
  self.postInstAcion   = 0
  self.VVkzJh  = "enigma2-plugin-extensions-"
  self.VVHXll  = "enigma2-plugin-systemplugins-"
  self.VVQMII = "enigma2-"
  self.VVTmJO  = 0
  self.VVVHwU  = 1
  self.VVh1n5  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVJ8H4 = "DEBIAN"
  else        : self.VVJ8H4 = "CONTROL"
  self.controlPath = self.Path + self.VVJ8H4
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VV6sgm:
   self.packageExt  = ".deb"
   self.VVLuY4  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVLuY4  = "#11001020"
  FF32Yx(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFCDDm(self["keyRed"] , "Create")
  FFCDDm(self["keyGreen"] , "Post Install")
  FFCDDm(self["keyYellow"], "Installation Path")
  FFCDDm(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(VVjUqm,
  {
   "red"   : self.VVHOvm  ,
   "green"   : self.VVCESo ,
   "yellow"  : self.VVBxpx  ,
   "blue"   : self.VVVSSB  ,
   "cancel"  : self.VVrJyp
  }, -1)
  self.onShown.append(self.VVSDD3)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  FFieY3(self)
  if self.VVLuY4:
   FFzBm8(self["myBody"], self.VVLuY4)
   FFzBm8(self["myLabel"], self.VVLuY4)
  self.VVgLzb(True)
  self.VVsyYq(True)
 def VVsyYq(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVmp7Z()
  if isFirstTime:
   if   package.startswith(self.VVkzJh) : self.VV5rgV = VVFTYs + self.VVVbzy + "/"
   elif package.startswith(self.VVHXll) : self.VV5rgV = VVbd2l + self.VVVbzy + "/"
   else            : self.VV5rgV = self.Path
  if self.VVTBuO : myColor = VVtz60
  else    : myColor = VViypC
  txt  = ""
  txt += "Source Path\t: %s\n" % FFCzRx(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFCzRx(self.VV5rgV, VVRJhR)
  if self.VVMstS : txt += "Package File\t: %s\n" % FFCzRx(self.VVMstS, VVzv5p)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFCzRx("Check Control File fields : %s" % errTxt, VVfMEC)
  if self["keyGreen"].getVisible():
   if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFCzRx("Restart GUI", VVtz60)
   elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFCzRx("Reboot Device", VVtz60)
   else      : act = "No action."
   txt += "\n%s\t: %s\n" % (FFCzRx("Post Install", VVXF4f), act)
  if not errTxt and VVfMEC in controlInfo:
   txt += "Warning\t: %s\n" % FFCzRx("Errors in control file may affect the result package.", VVfMEC)
  txt += "\nControl File\t: %s\n" % FFCzRx(self.controlFile, VVzv5p)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVCESo(self):
  if self["keyGreen"].getVisible():
   VVMVqr = []
   VVMVqr.append(("No Action"    , "noAction"  ))
   VVMVqr.append(("Restart GUI"    , "VViiZ9"  ))
   VVMVqr.append(("Reboot Device"   , "rebootDev"  ))
   FF7ARM(self, self.VV0bMp, title="Package Installation Option (after completing installation)", VVMVqr=VVMVqr)
 def VV0bMp(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VViiZ9"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVgLzb(False)
   self.VVsyYq()
 def VVBxpx(self):
  rootPath = FFCzRx("/%s/" % self.VVVbzy, VV61JF)
  VVMVqr = []
  VVMVqr.append(("Current Path"        , "toCurrent"  ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Extension Path"       , "toExtensions" ))
  VVMVqr.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVMVqr.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FF7ARM(self, self.VV6654, title="Installation Path", VVMVqr=VVMVqr)
 def VV6654(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVgqH7(FFIRGA(self.Path, True))
   elif item == "toExtensions"  : self.VVgqH7(VVFTYs)
   elif item == "toSystemPlugins" : self.VVgqH7(VVbd2l)
   elif item == "toRootPath"  : self.VVgqH7("/")
   elif item == "toRoot"   : self.VVgqH7("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVcjB8, BF(CCUGPF, mode=CCUGPF.VVGIMp, VVRawy=VVYfYu))
 def VVcjB8(self, path):
  if len(path) > 0:
   self.VVgqH7(path)
 def VVgqH7(self, parent, withPackageName=True):
  if withPackageName : self.VV5rgV = parent + self.VVVbzy + "/"
  else    : self.VV5rgV = "/"
  mode = self.VVYu80()
  FFgSm7("sed -i '/Package/c\Package: %s' %s" % (self.VVs49c(mode), self.controlFile))
  self.VVsyYq()
 def VVVSSB(self):
  if fileExists(self.controlFile):
   lines = FF2WPS(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFBgSg(self, self.VV2TkM, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFzrXb(self, "Version not found or incorrectly set !")
  else:
   FFZ5Ys(self, self.controlFile)
 def VV2TkM(self, VVEKeH):
  if VVEKeH:
   version, color = self.VVsyM7(VVEKeH, False)
   if color == VVAaU5:
    FFgSm7("sed -i '/Version:/c\Version: %s' %s" % (VVEKeH, self.controlFile))
    self.VVsyYq()
   else:
    FFzrXb(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVrJyp(self):
  if self.newControlPath:
   if self.VVTBuO:
    self.VV0Tvr()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFCzRx(self.newControlPath, VVzv5p)
    txt += FFCzRx("Do you want to keep these files ?", VVRJhR)
    FFo4dm(self, self.close, txt, callBack_No=self.VV0Tvr, title="Create Package", VVxcAw=True)
  else:
   self.close()
 def VV0Tvr(self):
  FFgSm7("rm -rf '%s'" % self.newControlPath)
  self.close()
 def VVs49c(self, mode):
  prefix, name = "", ""
  package = self.origPackageName or self.VV8bD6
  if package.startswith(self.VVQMII):
   span = iSearch(r"(.+-)(.+)", package)
   if span:
    prefix, name = span.group(1).strip(), span.group(2)
  if not name:
   prefix, name = self.VVQMII, package
  prefix = iSub(r"([^a-z0-9+-.]+)", r"-", prefix)
  name = iSub(r"([^a-z0-9+-.]+)", r"-", name)
  if   mode == self.VVVHwU : prefix = self.VVkzJh
  elif mode == self.VVh1n5 : prefix = self.VVHXll
  return (prefix + name).lower()
 def VVYu80(self):
  if   self.VV5rgV.startswith(VVFTYs) : return self.VVVHwU
  elif self.VV5rgV.startswith(VVbd2l) : return self.VVh1n5
  else            : return self.VVTmJO
 def VVgLzb(self, isFirstTime):
  self.VVVbzy   = FFZ5fy(self.Path)
  self.VVVbzy   = "_".join(self.VVVbzy.split())
  self.VV8bD6 = self.VVVbzy.lower()
  self.VVTBuO = self.VV8bD6 == VV17ob.lower()
  if self.VVTBuO and self.VV8bD6.endswith(VV17ob.lower()):
   self.VV8bD6 += "el"
  if self.VVTBuO : self.VVUArD = VVYfYu
  else    : self.VVUArD = CFG.packageOutputPath.getValue()
  self.VVUArD = FF5DjF(self.VVUArD)
  if not pathExists(self.controlPath):
   FFgSm7("mkdir '%s'" % self.controlPath)
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  mode = self.VVYu80()
  if fileExists(self.controlFile):
   lines = FF2WPS(self.controlFile)
   for line in lines:
    if line.strip().startswith("Package") and line.count(":") == 1:
     self.origPackageName = line.split(":")[1].strip()
     break
  else:
   if self.VVTBuO : version, descripton, maintainer = VVAnTo , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVVbzy , self.VVVbzy
   txt = ""
   txt += "Package: %s\n"  % self.VVs49c(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: \n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
  if self.VVTBuO : t = PLUGIN_NAME
  else    : t = self.VVVbzy
  self.VVrPB4(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  self.VVrPB4(self.postrmFile, "echo 'Package removed.'\n")
  if self.VVTBuO : self.VVrPB4(self.preinstFile, "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVAnTo))
  else    : self.VVrPB4(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVVbzy)
  if isFirstTime and not mode == self.VVTmJO:
   self.postInstAcion = 1
  txt = self.VVD3RH(self.postInstAcion)
  canChange = True
  self["keyGreen"].show()
  if fileExists(self.postinstFile):
   fText = FFpCvR(self.postinstFile).strip()
   if txt.strip() == fText:
    canChange = False
   else:
    for action in range(3):
     if fText.strip() == self.VVD3RH(action).strip():
      break
    else:
     canChange = False
     self["keyGreen"].hide()
  if canChange:
   with open(self.postinstFile, "w") as f:
    f.write(txt)
  FFgSm7("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile))
 def VVrPB4(self, path, lines):
  if not fileExists(path):
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0\n")
 def VVD3RH(self, action):
  sep  = "echo '%s'\n" % SEP
  txt = "#!/bin/bash\n" + sep
  if action == 0:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  elif action == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl; then sleep 2; systemctl restart enigma2; elif [ -r '/usr/lib/enigma2/python/EGAMI' ]; then sleep 2; killall -9 enigma2; else init 4; sleep 4; init 3; fi\n"
  elif action == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   return ""
  txt += "exit 0\n"
  return txt
 def VVmp7Z(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FF2WPS(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key, val= parts[0].strip(), parts[1].strip()
      if key == "Description":
       isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFCzRx(line, VVfMEC)
     elif not line.startswith(" ")    : line = FFCzRx(line, VVfMEC)
     else          : line = FFCzRx(line, VVAaU5)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVAaU5
   else   : color = VVfMEC
   descr = FFCzRx(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVfMEC
     elif line.startswith((" ", "\t")) : color = VVfMEC
     elif line.startswith("#")   : color = VVzv5p
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVsyM7(val, True)
      elif key == "Version"  : version, color = self.VVsyM7(val, False)
      elif key == "Maintainer" : maint  , color = val, VVAaU5
      elif key == "Architecture" : arch  , color = val, VVAaU5
      else:
       color = VVAaU5
      if not key == "OE" and not key.istitle():
       color = VVfMEC
     else:
      color = VVtz60
     txt += FFCzRx(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVMstS = self.VVUArD + packageName
   self.VV7Sqq = True
   errTxt = ""
  else:
   self.VVMstS  = ""
   self.VV7Sqq = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVsyM7(self, val, isPackage):
  if   isPackage : pattern = r"^[a-z]+[a-z0-9+-_.]+$"
  else   : pattern = r"^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVAaU5
  else          : return val, VVfMEC
 def VVHOvm(self):
  if not self.VV7Sqq:
   FFzrXb(self, "Please fix Control File errors first.")
   return
  if self.VV6sgm: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFIRGA(self.VV5rgV, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVVbzy
  symlinkTo  = FFZuCm(self.Path)
  dataDir   = self.VV5rgV.rstrip("/")
  removePorjDir = FFgeXp("rm -rf '%s'"  % projDir)
  cmd  = ""
  cmd += FFgeXp("rm -f '%s'" % self.VVMstS)
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFQ4w6()
  if self.VV6sgm:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFkbwj("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVTBuO:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VV5rgV == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVJ8H4)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Cannot create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVMstS, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVMstS
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVMstS, FFC7pV(result  , VVXF4f))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VV5rgV, FFC7pV(instPath, VVAaU5))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFC7pV(failed, VVfMEC))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFHguD(self, cmd)
class CCrfsB():
 VVOyww  = "666"
 VVgyuu   = "888"
 def __init__(self, SELF, waitMsgSELF, title, servRefListFnc, defBName="Bouquet1"):
  self.SELF     = SELF
  self.waitMsgSELF   = waitMsgSELF
  self.Title     = title
  self.servRefListFnc   = servRefListFnc
  self.defBName    = defBName
  self.VVdtUh   = None
  self.VVY4cW()
 def VVY4cW(self):
  VVMVqr = CCrfsB.VVcVdn()
  if VVMVqr:
   VV0afn = ("Create New", self.VVKuH9)
   self.VVdtUh = FF7ARM(self.SELF, self.VVzH2q, VVMVqr=VVMVqr, title=self.Title, VV0afn=VV0afn, VVy9CS=True, VVZYdg="#22222233", VVcwfs="#22222233")
  else:
   self.VVKuH9()
 def VVzH2q(self, item):
  if item:
   bName, bRef, ndx = item
   self.VVDPng(bName, bRef)
  else:
   CCrfsB.VVv8EY(self)
 def VVKuH9(self, selectionObj=None, item=None):
  FFBgSg(self.SELF, BF(self.VVVfb1), defaultText=self.defBName, title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVVfb1(self, bName):
  if bName:
   bName = bName.strip()
   if bName:
    if self.VVdtUh:
     self.VVdtUh.cancel()
    self.VVDPng(bName, "")
   else:
    FFycel(self.VVdtUh, "Incorrect Bouquet Name !", 2000)
    CCrfsB.VVv8EY(self)
 def VVDPng(self, bName, bRef):
  FFzW1w(self.waitMsgSELF, BF(self.VVJkW1, bName, bRef), title="Adding Services ...")
 def VVJkW1(self, bName, bRef):
  CCrfsB.VVMouF(self.SELF, self.Title, bName, bRef, self.servRefListFnc())
 @staticmethod
 def VVv8EY(classObj):
  del classObj
 @staticmethod
 def VVMouF(SELF, title, bName, bRef, servRefLst, showRes=True):
  if not servRefLst:
   FFzrXb(SELF, "No services to add !", title=title)
   return
  tvBouquetFile = VVTAUs + "bouquets.tv"
  if not fileExists(tvBouquetFile):
   FFZ5Ys(SELF, tvBouquetFile, title=title)
   return
  if bRef:
   bFile = CCrfsB.VVGT0Q(bRef)
   bPath = VVTAUs + bFile
  else:
   fName = CCfw0y.VV02WJ(bName)
   bFile = "userbouquet.%s.tv" % fName
   bPath = VVTAUs + bFile
   num   = 0
   while fileExists(bPath):
    num += 1
    bFile = "userbouquet.%s_%d.tv" % (fName, num)
    bPath = VVTAUs + bFile
   with open(bPath, "w") as f:
    f.write("#NAME %s\n" % bName)
  FFElys(bPath)
  with open(bPath, "a") as f:
   for chUrl in servRefLst:
    serv = eServiceReference(chUrl)
    chName = serv and serv.getName() or ""
    try:
     chName = chName.encode("UTF-8", "replace").decode()
    except:
     chName = iSub(r"([^\x00-\x7F]+)", r"?", chName)
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
  if not bRef and fileExists(bPath):
   FFElys(tvBouquetFile)
   with open(tvBouquetFile, "a") as f:
    f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
  totPicons = 0
  piconPath = CCxrlm.VVjBFN()
  for chUrl in servRefLst:
   span = iSearch(r"((?:[A-Fa-f0-9]+:){10})", chUrl.rstrip(":"))
   if span:
    serv = eServiceReference(chUrl)
    if serv:
     picon = piconPath + span.group(1).strip(":").replace(":", "_").upper() + ".png"
     fPath = serv.getPath()
     fNameNoExt = os.path.splitext(serv.getPath())[0]
     for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
      poster = "%s.%s" % (fNameNoExt, ext)
      if fileExists(poster):
       totPicons += 1
       FFgSm7("cp -f '%s' '%s'" % (poster, picon))
       FFgSm7(CCoD37.VVBGeg(picon))
       break
  FFwQUx()
  if showRes:
   txt  = "Bouquet Name\t\t: %s\n"  % bName
   txt += "Added Services\t\t: %d\n" % len(servRefLst)
   if totPicons:
    txt += "Added PIcons\t\t: %s" % totPicons
   FFtybv(SELF, txt, title=title)
 @staticmethod
 def VVSSgW(bName):
  mode = CCPClU.VV2iJm(default=-1)
  modeTxt = "tv" if mode == 0 else "radio"
  fName = CCfw0y.VV02WJ(bName)
  bFile = "userbouquet.%s.%s" % (fName, modeTxt)
  num   = 0
  while fileExists(VVTAUs + bFile):
   num += 1
   bFile = "userbouquet.%s_%d.%s" % (fName, num, modeTxt)
  with open(VVTAUs + bFile, "w") as f:
   f.write("#NAME %s\n" % bName)
  mainBFile = "%sbouquets.%s" % (VVTAUs, modeTxt)
  if fileExists(mainBFile):
   FFElys(mainBFile)
   with open(mainBFile, "a") as f:
    f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
 @staticmethod
 def VVxaH6(ref, bName):
  bFile = CCrfsB.VVGT0Q(ref)
  ok = False
  if bFile:
   bFile = VVTAUs + bFile
   if fileExists(bFile):
    lines = FF2WPS(bFile, keepends=True)
    with open(bFile, "w") as f:
     for line in lines:
      if line.startswith("#NAME "):
       f.write("#NAME %s\n" % bName)
       ok = True
      else:
       f.write(line)
  return ok
 @staticmethod
 def VVcVdn(mode=2, showTitle=True, prefix="", onlyIptv=False):
  VVMVqr = []
  if mode in (0, 2): VVMVqr.extend(CCrfsB.VV496L(0, showTitle, prefix, onlyIptv))
  if mode in (1, 2): VVMVqr.extend(CCrfsB.VV496L(1, showTitle, prefix, onlyIptv))
  return VVMVqr
 @staticmethod
 def VV496L(mode, showTitle, prefix, onlyIptv):
  VVMVqr = []
  lst = CCrfsB.VVj8xx(mode)
  if onlyIptv:
   lst = CCrfsB.VVmt1F(lst)
  if lst:
   if showTitle:
    VVMVqr.append(FFfdOi("TV Bouquets" if mode == 0 else "Radio Bouquets"))
   if prefix:
    for item in lst : VVMVqr.append((item[0], prefix + item[0]))
   else:
    for item in lst : VVMVqr.append((item[0], item[1].toString()))
  return VVMVqr
 @staticmethod
 def VVmt1F(lst):
  fLst = CCfw0y.VVvkN7(onlyFileName=True)
  newLst = []
  if fLst:
   for item in lst:
    span = iSearch(r".+(userbouquet\..+\.(tv|radio))", item[1].toString())
    if span and span.group(1) in fLst:
     newLst.append(item)
  return newLst
 @staticmethod
 def VVUPlX():
  lst = CCrfsB.VVj8xx(0)
  lst.extend(CCrfsB.VVj8xx(1))
  return lst
 @staticmethod
 def VVj8xx(mode=0):
  bList = []
  VV8OMp = InfoBar.instance
  VV2NxO = VV8OMp and VV8OMp.servicelist
  if VV2NxO:
   curMode = VV2NxO.mode
   CCrfsB.VVwFPv(VV2NxO, mode)
   bList.extend(VV2NxO.getBouquetList() or [])
   CCrfsB.VVwFPv(VV2NxO, curMode)
  return bList
 @staticmethod
 def VVwFPv(VV2NxO, mode):
  if not mode == VV2NxO.mode:
   if   mode == 0: VV2NxO.setModeTv()
   elif mode == 1: VV2NxO.setModeRadio()
 @staticmethod
 def VVldUx(isAll=True, onlyMain=False):
  bLst = []
  inst = InfoBar.instance
  if inst:
   csel = inst.servicelist
   if csel:
    root = csel.bouquet_root
    VVHa0D = eServiceCenter.getInstance()
    if onlyMain:
     info = VVHa0D.info(root)
     if info:
      bLst.append((info.getName(root), root.toString()))
    else:
     list = VVHa0D and VVHa0D.list(root)
     if list:
      while True:
       s = list.getNext()
       if not s.valid():
        break
       if isAll or (s.flags & eServiceReference.isDirectory and not s.flags & eServiceReference.isInvisible):
        info = VVHa0D.info(s)
        if info:
         bLst.append((info.getName(s), s.toString()))
  return bLst
 @staticmethod
 def VVGT0Q(bRef):
  span = iSearch(r'BOUQUET\s+"(.+)"\s+ORDER', bRef, IGNORECASE)
  if span : return span.group(1)
  else : return ""
 @staticmethod
 def VVt6zw(ref, dstFile):
  dstFile = VVTAUs + dstFile
  if fileExists(dstFile):
   FFElys(dstFile)
   bLine = ""
   srcFile = CCrfsB.VVGT0Q(ref)
   if srcFile:
    span = iSearch(r"\.(.+)\.(tv|radio)", srcFile, IGNORECASE)
    if span:
     fName, fType = span.group(1), span.group(2)
     newName = "userSubBouquet.%s.%s" % (fName, fType)
     num = 0
     while fileExists(VVTAUs + newName):
      num += 1
      newName = "userSubBouquet.%s_%d.%s" % (fName, num, fType)
     subFile = VVTAUs + newName
     FFgSm7("cp -f '%s%s' '%s'" % (VVTAUs, srcFile, subFile))
     if fileExists(subFile):
      bLine = '1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % newName
   else:
    bLine = ref
   if bLine:
    if fileExists(dstFile):
     with open(dstFile, "a") as f:
      f.write("#SERVICE %s\n" % bLine)
     return True
  return False
 @staticmethod
 def VVMKYk():
  try:
   fName = CCrfsB.VVGT0Q(InfoBar.instance.servicelist.getRoot().toString())
   path = "%s%s" % (VVTAUs, fName)
   if fileExists(path):
    return path
  except:
   pass
  return ""
 @staticmethod
 def VVGByY():
  path = CCrfsB.VVMKYk()
  if path:
   txt = FFpCvR(path, maxSize=300)
   span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
   if span:
    return span.group(1).strip()
  return ""
 @staticmethod
 def VVKfvZ():
  return FFwksx(InfoBar.instance.servicelist.getRoot())
 @staticmethod
 def VVXSkm():
  lst = []
  for b in CCrfsB.VVUPlX():
   bName = b[0]
   bRef  = b[1].toString()
   path = VVTAUs + CCrfsB.VVGT0Q(bRef)
   if fileExists(path):
    lines = FF2WPS(path)
    for line in lines:
     if line.startswith("#SERVICE"):
      if not line.startswith("#SERVICE 1:64:"):
       break
    else:
     if not "userbouquet.favourites." in bRef:
      lst.append((bName, bRef))
  return lst
 @staticmethod
 def VVkMA7(SID, stripRType):
  if stripRType: return r"(?:[A-Fa-f0-9]+:)((?:[A-Fa-f0-9]+:){2}%s:(?:[A-Fa-f0-9]+:){6})" % SID
  else   : return r"((?:[A-Fa-f0-9]+:){3}%s:(?:[A-Fa-f0-9]+:){6})" % SID
 @staticmethod
 def VVaKV4(SID="", stripRType=False):
  if SID : patt = CCrfsB.VVkMA7(SID, stripRType)
  else : patt = r"((?:[A-Fa-f0-9]+:){10})"
  lst = []
  for b in CCrfsB.VVUPlX():
   for service in FFwksx(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper())
  return lst
 @staticmethod
 def VVeBU6():
  patt = r"((?:[A-Fa-f0-9]+:){10})http.+"
  lst = []
  for b in CCrfsB.VVUPlX():
   for service in FFwksx(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper().rstrip(":"))
  return lst
 @staticmethod
 def VVjeuE(rType, SID, refLst, startId, startNS):
  for Id in range(max(6, startId), 65535):
   hexId = ("%1x" % Id).upper()
   for NS in range(startNS, 65535):
    hexNS = ("FFF%04x" % NS).upper()
    tRef = "0:1:%s:%s:%s:%s:0:0:0:" % (SID, hexId, hexId, hexNS)
    if not tRef in refLst:
     refCode = "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, hexId, hexId, hexNS)
     if NS < 65535 - 1: NS += 1
     else    : NS, Id = 6, Id + 1
     return refCode, Id, NS
  return "", 0, 0
 @staticmethod
 def VVFi0q(pathLst, rType=""):
  refLst = CCrfsB.VVaKV4(CCrfsB.VVOyww, stripRType=True)
  chUrlLst = []
  startId  = startNS = 0
  rType  = rType or CFG.iptvAddToBouquetRefType.getValue()
  for path in pathLst:
   refCode, startId, startNS = CCrfsB.VVjeuE(rType, CCrfsB.VVOyww, refLst, startId, startNS)
   if refCode:
    chName = os.path.splitext(os.path.basename(path))[0].replace("-", " ").replace("_", " ").replace(".", " ")
    chUrl = "%s%s:%s" % (refCode, path, chName)
    chUrlLst.append(chUrl)
   else:
    break
  return chUrlLst
class CCUGPF(Screen):
 VVpesc   = 0
 VV6Mn2  = 1
 VVGIMp  = 2
 VVJKgI = 3
 VVui5c    = 20
 VVZ1Di   = 0
 VVvLdb   = 1
 VVtxc5   = 2
 def __init__(self, session, VVRawy="/", mode=VVpesc, VVSPOW="Select", width=1400, height=920, VVHZHw=30, VVZYdg="#22001111", VVcwfs="#22000000", pickTitleBG="#11001144", pickBodyBG="#11002255", cursorBG="#06003333", gotoMovie=False, jumpToFile="", patternMode=""):
  self.skin, self.skinParam = FF5TEn(VVL1I3, width, height, 30, 40, 20, VVZYdg, VVcwfs, VVHZHw, barHeight=40, topRightBtns=2)
  self.session   = session
  self.VVZYdg   = VVZYdg
  self.VVcwfs    = VVcwfs
  self.pickTitleBG  = pickTitleBG
  self.pickBodyBG   = pickBodyBG
  FF32Yx(self)
  FFCDDm(self["keyRed"] , "Exit")
  FFCDDm(self["keyYellow"], "More Options")
  FFCDDm(self["keyBlue"] , "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVSPOW = VVSPOW
  self.jumpToFile   = jumpToFile
  self.patternMode  = patternMode
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  self.cursorBG   = cursorBG
  self.multiSelectState = False
  VVmimI = None
  if patternMode:
   self.mode = self.VVJKgI
   if   patternMode == "srt"  : VVmimI = ("^.*\.srt$"    , IGNORECASE)
   elif patternMode == "ajpSet" : VVmimI = ("^.*\/ajpanel_settings_" , 0    )
   elif patternMode == "poster" : VVmimI = ("^.*\.(jpg|png)$"    , IGNORECASE)
   elif patternMode == "pkgCtrl": VVmimI = ("^.*\/(control|preinst|prerm|postinst|postrm)$", 0)
   elif patternMode == "movies" : VVmimI = ("^.*\.(%s)$" % "|".join(CC87Iy.VVbM6s()["mov"]), IGNORECASE)
   else       : VVmimI = None
  if self.mode in (self.VVGIMp, self.VVJKgI):
   FFCDDm(self["keyRed"], "Cancel")
  if   self.jumpToFile       : VVbdOU, self.VVRawy = True , FFIRGA(self.jumpToFile, True) or "/"
  elif self.gotoMovie        : VVbdOU, self.VVRawy = True , CCUGPF.VVKW1S(self)[1] or "/"
  elif self.mode == self.VVpesc  : VVbdOU, self.VVRawy = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVGIMp : VVbdOU, self.VVRawy = False, VVRawy
  elif self.mode == self.VVJKgI : VVbdOU, self.VVRawy = True , VVRawy
  else           : VVbdOU, self.VVRawy = True , VVRawy
  self.VVRawy = FF5DjF(self.VVRawy)
  self["myMenu"] = CC87Iy(  directory   = None
         , VVmimI = VVmimI
         , VVbdOU   = VVbdOU
         , VV7Xbp = True
         , VVAGyU = True
         , VVqbE4   = self.skinParam["width"]
         , VVHZHw   = self.skinParam["bodyFontSize"]
         , VVjcdW  = self.skinParam["bodyLineH"] )
  self["myActionMap"] = ActionMap(VVjUqm,
  {
   "ok" : self.VVthYm    ,
   "red" : self.VVaEoD   ,
   "green" : self.VVYhQy,
   "yellow": self.VV6xyc  ,
   "blue" : self.VVj0CM ,
   "menu" : self.VV6Y5z  ,
   "info" : self.VVibc1  ,
   "cancel": self.VVgn9P    ,
   "pageUp": self.VV1gQZ   ,
   "chanUp": self.VV1gQZ
  }, -1)
  FFwY39(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVoxFs)
  global VV48oF
  VV48oF = True
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  if self.mode == self.VVpesc:
   FFzMsA("VV48oF")
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVoxFs)
  FFDoNq(self)
  FFWzaz(self["myMenu"], bg=self.cursorBG)
  FFieY3(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode in (self.VVGIMp, self.VVJKgI):
   FFCDDm(self["keyGreen"], self.VVSPOW)
   self.VVEmE1(self.VVvLdb)
  self.VVoxFs()
  w  = self["myMenu"].instance.size().width()
  h  = self["myMenu"].instance.size().height()
  pos  = self["myMenu"].getPosition()
  part = self["myMenu"].instance.size().height() % self.skinParam["bodyLineH"]
  half = int(part / 2)
  self["myMenu"].instance.resize(eSize(*(w, h - part)))
  self["myMenu"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.VV0KoM(self.VVRawy) > self.bigDirSize: FFzW1w(self, self.VVSNnb, title="Changing directory...")
  else              : self.VVSNnb()
 def VVSNnb(self):
  if self.jumpToFile : self.VVTnU9(self.jumpToFile)
  elif self.gotoMovie : self.VVBNur(chDir=False)
  else    : self["myMenu"].VVPCRg(self.VVRawy)
 def VV7qpv(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VVKkQ7(self):
  FFzW1w(self, self.VV5itC, title="Refreshing list ...")
 def VV5itC(self):
  isSel = self["myMenu"].VVx2tg()
  if not isSel:
   self.VVLrDt(False)
  FFZvbd()
 def VVDPK8(self, saved):
  if saved: self.VVKkQ7()
 def VV0KoM(self, path):
  try:
   return len(os.listdir(path))
  except:
   return 0
 def VVthYm(self):
  if self.multiSelectState:
   ok = self["myMenu"].VVevtz()
   if ok : self["keyBlue"].setText(self.VVYpNT())
   else : FFycel(self, "Cannot select item", 500)
  elif self["myMenu"].VV9TFq(): self.VVSLhv()
  else       : self.VVJrDL()
 def VV1gQZ(self):
  if self.multiSelectState:
   FFycel(self, "Disable Multi-Select first", 1000)
  else:
   self["myMenu"].moveToIndex(0)
   if self["myMenu"].VVEqSe():
    self.VVSLhv()
 def VVSLhv(self, isDirUp=False):
  if self["myMenu"].VV9TFq():
   if not self["myMenu"].getSelection() is None: path = self["myMenu"].getSelection()[0]
   else          : path = self.VVt0jN(self.VVQYvn())
   if self.VV0KoM(path) > self.bigDirSize : FFzW1w(self, self.VVwSRK, title="Changing directory...")
   else           : self.VVwSRK()
 def VVwSRK(self):
  self["myMenu"].descent()
  self.VVoxFs()
 def VVgn9P(self):
  if   self.multiSelectState     : self.VVLrDt(False, True)
  elif CFG.FileManagerExit.getValue() == "e" : self.VVaEoD()
  else          : self.VV1gQZ()
 def VVaEoD(self):
  if not FFA72r(self):
   self.close("")
 def VVYhQy(self):
  path = self.VVt0jN(self.VVQYvn())
  if self.mode == self.VVGIMp:
   self.close(path)
  elif self.mode == self.VVJKgI:
   if os.path.isfile(path) : self.close(path)
   else     : FFycel(self, "Cannot access this file", 1000)
 def VVibc1(self):
  FFzW1w(self, self.VVMskK, title="Calculating size ...")
 def VVMskK(self):
  path = self.VVt0jN(self.VVQYvn())
  param = self.VVz4Pq(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FFwTnb("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CCUGPF.VVIwRI(path)
     freeSize = CCUGPF.VV5yeR(path)
     size = totSize - freeSize
     totSize  = CCUGPF.VVuy4U(totSize)
     freeSize = CCUGPF.VVuy4U(freeSize)
    else:
     size = FFM9Wx(path)
   usedSize = CCUGPF.VVuy4U(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFCzRx(pathTxt, VVtz60) + "\n"
   if slBroken : fileTime = self.VVuGkW(path)
   else  : fileTime = self.VVpKiG(path)
   def VVulVX(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVulVX("Path"    , pathTxt)
   txt += VVulVX("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVulVX("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VVulVX("Total Size"   , "%s" % totSize)
    txt += VVulVX("Used Size"   , "%s" % usedSize)
    txt += VVulVX("Free Size"   , "%s" % freeSize)
   else:
    txt += VVulVX("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VVulVX("Owner"    , owner)
   txt += VVulVX("Group"    , group)
   txt += VVulVX("Perm. (User)"  , permUser)
   txt += VVulVX("Perm. (Group)"  , permGroup)
   txt += VVulVX("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVulVX("Perm. (Ext.)" , permExtra)
   txt += VVulVX("iNode"    , iNode)
   txt += VVulVX("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (SEP, SEP)
    txt += hLinkedFiles
   txt += self.VVO2JM(path)
  else:
   FFzrXb(self, "Cannot access information !")
  if len(txt) > 0:
   FFtybv(self, txt)
 def VVz4Pq(self, path):
  path = path.strip()
  path = FFZuCm(path)
  result = FFwTnb("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVcWRy(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVcWRy(perm, 1, 4)
   permGroup = VVcWRy(perm, 4, 7)
   permOther = VVcWRy(perm, 7, 10)
   permExtra = VVcWRy(perm, 10, 100)
   typeChar = perm[0:1]
   typeStr = {"-":"File", "b":"Block Device File", "c":"Character Device File", "d":"Directory", "e":"External Link", "l":"Symbolic Link", "n":"Network File", "p":"Named Pipe", "s":"Local Socket File"}.get(typeChar, "Unknown")
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFpCvy("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVO2JM(self, path):
  txt  = ""
  res  = FFwTnb("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = {"a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file"}
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FFCzRx("File Attributes:", VVMVIx), txt)
  return txt
 def VVpKiG(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFgCM6(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFgCM6(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFgCM6(os.path.getctime(path))
  return txt
 def VVuGkW(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFwTnb("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFwTnb("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFwTnb("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVt0jN(self, currentSel):
  currentDir  = self["myMenu"].VVKGHN()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VV9TFq():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVQYvn(self):
  sel = self["myMenu"].getSelection()
  if sel : return sel[0]
  else : return None
 def VVoxFs(self):
  path = self.VVt0jN(self.VVQYvn())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  self.VVQ0fd()
  if self.mode == self.VVpesc:
   if len(path) > 0: self["keyMenu"].show()
   else   : self["keyMenu"].hide()
  if self.mode == self.VVJKgI:
   path = self.VVt0jN(self.VVQYvn())
   if os.path.isfile(path) : self["keyGreen"].show()
   else     : self["keyGreen"].hide()
 def VV6Y5z(self):
  color1 = VVTKrH
  color2 = VV61JF
  color3 = VVYqlh
  totSel = 0
  menuW = 1000
  title = "Options"
  VVMVqr= []
  if self.multiSelectState:
   menuW = 850
   totSel = self["myMenu"].VVzFl9()
   if totSel > 0:
    if iTar:
     txt1 = "Archive to .tar.gz"
     txt2 = " (Preserve Path Structure)"
     title = "Options  (%d item%s)" % (totSel, FFoTxy(totSel))
     VVMVqr.append((color1 + txt1     , "VV82S41" ))
     VVMVqr.append((color1 + txt1 + txt2   , "VV82S42" ))
     VVMVqr.append(VVpTvr)
    VVMVqr.append(("[6] Copy"       , "copyBulk" ))
    VVMVqr.append(("[7] Move"       , "moveBulk" ))
    VVMVqr.append(("[8] %sDELETE" % VVtz60 , "VV4vNc" ))
   else:
    FFycel(self, "Nothing selected", 700)
    return
  elif self.mode in (self.VVGIMp, self.VVJKgI):
   VVMVqr.append(("Properties"           , "properties" ))
   VVMVqr.append(VVpTvr)
   VVMVqr.append((color3 + "Create New Directory (in current directory)" , "createNewDir"))
  else:
   menuW = 1000
   path  = self.VVt0jN(self.VVQYvn())
   isEditable = self["myMenu"].VVVJyP()
   VVMVqr.append(("Properties", "properties"))
   if os.path.isdir(path):
    if isEditable:
     VVMVqr.append(VVpTvr)
     VVMVqr.append((color1 + "Archiving / Packaging", "VVQhJb_dir"))
   elif os.path.isfile(path):
    selFile = self.VVQYvn()
    isArch = selFile.endswith((".tar", ".gz", ".tar.bz2", "tar.xz", ".zip", ".rar", ".7z"))
    if not isArch:
     VVMVqr.append((color1 + "Archive ...", "VVQhJb_file"))
    isText = False
    txt = ""
    if   isArch            : VVMVqr.extend(self.VVHmAm(path, True))
    elif selFile.endswith((".ipk", ".deb"))     : txt = "Package Tools"
    elif selFile.endswith((".m3u", ".m3u8"))    : VVMVqr.extend(self.VV59a9(True))
    elif selFile.endswith(".sh"):
     VVMVqr.extend(self.VVhrT0(True))
     isText = True
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not CCUGPF.VViwWz(path):
     VVMVqr.append(VVpTvr)
     VVMVqr.append((color2 + "View"     , "textView_def"))
     VVMVqr.append((color2 + "View (Select Encoder)" , "textView_enc"))
     VVMVqr.append((color2 + "Edit"     , "text_Edit" ))
     isText = True
    elif self["myMenu"].VVsdcQ(path) == "pic":
     VVMVqr.append(VVpTvr)
     VVMVqr.append((color2 + "Set as PIcon for current channel" , "VVzWd3" ))
     if FFlgKV("ffmpeg") and selFile.lower().endswith((".jpg", ".png")):
      VVMVqr.append(VVpTvr)
      VVMVqr.append((color2 + "Convert to MVI (1280 x 720 )" , "VVF0W9Hd"   ))
      VVMVqr.append((color2 + "Convert to MVI (1920 x 1080)" , "VVF0W9Fhd"   ))
    elif selFile.endswith(CCUGPF.VVhUen()):
     if selFile.endswith(".mvi"):
      if FFlgKV("showiframe"):
       VVMVqr.append(VVpTvr)
       VVMVqr.append((color2 + "View as Bootlogo (will interrupt the playing service)", "viewAsBootlogo"))
     else:
      VVMVqr.append(VVpTvr)
      VVMVqr.append((color2 + "Add Media File to a Bouquet"    , "addMovieToBouquet"  ))
      VVMVqr.append((color2 + "Add all Media in Directory to a Bouquet" , "addAllMoviesToBouquet" ))
      VVMVqr.append((color2 + "Play with ..."       , "playWith"    ))
    if isText:
     VVMVqr.append((color1 + "Save as UTF-8 ..."      , "textSave_encUtf8"))
     VVMVqr.append((color1 + "Save as other Encoding ..."    , "textSave_encOthr"))
     VVMVqr.append((color1 + "Convert Line-Breaks to Unix Format..." , "VVd0Mu" ))
    if len(txt) > 0:
     VVMVqr.append(VVpTvr)
     VVMVqr.append((color1 + txt, "VVJrDL"))
   VVMVqr.append(VVpTvr)
   VVMVqr.append(("[4] Create SymLink", "VVERao"))
   if isEditable:
    VVMVqr.append(("[5] Rename"      , "VVFLVY" ))
    VVMVqr.append(("[6] Copy"       , "copyFileOrDir" ))
    VVMVqr.append(("[7] Move"       , "moveFileOrDir" ))
    VVMVqr.append(("[8] %sDELETE" % VVtz60 , "VVe5iQ" ))
    if fileExists(path):
     VVMVqr.append(VVpTvr)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVMVqr.append((chmodTxt + "644)", "chmod644"))
     if show755 : VVMVqr.append((chmodTxt + "755)", "chmod755"))
     if show777 : VVMVqr.append((chmodTxt + "777)", "chmod777"))
   VVMVqr.append(VVpTvr)
   VVMVqr.append((color3 + "Create New File (in current directory)"  , "createNewFile" ))
   VVMVqr.append((color3 + "Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CCUGPF.VVKW1S(self)
   if fPath:
    VVMVqr.append(VVpTvr)
    VVMVqr.append((color2 + "Go to Current Movie Dir", "VVBNur"))
  FF7ARM(self, self.VVmCWW, width=menuW, height=1050, title=title, VVMVqr=VVMVqr, VV9LXs=False, VVZYdg="#00101020", VVcwfs="#00101A2A")
 def VVmCWW(self, item=None):
  if item is not None:
   path = self.VVt0jN(self.VVQYvn())
   selFile = self.VVQYvn()
   if   item == "VV82S41"    : self.VV82S4(False)
   if   item == "VV82S42"    : self.VV82S4(True)
   elif item == "copyBulk"     : self.VVWFUA(False)
   elif item == "moveBulk"     : self.VVWFUA(True)
   elif item == "VV4vNc"    : self.VV4vNc()
   elif item == "properties"    : self.VVibc1()
   elif item == "VVQhJb_dir" : self.VVQhJb(path, True)
   elif item == "VVQhJb_file" : self.VVQhJb(path, False)
   elif item == "VVeAgE"  : self.VVeAgE(path)
   elif item == "VVR7LB"  : self.VVR7LB(path)
   elif item.startswith("extract_")  : self.VVF104(path, selFile, item)
   elif item.startswith("script_")   : self.VVlsLT(path, selFile, item)
   elif item.startswith("m3u_")   : self.VVr87A(path, selFile, item)
   elif item.startswith("textView_def") : FFdD2h(self, path)
   elif item.startswith("textView_enc") : self.VV2Jon(path)
   elif item.startswith("text_Edit")  : CCH94c(self, path, VVEStC=self.VVDPK8)
   elif item.startswith("textSave_encUtf8"): self.VVDRTC(path, "Save as UTF-8"   , True)
   elif item.startswith("textSave_encOthr"): self.VVDRTC(path, "Save as Other Encoding", False)
   elif item.startswith("VVd0Mu") : self.VVd0Mu(path)
   elif item == "viewAsBootlogo"   : self.VVZzsi(path, True)
   elif item == "addMovieToBouquet"  : self.VVzbXu(path, False)
   elif item == "addAllMoviesToBouquet" : self.VVzbXu(path, True)
   elif item == "playWith"     : self.VV5GQ8(path)
   elif item == "VVzWd3" : self.VVzWd3(path)
   elif item == "VVF0W9Hd"   : FFzW1w(self, BF(self.VVF0W9, path, False))
   elif item == "VVF0W9Fhd"   : FFzW1w(self, BF(self.VVF0W9, path, True))
   elif item == "VVERao"   : self.VVERao(path, selFile)
   elif item == "VVFLVY"   : self.VVFLVY(path, selFile)
   elif item == "copyFileOrDir"   : self.VVnw06(path, False)
   elif item == "moveFileOrDir"   : self.VVnw06(path, True)
   elif item == "VVe5iQ"   : self.VVe5iQ(path, selFile)
   elif item == "chmod644"     : self.VVTkde(path, selFile, "644")
   elif item == "chmod755"     : self.VVTkde(path, selFile, "755")
   elif item == "chmod777"     : self.VVTkde(path, selFile, "777")
   elif item == "createNewFile"   : self.VVCv9D(path, True)
   elif item == "createNewDir"    : self.VVCv9D(path, False)
   elif item == "VVBNur"   : self.VVBNur()
   elif item == "VVJrDL"    : self.VVJrDL()
 def VVJrDL(self):
  if self.mode == self.VVJKgI and not self.patternMode == "poster":
   return
  selFile = self.VVQYvn()
  path  = self.VVt0jN(selFile)
  if os.path.isfile(path):
   cat = self["myMenu"].VVsdcQ(path)
   if   cat == "pic"       : self.VVGrTb(path)
   elif cat == "txt"       : FFdD2h(self, path)
   elif cat in ("tar", "rar", "zip", "p7z") : self.VVlz1a(path, selFile)
   elif cat == "scr"       : self.VVLTud(path, selFile)
   elif cat == "m3u"       : self.VVLErZ(path, selFile)
   elif cat in ("ipk", "deb")     : self.VVgfmW(path, selFile)
   elif cat in ("mov", "mus")     : self.VVZzsi(path)
   elif not CCUGPF.VViwWz(path) : FFdD2h(self, path)
 def VVGrTb(self, path):
  curIndex = 0
  curFile = os.path.basename(path)
  lst = []
  for item in self["myMenu"].list:
   if not item[0][1]:
    category = self["myMenu"].VVsdcQ(item[1][7])
    if category == "pic":
     if curFile == item[1][7]:
      curIndex = len(lst)
     lst.append(item[1][7])
  CCwf80.VVR0Px(self, path, fileList=lst, curIndex=curIndex, cbFnc=self.VVZ92Q)
 def VVZ92Q(self, path):
  self.VVTnU9(path)
 def VVZzsi(self, path, asLogo=False):
  if asLogo : CC6hh9.VVeomu(self, path)
  else  : FFzW1w(self, BF(self.VV0bc3, self, path), title="Playing Media ...")
 def VVj0CM(self):
  if self["keyBlue"].getVisible():
   VVWsIU = self.VVkpib()
   if VVWsIU:
    path = self.VVt0jN(self.VVQYvn())
    enableGreenBtn = False if path in self.VVkpib() else True
    newList = []
    for line in VVWsIU:
     newList.append((line, line))
    VVRZ74  = ("Delete"    , self.VVLh2l    )
    VVYJ07  = ("Add Current Dir"   , BF(self.VV3cMV, path) ) if enableGreenBtn else None
    VV0afn = ("Move Up"     , self.VVQO5y    )
    VVdhQt  = ("Move Down"   , self.VVOZiP    )
    self.bookmarkMenu = FF7ARM(self, self.VVMCaD, width=1200, title="Bookmarks", VVMVqr=newList, minRows=10 ,VVRZ74=VVRZ74, VVYJ07=VVYJ07, VV0afn=VV0afn, VVdhQt=VVdhQt, VVZYdg="#00000022", VVcwfs="#00000022")
 def VVLh2l(self, VVdtUh=None, path=None):
  VVWsIU = self.VVkpib()
  if VVWsIU:
   while path in VVWsIU:
    VVWsIU.remove(path)
   self.VVGT1q(VVWsIU)
  if self.bookmarkMenu:
   self.bookmarkMenu.VVInEv(VVWsIU)
   self.bookmarkMenu.VVnF2F(("Add Current Dir", BF(self.VV3cMV, path)))
  else:
   FFycel(self, "Removed", 800)
  self.VVQ0fd()
 def VV3cMV(self, path, VVdtUh=None, item=None):
  VVWsIU = self.VVkpib()
  if len(VVWsIU) >= self.VVui5c:
   FFzrXb(SELF, "Max bookmarks reached (max=%d)." % self.VVui5c)
  elif not path in VVWsIU:
   if not os.path.isdir(path):
    path = FFIRGA(path, True)
   newList = [path] + VVWsIU
   self.VVGT1q(newList)
   if self.bookmarkMenu:
    self.bookmarkMenu.VVInEv(newList)
    self.bookmarkMenu.VVnF2F()
   else:
    FFycel(self, "Added", 800)
  self.VVQ0fd()
 def VVQO5y(self, selectionObj, path):
  if self.bookmarkMenu:
   VVWsIU = self.bookmarkMenu.VVkpcz(True)
   if VVWsIU:
    self.VVGT1q(VVWsIU)
 def VVOZiP(self, selectionObj, path):
  if self.bookmarkMenu:
   VVWsIU = self.bookmarkMenu.VVkpcz(False)
   if VVWsIU:
    self.VVGT1q(VVWsIU)
 def VVMCaD(self, folder=None):
  if folder:
   folder = FF5DjF(folder)
   self["myMenu"].VVPCRg(folder)
   self["myMenu"].moveToIndex(0)
  self.VVoxFs()
 def VVkpib(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return []
 def VV6at2(self):
  return True if VVkpib() else False
 def VVGT1q(self, VVWsIU):
  line = ",".join(VVWsIU)
  FF2tHk(CFG.browserBookmarks, line)
 def VVTnU9(self, path):
  if fileExists(path):
   fDir  = FF5DjF(os.path.dirname(path))
   if fDir:
    self["myMenu"].VVPCRg(fDir)
   fName = os.path.basename(path)
   for ndx, item in enumerate(self["myMenu"].list):
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FFycel(self, "Not found", 1000)
 def VVBNur(self, chDir=True):
  fPath, fDir, fName = CCUGPF.VVKW1S(self)
  self.VVTnU9(fPath)
 def VV6xyc(self):
  path = self.VVt0jN(self.VVQYvn())
  isAdd = False if path in self.VVkpib() else True
  dirTxt = "Selected" if os.path.isdir(path) else "Current"
  c1, c2 , c3 = VVAaU5, VVJS3b, VV61JF
  VVMVqr = []
  VVMVqr.append(("Find Files ..." , "find"))
  VVMVqr.append(("Sort ..."   , "sort"))
  VVMVqr.append(VVpTvr)
  if isAdd: VVMVqr.append((c1 + "Add %s Dir to Bookmarks"  % dirTxt, "addBM"))
  else : VVMVqr.append((c1 + "Remove %s Dir from Bookmarks" % dirTxt, "remBM"))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(    (c2 + 'Set %s Dir as "Startup Dir"' % dirTxt, "start"))
  if self.mode == self.VVpesc:
   VVMVqr.append(VVpTvr)
   if self.multiSelectState: VVMVqr.append( (c3 + "Disable Multi-Select ", "multiOff"))
   else     : VVMVqr.append( (c3 + "Enable Multi-Select"  , "multiOn" ))
   VVMVqr.append(       (c3 + "Select all"    , "selAll"  ))
  FF7ARM(self, BF(self.VV5Jg3, path), width=750, title="More Options", VVMVqr=VVMVqr, VVZYdg="#00221111", VVcwfs="#00221111")
 def VV5Jg3(self, path, item):
  if item:
   if   item == "find"  : self.VV4hi2(path)
   elif item == "sort"  : self.VVH8t9()
   elif item == "addBM" : self.VV3cMV(path)
   elif item == "remBM" : self.VVLh2l(None, path)
   elif item == "start" : self.VVIJfJ(path)
   elif item == "multiOn" : self.VVLrDt(True)
   elif item == "multiOff" : self.VVLrDt(False)
   elif item == "selAll" : self.VVLrDt(True, True)
 def VVLrDt(self, isOn, isAll=False):
  self.multiSelectState = isOn
  if isAll or not isOn:
   FFzW1w(self, BF(self["myMenu"].VVPZyq, isOn), title="Selecting ..." if isOn else "Unselecting ...")
  self.VVEmE1(self.VVtxc5 if isOn else self.VVZ1Di)
 def VVEmE1(self, mode=0):
  if   mode == self.VVvLdb : titBg, bodBg = self.pickTitleBG, self.pickBodyBG
  elif mode == self.VVtxc5: titBg, bodBg = "#01883366", "#11002233"
  else        : titBg, bodBg = self.VVZYdg, self.VVcwfs
  FFzBm8(self["myTitle"], titBg)
  FFzBm8(self["myBar"], titBg)
  FFzBm8(self["myBody"], bodBg)
  FFzBm8(self["myMenu"], bodBg)
  if self.multiSelectState: bg, txt = "#01883366", self.VVYpNT()
  else     : bg, txt = VVoWXg[3], "Bookmarks"
  FFCDDm(self["keyBlue"], txt)
  FFzBm8(self["keyBlue"], bg)
  self.VVQ0fd()
 def VVYpNT(self):
  return "Selected Items = %d" % self["myMenu"].VVzFl9()
 def VVQ0fd(self):
  if self.VVkpib() or self.multiSelectState: self["keyBlue"].show()
  else            : self["keyBlue"].hide()
 def VV4hi2(self, path):
  VVMVqr = []
  VVMVqr.append(("Find in Current Directory"    , "findCur"  ))
  VVMVqr.append(("Find in Current Directory (recursive)" , "findCurR" ))
  VVMVqr.append(("Find in all Storage Systems"    , "findAll"  ))
  FF7ARM(self, BF(self.VV4vS9, path), width=700, title="Find File/Pattern", VVMVqr=VVMVqr, VVy9CS=True, VVMTvd=True, VVZYdg="#00221111", VVcwfs="#00221111")
 def VV4vS9(self, path, item):
  if item:
   title, item, ndx = item
   if   item == "findCur" : self.VV9dmE(0, path, title)
   elif item == "findCurR" : self.VV9dmE(1, path, title)
   elif item == "findAll" : self.VV9dmE(2, path, title)
 def VV9dmE(self, mode, path, title):
  if CFG.lastFileManFindPatt.getValue(): txt = CFG.lastFileManFindPatt.getValue()
  else         : txt = "*.ipk"
  FFBgSg(self, BF(self.VVYsCQ, mode, path, title), defaultText=txt, title=title, message="Enter Name/Pattern:")
 def VVYsCQ(self, mode, path, title, filePatt):
  if filePatt is not None:
   filePatt = filePatt.strip()
   FF2tHk(CFG.lastFileManFindPatt, filePatt)
   badLst = filePatt.replace(" ", "") in ("*.*", "*.", ".*")
   if not filePatt : FFycel(self, "No entery", 1500)
   elif badLst  : FFycel(self, "Too many file !", 1500)
   else   : FFzW1w(self, BF(self.VVc3YU, mode, path, title, filePatt), title="Searching ...")
 def VVc3YU(self, mode, path, title, filePatt):
  lst = FFSInC(FFdlNi("find '%s' -type f -iname '%s' %s" % ("/" if mode==2 else path, filePatt, "-maxdepth 1" if mode == 0 else "")))
  if lst:
   err = CCUGPF.VVnFIi(lst)
   if err:
    FFzrXb(self, err)
   else:
    for ndx, path in enumerate(lst):
     lst[ndx] = (os.path.basename(path), os.path.dirname(path))
    lst.sort(key=lambda x: x[0].lower())
    header = ("File", "Directory" )
    widths = (50  , 50   )
    VV1Jd7 = (""     , self.VVvO4I , [])
    VVEXwE = ("Go to File Location", self.VVuorp  , [])
    FFldB6(self, None, title="%s : %s" % (title, filePatt), header=header, VVWsIU=lst, VVv3Wm=widths, VVHZHw=26, VV1Jd7=VV1Jd7, VVEXwE=VVEXwE)
  else:
   FFhcEU(self, "Not found !", 2000)
 def VVuorp(self, VVoLtS, title, txt, colList):
  path = os.path.join(colList[1], colList[0])
  if fileExists(path):
   VVoLtS.cancel()
   self.VVTnU9(path)
  else:
   FFycel(VVoLtS, "Path not found !", 1000)
 def VVvO4I(self, VVoLtS, title, txt, colList):
  txt = "%s\n%s\n\n" % (FFCzRx("File:"  , VV61JF), colList[0])
  txt += "%s\n%s"  % (FFCzRx("Directory:", VV61JF), FF5DjF(colList[1]))
  FFtybv(VVoLtS, txt, title=title)
 def VVH8t9(self):
  nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVaSBQ()
  VVMVqr = []
  VVMVqr.append(("Name\t%s" % nameAlpTxt, "nameAlp"))
  VVMVqr.append(("Name\t%s" % nameNumTxt, "nameNum"))
  VVMVqr.append(("Date\t%s" % dateTxt, "dateAlp"))
  VVMVqr.append(("Type\t%s" % typeTxt, "typeAlp"))
  VVdhQt = ("Mix", BF(self.VVsddN, True))
  FF7ARM(self, BF(self.VV5nan, False), barText=txt, width=650, title="Sort Options", VVMVqr=VVMVqr, VVdhQt=VVdhQt, VVMTvd=True, VVZYdg="#00221111", VVcwfs="#00221111")
 def VVsddN(self, isMix, VVdtUh, item):
  self.VV5nan(True, item)
 def VV5nan(self, isMix, item):
  if item:
   nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVaSBQ()
   title = "Sorting ... "
   if   item == "nameAlp": FFzW1w(self, BF(self["myMenu"].VVkA7r, nameAlpMode, isMix, False), title=title)
   elif item == "nameNum": FFzW1w(self, BF(self["myMenu"].VVkA7r, nameNumMode, isMix, True ), title=title)
   elif item == "dateAlp": FFzW1w(self, BF(self["myMenu"].VVkA7r, dateMode , isMix, False), title=title)
   elif item == "typeAlp": FFzW1w(self, BF(self["myMenu"].VVkA7r, typeMode , isMix, False), title=title)
 def VVIJfJ(self, path):
  if not os.path.isdir(path):
   path = FFIRGA(path, True)
  FF2tHk(CFG.browserStartPath, path)
  FFycel(self, "Done", 500)
 def VV3Vfg(self, selFile, VV66pG, command):
  FFo4dm(self, BF(FFHguD, self, command, consFont=True, VVFgpi=self.VVKkQ7), "%s\n\n%s" % (VV66pG, selFile))
 def VVHmAm(self, path, calledFromMenu):
  destPath = self.VVOp5u(path)
  lastPart = FFZ5fy(destPath)
  color = VV61JF if calledFromMenu else ""
  VVMVqr = []
  if path.endswith(".gz") and not path.endswith(".tar.gz"):
   VVMVqr.append((color + "Extract Content"           , "extract_gz" ))
  else:
   if calledFromMenu: VVMVqr.append(VVpTvr)
   VVMVqr.append((color + "List Archived Files"          , "extract_listFiles" ))
   VVMVqr.append(VVpTvr)
   VVMVqr.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
   VVMVqr.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
   VVMVqr.append((color + "Extract Here"            , "extract_here"  ))
   if iTar and iZip:
    if path.endswith(".zip"):
     if not calledFromMenu: VVMVqr.append(VVpTvr)
     VVMVqr.append((color + "Convert .zip to .tar.gz"       , "VVeAgE" ))
    elif path.endswith(".tar.gz"):
     if not calledFromMenu: VVMVqr.append(VVpTvr)
     VVMVqr.append((color + "Convert .tar.gz to .zip"       , "VVR7LB" ))
  return VVMVqr
 def VVlz1a(self, path, selFile):
  FF7ARM(self, BF(self.VVF104, path, selFile), title="Compressed File Options", VVMVqr=self.VVHmAm(path, False))
 def VVF104(self, path, selFile, item=None):
  if item is not None:
   parent  = FFIRGA(path, False)
   destPath = self.VVOp5u(path)
   lastPart = FFZ5fy(destPath)
   cmd   = ""
   ques  = "Extract file ?\n\n%s" % selFile
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % SEP
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FFkbwj("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo ''; unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FFkbwj("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo ''; unrar l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".7z"):
     cmd += FFkbwj("7za", "p7zip", "P7Zip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo ''; 7za l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n\n';" % path
     cmd += "totFiles=$(tar -tf '%s' | wc -l);" % path
     cmd += "if (( $totFiles > 300 )); then moreInf='  ... Will list the first 300 only ...'; else moreInf=''; fi;"
     cmd += "echo -e '\n%s\n--- Contents (Total='$totFiles')'$moreInf'\n%s';" % (SEP, SEP)
     cmd += "tar -tf '%s' | head -n300;" % path
     cmd += "if (( $totFiles > 300 )); then echo '\n... Only the first 300 are listed ...'; fi;"
    cmd += "echo '';"
    cmd += linux_sep
    FFK0Ik(self, cmd, consFont=True)
   elif path.endswith(".rar"):
    self.VVktQr(item, path, parent, destPath, ques)
   elif path.endswith(".7z"):
    self.VVSmo1(item, path, parent, destPath, ques)
   elif path.endswith(".zip"):
    if item == "VVeAgE" : self.VVeAgE(path)
    else       : self.VVCkGB(item, path, parent, destPath, ques)
   elif item == "VVR7LB" and path.endswith(".tar.gz"):
    self.VVR7LB(path)
   elif item == "extract_gz":
    title = 'Extract ".gz" file'
    res = FFwTnb("RES=$(gzip -dk '%s') && echo ok || echo $RES" % path)
    if res == "ok":
     FFuXZg(self, "Result:\n\n%s" % path[:-3], title=title)
     self.VVKkQ7()
    else:
     FFzrXb(self, "Error:\n\n%s" % res, title=title)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFgeXp("mkdir '%s'"   % lastPart)
    cmd += 'if [ -d "%s" ]; then '  % lastPart
    cmd += " tar -xvf '%s' -C '%s';" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VV3Vfg(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VV3Vfg(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here":
    parent = FFIRGA(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VV3Vfg(selFile, "Extract Here ?"      , cmd)
 def VVOp5u(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  elif path.endswith(".7z")  : extLen = 3
  elif path.endswith(".gz")  : extLen = 3
  else       : extLen = 0
  return path[:-extLen]
 def VVCkGB(self, item, path, parent, destPath, VV66pG):
  FFo4dm(self, BF(self.VVHPaS, item, path, parent, destPath), VV66pG)
 def VVHPaS(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % SEP
  cmd  = FFkbwj("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFC7pV(destPath, VVXF4f))
  cmd +=   sep
  cmd += "fi;"
  FFr7wJ(self, cmd, VVFgpi=self.VVKkQ7, consFont=True)
 def VVktQr(self, item, path, parent, destPath, VV66pG):
  FFo4dm(self, BF(self.VVcf5e, item, path, parent, destPath), VV66pG)
 def VVcf5e(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FF5DjF(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % SEP
  cmd  = FFkbwj("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFC7pV(destPath, VVXF4f))
  cmd +=   sep
  cmd += "fi;"
  FFr7wJ(self, cmd, VVFgpi=self.VVKkQ7, consFont=True)
 def VVSmo1(self, item, path, parent, destPath, VV66pG):
  FFo4dm(self, BF(self.VVcvYT, item, path, parent, destPath), VV66pG)
 def VVcvYT(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = destPath
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += "7za x '%s' -o'%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % SEP
  cmd  = FFkbwj("7za", "p7zip", "P7Zip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFC7pV(destPath, VVXF4f))
  cmd +=   sep
  cmd += "fi;"
  FFr7wJ(self, cmd, VVFgpi=self.VVKkQ7, consFont=True)
 def VVhrT0(self, addSep=False):
  VVMVqr = []
  if addSep:
   VVMVqr.append(VVpTvr)
  VVMVqr.append((VV61JF + "View Script File"  , "script_View"  ))
  VVMVqr.append((VV61JF + "Execute Script File" , "script_Execute" ))
  VVMVqr.append((VV61JF + "Edit"     , "script_Edit"  ))
  return VVMVqr
 def VVLTud(self, path, selFile):
  FF7ARM(self, BF(self.VVlsLT, path, selFile), title="Script File Options", VVMVqr=self.VVhrT0())
 def VVlsLT(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFdD2h(self, path)
   elif item == "script_Execute" : self.VV3Vfg(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCH94c(self, path, VVEStC=self.VVDPK8)
 def VV59a9(self, addSep=False):
  VVMVqr = []
  if addSep:
   VVMVqr.append(VVpTvr)
  VVMVqr.append((VV61JF + "Browse IPTV Channels" , "m3u_Browse" ))
  VVMVqr.append((VV61JF + "Edit"     , "m3u_Edit" ))
  VVMVqr.append((VV61JF + "View"     , "m3u_View" ))
  return VVMVqr
 def VVLErZ(self, path, selFile):
  FF7ARM(self, BF(self.VVr87A, path, selFile), title="M3U/M3U8 File Options", VVMVqr=self.VV59a9())
 def VVr87A(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FFzW1w(self, BF(self.session.open, CCfw0y, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CCH94c(self, path, VVEStC=self.VVDPK8)
   elif item == "m3u_View"  : FFdD2h(self, path)
 def VV2Jon(self, path):
  if fileExists(path) : FFzW1w(self, BF(CCscRA.VVf3m2, self, path, BF(self.VVNSyX, path)), title="Loading Codecs ...")
  else    : FFZ5Ys(self, path)
 def VVNSyX(self, path, item=None):
  if item:
   FFdD2h(self, path, encLst=item)
 def VVDRTC(self, path, title, asUtf8):
  if fileExists(path) : FFzW1w(self, BF(CCscRA.VVf3m2, self, path, BF(self.VVWadg, path, title, asUtf8), title="Original Encoding"), title="Loading Codecs ...")
  else    : FFZ5Ys(self, path)
 def VVWadg(self, path, title, asUtf8, fromEnc=None):
  if fromEnc:
   if asUtf8: self.VVXtsG(path, title, fromEnc, "UTF-8")
   else  : CCscRA.VVW4Bp(self, BF(self.VVXtsG, path, title, fromEnc), title="Convert to Encoding")
 def VVXtsG(self, path, title, fromEnc, item):
  if item:
   txt, toEnc, ndx = item
   if fileExists(path):
    try:
     outFile = "%s_%s%s" % (path, toEnc, os.path.splitext(path)[1])
     with ioOpen(path, "r", encoding=fromEnc) as src:
      BLOCK_1MB = 1048576
      with ioOpen(outFile, "w", encoding=toEnc) as dest:
       while True:
        cont = src.read(BLOCK_1MB)
        if not cont:
         break
        dest.write(cont)
      txt  = FFCzRx("Successful\n\n", VVXF4f)
      txt += FFCzRx("From Encoding (%s):\n" % fromEnc, VVRJhR)
      txt += "%s\n\n" % path
      txt += FFCzRx("To Encoding (%s):\n" % toEnc, VVRJhR)
      txt += "%s\n\n" % outFile
      FFtybv(self, txt, title=title)
    except:
     FFzrXb(self, 'Cannot encode the file:\n%s\n\nFrom "%s" to "%s"' % (path, fromEnc, toEnc), title=title)
   else:
    FFycel(self, "Cannot open file", 2000)
   self.VVKkQ7()
 def VVd0Mu(self, path):
  title = "File Line-Break Conversion"
  FFo4dm(self, BF(self.VVKj1o, path, title), "Convert Line-Breaks to Unix for the file:\n\n%s" % path, title=title)
 def VVKj1o(self, path, title):
  if fileExists:
   with open(path, 'rb') as f:
    data = f.read()
   done = False
   if data:
    CRLF, LF, To = b"\r\n", b"\r", b"\n"
    totCRLF = data.count(CRLF)
    totLF = data.count(LF)
    if totCRLF or totLF:
     done = True
     with open(path, 'wb') as f:
      f.write(data.replace(CRLF, To).replace(LF, To))
   if done : txt = "%s\n\n%s" % (FFCzRx("File converted:", VVXF4f), path)
   else : txt = "Nothing to convert in:\n\n%s" % path
   FFuXZg(self, txt, title=title)
  else:
   FFZ5Ys(self, path, title=title)
 def VVTkde(self, path, selFile, newChmod):
  FFo4dm(self, BF(self.VVVcQP, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVVcQP(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VVWwsK)
  result = FFwTnb(cmd)
  if result == "Successful" : FFuXZg(self, result)
  else      : FFzrXb(self, result)
 def VVERao(self, path, selFile):
  parent = FFIRGA(path, False)
  self.session.openWithCallback(self.VVz7s8, BF(CCUGPF, mode=CCUGPF.VVGIMp, VVRawy=parent, VVSPOW="Create Symlink here"))
 def VVz7s8(self, newPath):
  if len(newPath) > 0:
   target = self.VVt0jN(self.VVQYvn())
   target = FFZuCm(target)
   linkName = FFZ5fy(target)
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FF5DjF(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFzrXb(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFo4dm(self, BF(self.VV4aGz, target, link), "Create Soft Link ?\n\n%s" % txt, VVxcAw=True)
 def VV4aGz(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VVWwsK)
  result = FFwTnb(cmd)
  if result == "Successful" : FFuXZg(self, result)
  else      : FFzrXb(self, result)
 def VVFLVY(self, path, selFile):
  lastPart = FFZ5fy(path)
  FFBgSg(self, BF(self.VVt5Lj, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVt5Lj(self, path, selFile, VVEKeH):
  if VVEKeH:
   parent = FFIRGA(path, True)
   if os.path.isdir(path):
    path = FFZuCm(path)
   newName = parent + VVEKeH
   cmd = "mv '%s' '%s' %s" % (path, newName, VVWwsK)
   if VVEKeH:
    if selFile != VVEKeH:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFo4dm(self, BF(self.VVnYA2, cmd), message, title="Rename file?")
    else:
     FFzrXb(self, "Cannot use same name!", title="Rename")
 def VVnYA2(self, cmd):
  result = FFwTnb(cmd)
  if "Fail" in result:
   FFzrXb(self, result)
  self.VVKkQ7()
 def VV82S4(self, preserve):
  title="Archive to .tar.gz"
  self.session.open(CCSCNk, barTheme=CCSCNk.VVSu4G, titleBg="#22003344", bodyBg="#22001122"
      , titlePrefix = title
      , fncToRun  = BF(self.VV7yiW, title, preserve)
      , VVEStC = BF(self.VV4fFQ, title))
 def VV7yiW(self, title, preserve, VV2ohY):
  totSel = self["myMenu"].VVzFl9()
  totOk = totFail = 0
  VV2ohY.VVHJ4P(totSel)
  VV2ohY.VVRTV9 = ["", totSel, totOk, totFail, ""]
  VV2ohY.VVKDNk("Prepareing targz file")
  curDir = self["myMenu"].VVKGHN()
  lastPart = FFZ5fy(curDir) or "archive"
  outF = os.path.join(curDir, lastPart + ".tar.gz")
  c = 0
  while fileExists(outF):
   c += 1
   outF = os.path.join(curDir, lastPart + "_%d.tar.gz" % c)
  totOk = totFail = 0
  path = ""
  try:
   with iTar.open(outF, mode="w:gz") as tarF:
    for row in self["myMenu"].list:
     if not VV2ohY or VV2ohY.isCancelled:
      return
     if row[2][6]:
      VV2ohY.VVc1xD(1)
      name  = FFZuCm(row[0][0])
      lastPath = FFZ5fy(name)
      path  = os.path.join(curDir, name)
      tarF.add(path, arcname=None if preserve else lastPath)
      totOk += 1
      if VV2ohY:
       VV2ohY.VVRTV9 = [outF, totSel, totOk, totFail, path]
       VV2ohY.VV3aSA(totOk, lastPath)
  except:
   totFail += 1
   if VV2ohY:
    VV2ohY.VVRTV9 = [outF, totSel, totOk, totFail, path]
 def VV4fFQ(self, title, VVPnF9, VVRTV9, threadCounter, threadTotal, threadErr):
  outF, totSel, totOk, totFail, path = VVRTV9
  txt  = "%s:\n%s\n\n"   % (FFCzRx("Output File", VVXF4f), outF)
  txt += "Total\t: %d\n"  % totSel
  txt += "Archived\t: %d\n" % totOk
  if totFail   : txt += FFCzRx("Failed\t: %d\n" % totFail, VVtz60)
  if not VVPnF9: txt += "%s\n%s" % (FFCzRx("\nCancelled while copying:", VVtz60), path)
  FFtybv(self, txt, title=title)
  self.VVKkQ7()
 def VVWFUA(self, isMove):
  self.session.openWithCallback(BF(self.VVopp5, isMove), BF(CCUGPF, mode=CCUGPF.VVGIMp, VVRawy=self["myMenu"].VVKGHN(), VVSPOW="Move to here" if isMove else "Paste here"))
 def VVopp5(self, isMove, newPath):
  if newPath:
   if isMove : title, action = "Move Items", "Moved"
   else  : title, action = "Copy Items", "Copied"
   self.session.open(CCSCNk, barTheme=CCSCNk.VVSu4G, titleBg="#22003344", bodyBg="#22001122"
       , titlePrefix = title
       , fncToRun  = BF(self.VVvMk5, title, action, isMove, newPath)
       , VVEStC = BF(self.VVxfsK, title, action, isMove, newPath))
 def VVvMk5(self, title, action, isMove, newPath, VV2ohY):
  curDir = self["myMenu"].VVKGHN()
  totOk = totFail = 0
  totSel = self["myMenu"].VVzFl9()
  if isMove: cmd = "mv -f"
  else  : cmd = "cp -frp"
  VV2ohY.VVHJ4P(totSel)
  VV2ohY.VVRTV9 = [totSel, totOk, totFail, ""]
  for row in self["myMenu"].list:
   if not VV2ohY or VV2ohY.isCancelled:
    return
   if row[2][6]:
    VV2ohY.VVc1xD(1)
    VV2ohY.VVKQrf(action, totOk, FFZ5fy(row[0][0]))
    path = os.path.join(curDir, row[0][0])
    lastPart = FFZ5fy(path)
    if os.path.isdir(path): path = FFZuCm(path)
    dest = os.path.join(newPath, lastPart)
    if FFgSm7("%s '%s' '%s'" % (cmd, path, dest)) : totOk += 1
    else            : totFail += 1
    if VV2ohY:
     VV2ohY.VVRTV9 = [totSel, totOk, totFail, path]
     VV2ohY.VVKQrf(action, totOk, FFZ5fy(row[0][0]))
 def VVxfsK(self, title, action, isMove, newPath, VVPnF9, VVRTV9, threadCounter, threadTotal, threadErr):
  totSel, totOk, totFail, path = VVRTV9
  txt  = "Total\t: %d\n" % totSel
  txt += "%s\t: %d\n"  % (action, totOk)
  if totFail   : txt += FFCzRx("Failed\t: %d\n" % totFail, VVtz60)
  if not VVPnF9: txt += "%s\n%s" % (FFCzRx("\nCancelled while copying:", VVtz60), path)
  FFtybv(self, txt, title=title)
  self.VVKkQ7()
 def VV4vNc(self):
  tot = self["myMenu"].VVzFl9()
  FFo4dm(self, BF(FFzW1w, self, self.VV7TiA, title="Deleting ...", clearMsg=False), "Delete %d item%s ?" % (tot, FFoTxy(tot)), title="Delete Selection")
 def VV7TiA(self):
  path = self["myMenu"].VVKGHN()
  for row in self["myMenu"].list:
   if row[2][6]:
    FFBjqc(os.path.join(path, row[0][0]))
  FFycel(self)
  self.VVKkQ7()
 def VVnw06(self, path, isMove):
  self.session.openWithCallback(BF(self.VVW44i, isMove, path), BF(CCUGPF, mode=CCUGPF.VVGIMp, VVRawy=FFIRGA(path, False), VVSPOW="Move to here" if isMove else "Paste here"))
 def VVW44i(self, isMove, src, dst):
  if not dst:
   return
  action = "Move" if isMove else "Copy"
  src = FFZuCm(src)
  if os.path.isfile(src) or os.path.islink(src): isFile, srcSubj = True , "File"
  else           : isFile, srcSubj = False, "Directory"
  title = "%s %s" % (action, srcSubj)
  src = FFZuCm(src)
  dst = os.path.join(dst, FFZ5fy(src))
  if src == dst:
   FFzrXb(self, "From:\n%s\n\n To:\n%s" % (src, dst), title=("Cannot %s %s to itself" % (action, srcSubj)).capitalize())
   return
  prams = title, isFile, isMove, srcSubj, src, dst
  if fileExists(dst) or pathExists(dst): FFo4dm(self, BF(self.VV8CHT, prams), "Overwrite Destination %s ?\n\n%s" % (srcSubj, dst), title=title)
  elif not isFile       : FFo4dm(self, BF(self.VV8CHT, prams), "Overwrite Destination Files", title=title)
  else         : self.VV8CHT(prams)
 def VV8CHT(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  if isMove and CCUGPF.VVqkhN(src) == CCUGPF.VVqkhN(dst):
   FFzW1w(self, BF(self.VVAAQv, prams), title="Moving %s ..." % srcSubj)
  else:
   FFzW1w(self, BF(self.VVqhOP, prams), title="Calculating Size ...")
 def VVAAQv(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  res = FFwTnb("RES=$(mv -f '%s' '%s') && echo ok || echo $RES" % (src, dst))
  if res == "ok":
   self.VVKkQ7()
  else:
   FFzrXb(self, "Error : %s\n\n%s" % (res, src), title=title)
 def VVqhOP(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  if isFile: size = FFPLWs(src)
  else  : size = FFM9Wx(src)
  if size > -1:
   self.session.open(CCSCNk, barTheme=CCSCNk.VVSu4G, titleBg="#22220022", bodyBg="#22220022"
       , titlePrefix = "Moving %s ..." % srcSubj if isMove else "Copying %s ..." % srcSubj
       , fncToRun  = BF(self.VVXyL7, prams, size)
       , VVEStC = BF(self.VVt9nH, prams))
  else:
   FFzrXb(self, "Cannot get size for:\n\n%s" % src, title=title)
 def VVXyL7(self, prams, size, VV2ohY):
  title, isFile, isMove, srcSubj, src, dst = prams
  VV2ohY.VVHJ4P(size)
  VV2ohY.VVRTV9 = ("", "", False)
  def VV7VNt(srcFile, dstFile):
   if os.path.islink(srcFile):
    if fileExists(dstFile):
     FFnPMX(dstFile)
    os.symlink(os.readlink(srcFile), dstFile)
   elif os.path.isfile(srcFile):
    with open(srcFile, "rb") as srcF:
     with open(dstFile, "wb") as dstF:
      while True:
       if not VV2ohY or VV2ohY.isCancelled:
        VV2ohY.VVRTV9 = (srcFile, "", True)
        FFnPMX(dstFile)
        return False
       try:
        data = srcF.read(1024)
        if not data:
         break
        dstF.write(data)
        VV2ohY.VVc1xD(len(data))
       except Exception as e:
        VV2ohY.VVRTV9 = (srcFile, str(e), False)
        FFnPMX(dstFile)
        return False
   if iCopymode: iCopymode(srcFile, dstFile)
   if isMove: FFnPMX(srcFile)
   return True
  if isFile:
   tot = 1
   VV7VNt(src, dst)
  else:
   VV2ohY.VVKDNk("Calculating Dirs/Files ...")
   totDir, totFile, totLink = FFTsWT(src)
   if not VV2ohY or VV2ohY.isCancelled:
    VV2ohY.VVRTV9 = ("", "", True)
    return
   tot = totFile + totLink
   fCount = 0
   for Dir, dirs, files in os.walk(src):
    files = os.listdir(Dir)
    dstDir = os.path.join(dst, Dir[len(src):].lstrip("/"))
    if not pathExists(dstDir):
     try:
      os.makedirs(dstDir)
     except Exception as e:
      VV2ohY.VVRTV9 = (os.path.join(Dir, f), str(e), False)
    for f in files:
     srcFile = os.path.join(Dir, f)
     dstFile = os.path.join(dst, srcFile[len(src):].lstrip("/"))
     if os.path.islink(srcFile) or os.path.isfile(srcFile):
      fCount += 1
      VV2ohY.VVKDNk("File: %d/%d >> %s" % (fCount, tot, f))
      if not VV7VNt(srcFile, dstFile):
       return
    if isMove and not os.listdir(Dir):
     FFgSm7("rm -fr '%s'" % Dir)
   if isMove:
    FFgSm7("rm -fr '%s'" % src)
 def VVt9nH(self, prams, VVPnF9, VVRTV9, threadCounter, threadTotal, threadErr):
  title, isFile, isMove, srcSubj, src, dst = prams
  lastFile, err, isCancelled = VVRTV9
  if err:
   FFzrXb(self, "%s\n\n%s" % (err, lastFile), title=title + " ... Error")
  elif isCancelled:
   if isFile: FFycel(self, "Canelled", 1000)
   else  : FFzrXb(self, "Cancelled at file:\n\n%s" % lastFile if lastFile else "Process Stopped.", title=title + " ... Cancelled")
  else:
   FFycel(self, "Done", 1500, isGrn=True)
  if VVPnF9 and isMove:
   self.VVKkQ7()
 def VVe5iQ(self, path, fileName):
  path = FFZuCm(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFo4dm(self, BF(FFzW1w, self, BF(self.VV6vbG, path), title="Deleting ...", clearMsg=False), "%s\n\nDelete %s ?" % (path, pathType), title="Delete %s" % pathType)
 def VV6vbG(self, path):
  FFBjqc(path)
  FFycel(self)
  self.VVKkQ7()
 def VVCv9D(self, path, isFile):
  dirName = FF5DjF(os.path.dirname(path))
  if isFile : objName, VVEKeH = "File"  , self.edited_newFile
  else  : objName, VVEKeH = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFBgSg(self, BF(self.VV3bG0, dirName, isFile, title), title=title, defaultText=VVEKeH, message="Enter %s Name:" % objName)
 def VV3bG0(self, dirName, isFile, title, VVEKeH):
  if VVEKeH:
   if isFile : self.edited_newFile = VVEKeH
   else  : self.edited_newDir  = VVEKeH
   path = dirName + VVEKeH
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VVWwsK)
    else  : cmd = "mkdir '%s' %s" % (path, VVWwsK)
    result = FFwTnb(cmd)
    if "Fail" in result:
     FFzrXb(self, result)
    self.VVKkQ7()
   else:
    FFzrXb(self, "Name already exists !\n\n%s" % path, title)
 def VVgfmW(self, path, selFile):
  c1, c2, c3 = VVJS3b, VV61JF, VVTKrH
  VVMVqr = []
  VVMVqr.append((c1 + "List Package Files"         , "VV8S5M"     ))
  VVMVqr.append((c1 + "Package Information"         , "VVxmD9"     ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append((c2 + "Install Package"          , "VVYMNU_CheckVersion" ))
  VVMVqr.append((c2 + "Install Package (force reinstall)"     , "VVYMNU_ForceReinstall" ))
  VVMVqr.append((c2 + "Install Package (force overwrite)"     , "VVYMNU_ForceOverwrite" ))
  VVMVqr.append((c2 + "Install Package (force downgrade)"     , "VVYMNU_ForceDowngrade" ))
  VVMVqr.append((c2 + "Install Package (ignore failed dependencies)"  , "VVYMNU_IgnoreDepends" ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append((c3 + "Remove Related Package"        , "VVo0ms_ExistingPackage" ))
  VVMVqr.append((c3 + "Remove Related Package (force remove)"    , "VVo0ms_ForceRemove"  ))
  VVMVqr.append((c3 + "Remove Related Package (ignore failed dependencies)" , "VVo0ms_IgnoreDepends" ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Extract Files"           , "VV0CZA"     ))
  VVMVqr.append(("Unbuild Package"           , "VVH3Vi"     ))
  FF7ARM(self, BF(self.VVFmul, path, selFile), VVMVqr=VVMVqr)
 def VVFmul(self, path, selFile, item=None):
  if item is not None:
   if   item == "VV8S5M"      : self.VV8S5M(path, selFile)
   elif item == "VVxmD9"      : self.VVxmD9(path)
   elif item == "VVYMNU_CheckVersion"  : self.VVYMNU(path, selFile, VVLFdd     )
   elif item == "VVYMNU_ForceReinstall" : self.VVYMNU(path, selFile, VV8F5p )
   elif item == "VVYMNU_ForceOverwrite" : self.VVYMNU(path, selFile, VVYC8S )
   elif item == "VVYMNU_ForceDowngrade" : self.VVYMNU(path, selFile, VVLn3s )
   elif item == "VVYMNU_IgnoreDepends" : self.VVYMNU(path, selFile, VVIAJ8 )
   elif item == "VVo0ms_ExistingPackage" : self.VVo0ms(path, selFile, VVS3eG     )
   elif item == "VVo0ms_ForceRemove"  : self.VVo0ms(path, selFile, VVzVlq  )
   elif item == "VVo0ms_IgnoreDepends"  : self.VVo0ms(path, selFile, VVWN0E )
   elif item == "VV0CZA"     : self.VV0CZA(path, selFile)
   elif item == "VVH3Vi"     : self.VVH3Vi(path, selFile)
 def VV8S5M(self, path, selFile):
  if FFlgKV("ar") : cmd = "allOK='1';"
  else    : cmd  = FFQ4w6()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (SEP, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (SEP, SEP)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFLde9(self, cmd, VVFgpi=self.VVKkQ7)
 def VV0CZA(self, path, selFile):
  lastPart = FFZ5fy(path)
  dest  = FFIRGA(path, True) + selFile[:-4]
  cmd  =  FFQ4w6()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFgeXp("mkdir '%s'" % dest)
  cmd +=    FFgeXp("cd '%s'" % dest)
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFC7pV(dest, VVXF4f))
  cmd += "fi;"
  FFHguD(self, cmd, VVFgpi=self.VVKkQ7)
 def VVH3Vi(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVfkpo = os.path.splitext(path)[0]
  else        : VVfkpo = path + "_"
  if path.endswith(".deb")   : VVJ8H4 = "DEBIAN"
  else        : VVJ8H4 = "CONTROL"
  cmd  = FFQ4w6()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -rf '%s' > /dev/null 2>&1;" % VVfkpo
  cmd += "  mkdir '%s';"      % VVfkpo
  cmd += "  CONTPATH='%s/%s';"    % (VVfkpo, VVJ8H4)
  cmd += '  mkdir "$CONTPATH";'
  cmd += "  cd '%s';"       % VVfkpo
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"      % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f \"$FILE\" ] && tar -xzf \"$FILE\" -C '%s'          && rm -f \"$FILE\";" % (VVfkpo, VVfkpo)
  cmd += "  FILE='%s/control.tar.gz'; [ -f \"$FILE\" ] && tar -xzf \"$FILE\" -C \"$CONTPATH\" && rm -f \"$FILE\";" %  VVfkpo
  cmd += "  FILE='%s/data.tar.xz';    [ -f \"$FILE\" ] && tar -xJf \"$FILE\" -C '%s'          && rm -f \"$FILE\";" % (VVfkpo, VVfkpo)
  cmd += "  FILE='%s/control.tar.xz'; [ -f \"$FILE\" ] && tar -xJf \"$FILE\" -C \"$CONTPATH\" && rm -f \"$FILE\";" %  VVfkpo
  cmd += "  FILE='%s/debian-binary';  [ -f \"$FILE\" ]                                        && rm -f \"$FILE\";" %  VVfkpo
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e '\nOutput Directory:\n%s' %s;" % (VVfkpo, FFC7pV(VVfkpo, VVXF4f))
  cmd += "fi;"
  FFHguD(self, cmd, VVFgpi=self.VVKkQ7)
 def VVxmD9(self, path):
  listCmd  = FF1dKx(VVoElo, "")
  infoCmd  = FF4ZaS(VV3ArY , "")
  filesCmd = FF4ZaS(VVpVRu, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFQHwo(VVRJhR)
   notInst = "Package not installed."
   cmd  = FFxGY8("File Info", VVRJhR)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFxGY8("System Info", VVRJhR)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFC7pV(notInst, VVtz60))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFxGY8("Related Files", VVRJhR)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFK0Ik(self, cmd)
  else:
   FFV7xB(self)
 def VVYMNU(self, path, selFile, cmdOpt):
  cmd = FF4ZaS(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFo4dm(self, BF(FFHguD, self, cmd, VVFgpi=FFZvbd), "Install Package ?\n\n%s" % selFile)
  else:
   FFV7xB(self)
 def VVo0ms(self, path, selFile, cmdOpt):
  listCmd  = FF1dKx(VVoElo, "")
  infoCmd  = FF4ZaS(VV3ArY, "")
  instRemCmd = FF4ZaS(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFC7pV(errTxt, VVtz60))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFC7pV(cannotTxt, VVtz60))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFC7pV(tryTxt, VVtz60))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFo4dm(self, BF(FFHguD, self, cmd, VVFgpi=FFZvbd), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFV7xB(self)
 def VVvu5j(self, path):
  hostName = FFwTnb("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVQhJb(self, path, isDir):
  txt1 = "Archive to "
  txt2 = "Archive (Preserve Path Structure) to "
  VVMVqr = []
  VVMVqr.append(("%s.tar"  % txt1 , "archDir_tar"  ))
  VVMVqr.append(("%s.tar.gz" % txt1 , "archDir_tar_gz" ))
  VVMVqr.append(("%s.tar.xz" % txt1 , "archDir_tar_xz" ))
  VVMVqr.append(("%s.tar.bz2" % txt1 , "archDir_tar_bz2" ))
  VVMVqr.append(("%s.zip"  % txt1 , "archDir_zip"  ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("%s.tar"  % txt2 , "archPath_tar" ))
  VVMVqr.append(("%s.tar.gz" % txt2 , "archPath_tar_gz" ))
  VVMVqr.append(("%s.tar.xz" % txt2 , "archPath_tar_xz" ))
  VVMVqr.append(("%s.tar.bz2" % txt2 , "archPath_tar_bz2"))
  VVMVqr.append(("%s.zip"  % txt2 , "archPath_zip" ))
  if isDir and not self.multiSelectState:
   VVMVqr.append(VVpTvr)
   VVMVqr.append(('Convert to ".ipk" Package', "convertDirToIpk" ))
   VVMVqr.append(('Convert to ".deb" Package', "convertDirToDeb" ))
  if isDir: c1, c2, title = "#11003322", "#11002222", "Archive Directory"
  else : c1, c2, title = "#11003344", "#11002244", "Archive File"
  FF7ARM(self, BF(self.VVI8bg, path, isDir, title), VVMVqr=VVMVqr, title=title, VVZYdg=c1, VVcwfs=c2)
 def VVI8bg(self, path, isDir, title, item):
  if item is not None:
   if   item == "archDir_tar"  : self.VVPqqV(title, path, isDir, ".tar" , False)
   elif item == "archDir_tar_gz" : self.VVPqqV(title, path, isDir, ".tar.gz" , False)
   elif item == "archDir_tar_xz" : self.VVPqqV(title, path, isDir, ".tar.xz" , False)
   elif item == "archDir_tar_bz2" : self.VVPqqV(title, path, isDir, ".tar.bz2", False)
   elif item == "archDir_zip"  : self.VVPqqV(title, path, isDir, ".zip" , False)
   elif item == "archPath_tar"  : self.VVPqqV(title, path, isDir, ".tar" , True)
   elif item == "archPath_tar_gz" : self.VVPqqV(title, path, isDir, ".tar.gz" , True)
   elif item == "archPath_tar_xz" : self.VVPqqV(title, path, isDir, ".tar.xz" , True)
   elif item == "archPath_tar_bz2" : self.VVPqqV(title, path, isDir, ".tar.bz2", True)
   elif item == "archPath_zip"  : self.VVPqqV(title, path, isDir, ".zip" , True)
   elif item == "convertDirToIpk" : self.VVJqOg(path, False)
   elif item == "convertDirToDeb" : self.VVJqOg(path, True)
 def VVJqOg(self, path, VV6sgm):
  self.session.openWithCallback(self.VVKkQ7, BF(CCfeee, path=path, VV6sgm=VV6sgm))
 def VVPqqV(self, title, path, isDir, fileExt, preserveDirStruct):
  parent  = FFIRGA(path, True)
  lastPart = FFZ5fy(path)
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
  else:
   targetDir = lastPart
  if isDir: outFile, srcTxt = archFile , "Source Directory"
  else : outFile, srcTxt = resultFile , "Source File"
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFkbwj("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFkbwj("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFkbwj("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = "%s '%s' -C / '%s';" % (archCmd, outFile, targetDir[1:])
   else              : archCmd = "%s '%s' '%s';"    % (archCmd, outFile, targetDir)
  else:
   if isDir: archCmd = "cd '%s'; %s '../%s' *;" % (path, archCmd, outFile)
   else : archCmd = "cd '%s'; %s '%s' '%s';" % (parent, archCmd, outFile, os.path.basename(path))
  failed = "Process failed !"
  sep  = " echo -e '%s';" % SEP
  cmd  = toolCmd
  cmd += "echo -e 'Archiving ...\n';"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFgeXp("rm -f '%s'" % archFile)
  cmd +=   archCmd
  cmd += " cd '%s';"      % parent
  cmd +=   sep
  cmd += " if [ $? -ne 0 ]; then "
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFC7pV(failed, VVszO3))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " elif [ -f '%s' ]; then "  % archFile
  cmd += "  chmod 644 '%s';"    % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e '%s:' %s;"   % (srcTxt, FFC7pV(srcTxt, VVAaU5))
  cmd += "  echo -e '%s:\n';"    % path
  cmd += "  echo -e '%s:' %s;"   % ("Output", FFC7pV("Output", VVXF4f))
  cmd += "  echo -e '%s\n';"    % outFile
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFC7pV(failed, VVfMEC))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFLde9(self, cmd, VVFgpi=self.VVKkQ7, title=title)
 def VVzbXu(self, path, isAll):
  if isAll: title, pathLst = "Add all Media in Directory to a Bouquet", CCUGPF.VVezm4(FFIRGA(path, True))
  else : title, pathLst = "Add Media File to a Bouquet"   , [path]
  picker = CCrfsB(self, self, title, BF(self.VVxi5N, pathLst))
 def VVxi5N(self, pathLst):
  return CCrfsB.VVFi0q(pathLst)
 def VVeAgE(self, zipPath):
  title = "Convert .zip to .tar.gz"
  if iZip.is_zipfile(zipPath):
   tarPath = os.path.splitext(zipPath)[0] + ".tar.gz"
   fnc  = BF(self.VV0n43, zipPath, tarPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFo4dm(self, BF(FFzW1w, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FFzW1w(self, fnc, title=txt)
  else:
   FFzrXb(self, "Invalid zip file:\n\n%s" % os.path.basename(zipPath), title=title)
 def VV0n43(self, zipPath, tarPath, title):
  try:
   with iZip.ZipFile(zipPath) as zipF:
    with iTar.open(tarPath, "w:gz") as tarF:
     for zipInfo in zipF.infolist():
      tarInfo = iTar.TarInfo(name=zipInfo.filename)
      tarInfo.size = zipInfo.file_size
      tarInfo.mtime = mktime(tuple(list(zipInfo.date_time) + [-1, -1, -1]))
      tarF.addfile(tarinfo=tarInfo, fileobj=zipF.open(zipInfo.filename))
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FFtybv(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(zipPath), os.path.basename(tarPath)), title=title)
   self.VVKkQ7()
  else:
   FFnPMX(tarPath)
   FFzrXb(self, "Error while converting.", title=title)
 def VVR7LB(self, tarPath):
  title = "Convert .tar.gz to .zip"
  if iTar.is_tarfile(tarPath):
   zipPath = tarPath[:-7] + ".zip"
   fnc  = BF(self.VVSeKI, tarPath, zipPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFo4dm(self, BF(FFzW1w, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FFzW1w(self, fnc, title=txt)
  else:
   FFzrXb(self, "Invalid tar file:\n\n%s" % os.path.basename(tarPath), title=title)
 def VVSeKI(self, tarPath, zipPath, title):
  try:
   with iTar.open(tarPath) as tar:
    with iZip.ZipFile(zipPath, mode='w', compression=iZip.ZIP_DEFLATED) as zipF:
     for mem in tar.getmembers():
      if mem.isfile():
       mtime = datetime.fromtimestamp(mem.mtime)
       zipInfo = iZip.ZipInfo(filename=mem.name, date_time=(mtime.year, mtime.month, mtime.day, mtime.hour, mtime.minute, mtime.second))
       zipF.writestr(zipInfo, tar.extractfile(mem).read(), compress_type=iZip.ZIP_DEFLATED)
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FFtybv(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(tarPath), os.path.basename(zipPath)), title=title)
   self.VVKkQ7()
  else:
   FFnPMX(zipPath)
   FFzrXb(self, "Error while converting.", title=title)
 def VVF0W9(self, path, isFhd):
  size = "1920x1080" if isFhd else "1280x720"
  title = "Convert to MVI (%s)" % size
  Dir  = FF5DjF(os.path.dirname(path))
  filName = os.path.splitext(os.path.basename(path))[0]
  m1v  = "%s%s_%s.m1v" % (Dir, filName, size)
  mvi  = "%s%s_%s.mvi" % (Dir, filName, size)
  FFgSm7("rm -f '%s' '%s'" % (m1v, mvi))
  if FFgSm7("ffmpeg -i '%s' -r 25 -b:v 20000 -s %s '%s'" % (path, size, m1v)) and fileExists(m1v):
   FFgSm7("mv -f '%s' '%s'" % (m1v, mvi))
   self.VVKkQ7()
   FFuXZg(self, "Converted to:\n\n%s" % os.path.basename(mvi), title=title)
  else:
   FFzrXb(self, "Cannot convert this file !", title=title)
 def VVzWd3(self, path):
  title = "Set as PIcon for current channel"
  pPath = CCxrlm.VVjBFN()
  if pathExists(pPath):
   if CCz5Bp.VVdbmR(self, title, False, cbFnc=BF(self.VVzWd3, path)):
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFmvpz(self)
    picon = "%s%s.png" % (pPath, refCode.strip(":").replace(":", "_").upper())
    VVMVqr = []
    for item in ((50,30),(96,64),(100,60),(220,132),(400,160),(400,240),(500,300)):
     VVMVqr.append(("%d x %d" % (item), item))
    VVGygu = self.VVl5Mk
    VVdhQt = ("Stretch", BF(self.VVytgo, title, path, picon))
    VVdtUh = FF7ARM(self, BF(self.VVsc7w, title, path, picon, False), VVMVqr=VVMVqr, width=700, title='PIcon Max. Size', VVGygu=VVGygu, VVdhQt=VVdhQt, barText="OK = Fit within size")
    VVdtUh.VVT53N(3)
  else:
   FFzrXb(self, "PIcons path not found:\n\n%s\n\n( You can change it in Settings )" % pPath, title=title)
 def VVytgo(self, title, path, picon, selectionObj, item):
  self.VVsc7w(title, path, picon, True, item)
  selectionObj.cancel()
 def VVsc7w(self, title, path, picon, stretch, sz=None):
  if sz:
   try:
    from PIL import Image
    im = Image.open(path)
    if stretch: im = im.resize(sz, Image.ANTIALIAS)
    else   : im.thumbnail(sz)
    im.save(picon)
    FFp5JP(self, fncMode=CCoD37.VVp0RA)
   except Exception as e:
    FFzrXb(self, "Image Processing error:\n\n%s" % e)
 def VVl5Mk(self, VVdtUh, txt, ref, ndx):
  FFGkYk(self, "_help_resize", "Picture File Resizing")
 def VV5GQ8(self, path):
  FF7ARM(self, BF(self.VVujhv, path), VVMVqr=CCfw0y.VVOqDo(), width=650, title="Select Player", VVZYdg="#11220000", VVcwfs="#11220000")
 def VVujhv(self, path, rType=None):
  if rType:
   FFzW1w(self, BF(self.VV0bc3, self, path, rType), title="Playing Media ...")
 @staticmethod
 def VV0bc3(SELF, path, rType=""):
  try:
   if   rType     : prefix = rType
   elif path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   CCA3uT.VV1gQV(SELF.session, enableZapping= False, enableDownloadMenu=False)
  except:
   pass
 @staticmethod
 def VVKW1S(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FF5DjF(fDir), fName
  return "", "", ""
 @staticmethod
 def VVIwRI(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VV5yeR(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VVuy4U(size, mode=0):
  txt = CCUGPF.VVQQD8(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VVQQD8(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
 @staticmethod
 def VViwWz(path):
  rangeList = list(range(0x20, 0x100))
  with open(path, 'rb') as f:
   bytes = f.read(1024)
  textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
  return bool(bytes.translate(None, textchars))
 @staticmethod
 def VV1eSU(SELF, path, title=""):
  try:
   with ioOpen(path, "r", encoding="UTF-8") as f:
    txt = f.read()
   return True
  except:
   if title:
    FFzrXb(SELF, "File is not in 'UTF-8' Encoding:\n\n%s" % path, title=title)
   return False
 @staticmethod
 def VVhUen():
  tDict = CC87Iy.VVbM6s()
  lst = list(tDict["mov"])
  lst.extend(list(tDict["mus"]))
  return tuple(lst)
 @staticmethod
 def VVezm4(path):
  lst = []
  for ext in CCUGPF.VVhUen():
   lst.extend(FFY7QR(path, "*.%s" % ext))
  return sorted(lst, key=FFkmXe(FFEzkZ))
 @staticmethod
 def VV594T(path):
  return FFgSm7("tar -tzf '%s'" % path)
 @staticmethod
 def VVqkhN(path):
  path = os.path.abspath(path)
  while not os.path.ismount(path):
   path = os.path.dirname(path)
  return path
 @staticmethod
 def VVnFIi(lst, fromFind=True):
  if len(lst) == 1 and lst[0] == VV7GSC:
   return VV7GSC
  elif fromFind:
   for line in lst:
    span = iSearch(r"find:\s*(.+):\s*Input\/output error", line, IGNORECASE)
    if span:
     return 'Filesystem Error in:\n\n%s' % span.group(1)
  return ""
class CC87Iy(MenuList):
 VVzcm1   = 0
 VVzCUF   = 1
 VVqecg   = 2
 VVCEof   = 3
 VVEuxM   = 4
 VV7LxR   = 5
 VV1Ab3   = 6
 VVDoNO   = 7
 VVEE3g   = "<List of Storage Devices>"
 VVtowH  = "<Parent Directory>"
 VV7iY8   = 0
 VVwPKF   = 1
 VVOXZv = 2
 VVrdWM  = 3
 VV1hRR   = 4
 VVzunx   = 5
 FILE_TYPE_LINK   = 6
 VVbnIH  = 7
 PROHIBITED_FILES  = ["/%s/" % x for x in ("DEBIAN","bin","boot","dev","etc","hdd","home","lib","media","mnt","network","proc","run","sbin","sys","tmp","usr","var")]
 def __init__(self, VVAGyU=False, directory="/", VVM9Ba=True, VVbdOU=True, VV7Xbp=True, VVmimI=None, VVP6Xq=False, VVeapj=False, VV3fyi=False, isTop=False, VViTe9=None, VVqbE4=1000, VVHZHw=30, VVjcdW=30):
  MenuList.__init__(self, list, VVAGyU, eListboxPythonMultiContent)
  self.VVM9Ba  = VVM9Ba
  self.VVbdOU    = VVbdOU
  self.VV7Xbp  = VV7Xbp
  self.VVmimI  = VVmimI
  self.VVP6Xq   = VVP6Xq
  self.VVeapj   = VVeapj or []
  self.VV3fyi   = VV3fyi or []
  self.isTop     = isTop
  self.additional_extensions = VViTe9
  self.VVqbE4    = VVqbE4
  self.VVHZHw    = VVHZHw
  self.VVjcdW    = VVjcdW
  self.EXTENSIONS    = CC87Iy.VVbM6s()
  self.VVHa0D   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.multiSelect_color  = FFBCuC("#11ff4444")
  self.l.setFont(0, gFont(VVXtOH, self.VVHZHw))
  self.l.setItemHeight(self.VVjcdW)
  self.png_mem   = CC87Iy.VVsdXn("mem")
  self.png_usb   = CC87Iy.VVsdXn("usb")
  self.png_fil   = CC87Iy.VVsdXn("fil")
  self.png_dir   = CC87Iy.VVsdXn("dir")
  self.png_dirup   = CC87Iy.VVsdXn("dirup")
  self.png_srv   = CC87Iy.VVsdXn("srv")
  self.png_slwfil   = CC87Iy.VVsdXn("slwfil")
  self.png_slbfil   = CC87Iy.VVsdXn("slbfil")
  self.png_slwdir   = CC87Iy.VVsdXn("slwdir")
  self.VVXcD0()
  self.VVPCRg(directory)
 @staticmethod
 def VVsdXn(category):
  return LoadPixmap("%s%s.png" % (VVLS8v, category), getDesktop(0))
 @staticmethod
 def VVbM6s():
  return {"pic":("bmp","gif","jpe","jpeg","jpg","png"),"mov":("3g2","3gp","asf","avi","divx","flv","ifo","iso","m2ts","m4v","mkv","mod","mov","mp4","mpe","mpeg","mpg","mts","mvi","ogm","ogv","pva","rm","rmvb","stream","ts","vob","webm","wmv","wtv","h264","h265","mjpeg","mk3d","mks","xvid"),"mus":("aac","ac3","alac","amr","ape","au","dts","flac","m2a","m4a","mid","mka","mp2","mp3","oga","ogg","wav","wave","wma","wv","m3u","m4b","m4p","mpc","wpl"),"txt":("cfg","conf","htm","html","py","txt","xml"),"tar":("bz2","gz","tar","xz"),"rar":("rar"),"zip":("zip"),"p7z":("7z"),"ipk":("ipk"),"deb":("deb"),"scr":("sh"),"m3u":("m3u","m3u8")}
 def VVFbHv(self, name, absolute=None, isDir=False, typ=None, png=None):
  if absolute and isDir:
   path = absolute
   path = FFZuCm(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFCzRx(" -> " , VVRJhR) + FFCzRx(os.readlink(path), VVXF4f)
  tableRow = [ (absolute, isDir, typ) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVjcdW + 10, 0, self.VVqbE4, self.VVjcdW, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   tableRow.append(CCYFn3.VVsoXp(0, 2, self.VVjcdW-4, self.VVjcdW-4, png))
  return tableRow
 def VVsdcQ(self, name):
  ext = os.path.splitext(name)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in self.EXTENSIONS.items():
    if ext in lst:
     return cat
  return ""
 def VVXcD0(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse=True)
 def VV2SuC(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVxFfL(self, file):
  if os.path.realpath(file) == file:
   return self.VV2SuC(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VV2SuC(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VV2SuC(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVevtz(self):
  ndx = self.l.getCurrentSelectionIndex()
  row = self.list[ndx]
  bg = self.multiSelect_color if row[2][6] == None else None
  ndx = self.getSelectionIndex()
  if ndx < len(self.list) - 1:
   self.moveToIndex(self.getSelectionIndex() + 1)
  iconData = self.VVBi5s(row, bg)
  if iconData:
   row[2] = iconData
   self.l.setList(self.list)
   return True
  else:
   return False
 def VVPZyq(self, isSel):
  bg = self.multiSelect_color if isSel else None
  for ndx, row in enumerate(self.list):
   iconData = self.VVBi5s(row, bg)
   if iconData:
    row[2] = iconData
  self.l.setList(self.list)
 def VVBi5s(self, row, bg):
  if self.VVQ3Kv(row):
   iconData = list(row[2])
   iconData[6] = bg
   iconData[7] = bg
   return tuple(iconData)
  else:
   return None
 def VVQ3Kv(self, row):
  if not row[0][0] in self.mountpoints:
   if   row[0][2] in (self.VVzunx, self.FILE_TYPE_LINK): return True
   elif row[0][2] == self.VV1hRR:
    if   VVPdMM           : return True
    elif not row[0][0] in self.PROHIBITED_FILES    : return True
  return False
 def VVVJyP(self):
  return self.VVQ3Kv(self.list[self.l.getCurrentSelectionIndex()])
 def VVzFl9(self):
  tot = 0
  for row in self.list:
   if row[2][6]:
    tot += 1
  return tot
 def VVJAhs(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVPCRg(self, directory, selItem=None):
  self.list = []
  directories = []
  files = []
  if self.current_directory is None:
   if directory and self.VV7Xbp:
    self.current_mountpoint = self.VVxFfL(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  if directory is None:
   if self.VV7Xbp:
    for p in harddiskmanager.getMountedPartitions():
     path = os.path.join(p.mountpoint, "")
     if path not in self.VV3fyi and not self.VVJAhs(path, self.VVeapj):
      if path == "/" : png = self.png_mem
      else   : png = self.png_usb
      self.list.append(self.VVFbHv(name=p.description, absolute=path, isDir=True, typ=self.VV7iY8, png=png))
    path = "/"
    if path not in self.VV3fyi and not self.VVJAhs(path, self.VVeapj):
     for item in self.list:
      if path == item[0][0]:
       break
     else:
      self.list.append(self.VVFbHv(name="INTERNAL FLASH", absolute="/", isDir=True, typ=self.VVwPKF, png=self.png_mem))
  elif self.VVP6Xq:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVHa0D = eServiceCenter.getInstance()
   list = VVHa0D.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVM9Ba and not self.isTop:
   if directory == self.current_mountpoint and self.VV7Xbp:
    self.list.append(self.VVFbHv(name=self.VVEE3g, absolute=None, isDir=True, typ=self.VVOXZv, png=self.png_dirup))
   elif (directory != "/") and not (self.VV3fyi and self.VV2SuC(directory) in self.VV3fyi):
    self.list.append(self.VVFbHv(name=self.VVtowH, absolute='/'.join(directory.split('/')[:-2]) + '/', isDir=True, typ=self.VVrdWM, png=self.png_dirup))
  if self.VVM9Ba:
   for x in directories:
    if not (self.VV3fyi and self.VV2SuC(x) in self.VV3fyi) and not self.VVJAhs(x, self.VVeapj):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVFbHv(name=name, absolute=x, isDir=True, typ=self.FILE_TYPE_LINK if os.path.islink(FFZuCm(x)) else self.VV1hRR, png=png))
  if self.VVbdOU:
   for x in files:
    if self.VVP6Xq:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(target):
        png = self.png_slwfil
        name += FFCzRx(" -> " , VVRJhR) + FFCzRx(target, VVXF4f)
       else:
        png = self.png_slbfil
        name += FFCzRx(" -> " , VVRJhR) + FFCzRx(target, VVfMEC)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVsdcQ(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVLS8v, category))
    if (self.VVmimI is None) or iCompile(self.VVmimI[0], flags=self.VVmimI[1]).search(path):
     self.list.append(self.VVFbHv(name=name, absolute=x , isDir=False, typ=self.VVzunx, png=png))
  if self.VV7Xbp and len(self.list) == 0:
   self.list.append(self.VVFbHv(name=FFCzRx("No USB connected", VVzv5p), absolute=None, isDir=False, typ=self.VVbnIH, png=self.png_usb))
  self.l.setList(self.list)
  self.VVkA7r()
  if selItem is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference): p = p.getPath()
    if p == selItem: self.moveToIndex(i)
    i += 1
 def VVKGHN(self):
  return self.current_directory
 def VV9TFq(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def VVEqSe(self):
  return self.VVG0Dk() and self.VVKGHN()
 def VVG0Dk(self):
  return self.list[0][1][7] in (self.VVEE3g, self.VVtowH)
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVPCRg(self.getSelection()[0], self.current_directory)
 def VVFInp(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VV3hlp)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VV3hlp)
 def VV3hlp(self, action, device):
  self.VVXcD0()
  if self.current_directory is None:
   self.VVx2tg()
 def VVx2tg(self):
  tDict = {}
  for row in self.list:
   if row[2][6]:
    tDict[row[0][0]] = 1
  self.VVPCRg(self.current_directory, self.VVFInp())
  isSel = 0
  if tDict:
   for row in self.list:
    if tDict.get(row[0][0], 0):
     row[2] = list(row[2])
     row[2][6] = row[2][7] = self.multiSelect_color
     row[2] = tuple(row[2])
     isSel = 1
   self.l.setList(self.list)
  return isSel
 def VVaSBQ(self):
  mode = CFG.browserSortMode.getValue()
  mix  = CFG.browserSortMix.getValue()
  sAZ, sZA, s09, s90, sNO, sON = "A > Z", "Z > A", "0 > 9", "9 > 0", "New > Old", "Old > New"
  if mode == self.VVzcm1 : nameAlpMode, nameAlpTxt = self.VVzCUF, sZA
  else       : nameAlpMode, nameAlpTxt = self.VVzcm1, sAZ
  if mode == self.VVqecg : nameNumMode, nameNumTxt = self.VVCEof, s90
  else       : nameNumMode, nameNumTxt = self.VVqecg, s09
  if mode == self.VVEuxM : dateMode, dateTxt = self.VV7LxR, sON
  else       : dateMode, dateTxt = self.VVEuxM, sNO
  if mode == self.VV1Ab3 : typeMode, typeTxt = self.VVDoNO, sZA
  else       : typeMode, typeTxt = self.VV1Ab3, sAZ
  if   mode in (self.VVzcm1, self.VVzCUF): txt = "Name (%s)" % (sAZ if mode == self.VVzcm1 else sZA)
  elif mode in (self.VVqecg, self.VVCEof): txt = "Name (%s)" % (s09 if mode == self.VVzcm1 else s90)
  elif mode in (self.VVEuxM, self.VV7LxR): txt = "Date (%s)" % (sNO if mode == self.VVEuxM else sON)
  elif mode in (self.VV1Ab3, self.VVDoNO): txt = "Type (%s)" % (sAZ if mode == self.VV1Ab3 else sZA)
  if mix:
   txt += " .. Mixed"
  return nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt, dateMode, dateTxt, typeMode, typeTxt, "Cur = by %s" % txt
 def VVkA7r(self, mode=None, isMix=False, isNum=False):
  if not mode is None:
   FF2tHk(CFG.browserSortMode, mode)
   FF2tHk(CFG.browserSortMix, isMix)
  if self.list:
   if self.VVG0Dk() : item0, topRow = 1, self.list[0]
   else    : item0, topRow = 0, None
   mode = CFG.browserSortMode.getValue()
   isMix = CFG.browserSortMix.getValue()
   if mode in (self.VVzcm1, self.VVzCUF):
    rev = True if mode == self.VVzCUF else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: x[1][7]         , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], x[1][7]), reverse=rev)
   elif mode in (self.VVqecg, self.VVCEof):
    rev = True if mode == self.VVCEof else False
    self.list = sorted(self.list[item0:], key=FFkmXe(BF(self.VVA6g7, isMix, rev)), reverse=rev)
   elif mode in (self.VVEuxM, self.VV7LxR):
    rev = True if mode == self.VV7LxR else False
    self.list = sorted(self.list[item0:], key=FFkmXe(BF(self.VVOL0c, isMix)), reverse=rev)
   else:
    rev = True if mode == self.VVDoNO else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: os.path.splitext(x[1][7])[1]            , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], os.path.splitext(x[1][7])[1], x[1][7]) , reverse=rev)
   if topRow:
    self.list.insert(0, topRow)
   self.l.setList(self.list)
 def VVA6g7(self, mix, rev, p1, p2):
  dir1, name1 = p1[0][1], p1[1][7]
  dir2, name2 = p2[0][1], p2[1][7]
  if mix:
   return FFEzkZ(name1.lower(), name2.lower())
  else:
   if rev: dir1, dir2 = dir2, dir1
   return FFCxZi(dir2, dir1) or FFEzkZ(name1, name2)
 def VVOL0c(self, mix, p1, p2):
  dir1 = p1[0][1]
  dir2 = p2[0][1]
  if mix or dir1 == dir2:
   path1 = "" if dir1 else self.current_directory
   path2 = "" if dir2 else self.current_directory
   try:
    stat1 = os.stat(path1 + p1[0][0])
    stat2 = os.stat(path2 + p2[0][0])
    if mix : return FFCxZi(stat2.st_ctime, stat1.st_ctime)
    else : return FFCxZi(dir2, dir1) or FFCxZi(stat2.st_ctime, stat1.st_ctime)
   except:
    pass
  return 0
class CCFKE9(Screen):
 def __init__(self, session, defFG="", defBG="", onlyBG=False):
  self.skin, self.skinParam = FF5TEn(VV5gWf, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.onlyBG   = onlyBG
  self.Title   = "Color"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VVWsIU   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVZ3sm(defFG, "#00FFFFFF")
  self.defBG   = self.VVZ3sm(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FF32Yx(self, self.Title)
  self["keyRed"].show()
  FFCDDm(self["keyGreen"] , "< > Transp.")
  FFCDDm(self["keyYellow"], "Foreground")
  FFCDDm(self["keyBlue"] , "Background")
  if self.onlyBG:
   self["keyYellow"].hide()
   self["keyBlue"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(VVjUqm,
  {
   "ok"   : self.VVKcEY     ,
   "green"   : self.VVKcEY     ,
   "yellow"  : BF(self.VVIEFK, False)  ,
   "blue"   : BF(self.VVIEFK, True)  ,
   "up"   : self.VVL9bj       ,
   "down"   : self.VVRnLl      ,
   "left"   : self.VVgzL2      ,
   "right"   : self.VVPVKV      ,
   "last"   : BF(self.VVGuIu, -5) ,
   "next"   : BF(self.VVGuIu, 5) ,
   "cancel"  : BF(self.close, None, None)
  }, -1)
  self.onShown.append(self.VVSDD3)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFzBm8(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFzBm8(self["keyRed"] , c)
  FFzBm8(self["keyGreen"] , c)
  self.VV54uY()
  self.VVLKOi()
  FFcdG1(self["myColorTst"], self.defFG)
  FFzBm8(self["myColorTst"], self.defBG)
 def VVZ3sm(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVLKOi(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VVvmgd(0, 0)
     return
 def VVKcEY(self):
  self.close(self.defFG, self.defBG)
 def VVL9bj(self): self.VVvmgd(-1, 0)
 def VVRnLl(self): self.VVvmgd(1, 0)
 def VVgzL2(self): self.VVvmgd(0, -1)
 def VVPVKV(self): self.VVvmgd(0, 1)
 def VVvmgd(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVkhG9()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVK3ub()
 def VV54uY(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVK3ub(self):
  color = self.VVkhG9()
  if self.isBgMode: FFzBm8(self["myColorTst"], color)
  else   : FFcdG1(self["myColorTst"], color)
 def VVIEFK(self, isBg):
  if not self.onlyBG:
   self.isBgMode = isBg
   self.VV54uY()
   self.VVLKOi()
 def VVGuIu(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VVvmgd(0, 0)
 def VVDrRM(self):
  return hex(self.transp)[2:].zfill(2)
 def VVkhG9(self):
  return ("#%s%s" % (self.VVDrRM(), self.colors[self.curRow][self.curCol])).upper()
class CCyEAP(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FF5TEn(VVQdy0, 1860, 1030, 20, 20, 30, "#33002233", "#33002233", 25, topRightBtns=2)
  self.session   = session
  self.timerUpdate  = eTimer()
  self.timerEndText  = eTimer()
  self.timerSubtLines  = eTimer()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  self.subtList   = []
  self.lastSubtInfo  = ""
  self.lastSubtFile  = ""
  self.lastSubtEnc  = ""
  self.settingShown  = False
  self.CursorPos   = 0
  self.Title    = "Subtitle Settings"
  self.diac    = u"\u0610\u0611\u0612\u0613\u0614\u0615\u0616\u0617\u0618\u0619\u061a\u064b\u064c\u064d\u064e\u064f\u0650\u0651\u0652\u0653\u0654\u0655\u0656\u0657\u0658\u0659\u065a\u065b\u065c\u065d\u065e\u0670\u06d6\u06d7\u06d8\u06d9\u06da\u06db\u06dc\u06df\u06e0\u06e1\u06e2\u06e3\u06e4\u06e7\u06e8\u06ea\u06eb\u06ec\u06ed"
  FF32Yx(self, title="%s%s%s" % (self.Title, " " * 10, FFCzRx("Change values with Up , Down, < , 0 , >", VVzv5p)))
  self["mySubtCover"] = Label()
  self.ctrlBtns = ("keyRed", "keyGreen", "keyYellow", "keyBlue")
  subj = ("Reset All", "Save", "Reset Delay", "Pick Line")
  for i, name in enumerate(self.ctrlBtns):
   self[name] = Label(subj[i])
  self["mySubtCursor"] = Label()
  subj = ("Delay", "BG Trans %", "Text Color", "Text Font", "Text Size", "Alignment", "Shadow Color", "Shadow Size", "Posision")
  self.settingLabels = ["Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos"]
  self.settingLabels1 = list(self.settingLabels)
  for i, name in enumerate(self.settingLabels):
   self.settingLabels[i]  = "mySubt%s"   % name
   self.settingLabels1[i] = "mySubt%s1"  % name
   self[self.settingLabels[i]]  = Label(subj[i])
   self[self.settingLabels1[i]] = Label(subj[i])
  self["mySubtFr"] = Label()
  for i in range(3): self["mySubt%d"  % i] = Label()
  for i in range(4): self["mySubtSep%d" % i] = Label()
  self["myAction"] = ActionMap(VVjUqm,
  {
   "ok"  : self.VVthYm      ,
   "cancel" : self.VVmU2O      ,
   "info"  : self.VVGA2q    ,
   "red"  : self.VVl7JR  ,
   "green"  : self.VVVKdq   ,
   "yellow" : BF(self.VVOUnP, 0)  ,
   "blue"  : self.VVJb0p    ,
   "menu"  : self.VVMBrJ      ,
   "left"  : self.VVgzL2      ,
   "right"  : self.VVPVKV      ,
   "last"  : self.VVtB4U     ,
   "next"  : self.VVqHVE     ,
   "0"   : self.VVWGEA    ,
   "up"  : self.VVL9bj       ,
   "down"  : self.VVRnLl      ,
   "pageUp" : BF(self.VV1Fk2, True) ,
   "pageDown" : BF(self.VV1Fk2, False) ,
   "chanUp" : BF(self.VV1Fk2, True) ,
   "chanDown" : BF(self.VV1Fk2, False) ,
   "play"  : BF(self.VVcUwJ, "pause")  ,
   "pause"  : BF(self.VVcUwJ, "pause")  ,
   "playPause" : BF(self.VVcUwJ, "pause")  ,
   "stop"  : BF(self.VVcUwJ, "pause")  ,
   "audio"  : BF(self.VVcUwJ, "audio")  ,
   "subtitle" : BF(self.VVcUwJ, "subtitle") ,
   "rewind" : BF(self.VVcUwJ, "rewind" ) ,
   "forward" : BF(self.VVcUwJ, "forward" ) ,
   "rewindDm" : BF(self.VVcUwJ, "rewindDm") ,
   "forwardDm" : BF(self.VVcUwJ, "forwardDm")
  }, -1)
  self.VVkRdm()
  self.onShown.append(self.VVSDD3)
  self.onClose.append(self.VV7v4u)
 def VVkRdm(self):
  lst = []
  for fil in FFY7QR(resolveFilename(SCOPE_FONTS), "*.[tToO][tT][fF]"):
   name = os.path.splitext(os.path.basename(fil))[0]
   lst.append((fil, name))
  if lst:
   lst.sort(key=lambda x: x[1].lower())
   default = CFG.subtTextFont.default
   if default == VVSkqN:
    for path, name in lst:
     if "almateen" in name.lower():
      default = name
      break
   CFG.subtTextFont = ConfigSelection(default=default, choices=lst)
 def VVSDD3(self):
  self.onShown.remove(self.VVSDD3)
  FFieY3(self)
  FFDoNq(self)
  for i in range(3):
   self["mySubt%d" % i].hide()
  self.VVmPMI()
  self.VVHck6()
  self.VVYhsl()
 def VV7v4u(self):
  self.timerUpdate.stop()
  self.timerEndText.stop()
 def VVsqzR(self):
  self.settingShown = True
  for name in self.ctrlBtns: self[name].show()
  for name in self.settingLabels : self[name].show()
  for name in self.settingLabels1: self[name].show()
  for i in range(4): self["mySubtSep%d" % i].show()
  self["myTitle"].show()
  self["mySubtFr"].show()
  FFzBm8(self["myBody"], "#33002233")
  self["keyMenu"].show()
  self["keyInfo"].show()
  self["mySubtCover"].hide()
  self.VVwvYt()
 def VVmPMI(self):
  self.settingShown = False
  for name in self.ctrlBtns: self[name].hide()
  for name in self.settingLabels : self[name].hide()
  for name in self.settingLabels1: self[name].hide()
  for i in range(4): self["mySubtSep%d" % i].hide()
  self["myTitle"].hide()
  self["mySubtFr"].hide()
  FFzBm8(self["myBody"], "#ff000000")
  self["keyMenu"].hide()
  self["keyInfo"].hide()
  self["mySubtCover"].show()
 def VVthYm(self):
  if self.settingShown:
   confItem = self.VVRKmW()[self.CursorPos]
   title = self[self.settingLabels[self.CursorPos]].getText()
   lst = confItem.choices.choices
   VVMVqr = []
   if isinstance(lst[0], tuple): VVMVqr = [(x[1], x[0]) for x in lst]
   else      : VVMVqr = [(x, x) for x in lst]
   VVdtUh = FF7ARM(self, self.VVOt2u, VVMVqr=VVMVqr, width=700, title=title, VVZYdg="#33221111", VVcwfs="#33110011")
   VVdtUh.VVzELa(confItem.getText())
  else:
   self.close("subtExit")
 def VVOt2u(self, item=None):
  if item:
   self.VVRKmW()[self.CursorPos].setValue(item)
   self.VVwvYt()
   self.VVHck6()
   self.VVvAQJ(True)
 def VVmU2O(self):
  for confItem in self.VVRKmW():
   if confItem.isChanged():
    FFo4dm(self, BF(self.VVjqgm, cbFnc=self.VVu5fR), "Save Changes ?", callBack_No=self.VVNZcq, title=self.Title)
    break
  else:
   self.VVu5fR()
 def VVu5fR(self):
   if self.settingShown: self.VVmPMI()
   else    : self.close("subtExit")
 def VVMBrJ(self):
  if self.settingShown: self.VVmpa7()
  else    : self.VVsqzR()
 def VVgzL2(self): self.VVZrSj(-1)
 def VVPVKV(self): self.VVZrSj(1)
 def VVZrSj(self, pos):
  if self.settingShown:
   self.CursorPos += pos
   if   self.CursorPos > len(self.settingLabels) - 1: self.CursorPos = 0
   elif self.CursorPos < 0        : self.CursorPos = len(self.settingLabels) - 1
   inst = self[self.settingLabels[self.CursorPos]].instance
   left = inst.position().x() - 5
   inst = self["mySubtCursor"].instance
   inst.move(ePoint(left, int(inst.position().y())))
  else:
   posVal, durVal = self.VVU2sq()
   if pos == -1: ndx = self.VVy16m(posVal)
   else  : ndx = self.VVvHAI(posVal)
   if   ndx < 0      : FFycel(self, "Not found" , 500)
   elif ndx == 0      : FFycel(self, "First line", 500)
   elif ndx == len(self.subtList) - 1 : FFycel(self, "Last line" , 500)
   else:
    capNum, frmSec, toSec, subtLines = self.subtList[ndx]
    delay, color, allow = self.VVyZ1g(frmSec)
    if allow:
     self.VVOUnP(delay, True)
     self.VVvAQJ(force=True)
     CCt8ct(self.session, "Changed Delay to %d sec" % delay, timeout=500, fonSize=35)
    else:
     FFycel(self, "Delay out of range", 800)
 def VV1Fk2(self, isUp):
  self.close("subtZapUp" if isUp else "subtZapDn")
 def VVcUwJ(self, reason):
  if not self.settingShown:
   self.close(reason)
 def VVtB4U(self) : self.VVaWni(5)
 def VVqHVE(self) : self.VVaWni(6)
 def VVWGEA(self) : self.VVaWni(-1)
 def VVL9bj(self):
  if self.settingShown: self.VVaWni(1)
  else    : self.VV1Fk2(True)
 def VVRnLl(self):
  if self.settingShown: self.VVaWni(0)
  else    : self.VV1Fk2(False)
 def VVaWni(self, direction):
  if self.settingShown:
   confItem = self.VVRKmW()[self.CursorPos]
   if direction == -1:
    confItem.setValue(confItem.default)
   else:
    if direction in (0, 1) and confItem in (CFG.subtTextFg, CFG.subtTextFont, CFG.subtTextAlign, CFG.subtShadowColor, CFG.subtVerticalPos):
     direction = 0 if direction == 1 else 1
    confItem.handleKey(direction)
   if confItem is CFG.subtTextAlign:
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    for i in range(3):
     inst = self["mySubt%d" % i].instance
     w   = inst.calculateSize().width() + 50
     if   align == "0" : left = 0
     elif align == "2" : left = boxWidth - w
     else    : left = int((getDesktop(0).size().width() - w) / 2.0)
     inst.move(ePoint(left, int(inst.position().y())))
   self.VVwvYt()
   self.VVHck6()
   self.VVvAQJ(True)
 def VVRKmW(self):
  return (  CFG.subtDelaySec
    , CFG.subtBGTransp
    , CFG.subtTextFg
    , CFG.subtTextFont
    , CFG.subtTextSize
    , CFG.subtTextAlign
    , CFG.subtShadowColor
    , CFG.subtShadowSize
    , CFG.subtVerticalPos)
 def VVNZcq(self):
  for confItem in self.VVRKmW(): confItem.cancel()
  self.VVwvYt()
  self.VVHck6()
  self.VVmPMI()
 def VVl7JR(self):
  if self.settingShown:
   FFo4dm(self, self.VVigSV, "Reset Subtitle Settings to default ?", title=self.Title)
 def VVigSV(self):
  for confItem in self.VVRKmW(): confItem.setValue(confItem.default)
  self.VVjqgm()
  self.VVwvYt()
  self.VVHck6()
 def VVOUnP(self, delay, force=False):
  if self.settingShown or force:
   FF2tHk(CFG.subtDelaySec, delay)
   self.VVVv5O()
   self.VVwvYt()
   self.VVHck6()
   if self.settingShown:
    FFycel(self, 'Reset to "0"', 800, isGrn=True)
 def VVVKdq(self):
  if self.settingShown:
   self.VVjqgm()
   self.VVmPMI()
 def VVjqgm(self, cbFnc=None):
  for confItem in self.VVRKmW(): confItem.save()
  configfile.save()
  self.VVVv5O()
  FFycel(self, "Saved", 1000, isGrn=True)
  if cbFnc:
   cbFnc()
 def VVwvYt(self):
  cfgLst = self.VVRKmW()
  for i, name in enumerate(self.settingLabels1):
   self[name].setText(str(cfgLst[i].getText()))
 def VVHck6(self):
  path = CFG.subtTextFont.getValue()
  if fileExists(path):
   fnt = "AJP_Subtitle"
   FF51vv(path, fnt, isRepl=1)
  else:
   fnt = VVXtOH
  lineH = 0
  top = self["mySubt0"].instance.position().y()
  bg = int(FFpM97(CFG.subtBGTransp.getValue(), 0, 100, 0, 255))
  try:
   for i in range(3):
    obj = self["mySubt%d" % i]
    inst = obj.instance
    bodyFontSize = CFG.subtTextSize.getValue()
    if CFG.subtTextFg.getValue().startswith("#"):
     FFcdG1(obj, CFG.subtTextFg.getValue())
    inst.setFont(gFont(fnt, bodyFontSize))
    FFzBm8(obj, "#%0.2X000000" % bg)
    inst.setBorderColor(parseColor(CFG.subtShadowColor.getValue()))
    inst.setBorderWidth(int(CFG.subtShadowSize.getValue()))
    lineH = FFYyT1(bodyFontSize, 0.18)
    inst.resize(eSize(*(int(inst.size().width()), lineH)))
    if i > 0:
     inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
   for i in range(1, 4):
    inst = self["mySubtSep%d" % i].instance
    inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
  except:
   pass
  inst = self["mySubt2"].instance
  winH = inst.position().y() + inst.size().height() + 2
  winW = self.instance.size().width()
  self.instance.resize(eSize(*(int(winW), int(winH))))
  y = int(FFpM97(CFG.subtVerticalPos.getValue(), 0, 100, 0, FFM4r3()[1] - winH))
  self.instance.move(ePoint(int(self.instance.position().x()), y))
  FFRlMK(self, winW, winH)
 def VVGA2q(self):
  sp = "    "
  txt  = "%s\n"   % FFCzRx("Subtitle File:", VV61JF)
  txt += sp + "%s\n\n" % self.lastSubtFile
  txt += "%s\n"     % FFCzRx("Subtitle Settings:", VV61JF)
  txt += sp + "Encoding\t: %s\n" % (self.lastSubtEnc or "Default")
  txt += sp + "Delay\t: %s sec\n" % CFG.subtDelaySec.getValue()
  if self.subtList:
   posVal, durVal = self.VVU2sq()
   capNum1, frmSec1, toSec1, subtLines1 = self.subtList[0]
   capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
   time1 = FFRTnP(frmSec1)
   time2 = FFRTnP(toSec2)
   txt += "\n"
   txt += "%s\n"       % FFCzRx("Timing:", VV61JF)
   txt += sp + "Captions\t: %s - %s\n"  % (capNum1, capNum2)
   txt += sp + "Subt. Time\t: %s - %s\n" % (time1, time2)
   txt += sp + "Event Dur.\t: %s\n"  % FFRTnP(durVal)
   txt += sp + "Progress\t: %s\n" % FFRTnP(posVal)
   if posVal > toSec2: txt += sp + "Remarks\t: %s\n" % FFCzRx("Subtitle end reached.", VVszO3)
  FFtybv(self, txt, title="Current Subtitle")
 def VVYhsl(self, path="", delay=0, enc=""):
  FFzW1w(self, BF(self.VVoI4P, path=path, delay=delay, enc=enc), "Checking Subtitle ...", clearMsg=False)
 def VVoI4P(self, path="", delay=0, enc=""):
  FFycel(self)
  try:
   self.timerUpdate.stop()
   if path:
    subtList, err = self.VVGNYd(path, enc=enc)
    if err    : self.close(err)
    elif not subtList : self.close("subtInval")
    else    :
     self.subtList = subtList
     CFG.subtDelaySec.setValue(int(delay))
     self.VVwvYt()
     self.VVooPB()
   else:
    path, delay, enc = CCyEAP.VVa82L(self)
    if path:
     self.VVYhsl(path=path, delay=delay, enc=enc)
    else:
     self.VVmpa7()
  except:
   pass
 def VVooPB(self):
  posVal, durVal = self.VVU2sq()
  if self.VVoJP6(posVal):
   return
  CCyEAP.VVU10z(None)
  try:
   self.timerUpdate_conn = self.timerUpdate.timeout.connect(self.VVvAQJ)
  except:
   self.timerUpdate.callback.append(self.VVvAQJ)
  self.timerUpdate.start(500, False)
  try:
   self.timerEndText_conn = self.timerEndText.timeout.connect(self.VVhB7O)
  except:
   self.timerEndText.callback.append(self.VVhB7O)
  FFycel(self, "Subtitle started", 700, isGrn=True)
 def VVoJP6(self, posVal):
  capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
  if posVal > toSec2:
   path = CCyEAP.VVwMtY(self)
   FFnPMX(path)
   self.close("subtEnd")
   return True
  else:
   return False
 def VVmpa7(self):
  c1, c2, c3, c4, c5 = "", VV61JF, VVYqlh, VVTKrH, VVszO3
  VVMVqr = []
  VVMVqr.append((c1 + "Find srt Files (in all directories)"  , "allSrt"  ))
  VVMVqr.append((c1 + "Find srt Files (in Current Directory)" , "curDirSrt" ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append((c2 + "Manual Search (with File Manager)"  , "fileMan"  ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append((c3 + "Suggest srt files (35% similar)"   , "sugSrt0.35" ))
  VVMVqr.append((c3 + "Suggest srt files (50% similar)"   , "sugSrt0.50" ))
  VVMVqr.append((c3 + "Suggest srt files (80% similar)"   , "sugSrt0.80" ))
  if self.settingShown:
   VVMVqr.append(VVpTvr)
   VVMVqr.append((c4 + "Change Subtitle File Encoding"  , "enc"   ))
   VVMVqr.append(VVpTvr)
   VVMVqr.append((c5 + "Disable Current Subtitle"   , "disab"  ))
   VVMVqr.append(VVpTvr)
   VVMVqr.append(("Help (Keys)"        , "help"  ))
  FF7ARM(self, self.VVRzbV, VVMVqr=VVMVqr, width=700, title='Find Subtitle ".srt" File', VVZYdg="#33221111", VVcwfs="#33110011")
 def VVRzbV(self, item=None):
  if item:
   if   item == "allSrt"   : self.VVeTxP(defSrt=self.lastSubtFile, mode=0)
   elif item == "curDirSrt"  : self.VVeTxP(defSrt=self.lastSubtFile, mode=1)
   elif item == "fileMan"   :
    sDir = "/"
    for path in (CFG.lastFileManFindSrt.getValue(), CFG.MovieDownloadPath.getValue(), "/media/usb/movie/", "/media/hdd/movie/", "/media/"):
     if pathExists(path):
      sDir = path
      break
    self.session.openWithCallback(self.VVOknk, BF(CCUGPF, patternMode="srt", VVRawy=sDir))
   elif item.startswith("sugSrt") : self.VVeTxP(defSrt=self.lastSubtFile, mode=2, coeff=float(item[6:]))
   elif item == "enc":
    if self.lastSubtFile and fileExists(self.lastSubtFile) : FFzW1w(self, BF(CCscRA.VVf3m2, self, self.lastSubtFile, self.VVIE7g, self.lastSubtEnc or CFG.subtDefaultEnc.getValue()), title="Loading Codecs ...")
    else             : FFycel(self, "SRT File error", 1000)
   elif item == "disab":
    FFnPMX(CCyEAP.VVwMtY(self))
    self.close("subtExit")
   elif item == "help"    : FFGkYk(self, "_help_subt", "Subtitle (Keys)")
  elif not self.settingShown:
   self.close("subtCancel")
 def VVIE7g(self, item=None):
  if item:
   FFzW1w(self, BF(self.VVYhsl, path=self.lastSubtFile, delay=CFG.subtDelaySec.getValue(), enc=item), title="Loading Subtitle ...")
 def VVOknk(self, path):
  if path:
   FF2tHk(CFG.lastFileManFindSrt, os.path.dirname(path))
   self.VVYhsl(path=path)
  elif not self.settingShown:
   self.close("subtCancel")
 def VVeTxP(self, defSrt="", mode=0, coeff=0.25):
  FFzW1w(self, BF(self.VV9B5J, defSrt, mode=mode, coeff=coeff), title="Searching for srt files")
 def VV9B5J(self, defSrt="", mode=0, coeff=0.25):
  if mode == 1:
   srtList = CCyEAP.VVsFsH(self)
   srtList.sort()
   title = "Subtitle Files (from Current Path)"
  else:
   srtList = FFSInC('find / %s \( -iname "*.srt" \) | grep -i "\.srt"' % (FFWdDQ(1)))
   if srtList:
    srtList.sort()
    if mode == 2:
     title = "Subtitle Files (with Similar Names)"
     srtList, err = self.VVscbs(srtList, coeff)
     if err:
      if self.settingShown: FFhcEU(self, err, 1500)
      else    : self.close(err)
      return
    else:
     title = "Subtitle Files (all srt files)"
  if srtList:
   VVpn2v = []
   curColor = "#f#0000FF00#"
   for path in srtList:
    fName, Dir = os.path.basename(path), FF5DjF(os.path.dirname(path))
    if defSrt == Dir + fName:
     fName, Dir = curColor + fName, curColor + Dir
    VVpn2v.append((fName, Dir))
   VVd479  = ("Select"    , self.VVgHeb     , [])
   VVNYAK = self.VVDOSS
   VV1Jd7 = (""     , self.VVHWG9       , [])
   VV4ePT = (""     , BF(self.VVWlYn, defSrt, False) , [])
   VVEXwE = ("Find Current File" , BF(self.VVWlYn, defSrt, True) , [])
   header   = ("File" , "Directory" )
   widths   = (60  , 40   )
   FFldB6(self, None, title=title, header=header, VVWsIU=VVpn2v, VVv3Wm=widths, VVHZHw=28, VVd479=VVd479, VVNYAK=VVNYAK, VV1Jd7=VV1Jd7, VV4ePT=VV4ePT, VVEXwE=VVEXwE, lastFindConfigObj=CFG.lastFindSubtitle
     , VVZYdg="#11002222", VVcwfs="#33001111", VVLuY4="#33001111", VVVU1s="#11ffff00", VVG27K="#11445544", VVQ9hc="#22222222", VVGpiI="#11002233")
  elif self.settingShown : FFhcEU(self, "Not found", 1500)
  else     : self.close("subtNoSrt")
 def VVDOSS(self, VVoLtS):
  VVoLtS.cancel()
  if not self.settingShown:
   self.close("subtCancel")
 def VVHWG9(self, VVoLtS, title, txt, colList):
  fName, Dir = colList
  FFtybv(VVoLtS, "%s\n\n%s%s" % (FFCzRx("Path:", VV61JF), Dir, fName), title=title)
 def VVWlYn(self, path, VVx3z3, VVoLtS, title, txt, colList):
  for ndx, row in enumerate(VVoLtS.VVGkEL()):
   if path == row[1].strip() + row[0].strip():
    VVoLtS.VV7qpv(ndx)
    break
  else:
   if VVx3z3:
    FFycel(VVoLtS, "Not in list !", 1000)
 def VVgHeb(self, VVoLtS, title, txt, colList):
  VVoLtS.cancel()
  path = "%s%s" % (colList[1].strip(), colList[0].strip())
  self.VVYhsl(path=path)
 def VVscbs(self, srtList, coeff):
  lst = []
  err = ""
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv and not serv.getPath():
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCL7is.VV5fo0(self)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFmvpz(self)
   evName = os.path.splitext(os.path.basename(chName))[0]
  if evName:
   if evName and CFG.epgLangTitle.getValue():
    CCL7is.VVBsQn(evName, "en")[0] or evName
   lst, err = CCyEAP.VVRbAY(evName, srtList, 50, coeff)
   if not err and not lst: err = "No Similar Names !"
  else:
   err = "No event Name !"
  return lst, err
 def VVGNYd(self, path, enc=None):
  if enc and CCscRA.VVnhog(path, enc)      : enc = enc
  elif CCscRA.VVnhog(path, CFG.subtDefaultEnc.getValue()): enc = CFG.subtDefaultEnc.getValue()
  else                   : enc = None
  if not fileExists(path):
   return [], "File not found"
  if (FFPLWs(path) > 1024 * 700):
   return [], "File too big"
  frmSec = toSec = bold = italic = under = 0
  capNum  = ""
  capFound = True
  color  = ""
  subtLines = []
  subtList = []
  lines  = FF2WPS(path, encLst=enc)
  lastNdx  = len(lines) - 1
  for ndx, line in enumerate(lines):
   line = str(line).strip()
   if line:
    if line.isdigit():
     capNum = line
    else:
     span = iSearch(r'(\d{2}:\d{2}:\d{2},\d{3})\s*\-->\s*(\d{2}:\d{2}:\d{2},\d{3})', line, IGNORECASE)
     if span:
      p  = list(map(int, span.group(1).replace(",", ":").split(":")))
      frmSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      p  = list(map(int, span.group(2).replace(",", ":").split(":")))
      toSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      subtLines = []
     else:
      span = iSearch(r'<font color="(.+)">(.+)', line, IGNORECASE)
      if span:
       color = self.VVcY1I(span.group(1))
       line = span.group(2)
      if "<b>" in line: bold = 1
      if "<i>" in line: italic = 1
      if "<u>" in line: under = 1
      line = line.replace("</font>", "").replace("</b>", "").replace("</i>", "").replace("</u>", "")
      line = line.replace("<b>", "").replace("<i>", "").replace("<u>", "")
      span = iSearch(r"{\\a\d}(.+)", line, IGNORECASE)
      if span:
       line = span.group(1)
      line = self.VVFxrt(line)
      subtLines.append((line.strip(), color, bold, italic, under))
      if ndx == lastNdx and subtList and (toSec - frmSec) > 0 and not subtList[len(subtList) - 1] == (capNum, frmSec, toSec, subtLines):
       subtList.append((capNum, frmSec, toSec, subtLines))
   else:
    if toSec > frmSec and subtLines:
     subtList.append((capNum, frmSec, toSec, subtLines))
    frmSec = toSec = bold = italic = under = 0
    capNum  = ""
    color  = ""
    subtLines = []
  if subtList:
   self.lastSubtFile = path
   self.lastSubtEnc  = enc
   self.VVVv5O()
  return subtList, ""
 def VVFxrt(self, line):
  line = line.replace(u"\u202A", "")
  line = line.replace(u"\u202B", "")
  line = line.replace(u"\u202C", "")
  for char in line:
   if 0x600 <= ord(char) <= 0x6FF and char in self.diac:
    line = line.replace(char, "")
  line = line.replace("\r", "..").replace("\n", "..")
  return str(line)
 def VVcY1I(self, color):
  lst = { "black": "#000000", "blue": "#0000ff", "brown":"#a52a2a", "cyan":"#00ffff", "darkblue": "#0000a0", "gray":"#808080", "green":"#008000", "grey": "#808080", "lightblue":"#add8E6", "lime":"#00ff00", "magenta":"#ff00ff", "maroon":"#800000", "olive":"#808000", "orange":"#ffa500", "purple":"#800080", "red":"#ff0000", "silver":"#c0c0c0", "white":"#ffffff", "yellow":"#ffff00"}
  code = lst.get(color.lower(), "")
  if code:
   return code
  else:
   span = iSearch(r"(#[A-Fa-f0-9]{6})", color, IGNORECASE)
   if span : return span.group(1)
   else : return ""
 def VVVv5O(self):
  path = CCyEAP.VVwMtY(self)
  if path:
   try:
    with open(path, "w") as f:
     f.write("srt=%s\n" % self.lastSubtFile)
     f.write("delay=%s\n" % CFG.subtDelaySec.getValue())
     if self.lastSubtEnc:
      f.write("enc=%s\n" % self.lastSubtEnc)
   except:
    pass
 def VVvAQJ(self, force=False):
  posVal, durVal = self.VVU2sq()
  if self.VVoJP6(posVal):
   return
  curIndex = self.VVNbsG(posVal)
  if curIndex < 0:
   return
  txtDur = 0
  if posVal:
   capNum, frmSec, toSec, subtLines = self.subtList[curIndex]
   if force or not self.lastSubtInfo == subtLines:
    self.lastSubtInfo = subtLines
    settingColor = ""
    if CFG.subtTextFg.getValue().startswith("#"):
     settingColor = CFG.subtTextFg.getValue()
    self.VVhB7O()
    subtLines = list(subtLines)
    l = len(subtLines)
    for i in range(3 - len(subtLines)):
     subtLines.insert(0, ("", "", 0, 0, 0))
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    txtDur = int(toSec * 1000 - frmSec * 1000)
    if txtDur > 0:
     for ndx, (line, color, bold, italic, under) in enumerate(subtLines):
      if line:
       if   bold   : newColor = "#aaffff"
       elif italic   : newColor = "#aaaaaa"
       elif under   : newColor = "#ffffaa"
       elif settingColor : newColor = settingColor
       elif color   : newColor = color
       else    : newColor = ""
       if ndx < 3:
        obj  = self["mySubt%d" % ndx]
        inst = obj.instance
        if newColor:
         FFcdG1(obj, newColor)
        obj.setText(line)
        obj.show()
        w   = inst.calculateSize().width() + 50
        inst.resize(eSize(*(w, inst.size().height())))
        if   align == "0" : left = 0
        elif align == "2" : left = boxWidth - w
        else    : left = int((getDesktop(0).size().width() - w) / 2.0)
        inst.move(ePoint(left, int(inst.position().y())))
    if txtDur > 0:
     self.timerEndText.start(txtDur, True)
 def VVU2sq(self):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCA3uT.VVsJTo(self)
  if not durVal and not posVal:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCL7is.VV5fo0(self)
   if evTime and evDur:
    posVal, durVal = iTime() - evTime, evDur
  return posVal, durVal
 def VVNbsG(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if posVal > frmSec and posVal < toSec:
     return ndx
  return -1
 def VVy16m(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if toSec > posVal:
     return ndx -1
  return -1
 def VVvHAI(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if frmSec > posVal:
     return ndx
  return -1
 def VVhB7O(self):
  for i in range(3):
   self["mySubt%d" % i].setText("")
   FFcdG1(self["mySubt%d" % i], "#00ffffff")
   self["mySubt%d" % i].hide()
 def VVJb0p(self):
  FFzW1w(self, self.VV5uO6, title="Loading Lines ...")
 def VV5uO6(self):
  VVpn2v = []
  for cap, frm, to, lines in self.subtList:
   firstLine = lines[0][0] if lines else ""
   VVpn2v.append((cap, FFRTnP(frm), str(frm), firstLine))
  if VVpn2v:
   title = "Select Current Subtitle Line"
   VVX8rQ  = self.VVt5Bd
   VVNYAK = self.VVjSyx
   VVd479  = ("Select"   , self.VVrmJT , [title])
   VVEXwE = ("Current Line" , self.VVrXkt , [True])
   VV7J8f = ("Reset Delay" , self.VVlWKg , [])
   VVJvWF = ("New Delay"  , self.VVNsGF   , [])
   header   = ("Cap" , "Time", "Time Val", "Subtitle Text" )
   widths   = (8  , 15 , 0    , 77    )
   VViqYN  = (CENTER , CENTER, CENTER , LEFT    )
   VVoLtS = FFldB6(self, None, title=title, header=header, VVWsIU=VVpn2v, VViqYN=VViqYN, VVv3Wm=widths, VVHZHw=28, VVX8rQ=VVX8rQ, VVNYAK=VVNYAK, VVd479=VVd479, VVEXwE=VVEXwE, VV7J8f=VV7J8f, VVJvWF=VVJvWF
          , VVZYdg="#33002222", VVcwfs="#33001111", VVLuY4="#33110011", VVVU1s="#11ffff00", VVG27K="#0a334455", VVQ9hc="#22222222", VVGpiI="#33002233")
  else:
   FFhcEU(self, "Cannot read lines !", 2000)
 def VVt5Bd(self, VVoLtS):
  self.subtLinesTable = VVoLtS
  if CFG.subtDelaySec.getValue():
   VVoLtS["keyYellow"].show()
   VVoLtS["keyYellow"].setText("Reset Delay (%s sec)" % CFG.subtDelaySec.getValue())
  else:
   VVoLtS["keyYellow"].hide()
  VVoLtS["keyBlue"].setText("New Delay: %s sec" % CFG.subtDelaySec.getValue())
  FFzBm8(VVoLtS["keyBlue"], "#22222222")
  VVoLtS.VVKoPU(BF(self.VVJUuC, VVoLtS))
  self.VVrXkt(VVoLtS, False)
  try:
   self.timerSubtLines_conn = self.timerSubtLines.timeout.connect(self.VVxtaJ)
  except:
   self.timerSubtLines.callback.append(self.VVxtaJ)
  self.timerSubtLines.start(1000, False)
 def VVjSyx(self, VVoLtS):
  self.timerSubtLines.stop()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  VVoLtS.cancel()
 def VVxtaJ(self):
  if self.subtLinesTable:
   VVoLtS = self.subtLinesTable
   posVal, durVal = self.VVU2sq()
   color = "#b#11551111#"
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVNbsG(posVal)
    if curIndex > -1:
     if self.subtLinesTableNdx > -1:
      row = VVoLtS.VVTQjx(self.subtLinesTableNdx)
      row[0] = row[0].replace(color, "")
      VVoLtS.VVzJT7(self.subtLinesTableNdx, row)
     row = VVoLtS.VVTQjx(curIndex)
     row[0] = color + row[0]
     VVoLtS.VVzJT7(curIndex, row)
     self.subtLinesTableNdx = curIndex
 def VVrmJT(self, VVoLtS, Title):
  delay, color, allow = self.VVLNYk(VVoLtS)
  if allow:
   self.VVjSyx(VVoLtS)
   self.VVOUnP(delay, True)
  else:
   FFycel(VVoLtS, "Delay out of range", 1500)
 def VVrXkt(self, VVoLtS, VVx3z3, onlyColor=False):
  if VVoLtS:
   posVal, durVal = self.VVU2sq()
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVNbsG(posVal)
    if curIndex > -1:
     VVoLtS.VV7qpv(curIndex)
    else:
     ndx = self.VVy16m(posVal)
     if ndx > -1:
      VVoLtS.VV7qpv(ndx)
 def VVlWKg(self, VVoLtS, title, txt, colList):
  if VVoLtS["keyYellow"].getVisible():
   self.VVOUnP(0, True)
   VVoLtS["keyYellow"].hide()
   self.VVrXkt(VVoLtS, False)
 def VVJUuC(self, VVoLtS):
  delay, color, allow = self.VVLNYk(VVoLtS)
  VVoLtS["keyBlue"].setText("%sNew Delay: %d sec" % (color, delay))
 def VVLNYk(self, VVoLtS):
  lineTime = float(VVoLtS.VVkHbA()[2].strip())
  return self.VVyZ1g(lineTime)
 def VVyZ1g(self, lineTime):
  posVal, durVal = self.VVU2sq()
  delay, color, allow = 0, "", False
  if posVal > 0:
   val = int(round(posVal - lineTime))
   if -600 <= val <= 600: allow, color = True , VVJS3b
   else     : allow, color = False, VVszO3
   delay = FFrrt7(val, -600, 600)
  return delay, color, allow
 def VVNsGF(self, VVoLtS, title, txt, colList):
  pass
 @staticmethod
 def VVRkFL(SELF):
  path, delay, enc = CCyEAP.VVa82L(SELF)
  return True if path else False
 @staticmethod
 def VVa82L(SELF):
  path, delay, enc = CCyEAP.VVrbDK(SELF)
  if not path:
   path = CCyEAP.VVnt4A(SELF)
  return path, delay, enc
 @staticmethod
 def VVrbDK(SELF):
  srtCfgPath = CCyEAP.VVwMtY(SELF)
  path = enc = ""
  delay = 0
  if srtCfgPath:
   if fileExists(srtCfgPath):
    lines = FF2WPS(srtCfgPath)
    for line in lines:
     line = line.strip()
     if   line.startswith("srt=") : path = line.split("=")[1].strip()
     elif line.startswith("delay=") : delay = line.split("=")[1].strip()
     elif line.startswith("enc=") : enc = line.split("=")[1].strip()
  if path and fileExists(path):
   try:
    delay = int(delay)
   except:
    pass
   return path, delay, enc
  else:
   return "", 0, ""
 @staticmethod
 def VVwMtY(SELF):
  fPath, fDir, fName = CCUGPF.VVKW1S(SELF)
  if not fPath:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCL7is.VV5fo0(SELF)
   if evName.strip() and evTime and evDur:
    fPath = "/tmp/" + evName[:30].strip()
  if not fPath:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFmvpz(SELF)
   if chName.strip():
    fPath = "/tmp/" + chName.strip()
  if fPath: return fPath + ".ajp"
  else : return ""
 @staticmethod
 def VVnt4A(SELF):
  bestRatio = 0
  fPath, fDir, fName = CCUGPF.VVKW1S(SELF)
  if fName:
   bestSrt = os.path.splitext(fPath)[0] + ".srt"
   if fileExists(bestSrt):
    return bestSrt
   else:
    movName = os.path.splitext(fName)[0]
    paths = CCyEAP.VVsFsH(SELF)
    bLst, err = CCyEAP.VVRbAY(movName, paths, 1, 0.3)
    if bLst:
     return bLst[0]
  return ""
 @staticmethod
 def VVsFsH(SELF):
  fPath, fDir, fName = CCUGPF.VVKW1S(SELF)
  if pathExists(fDir):
   files = FFY7QR(fDir, "*.srt")
   if files:
    return files
  return []
 @staticmethod
 def VVRbAY(word, paths, n=-1, cutoff=0.3):
  lst  = []
  if paths:
   try:
    from difflib import get_close_matches as iClosest
   except:
    return lst, 'Missing "difflib" library'
   if n == -1:
    n = len(paths)
   files = []
   cleanLst = ("25r", "colored", "srt", "REMUX", "AVC", "DTS", "MA", "utf8", "WEB", "DL", "NF", "EVO", "HD", "4k", "8k", "DDP5", "POWER", "WEBRip", "HDRip", "BRRip", "XviD", "HEVC", "Netflix", "MULTISUB", "MULTI", "SUB", "BluRay", "BlueRay", "BrRip", "YIFY", "YTS", "AM", "MX", "HDR", "AAC5", "mora", "AR", "EN", "English", "ARABIC")
   for ndx, p in enumerate(paths):
    fWords = os.path.splitext(os.path.basename(p))[0]
    fWords = iSub(r"([\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7e]+)", ".", fWords)  + "."
    fWords = iSub(r"\.\d{4}\."   , ".", fWords)
    fWords = iSub(r"\.\d{3,4}(p|P)\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]\d{3}\." , ".", fWords)
    fWords = iSub(r"\.\d{1,3}bit[s]?\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]{1,3}\d\.", ".", fWords)
    for txt in cleanLst: fWords = iSub(r"\.%s\." % txt, ".", fWords, flags=IGNORECASE)
    while ".." in fWords: fWords = fWords.replace("..", ".")
    fWords = fWords.replace(".", " ").strip()
    files.append("%d,%s" % (ndx, fWords))
   bLst = iClosest(word, files, n=n, cutoff=cutoff)
   if bLst:
    for item in bLst:
     ndx, fName = item.split(",", 1)
     lst.append(paths[int(ndx)])
  return lst, ""
 @staticmethod
 def VVzTN8():
  try:
   return InfoBar.instance.selected_subtitle
  except:
   try:
    return InfoBar.instance.__selected_subtitle
   except:
    return None
 @staticmethod
 def VVU10z(subt):
  if subt and isinstance(subt, tuple) and len(subt) >= 4 : state = True
  else             : subt, state = None, False
  try:
   InfoBar.instance.enableSubtitle(subt)
  except:
   try:
    if state:
     InfoBar.instance.__selected_subtitle = subt
    InfoBar.instance.setSubtitlesEnable(state)
   except:
    pass
  CCyEAP.VVHOtK()
 @staticmethod
 def VVHOtK():
  try:
   if config.subtitles.show.value : InfoBar.instance.subtitle_window.show()
   else       : InfoBar.instance.subtitle_window.hide()
  except:
   pass
class CCLLRm(ScrollLabel):
 def __init__(self, parentSELF, text="", VV1Ku8=True):
  ScrollLabel.__init__(self, text)
  self.VV1Ku8   = VV1Ku8
  self.long_text    = None
  self.scrollbar    = None
  self.message    = text
  self.instance    = None
  self.VVnxUj  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.pageLines    = 0
  self.column     = 0
  self.outputFileToSave  = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.fontFamily    = None
  self.VVHZHw    = None
  self.parentW    = None
  self.parentH    = None
  self.wrapEnabled   = True
  parentSELF["keyRedTop"]  = Label("Menu")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["myAction"]  = ActionMap(VVjUqm,
  {
   "ok"   : parentSELF.close  ,
   "cancel"  : parentSELF.close  ,
   "menu"   : self.VVwp8z ,
   "green"   : self.VV85M3 ,
   "yellow"  : self.VVICds ,
   "blue"   : self.VV6NOE ,
   "up"   : self.VVV1Tm   ,
   "down"   : self.VVKdZC  ,
   "left"   : self.VVV1Tm   ,
   "right"   : self.VVKdZC  ,
   "last"   : BF(self.VV01O2, 0) ,
   "0"    : BF(self.VV01O2, 1) ,
   "next"   : BF(self.VV01O2, 2) ,
   "pageUp"  : self.VVHtAW   ,
   "chanUp"  : self.VVHtAW   ,
   "pageDown"  : self.VVCPU4   ,
   "chanDown"  : self.VVCPU4
  }, -1)
 def VVqlfR(self, isResizable=True, VVoDLt=False, outputFileToSave=""):
  self.outputFileToSave = outputFileToSave
  FFcdG1(self.parentSELF["keyRedTop"], "#0055FF55" if outputFileToSave else "#00FFFFFF" )
  FFzBm8(self.parentSELF["keyRedTop"], "#113A5365")
  FFieY3(self.parentSELF, True)
  self.isResizable = isResizable
  if VVoDLt:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVHZHw  = font.pointSize
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFzBm8(self, color)
 def VVCZfE(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def applySkin(self, desktop, parent):
  import skin
  from enigma import eLabel, eSlider
  self.long_text = eLabel(self.instance)
  self.scrollbar = eSlider(self.instance)
  skin.applyAllAttributes(self.long_text, desktop, self.skinAttributes, parent.scale)
  self.pageWidth = self.long_text.size().width()
  VVjcdW  = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont())) or 30
  self.pageLines = int(self.long_text.size().height() / VVjcdW)
  margin   = int(VVjcdW / 6)
  self.pageHeight = int(self.pageLines * VVjcdW)
  self.instance.move(self.long_text.position())
  self.instance.resize(eSize(self.pageWidth, self.pageHeight + margin))
  w = 20
  self.scrollbar.move(ePoint(self.pageWidth - w, 0))
  self.scrollbar.resize(eSize(w, self.pageHeight + margin))
  self.scrollbar.setOrientation(eSlider.orVertical)
  self.scrollbar.setRange(0, 100)
  self.scrollbar.setBorderWidth(1)
  return True
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVnxUj - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VV8xNW()
 def VVV1Tm(self):
  if self.VVnxUj > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def VVKdZC(self):
  if self.VVnxUj > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVHtAW(self):
  self.setPos(0)
 def VVCPU4(self):
  self.setPos(self.VVnxUj-self.pageHeight)
 def VVnvOv(self):
  return self.VVnxUj <= self.pageHeight or self.curPos == self.VVnxUj - self.pageHeight
 def getText(self):
  return self.message
 def VV8xNW(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVnxUj, 3))
   start = int((100 - vis) * self.curPos / (self.VVnxUj - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def setText(self, text, VVr0Wh=VVdcIX):
  old_VVnvOv = self.VVnvOv()
  self.message = str(text)
  if self.pageHeight:
   if len(self.message.splitlines()) < self.pageLines - 2:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.message = self.message.rstrip() + "\n"
   self.long_text.setText(self.message)
   self.VVnxUj = self.long_text.calculateSize().height()
   if self.VV1Ku8 and self.VVnxUj > self.pageHeight:
    self.scrollbar.show()
    self.VV8xNW()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
    pageWidth  = self.instance.size().width() - w
    self.long_text.resize(eSize(pageWidth, self.VVnxUj))
    self.VVnxUj = self.long_text.calculateSize().height()
    self.long_text.resize(eSize(pageWidth, self.VVnxUj))
   else:
    self.scrollbar.hide()
   if   VVr0Wh == VVnCos: self.setPos(0)
   elif VVr0Wh == VVkqNa : self.VVCPU4()
   elif old_VVnvOv    : self.VVCPU4()
 def appendText(self, text, VVr0Wh=VVkqNa):
  self.setText(self.message + str(text), VVr0Wh=VVr0Wh)
 def VVICds(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VV3YcW(size)
 def VV6NOE(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VV3YcW(size)
 def VV85M3(self):
  self.VV3YcW(self.VVHZHw)
 def VV3YcW(self, VVHZHw):
  self.long_text.setFont(gFont(self.fontFamily, VVHZHw))
  self.setText(self.message, VVr0Wh=VVdcIX)
  self.VVteSG()
 def VV01O2(self, align):
  self.long_text.setHAlign(align)
 def VVwp8z(self):
  VVMVqr = []
  VVMVqr.append(("%s Wrapping" % ("Disable" if self.wrapEnabled else "Enable"), "wrap" ))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Align Left" , "left" ))
  VVMVqr.append(("Align Center" , "center" ))
  VVMVqr.append(("Align Right" , "right" ))
  if self.outputFileToSave:
   VVMVqr.append(VVpTvr)
   VVMVqr.append((FFCzRx("Save to File", VV61JF), "save"))
  VVMVqr.append(VVpTvr)
  VVMVqr.append(("Keys (Shortcuts)", "help"))
  FF7ARM(self.parentSELF, self.VVA66Z, VVMVqr=VVMVqr, title="Text Option", width=500)
 def VVA66Z(self, item=None):
  if item:
   if item == "wrap"  :
    self.wrapEnabled = not self.wrapEnabled
    self.long_text.setNoWrap(not self.wrapEnabled)
   elif item == "left"  : self.VV01O2(0)
   elif item == "center" : self.VV01O2(1)
   elif item == "right" : self.VV01O2(2)
   elif item == "save"  : self.VVhx7x()
   elif item == "help"  : FFGkYk(self.parentSELF, "_help_txt", "Text Viewer (Keys)")
 def VVhx7x(self):
  title = "%s Log File" % self.outputFileToSave.capitalize()
  expPath = CFG.exportedTablesPath.getValue()
  try:
   outF = "%sAJPanel_log_%s_%s.txt" % (FF5DjF(expPath), self.outputFileToSave, FF4rM4())
   with open(outF, "w") as f:
    f.write(FFQdrB(self.message))
   FFuXZg(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
  except:
   FFzrXb(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVteSG(self, minHeight=0):
  if self.isResizable:
   VVjcdW = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont()))
   textH = min(self.pageHeight, VVjcdW * (len(self.message.splitlines()) + 1))
   if textH < self.pageHeight and self.VVnxUj < self.pageHeight:
    textH = max(textH, self.VVnxUj)
   self.resize(eSize(*(self.instance.size().width(), textH + 6)))
   diff = self.pageHeight - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   if minHeight > 0:
    newH = max(newH, minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, min(self.parentH, newH))))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
